<?php

/**
 *  with PHP.
 *
 * @author 不见桃花-博客 Team
 */
require '../function/c_system_base.php';
$zbp->Load();
ob_clean();

$zbp->ShowValidCode(GetVars('id', 'GET'), GetVars('time', 'GET'));
