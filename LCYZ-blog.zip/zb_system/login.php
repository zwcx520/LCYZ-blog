<?php

/**
 *  with PHP.
 *
 * @author 不见桃花-博客 Team
 */

require 'function/c_system_base.php';

$zbp->Load();
if ($zbp->CheckRights('admin')) {
    Redirect302('cmd.php?act=admin');
}
?><!DOCTYPE HTML>
<html lang="<?php echo $lang['lang_bcp47']; ?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="robots" content="none" />
    <meta name="viewport" content="width=device-width,viewport-fit=cover" />
    <meta name="generator" content="<?php echo $option['ZC_BLOG_PRODUCT_FULL']; ?>" />
    <meta name="renderer" content="webkit" />
    <link rel="stylesheet" href="css/admin.css?<?php echo $blogversion; ?>" type="text/css" media="screen" />
    <script src="script/jquery-latest.min.js?<?php echo $blogversion; ?>"></script>
    <script src="script/zblogphp.js?<?php echo $blogversion; ?>"></script>
    <script src="script/md5.js?<?php echo $blogversion; ?>"></script>
    <script src="script/c_admin_js_add.php?hash=<?php echo $zbp->html_js_hash; ?>&<?php echo $blogversion; ?>"></script>
    <title><?php echo $blogname . '-' . $lang['msg']['login']; ?></title>
<?php
HookFilterPlugin('Filter_Plugin_Login_Header');
?>
</head>
<body class="body-login">
<div class="bg">
<div id="wrapper">
  <div class="logo"><span><?php echo htmlspecialchars($blogname); ?></span></div>
  <div class="login">
    <form method="post" action="#">
    <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken('login', 'minute'); ?>">
    <dl>
      <dt></dt>
      <dd class="username"><label for="edtUserName"><?php echo $lang['msg']['username']; ?></label><input type="text" id="edtUserName" name="edtUserName" size="20" value="<?php echo GetVars('username', 'COOKIE'); ?>" tabindex="1" /></dd>

      <dd class="password"><label for="edtPassWord"><?php echo $lang['msg']['password']; ?></label><input type="password" id="edtPassWord" name="edtPassWord" size="20" tabindex="2" /></dd>


    </dl>
    <dl>
      <dt></dt>
      <dd class="checkbox"><input type="checkbox" name="chkRemember" id="chkRemember"  tabindex="98" /><label for="chkRemember"><?php echo $lang['msg']['stay_signed_in']; ?></label></dd>
      <dd class="submit"><input id="btnPost" name="btnPost" type="submit" value="<?php echo $lang['msg']['login']; ?>" class="button" tabindex="99"/></dd>
    </dl>
    <input type="hidden" name="username" id="username" value="" />
    <input type="hidden" name="password" id="password" value="" />
    <input type="hidden" name="savedate" id="savedate" value="1" />
    </form>
  </div>
</div>
</div>
<script>
$("#btnPost").click(function(){

    var strUserName=$("#edtUserName").val();
    var strPassWord=$("#edtPassWord").val();
    var strSaveDate=$("#savedate").val()

    if (strUserName=== "" || strPassWord === ""){
        alert("<?php echo $lang['error']['66']; ?>");
        return false;
    }

    $("form").attr("action","cmd.php?act=verify");
    $("#edtUserName").val("");
    $("#edtPassWord").val("");
    $("#username").val(strUserName);
    $("#password").val(MD5(strPassWord));
    $("#savedate").val(strSaveDate);
})

$("#chkRemember").click(function(){
    $("#savedate").attr("value", $("#chkRemember").prop("checked") == true ? 30 : 1);
})

</script>
</body>
</html>
<?php
RunTime();

