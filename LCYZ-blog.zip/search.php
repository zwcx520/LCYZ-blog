<?php

/**
 *  with PHP.
 *
 * @author 不见桃花-博客 Team
 * @version
 */
require 'zb_system/function/c_system_base.php';

$zbp->action = 'search';
$zbp->Load();

HookFilterPlugin('Filter_Plugin_Search_Begin');

ViewIndex();

HookFilterPlugin('Filter_Plugin_Search_End');
