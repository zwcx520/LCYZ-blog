<?php
require dirname(__FILE__) . DIRECTORY_SEPARATOR . 'function/event.php';
#注册插件
RegisterPlugin("Jz52_fthree","ActivePlugin_Jz52_fthree");

function ActivePlugin_Jz52_fthree() {
	global $zbp;   
	Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu','Jz52_fthree_AddMenu');
	if ($zbp->Config('Jz52_fthree')->nseo&&$zbp->Config('Jz52_fthree')->seo){
	Add_Filter_Plugin('Filter_Plugin_Edit_Response5', 'Jz52_fthree_Filter_Plugin_Edit_Response5');
	Add_Filter_Plugin('Filter_Plugin_Category_Edit_Response', 'Jz52_fthree_Category_Edit_Response');
	}

	Add_Filter_Plugin('Filter_Plugin_Misc_Begin', 'Jz52_fthree_Event_CreateModule');
	Add_Filter_Plugin('Filter_Plugin_PostModule_Succeed', 'Jz52_fthree_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostComment_Succeed', 'Jz52_fthree_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostComment_Del', 'Jz52_fthree_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostArticle_Succeed', 'Jz52_fthree_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostArticle_Del', 'Jz52_fthree_Event_CreateModule');
}

function Jz52_fthree_AddMenu(&$m) {     	 			 	
	global $zbp;    		  	 		
	$m[] = MakeTopMenu("root", '主题配置', $zbp->host . "zb_users/theme/Jz52_fthree/admin/config.php", "", "topmenu_Jz52_fthree", "icon-x-diamond-fill");     	      
}   
	 			   
function Jz52_fthree_SubMenu( $id ) {    							 
	$arySubMenu = array(    	    	 	
		1 => array( '基本配置', 'config', 'left', false ),
		2 => array( 'SEO设置', 'seo', 'left', false ),
		3 => array( '侧栏及内页设置', 'celan', 'left', false ),
		4 => array( '帮助', 'help', 'left', false ),
	);    		 	  		
	foreach ( $arySubMenu as $k => $v ) {    			     
		echo '<a href="' . $v[ 1 ] . '.php" ' . ( $v[ 3 ] == true ? 'target="_blank"' : '' ) . '><span class="m-' . $v[ 2 ] . ' ' . ( $id == $k ? 'm-now' : '' ) . '">' . $v[ 0 ] . '</span></a>';    						  
	}     	      
} 

function Jz52_fthree_Category_Edit_Response() {
		global $zbp, $cate;
		echo '<p><span class="title">标题:(主题自带seo功能)</span><br /><input style="width:95%" name="meta_flbt" value="' . $cate->Metas->flbt . '"/></p><p><span class="title">关键词:(主题自带seo功能)</span><br /><input style="width:95%" name="meta_flgjc" value="' . $cate->Metas->flgjc . '"/></p>';
}

function Jz52_fthree_Filter_Plugin_Edit_Response5() {
		global $zbp, $article;
		echo '<table width="99%"><tr><td width="20%">关键词(主题自带seo)</td><td width="80%"><input style="width:95%" name="meta_nrgjc" value="' . $article->Metas->nrgjc . '"/></td></tr><tr><td>描述(主题自带seo)</td><td><input style="width:95%" name="meta_nrms" value="' . $article->Metas->nrms . '"/></td></tr></table>';
}

function Jz52_fthree_IMGC( $article, $w=400, $h=300, $c=false) {
  global $zbp;

	  if ( $zbp->Config( 'Jz52_fthree' )->thumb ) {
		$Thumb = $article->Thumbs( $w, $h, 1, $c);
		if ( isset( $Thumb[ 0 ] ) ) {
		  $img = $Thumb[0];
		} else {
		  if ( $article->ImageCount ) {
			$img = $article->AllImages[0];
		  }else{
			$img = Jz52_fthree_ranIMG($article->ID);
		  }
		}
	  } else {
		if ( $article->ImageCount ) {
		  $img = $article->AllImages[0];
		}else{
		  $img = Jz52_fthree_ranIMG($article->ID);
		}
	  }

  return $img;
}

function Jz52_fthree_ranIMG( $id=0 ) {
	global $zbp, $blogpath;

		$ran = $id % 6;
		$img = $zbp->host . 'zb_users/theme/Jz52_fthree/ran/' . $ran . '.jpg';

	  return $img;
}

function Jz52_fthree_mlnav(){     		 	 		
	global $zbp;  
	if(!isset($zbp->modulesbyfilename['jz52fthree-mnav']))
	{
		$mod = $zbp->modulesbyfilename["catalog"];
		$mod->Name = "三栏主题移动菜单";
		$mod->FileName = "jz52fthree-mnav"; 
		$mod->HtmlID = "jz52fthree-mNav";
		$mod->Type = "ul";
		$mod->Source = "plugin_LinksManage"; 
		$mod->ID = 0;
		$mod->Save();
	}
}
function Jz52_fthree_Footer(){     		 	 		
	global $zbp;      	   					 		  
	echo '<p>'.$zbp->option['ZC_BLOG_COPYRIGHT'];     		 	   
	if($zbp->Config('Jz52_fthree')->beian){      	  		 
	echo ' <a href="https://beian.miit.gov.cn/" target="_blank">'.$zbp->Config('Jz52_fthree')->beian.'</a></p>';  		   
	}        	   
	echo '<p>Powered: <a href="http://www.zblogcn.com/" target="_blank">Z-BlogPHP</a>';			  		
	echo ' Themes: <a href="https://app.zbp.cool/" title="隔壁老李" target="_blank">GebiLaoli</a>';       	    	      	
	echo '</p>';    	        	 		   	
} 
function InstallPlugin_Jz52_fthree(){
	global $zbp;
	if(!$zbp->HasConfig('Jz52_fthree')){
		$zbp->Config('Jz52_fthree')->Version = '1.0.0';
		$zbp->Config('Jz52_fthree')->logo = $zbp->host.'zb_users/theme/Jz52_fthree/images/logo.png';
		$zbp->Config('Jz52_fthree')->imglogo = '1';
        $zbp->Config('Jz52_fthree')->seotitle = '网站标题';
        $zbp->Config('Jz52_fthree')->seokeywords = '网站关键字,用英文的逗号隔开';
        $zbp->Config('Jz52_fthree')->seodescription = '用一段话描述你的网站';
		$zbp->Config('Jz52_fthree')->side_tui_list = '446,456,427';
		$zbp->Config('Jz52_fthree')->side_hot_cmt_day ='';
		$zbp->Config('Jz52_fthree')->side_hot_view_day ='';
		$zbp->Config('Jz52_fthree')->aboutimg = $zbp->host.'zb_users/theme/Jz52_fthree/images/about.jpg';
		$zbp->Config('Jz52_fthree')->about_avatar = $zbp->host.'zb_users/theme/Jz52_fthree/images/avater.png';
		$zbp->Config('Jz52_fthree')->about_tit ='隔壁老李';
		$zbp->Config('Jz52_fthree')->about_tittxt ='开车老司机 建站野路子';
		$zbp->Config('Jz52_fthree')->wximg = $zbp->host.'zb_users/theme/Jz52_fthree/images/wximg.png';
		$zbp->Config('Jz52_fthree')->wxtxt = '微信扫一扫关注站长';
		$zbp->Config('Jz52_fthree')->about_li = '<li><i class="gbllicon-home"></i>中国·山东</li>
<li><i class="gbllicon-phone"></i>13999999999</li>
<li><i class="gbllicon-mail-line"></i>mail@mail.com</li>';
		$zbp->Config('Jz52_fthree')->sns = '<a class="sns-icon qq" href="#" target="_blank" title="QQ"><i class="gbllicon-qq"></i></a>
<a class="sns-icon weixin sidebar-left-about-wexin" title="微信"><i class="gbllicon-weixin"></i></a>
<a class="sns-icon weibo" href="#" target="_blank" title="微博"><i class="gbllicon-weibo"></i></a>
<a class="sns-icon bilibili" href="#" target="_blank" title="小破站"><i class="gbllicon-bilibili"></i></a>
<a class="sns-icon douyin" href="#" target="_blank" title="抖音"><i class="gbllicon-douyin"></i></a>';
		$zbp->Config('Jz52_fthree')->zanshang = '0';
		$zbp->Config('Jz52_fthree')->zstxt = '感谢您对我的支持，多少都是您的心意！';
		$zbp->Config('Jz52_fthree')->zszfb =  $zbp->host.'zb_users/theme/Jz52_fthree/images/wximg.png';
		$zbp->Config('Jz52_fthree')->zswx =  $zbp->host.'zb_users/theme/Jz52_fthree/images/wximg.png';

		
		$zbp->SaveConfig('Jz52_fthree');
	}
	Jz52_fthree_Event_CreateModule();
	Jz52_fthree_mlnav();
}
function UninstallPlugin_Jz52_fthree(){
	global $zbp;
	if($zbp->Config('Jz52_fthree')->DelCon){
	$zbp->DelConfig('Jz52_fthree');	
	Jz52_fthree_Event_DelModule();
	}
}
?>