<?php
require '../../../../zb_system/function/c_system_base.php';     		 	 		
require $blogpath . 'zb_users/theme/Jz52_fthree/admin/Admin_header.php';     			 			
?>

<link rel="stylesheet" href="<?php echo $bloghost?>zb_users/theme/Jz52_fthree/style/css/style.css">

<div class="SubMenu">
  <?php Jz52_fthree_SubMenu(4);?>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc"><span class="m-right">更多应用</span></a>
  <a href="https://gebilaoli.com" target="_blank"><span class="m-right">作者网站</span></a></div>
<div id="divMain2">



<table name="form1" width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
	<tr>
          <th width="15%"><p align="center">名称</p></th>
          <th><p align="center">说明</p></th>
        </tr>
        <tr>
          <td><label for="side_tui_list">
            <p align="center">社交图标代码</p>
            </label></td>
          <td><p align="left">
              &lt;a class=&quot;sns-icon qq&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;QQ&quot;&gt;&lt;i class=&quot;gbllicon-qq&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon weixin sidebar-left-about-wexin&quot; title=&quot;微信&quot;&gt;&lt;i class=&quot;gbllicon-weixin&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon weibo&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;微博&quot;&gt;&lt;i class=&quot;gbllicon-weibo&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon bilibili&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;小破站&quot;&gt;&lt;i class=&quot;gbllicon-bilibili&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon zhihu&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;知乎&quot;&gt;&lt;i class=&quot;gbllicon-zhihu&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon kuaishou&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;快手&quot;&gt;&lt;i class=&quot;gbllicon-kuaishou&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon douyin&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;抖音&quot;&gt;&lt;i class=&quot;gbllicon-douyin&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon momo&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;陌陌&quot;&gt;&lt;i class=&quot;gbllicon-momo&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon rss&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;RSS&quot;&gt;&lt;i class=&quot;gbllicon-rss&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon github&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;github&quot;&gt;&lt;i class=&quot;gbllicon-github&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon twitter&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;twitter&quot;&gt;&lt;i class=&quot;gbllicon-twitter&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon facebook&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;facebook&quot;&gt;&lt;i class=&quot;gbllicon-facebook&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon instagram&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;instagram&quot;&gt;&lt;i class=&quot;gbllicon-instagram&quot;&gt;&lt;/i&gt;&lt;/a&gt;</br>&lt;a class=&quot;sns-icon pinterest&quot; href=&quot;#&quot; target=&quot;_blank&quot; title=&quot;pinterest&quot;&gt;&lt;i class=&quot;gbllicon-pinterest&quot;&gt;&lt;/i&gt;&lt;/a&gt;
            </p>
		 </td>
        </tr>
		<tr>
          <td><label for="side_tui_list">
            <p align="center">所有图标及类名</p>
            </label></td>
          <td><p align="left">
               <span> <span class="gbllicon-phone"></span> <span class="mls"> gbllicon-phone</span> </span> <span> <span class="gbllicon-kuaishou"></span> <span class="mls"> gbllicon-kuaishou</span> </span> <span> <span class="gbllicon-momo"></span> <span class="mls"> gbllicon-momo</span> </span> <span> <span class="gbllicon-douyin"></span> <span class="mls"> gbllicon-douyin</span> </span> <span> <span class="gbllicon-add"></span> <span class="mls"> gbllicon-add</span> </span> <span> <span class="gbllicon-alipay"></span> <span class="mls"> gbllicon-alipay</span> </span> <span> <span class="gbllicon-angle-left"></span> <span class="mls"> gbllicon-angle-left</span> </span> <span> <span class="gbllicon-angle-right"></span> <span class="mls"> gbllicon-angle-right</span> </span> <span> <span class="gbllicon-angle-up"></span> <span class="mls"> gbllicon-angle-up</span> </span> <span> <span class="gbllicon-bilibili"></span> <span class="mls"> gbllicon-bilibili</span> </span> <span> <span class="gbllicon-github"></span> <span class="mls"> gbllicon-github</span> </span> <span> <span class="gbllicon-pinterest"></span> <span class="mls"> gbllicon-pinterest</span> </span> <span> <span class="gbllicon-qq"></span> <span class="mls"> gbllicon-qq</span> </span> <span> <span class="gbllicon-rss"></span> <span class="mls"> gbllicon-rss</span> </span> <span> <span class="gbllicon-weibo"></span> <span class="mls"> gbllicon-weibo</span> </span> <span> <span class="gbllicon-weixin"></span> <span class="mls"> gbllicon-weixin</span> </span> <span> <span class="gbllicon-weixinzhifu"></span> <span class="mls"> gbllicon-weixinzhifu</span> </span> <span> <span class="gbllicon-zhihu"></span> <span class="mls"> gbllicon-zhihu</span> </span> <span> <span class="gbllicon-time"></span> <span class="mls"> gbllicon-time</span> </span> <span> <span class="gbllicon-settings"></span> <span class="mls"> gbllicon-settings</span> </span> <span> <span class="gbllicon-account"></span> <span class="mls"> gbllicon-account</span> </span> <span> <span class="gbllicon-file-list"></span> <span class="mls"> gbllicon-file-list</span> </span> <span> <span class="gbllicon-arrow-down"></span> <span class="mls"> gbllicon-arrow-down</span> </span> <span> <span class="gbllicon-home"></span> <span class="mls"> gbllicon-home</span> </span> <span> <span class="gbllicon-store"></span> <span class="mls"> gbllicon-store</span> </span> <span> <span class="gbllicon-tag-fill"></span> <span class="mls"> gbllicon-tag-fill</span> </span> <span> <span class="gbllicon-tag"></span> <span class="mls"> gbllicon-tag</span> </span> <span> <span class="gbllicon-message-fill"></span> <span class="mls"> gbllicon-message-fill</span> </span> <span> <span class="gbllicon-money-fill"></span> <span class="mls"> gbllicon-money-fill</span> </span> <span> <span class="gbllicon-article"></span> <span class="mls"> gbllicon-article</span> </span> <span> <span class="gbllicon-exchange"></span> <span class="mls"> gbllicon-exchange</span> </span> <span> <span class="gbllicon-account-circle"></span> <span class="mls"> gbllicon-account-circle</span> </span> <span> <span class="gbllicon-edit-box"></span> <span class="mls"> gbllicon-edit-box</span> </span> <span> <span class="gbllicon-archive-drawer"></span> <span class="mls"> gbllicon-archive-drawer</span> </span> <span> <span class="gbllicon-mail-line"></span> <span class="mls"> gbllicon-mail-line</span> </span> <span> <span class="gbllicon-twitter"></span> <span class="mls"> gbllicon-twitter</span> </span> <span> <span class="gbllicon-facebook"></span> <span class="mls"> gbllicon-facebook</span> </span> <span> <span class="gbllicon-instagram"></span> <span class="mls"> gbllicon-instagram</span> </span> <span> <span class="gbllicon-arrow-right"></span> <span class="mls"> gbllicon-arrow-right</span> </span> <span> <span class="gbllicon-close"></span> <span class="mls"> gbllicon-close</span> </span> <span> <span class="gbllicon-search"></span> <span class="mls"> gbllicon-search</span> </span> <span> <span class="gbllicon-chat"></span> <span class="mls"> gbllicon-chat</span> </span> <span> <span class="gbllicon-message"></span> <span class="mls"> gbllicon-message</span> </span> <span> <span class="gbllicon-eye"></span> <span class="mls"> gbllicon-eye</span> </span> <span> <span class="gbllicon-heart-line"></span> <span class="mls"> gbllicon-heart-line</span> </span> <span> <span class="gbllicon-thumb-up-fill"></span> <span class="mls"> gbllicon-thumb-up-fill</span> </span> <span> <span class="gbllicon-thumb-up-line"></span> <span class="mls"> gbllicon-thumb-up-line</span> </span> <span> <span class="gbllicon-menu"></span> <span class="mls"> gbllicon-menu</span> </span> <span> <span class="gbllicon-moon-line"></span> <span class="mls"> gbllicon-moon-line</span> </span> <span> <span class="gbllicon-moon-fill"></span> <span class="mls"> gbllicon-moon-fill</span> </span>
            </p>
		 </td>
        </tr>
		<tr>
          <td><label for="side_tui_list">
            <p align="center">如何显示点赞</p>
            </label></td>
          <td><p align="left">
               安装启用 <a href="https://app.zblogcn.com/?id=498" target="_blank">文章点赞开发版</a> 即可
            </p>
		 </td>
        </tr>
		<tr>
          <td><label for="side_tui_list">
            <p align="center">关于侧栏</p>
            </label></td>
          <td><p align="left">
               首页和文章列表使用侧栏1侧栏2，文章页和单页使用侧栏3侧栏4。
            </p>
		 </td>
        </tr>
</table>

  

  
</div>
</div>
<script type="text/javascript">
	ActiveTopMenu( "topmenu_Jz52_fthree" );
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';    			 	 	 
RunTime();    			  	 	
?>
