<?php			 
require '../../../../zb_system/function/c_system_base.php';        	 		
require $blogpath . 'zb_users/theme/Jz52_fthree/admin/Admin_header.php';    		 	  	 
?>
<div class="SubMenu">
  <?php Jz52_fthree_SubMenu(2);?>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc"><span class="m-right">更多应用</span></a>
  <a href="https://gebilaoli.com" target="_blank"><span class="m-right">作者网站</span></a></div>
<div id="divMain2">
  <?php
	if ($_POST){
    CheckIsRefererValid();
    foreach ($_POST as $k => $v){    				    
        if ($k == 'csrfToken') continue;     	 		   
        $zbp->Config('Jz52_fthree')->$k = $v;      	 	  	
    }
    $zbp->SaveConfig('Jz52_fthree');  
    $zbp->SetHint('good');
    redirect(GetVars('HTTP_REFERER','SERVER'));
	}      					  	
?>

<form id="form2" name="form2" method="post">
  <table width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
    <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken();?>">
    <tr>
      <th width="15%"><p align="center">选项名称</p></th>
      <th width="50%"><p align="center">选项内容</p></th>
      <th width="25%"><p align="center">选项说明</p></th>
    </tr>
    <tr>
      <td><label for="seo">
        <p align="center">主题SEO设置</p>
        </label></td>
      <td><p align="left"><input type="text" id="seo" name="seo" class="checkbox" value="<?php echo $zbp->Config('Jz52_fthree')->seo;?>"/></p></td>
      <td><p align="left">选择是否使用主题自带SEO设置，如使用了SEO插件需要关闭</p></td>
    </tr>
    <tr>
      <td><label for="seotitle">
        <p align="center">站点标题</p>
        </label></td>
      <td><p align="left"><input type="text" name="seotitle" id="seotitle" style="width:80%;" value="<?php echo $zbp->Config('Jz52_fthree')->seotitle;?>"/><?php  if($zbp->subname){echo ' - ' .$zbp->subname;} ?></p></td>
      <td><p align="left">自定义网站首页标题，副标题在网站设置中设置，留空则不显示</p></td>
    </tr>
    <tr>
      <td><label for="seokeywords">
        <p align="center">关键词</p>
        </label></td>
      <td><p align="left"><input type="text" name="seokeywords" id="seokeywords" style="width:98%;" value="<?php echo $zbp->Config('Jz52_fthree')->seokeywords;?>"/></p></td>
      <td><p align="left">自定义网站关键词，多个关键词用英文逗号隔开</p></td>
    </tr>
    <tr>
      <td><label for="seodescription">
        <p align="center">网站描述</p>
        </label></td>
      <td><p align="left">
          <textarea name="seodescription" type="text" id="seodescription" style="width:98%;"><?php echo $zbp->Config('Jz52_fthree')->seodescription;?></textarea>
        </p></td>
      <td><p align="left">自定义网站描述</p></td>
    </tr>
	<tr>
      <td><label for="nseo">
        <p align="center">内页SEO</p>
        </label></td>
      <td><p align="left"><input type="text" id="nseo" name="nseo" class="checkbox" value="<?php echo $zbp->Config('Jz52_fthree')->nseo;?>"/></p></td>
      <td><p align="left">开启后列表、文章等页面可以自定一关键词，标题、描述等。</p></td>
    </tr>
  </table>
  <br />
  <input name="submit" type="Submit" class="button" style="width:15%;" value="保存"/>
</form>

</div>
</div>
<script type="text/javascript">
	ActiveTopMenu( "topmenu_Jz52_fthree" );
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';     				 		
RunTime();      		  		
?>
