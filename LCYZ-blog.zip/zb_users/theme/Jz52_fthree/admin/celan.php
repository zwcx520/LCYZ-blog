<?php
require '../../../../zb_system/function/c_system_base.php';      	  			
require $blogpath . 'zb_users/theme/Jz52_fthree/admin/Admin_header.php';    	  	   	
?>
<div class="SubMenu">
  <?php Jz52_fthree_SubMenu(3);?>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc"><span class="m-right">更多应用</span></a>
  <a href="https://gebilaoli.com" target="_blank"><span class="m-right">作者网站</span></a></div>
<div id="divMain2">
  <?php
	if ($_POST){
    CheckIsRefererValid();
    foreach ($_POST as $k => $v){    				    
        if ($k == 'csrfToken') continue;     	 		   
        $zbp->Config('Jz52_fthree')->$k = $v;      	 	  	
    }
    $zbp->SaveConfig('Jz52_fthree');  
	Jz52_fthree_Event_CreateModule();
    $zbp->SetHint('good');
    redirect(GetVars('HTTP_REFERER','SERVER'));
	}     		   
?>
 <form id="form3" name="form3" method="post">
      <table width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
        <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken();?>">
        <tr>
          <th width="15%"><p align="center">选项名称</p></th>
          <th width="50%"><p align="center">选项内容</p></th>
          <th width="25%"><p align="center">选项说明</p></th>
        </tr>
        <tr>
          <td><label for="side_tui_list">
            <p align="center">推荐文章</p>
            </label></td>
          <td><p align="left">
              <input type="text" name="side_tui_list" id="side_tui_list" style="width:98%;" value="<?php echo $zbp->Config('Jz52_fthree')->side_tui_list;?>"/>
            </p></td>
          <td><p align="left">输入文章ID，以 , 间隔</p></td>
        </tr>
        <tr>
          <td><label for="side_hot_view_day">
            <p align="center">热门文章时间</p>
            </label></td>
          <td><p align="left">
              <input type="text" name="side_hot_view_day" id="side_hot_view_day" style="width:98%;" value="<?php echo $zbp->Config('Jz52_fthree')->side_hot_view_day;?>"/>
            </p></td>
          <td><p align="left">按照天数计算，请输入时间天数范围的正整数</p></td>
        </tr>
        <tr>
          <td><label for="side_hot_cmt_day">
            <p align="center">热评文章时间</p>
            </label></td>
          <td><p align="left">
              <input type="text" name="side_hot_cmt_day" id="side_hot_cmt_day" style="width:98%;" value="<?php echo $zbp->Config('Jz52_fthree')->side_hot_cmt_day;?>"/>
            </p></td>
          <td><p align="left">按照天数计算，请输入时间天数范围的正整数</p></td>
        </tr>
		<tr>
          <td><p align="center">关于我们选项卡头图</p></td>
          <td><p><img src="<?php echo $zbp->Config('Jz52_fthree')->aboutimg;?>" alt="aboutimg" style = "height:40px;"/></p>
            <p class="uploadimg">
              <input name="aboutimg" id="aboutimg" type="text" class="uplod_img" style="width:68%;" value="<?php echo $zbp->Config('Jz52_fthree')->aboutimg;?>" />
              <strong>浏览文件</strong> </p></td>
          <td><p align="left">侧栏关于我们选项卡的顶部背景</p></td>
        </tr>
		<tr>
          <td><p align="center">关于我们选项卡头像</p></td>
          <td><p><img src="<?php echo $zbp->Config('Jz52_fthree')->about_avatar;?>" alt="about_avatar" style = "height:40px;"/></p>
            <p class="uploadimg">
              <input name="about_avatar" id="about_avatar" type="text" class="uplod_img" style="width:68%;" value="<?php echo $zbp->Config('Jz52_fthree')->about_avatar;?>" />
              <strong>浏览文件</strong> </p></td>
          <td><p align="left">侧栏关于我们选项卡的头像</p></td>
        </tr>
		<tr>
          <td><p align="center">关于我们标题</p></td>
          <td><p align="left">
              <input type="text" name="about_tit" id="about_tit" style="width:98%;" value="<?php echo $zbp->Config('Jz52_fthree')->about_tit;?>"/>
            </p></td>
          <td><p align="left">侧栏关于我们选项卡的标题</p></td>
        </tr>
		<tr>
          <td><p align="center">关于我们详情</p></td>
          <td><p align="left">
			   <textarea name="about_tittxt" type="text" id="about_tittxt" style="width:98%;"><?php echo $zbp->Config('Jz52_fthree')->about_tittxt;?></textarea>
            </p></td>
          <td><p align="left">侧栏关于我们选项卡的详情</p></td>
        </tr>
		<tr>
          <td><p align="center">中间代码</p></td>
          <td><p align="left">
			   <textarea name="about_li" rows="6" type="text" id="about_li" style="width:98%;"><?php echo $zbp->Config('Jz52_fthree')->about_li;?></textarea>
            </p></td>
          <td><p align="left">侧栏关于我们中间代码</p></td>
        </tr>
		<tr>
          <td width="20%"  align="center"><p>微信二维码</p></td>
          <td><p><img src="<?php echo $zbp->Config('Jz52_fthree')->wximg;?>" alt="wximg" style = "height:40px;"/></p>
            <p class="uploadimg">
              <input name="wximg" id="wximg" type="text" class="uplod_img" style="width:68%;" value="<?php echo $zbp->Config('Jz52_fthree')->wximg;?>" />
              <strong>浏览文件</strong> </p></td>
          <td><p align="left">微信二维码地址</p></td>
        </tr>
		<tr>
          <td width="20%"  align="center"><p>微信二维码显示文字</p></td>
          <td><p>
              <input type="text" name="wxtxt" id="wxtxt" style="width:98%;" value="<?php echo $zbp->Config('Jz52_fthree')->wxtxt;?>"/>
            </p></td>
          <td><p align="left">微信二维码显示文字</p></td>
        </tr>
		<tr>
        <td>
        <p align="center">社交图标代码</p>
        </label></td>
        <td width="20%" ><p align="left">
          <textarea name="sns"  rows="12" type="text" id="sns" style="width:98%;"><?php echo $zbp->Config('Jz52_fthree')->sns;?></textarea>
        </p></td>
       <td><p align="left">社交图标代码，不超过6个，代码样式详见帮助</p></td>
       </tr>
		<tr>
          <td><p align="center">显示赞赏</p>
            </td>
          <td><p align="left">
              <input type="text" id="zanshang" name="zanshang" class="checkbox" value="<?php echo $zbp->Config('Jz52_fthree')->zanshang;?>"/>
            </p></td>
          <td><p align="left">文章赞赏</p></td>
        </tr>
		<tr>
          <td width="20%"  align="center"><p>赞赏显示文字</p></td>
          <td><p>
              <input type="text" name="zstxt" id="zstxt" style="width:98%;" value="<?php echo $zbp->Config('Jz52_fthree')->zstxt;?>"/>
            </p></td>
          <td><p align="left">赞赏显示文字</p></td>
        </tr>
		<tr>
          <td><p align="center">支付宝收钱码</p></td>
          <td><p><img src="<?php echo $zbp->Config('Jz52_fthree')->zszfb;?>" alt="zszfb" style = "height:40px;"/></p>
            <p class="uploadimg">
              <input name="zszfb" id="zszfb" type="text" class="uplod_img" style="width:68%;" value="<?php echo $zbp->Config('Jz52_fthree')->zszfb;?>" />
              <strong>浏览文件</strong> </p></td>
          <td><p align="left">支付宝收钱码</p></td>
        </tr>
		<tr>
          <td><p align="center">微信收款码</p></td>
          <td><p><img src="<?php echo $zbp->Config('Jz52_fthree')->zswx;?>" alt="zswx" style = "height:40px;"/></p>
            <p class="uploadimg">
              <input name="zswx" id="zswx" type="text" class="uplod_img" style="width:68%;" value="<?php echo $zbp->Config('Jz52_fthree')->zswx;?>" />
              <strong>浏览文件</strong> </p></td>
          <td><p align="left">微信收款码</p></td>
        </tr>
      </table>
      <br />
      <input name="submit" type="Submit" class="button" style="width:15%;" value="保存"/>
    </form>



  
  
  
</div>
</div>

<script type="text/javascript" src="<?php echo $bloghost?>zb_users/plugin/UEditor/ueditor.config.php"></script> 
<script type="text/javascript" src="<?php echo $bloghost?>zb_users/plugin/UEditor/ueditor.all.min.js"></script> 
<script type="text/javascript" src="<?php echo $bloghost?>zb_users/theme/Jz52_fthree/admin/js/lib.upload.js"></script> 
<script type="text/javascript">
	ActiveTopMenu( "topmenu_Jz52_fthree" );
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';     	 					
RunTime();     	   	  
?>

