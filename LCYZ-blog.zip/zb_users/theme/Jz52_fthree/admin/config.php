<?php
require '../../../../zb_system/function/c_system_base.php';     		 	 		
require $blogpath . 'zb_users/theme/Jz52_fthree/admin/Admin_header.php';     			 			
?>
<div class="SubMenu">
  <?php Jz52_fthree_SubMenu(1);?>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc"><span class="m-right">更多应用</span></a>
  <a href="https://gebilaoli.com" target="_blank"><span class="m-right">作者网站</span></a>
</div>
<div id="divMain2">
  <?php
	if ($_POST){
    CheckIsRefererValid();
    foreach ($_POST as $k => $v){    				    
        if ($k == 'csrfToken') continue;     	 		   
        $zbp->Config('Jz52_fthree')->$k = $v;      	 	  	
    }
    $zbp->SaveConfig('Jz52_fthree');  
	Jz52_fthree_Event_CreateModule();
    $zbp->SetHint('good');
    redirect(GetVars('HTTP_REFERER','SERVER'));
	}    	  	   
?>
<table name="form1" width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
	<tr>
    <td>	
        <p>更多免费插件主题、建站交流请加群：<a href="http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=bcDlzrHvIzPwwSst49S53GMXebJYsZyZ&authKey=8S%2FpEvO4%2B4y%2BdSAE%2FXRp9Z2WcrMajg60dHhIQTt5T%2BGi20TfcoRZ767XPH66kgft&noverify=0&group_code=326269799" target="_blank"><img src="https://pub.idqqimg.com/wpa/images/group.png" alt="zblog建站交流" title="zblog建站交流"></a>（验证：zblog）</p>
		<p>部分设置需要在后台首页“清空缓存并重新编译模板”方可生效</p>
	</td>
	</tr>	
</table>
  <form id="form1" name="form1" method="post">
      <table width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
        <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken();?>">
        <tr>
          <th width="15%"><p align="center">选项名称</p></th>
          <th width="50%"><p align="center">选项内容</p></th>
          <th width="25%"><p align="center">选项说明</p></th>
        </tr>
		<tr>
          <td width="20%"  align="center"><p>启用图片logo</p></td>
          <td><p>
			  <input type="text" id="imglogo" name="imglogo" class="checkbox" value="<?php echo $zbp->Config('Jz52_fthree')->imglogo;?>"/>
            </p></td>
          <td><p align="left">开启后使用图片logo</p></td>
        </tr>
        <tr>
          <td width="20%"  align="center"><p>LOGO地址</p></td>
          <td><p><img src="<?php echo $zbp->Config('Jz52_fthree')->logo;?>" alt="logo" style = "height:40px;"/></p>
            <p class="uploadimg">
              <input name="logo" id="logo" type="text" class="uplod_img" style="width:68%;" value="<?php echo $zbp->Config('Jz52_fthree')->logo;?>" />
              <strong>浏览文件</strong> </p></td>
          <td><p align="left">LOGO图片地址，默认LOGO图片：<?php echo $zbp->host.'zb_users/theme/Jz52_fthree/images/logo.png';?></p></td>
        </tr>
        <tr>
          <td width="20%"  align="center"><p>备案号</p></td>
          <td><p>
              <input type="text" name="beian" id="beian" style="width:98%;" value="<?php echo $zbp->Config('Jz52_fthree')->beian;?>"/>
            </p></td>
          <td><p align="left">备案号</p></td>
        </tr>

		<tr>
          <td width="20%"  align="center"><p>列表图片生成缩略图</p></td>
          <td><p>
			  <input type="text" id="listimgt" name="thumb" class="checkbox" value="<?php echo $zbp->Config('Jz52_fthree')->thumb;?>"/>
            </p></td>
          <td><p align="left">开启后列表图片会生成缩略图，缩略图目录：网站根目录/thuimg，缩略图在第一次访问文章列表时生成，因为要生成缩略图，初次开启文章列表加载会很慢，静态图片都生成了就快了</p></td>
        </tr>

		<tr>
          <td width="20%"  align="center"><p>左侧栏粘性固定</p></td>
          <td><p>
			  <input type="text" id="celanz" name="celanz" class="checkbox" value="<?php echo $zbp->Config('Jz52_fthree')->celanz;?>"/>
            </p></td>
          <td><p align="left">侧栏跟随</p></td>
        </tr>
		<tr>
          <td width="20%"  align="center"><p>右侧栏粘性固定</p></td>
          <td><p>
			  <input type="text" id="celany" name="celany" class="checkbox" value="<?php echo $zbp->Config('Jz52_fthree')->celany;?>"/>
            </p></td>
          <td><p align="left">侧栏跟随</p></td>
        </tr>
        <tr>
          <td><label for="DelCon">
            <p align="center">清除设置</p>
            </label></td>
          <td><p align="left">
              <input type="text" id="DelCon" name="DelCon" class="checkbox" value="<?php echo $zbp->Config('Jz52_fthree')->DelCon;?>"/>
            </p></td>
          <td><p align="left">打开后更换主题会清除设置</p></td>
        </tr>
      </table>
      <br />
      <input name="submit" type="Submit" class="button" style="width:15%;" value="保存"/>
    </form>


  
  
  
</div>
</div>
<script type="text/javascript" src="<?php echo $bloghost?>zb_users/plugin/UEditor/ueditor.config.php"></script> 
<script type="text/javascript" src="<?php echo $bloghost?>zb_users/plugin/UEditor/ueditor.all.min.js"></script> 
<script type="text/javascript" src="<?php echo $bloghost?>zb_users/theme/Jz52_fthree/admin/js/lib.upload.js"></script> 
<script type="text/javascript">
	ActiveTopMenu( "topmenu_Jz52_fthree" );
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';    			 	 	 
RunTime();    			  	 	
?>
