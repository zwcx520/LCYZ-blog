<?php 
require '../../../../zb_system/function/c_system_admin.php';    				 		 
$zbp->Load();    					 	 
$action = 'root';    				 	 	
if ( !$zbp->CheckRights( $action ) ) {      	  			
	$zbp->ShowError( 6 );      	  		 
	die();     						 
}     		 				
if ( !$zbp->CheckPlugin( 'Jz52_fthree' ) ) {    		 	  	 
	$zbp->ShowError( 48 );    		 	 		 
	die();     		   		
}     		 	 	 
$blogtitle = '主题配置';    		 	 			
require $blogpath . 'zb_system/admin/admin_header.php';    			  	 	
require $blogpath . 'zb_system/admin/admin_top.php';      	 	 	 
?>
<style>
.lianxi {
    padding: 10px;
}
.lianxi p {
    line-height: 36px;
}
.lianxi a {
    padding: 0 10px;
}
.wiki {
    padding: 10px;
    background-color: #f4f4f4;
}
.wiki p {
    line-height: 36px;
}
input {
    margin: 5px 0;
}
strong {
    background-color: #3a6ea5;
    padding: 5px 10px;
    color: #ffffff;
}

</style>
<div id="divMain">
	<div class="divHeader">
		<?php echo $blogtitle;?>
	</div>
	