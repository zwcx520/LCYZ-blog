{* Template Name:首页列表模板 *}
{template:header}
<div class="main-post">
  <div class="content">
    <div class="box-middle">
      <div class="post-list">
		{if $type!='index'}	
        <div class="place fadeinyp"><a href="{$host}">网站首页</a>{if $type=='index'}{elseif $type=='category'} &gt; {$category.Name}{else} &gt; {$title}{/if} </div>
		{/if}
        <div class="divMain"> {foreach $articles as $article}
          {if $article.IsTop}
           <div class="post {if $type=='index'}index{/if} fadeinyp"> 
            <div class="post-img"><a href="{$article.Url}"><img src="{Jz52_fthree_IMGC($article)}" alt="{$article.Title}"></a></div>
            <div class="post-title">
              <h2><a href="{$article.Url}">[置顶]{$article.Title}</a> </h2>
            </div>
            <div class="post-content">
              <div class="p_part">
                <p>{php}$description = preg_replace('/[\r\n\s)]|(\s|\&nbsp\;|　|\xc2\xa0)+/', ' ', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),128)).'...');{/php}{$description}</p>
              </div>
            </div>
            <div class="post-footer">
              <div class="meta">
                <div class="info-left"> <span class="date"><i class="gbllicon-time"></i>{$article.Time('Y-m-d')}</span> <span class="date"><i class="gbllicon-archive-drawer"></i><a href="{$article.Category.Url}" rel="category tag">{$article.Category.Name}</a></span> <span class="date"><i class="gbllicon-eye"></i>{$article.ViewNums}</span> <span class="data"><i class="gbllicon-message"></i>{$article.CommNums}</span> </div>
                <div class="info-right"> <span class="author"><a href="{$article.Author.Url}" target="_blank" title="{$article.Author.StaticName}" ><img alt='{$article.Author.StaticName}' src='{$article.Author.Avatar}' class='avatar' height='96' width='96' /></a></span> </div>
              </div>
            </div>
          </div>
          {else}
          <div class="post {if $type=='index'}index{/if} fadeinyp"> 
            <div class="post-img"><a href="{$article.Url}"><img src="{Jz52_fthree_IMGC($article)}" alt="{$article.Title}"></a></div>
            <div class="post-title">
              <h2><a href="{$article.Url}">{$article.Title}</a> </h2>
            </div>
            <div class="post-content">
              <div class="p_part">
                <p>{php}$description = preg_replace('/[\r\n\s)]|(\s|\&nbsp\;|　|\xc2\xa0)+/', ' ', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),128)).'...');{/php}{$description}</p>
              </div>
            </div>

            <div class="post-footer">
              <div class="meta">
                <div class="info-left"> <span class="date"><i class="gbllicon-time"></i>{$article.Time('Y-m-d')}</span> <span class="date"><i class="gbllicon-archive-drawer"></i><a href="{$article.Category.Url}" rel="category tag">{$article.Category.Name}</a></span> <span class="date"><i class="gbllicon-eye"></i>{$article.ViewNums}</span> <span class="data"><i class="gbllicon-message"></i>{$article.CommNums}</span> </div>
                <div class="info-right"> <span class="author"><a href="{$article.Author.Url}" target="_blank" title="{$article.Author.StaticName}" ><img alt='{$article.Author.StaticName}' src='{$article.Author.Avatar}' class='avatar' height='96' width='96' /></a></span> </div>
              </div>
            </div>
          </div>
          {/if}
          {/foreach} </div>
        <div class="post-pagination"> {template:pagebar} </div>
      </div>
    </div>
    <aside id="sidebar-left"> {template:sidebar} </aside>
    <aside id="sidebar-right"> {template:sidebar2} </aside>
  </div>
{template:footer}