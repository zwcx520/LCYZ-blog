{* Template Name:单页模板 *}
<div class="main-single">
  <div class="single-content">
    <div class="box-middle">
      <div class="post-page">
        <div class="place fadeinyp"><a href="{$host}">网站首页</a> &gt; {$title} </div>
        <div class="post-single fadeinyp">
          <div class="post-title">
            <h1>{$article.Title}</h1>
          </div>
          <div class="post-content"> {$article.Content} </div>
          <div class="single-share">
            <div class="post-share"> <a title="分享"><i class="gbllicon-add"></i></a>
              <div class="share-icons" data-title="{$article.Title}" data-url="{$article.Url}"> <span class="share-wechat" data-type="wechat" title="分享到微信"><i class="gbllicon-weixin"></i>
                <span id="wechat-qrcode"></span>
                </span> <span class="share-sina-weibo" data-type="weibo" title="分享到微博"><i class="gbllicon-weibo"></i></span> <span class="share-qq" data-type="qq" title="分享到QQ好友"><i class="gbllicon-qq"></i></span> </div>
            </div>
			{if $zbp->Config('Jz52_fthree')->zanshang}
            <a class="donate_icon" title="打赏作者"><i class="gbllicon-money-fill"></i></a>
			{/if}
            {if $zbp->CheckPlugin('sf_praise_sdk')}
            <div class="post-like"> <a href="javascript:;"  title="点个赞" class="sf-praise-sdk dotGood"  sfa="click"  data-postid='{$article.ID}' data-value="1"> <i class="gbllicon-thumb-up-line"></i> <span class="sf-praise-sdk count" sfa="num" data-value="1" data-postid="{$article.ID}">{$sf_praise_sdk.value1}</span> </a> </div>
            {/if} </div>
        </div>
        {if !$article.IsLock}
        <div class="comments">
          <div id="comments" class="comments-area clearfix"> {template:comments} </div>
		</div>
        {/if} </div>
    </div>
    <aside id="sidebar-left"> {template:sidebar3} </aside>
    <aside id="sidebar-right"> {template:sidebar4} </aside>
  </div>
    {if $zbp->Config('Jz52_fthree')->zanshang}
  <div class="donate_hide_box"></div>
  <div class="donate_box">
    <p class="donate_close">
      <img src="{$host}zb_users/theme/{$theme}/style/images/close.svg" alt="关闭">
    </p>
  <h4>{$zbp->Config('Jz52_fthree')->zstxt}</h4>
  <span class="wedo doimg"><img src="{$zbp->Config('Jz52_fthree')->zswx}" alt="微信支付"></span> <span class="alido doimg"><img src="{$zbp->Config('Jz52_fthree')->zszfb}" alt="支付宝"></span>
  </div>
  {/if}