{* Template Name:404 *}
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="none" />
<title>{$name}-{$title}</title>
<style>
* {
    margin: 0;
    padding: 0;
    font-weight: lighter;
    text-decoration: none;
    text-align: center;
    line-height: 2em;
    box-sizing: border-box;
}
html, body {
    height: 100%;
    font-family: PingHei, 'PingFang SC', Helvetica Neue, 'Work Sans', 'Hiragino Sans GB', 'Microsoft YaHei', SimSun, sans-serif;
}
body {
    background:
        radial-gradient(900px 600px at 80% -10%, rgba(196, 181, 253, .6), transparent 60%),
        radial-gradient(800px 600px at 8% 20%, rgba(249, 168, 212, .5), transparent 60%),
        radial-gradient(700px 600px at 92% 85%, rgba(165, 243, 252, .55), transparent 60%),
        linear-gradient(160deg, #f6f4ff 0%, #fdf0fa 28%, #eff3ff 52%, #edfaf6 78%, #f4f3ff 100%);
    color: #55517a;
    overflow: hidden;
}
table {
    width: 100%;
    height: 100%;
    border: 0;
}
td {
    vertical-align: middle;
}
h1 {
    font-size: 120px;
    line-height: 1.1em;
    font-weight: 700;
    letter-spacing: 6px;
    background: linear-gradient(92deg, #7c5cff 0%, #c44de6 45%, #ff5fa2 100%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    color: transparent;
    filter: drop-shadow(0 10px 30px rgba(160, 90, 240, .45));
}
h3 {
    font-weight: 500;
    margin-top: 14px;
}
h3 a {
    display: inline-block;
    margin-left: 14px;
    padding: 6px 26px;
    font-weight: 500;
    color: #fff;
    background: linear-gradient(92deg, #7c5cff 0%, #e044a8 100%);
    border-radius: 999px;
    box-shadow: 0 12px 30px -8px rgba(180, 80, 240, .6);
    transition: transform .3s ease, box-shadow .3s ease;
}
h3 a:hover {
    transform: translateY(-3px);
    box-shadow: 0 18px 40px -8px rgba(200, 90, 255, .7);
}
p.tip {
    margin-top: 6px;
    font-size: 14px;
    color: #8a84b8;
}
</style>
</head>
<body>
<table cellspacing="0" cellpadding="0">
  <tr>
    <td><table cellspacing="0" cellpadding="0">
        <tr>
          <td><h1>404</h1>
            <h3>没有找到这个页面 <a href="{$host}">返回首页</a></h3>
            <p class="tip">你访问的页面可能已被移动或删除，请检查地址后重试</p></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
