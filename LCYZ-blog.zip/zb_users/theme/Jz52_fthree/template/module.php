{* Template Name:单个模块 *}
<div class="widget " id="{$module.HtmlID}">
{if (!$module.IsHideTitle)&&($module.Name)}<h3 class="function_t">{$module.Name}</h3>{else}<h3 style="display:none;"></h3>{/if}
{if $module.Type=='div'}
<div>{$module.Content}</div>
{/if}

{if $module.Type=='ul'}
<ul>{$module.Content}</ul>
{/if}

</div>