<li class="{$id}-item">
  <a href="{$item.href}" target="{$item.target}" title="{$item.title}">{$item.ico}{$item.text}</a>
  {if count($item.subs)}
  <ul  class="sub-nav">{foreach $item.subs as $item}{template:lm-module-navbar}{/foreach}</ul>
  {/if}
</li>
