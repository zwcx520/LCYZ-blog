{* Template Name:评论模块 *}
{if $socialcomment}
{$socialcomment}
{else}
<h4 class="comments-title"> <span><i class="gbllicon-message-fill"></i>{if $article.CommNums>0}{$article.CommNums} 条评论{else}暂无评论{/if}</span> </h4>
<div class="comment-list">
<label id="AjaxCommentBegin"></label>
<!--评论输出-->
{foreach $comments as $key => $comment}
{template:comment}
{/foreach}
<!--评论翻页条输出-->
<div class="post-pagination">
{template:pagebar}
</div>
<label id="AjaxCommentEnd"></label>
</div>
<!--评论框-->
{template:commentpost}
{/if}