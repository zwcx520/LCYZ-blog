{* Template Name:文章模板 *}
<div class="main-single">
  <div class="single-content">
    <div class="box-middle">
      <div class="post-page">
        <div class="place fadeinyp"><a href="{$host}">网站首页</a> &gt; <a href="{$article.Category.Url}">{$article.Category.Name}</a> &gt; 正文 </div>
        <div class="post-single fadeinyp">
          <div class="post-title">
            <h1>{$article.Title}</h1>
          </div>
          <div class="post-info">
            <div class="single-meta"> <span class="date"><i class="gbllicon-time"></i>{$article.Time('Y-m-d')}</span> <span class="date"><i class="gbllicon-archive-drawer"></i><a href="{$article.Category.Url}" rel="category tag">{$article.Category.Name}</a></span> <span class="date"><i class="gbllicon-eye"></i>{$article.ViewNums}</span> <span class="data"><i class="gbllicon-message"></i>{$article.CommNums}</span></div>
          </div>
          <div class="post-content"> {$article.Content} </div>
          {if count($article.Tags)}
          <div class="tags"> {foreach $article.Tags as $tag}<a href="{$tag.Url}" target="_blank">{$tag.Name}</a>{/foreach} </div>
          {/if}
          <div class="single-share">
            <div class="post-share"> <a title="分享"><i class="gbllicon-add"></i></a>
              <div class="share-icons" data-title="{$article.Title}" data-url="{$article.Url}"> <span class="share-wechat" data-type="wechat" title="分享到微信"><i class="gbllicon-weixin"></i>
                <span id="wechat-qrcode"></span>
                </span> <span class="share-sina-weibo" data-type="weibo" title="分享到微博"><i class="gbllicon-weibo"></i></span> <span class="share-qq" data-type="qq" title="分享到QQ好友"><i class="gbllicon-qq"></i></span> </div>
            </div>
			{if $zbp->Config('Jz52_fthree')->zanshang}
            <a class="donate_icon" title="打赏作者"><i class="gbllicon-money-fill"></i></a>
			{/if}
            {if $zbp->CheckPlugin('sf_praise_sdk')}
            <div class="post-like"> <a href="javascript:;"  title="点个赞" class="sf-praise-sdk dotGood"  sfa="click"  data-postid='{$article.ID}' data-value="1"> <i class="gbllicon-thumb-up-line"></i> <span class="sf-praise-sdk count" sfa="num" data-value="1" data-postid="{$article.ID}">{$sf_praise_sdk.value1}</span> </a> </div>
            {/if} </div>
        </div>
        <div class="posts-navigation single-entry-section clearfix">
          <div class="posts-navigation__prev">
            <article class="post--overlay post--overlay-bottom post--overlay-floorfade">
              <div class="background-img" style="background-image:url({if $article.Prev}{Jz52_fthree_IMGC($article.Prev)}{else}{$host}zb_users/theme/Jz52_fthree/images/prevnoimg.jpg{/if}"> </div>
              <div class="post__text inverse-text">
                <div class="post__text-wrap">
                  <div class="post__text-inner"> <span><i class="gbllicon-angle-left"></i>上一篇</span> {if $article.Prev}
                    <h3 class="post__title typescale-1 nav-prev">{$article.Prev.Title}</h3>
                    {else}
                    <h3 class="post__title typescale-1 nav-prev">没有了</h3>
                    {/if} </div>
                </div>
              </div>
              {if $article.Prev}<a href="{$article.Prev.Url}" class="link-overlay"></a>{/if} </article>
          </div>
          <div class="posts-navigation__next">
            <article class="post--overlay post--overlay-bottom post--overlay-floorfade">
              <div class="background-img" style="background-image:url({if $article.Next}{Jz52_fthree_IMGC($article.Next)}{else}{$host}zb_users/theme/Jz52_fthree/images/nextnoimg.jpg{/if})"> </div>
              <div class="post__text inverse-text">
                <div class="post__text-wrap">
                  <div class="post__text-inner"> <span>下一篇<i class="gbllicon-angle-right"></i></span> {if $article.Next}
                    <h3 class="post__title typescale-1 nav-next">{$article.Next.Title}</h3>
                    {else}
                    <h3 class="post__title typescale-1 nav-next">没有了</h3>
                    {/if} </div>
                </div>
              </div>
              {if $article.Next}<a href="{$article.Next.Url}" class="link-overlay"></a>{/if} </article>
          </div>
        </div>
        {if !$article.IsLock}
        <div class="comments">
          <div id="comments" class="comments-area clearfix"> {template:comments} </div>
		</div>
        {/if} </div>
    </div>
    <aside id="sidebar-left"> {template:sidebar3} </aside>
    <aside id="sidebar-right"> {template:sidebar4} </aside>
  </div>
  {if $zbp->Config('Jz52_fthree')->zanshang}
  <div class="donate_hide_box"></div>
  <div class="donate_box">
    <p class="donate_close">
      <img src="{$host}zb_users/theme/{$theme}/style/images/close.svg" alt="关闭">
    </p>
  <h4>{$zbp->Config('Jz52_fthree')->zstxt}</h4>
  <span class="wedo doimg"><img src="{$zbp->Config('Jz52_fthree')->zswx}" alt="微信支付"></span> <span class="alido doimg"><img src="{$zbp->Config('Jz52_fthree')->zszfb}" alt="支付宝"></span>
  </div>
  {/if}