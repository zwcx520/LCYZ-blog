{* Template Name:公用页脚模块 *}
  <div id="footer">
  {Jz52_fthree_Footer()}
  </div>
</div>
</div>
<a href="javascript:void(0);" class="to-top" id="to-top"><i class="gbllicon-angle-up"></i><em>返回顶部</em></a>
<script src="{$host}zb_users/theme/{$theme}/script/custom.js?v=3"></script>
<script src="{$host}zb_users/theme/{$theme}/script/qrcode.min.js"></script>
{$footer}
{if $zbp->Config('Jz52_fthree')->celanz}<script src="{$host}zb_users/theme/{$theme}/script/sticky-left.js"></script>{/if}
{if $zbp->Config('Jz52_fthree')->celany}<script src="{$host}zb_users/theme/{$theme}/script/sidebar-right.js"></script>{/if}
<div class="sidebar-left-about-wechat"></div>
<div class="sidebar-left-wechat">
  <p class="sidebar-left-close">
      <img src="{$host}zb_users/theme/{$theme}/style/images/close.svg" alt="关闭">
  </p>
  <h4>{$zbp->Config('Jz52_fthree')->wxtxt}</h4>
  <span class="sidebar-left-wechat-img"><img src="{$zbp->Config('Jz52_fthree')->wximg}" alt="微信二维码"></span> </div>
  <div class="mobile-sidebar">
  <div class="mobile-sidebar-header">
     <div class="btn-group">
		<a href="javascript:void(0);" id="gbllicon-close"><i class="gbllicon-close Navleft"></i></a>
     </div>
  </div>
    <ul class="navbar-nav">
      {$modules['jz52fthree-mnav'].Content}
    </ul>
  </div>
</body>
</html>