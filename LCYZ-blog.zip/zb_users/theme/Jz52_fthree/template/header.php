{* Template Name:鍏敤澶撮儴妯″潡 *}
<!DOCTYPE html>
<html lang="{$language}">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
{if $zbp->Config('Jz52_fthree')->seo}{template:seo}{else}<title>{$name}-{$title}</title>{/if}
<meta name="generator" content="{$zblogphp}">
<link rel="stylesheet" href="{$host}zb_users/theme/{$theme}/style/{$style}.css?v=10">
<script src="{$host}zb_system/script/jquery-2.2.4.min.js"></script>
<script src="{$host}zb_system/script/zblogphp.js"></script>
<script src="{$host}zb_system/script/c_html_js_add.php"></script>
{$header}
{if $type=='index'&&$page=='1'}
<link rel="alternate" type="application/rss+xml" href="{$feedurl}" title="{$name}">
{/if}
</head>
<body>
<div class="bgDiv"></div>
<div class="main">
<div class="header" id="header">
  <div class="page-top">
    <div id="logo-text"> <a class="logo-text" href="{$host}">{if $zbp->Config('Jz52_fthree')->imglogo}<img src="{$zbp->Config('Jz52_fthree')->logo}" alt="{$name}">{else}{$name}{/if}</a> </div>
    <ul id="top-nav" class="menu">
	   {module:navbar}
    </ul>

    <div class="header_search">
	<button id="toggle-search" class="header-button"><i class="gbllicon-search"></i></button>
	  <form action="{$host}search.php"  id="search-form">
        <input name="q" autocomplete="off" placeholder="请输入搜索内容..." type="search" value="" required="required">
        <input type="submit" value="搜索">
      </form>
    </div>
	<div class="con"> <i class="gbllicon-menu Navleft"></i></div>
	</div>
  <div id="percentageCounter"></div>
</div>