<?php echo'404';die();?>
{* Template Name:分页 *}
{if $pagebar}
{foreach $pagebar.buttons as $k=>$v}
{if $pagebar.PageNow==$k}
<a class='post-pagination__item post-pagination__item-current' href='javascript:void(0);'>{$k}</a>
{elseif $k=='‹‹' and $pagebar.PageNow!=$pagebar.PageFirst}
{elseif $k=='‹‹' and $pagebar.PageNow==$pagebar.PageFirst}
{elseif $k=='››' and $pagebar.PageNow==$pagebar.PageLast}
{elseif $k=='››' and $pagebar.PageNow!=$pagebar.PageLast}
{elseif $k=='‹'}
<a class="post-pagination__item"  href="{$v}" title='上一页'><i class="gbllicon-angle-left"></i></a>
{elseif $k=='›'}
<a class="post-pagination__item"  href="{$v}" title='下一页'><i class="gbllicon-angle-right"></i></a>
{else}
<a class="post-pagination__item"  href="{$v}">{$k}</a> {/if}
{/foreach}
{/if} 