<?php 
/**
 * 获取热门文章数组对象
 */
function Jz52_fthree_Event_GetHotArticleList($num = 10, $type = "view") {
    global $zbp;
    if ($type == "cmt") {
        $time = $zbp->Config('Jz52_fthree')->side_hot_cmt_day;
    } else {
        $time = $zbp->Config('Jz52_fthree')->side_hot_view_day;
    }
    if (empty($time)) {
        $time = 90 * 10;
    }
    $time = time() - $time * 24 * 60 * 60;

    $w = array();
    $w[] = array("=", "log_Type", "0");
    $w[] = array("=", "log_Status", "0");
    $w[] = array(">", "log_PostTime", $time);

    if ($type == "view") {
        $order = array("log_ViewNums" => "DESC");
    } else {
        $order = array("log_CommNums" => "DESC");
    }

    $articles = $zbp->GetArticleList(array('*'), $w, $order, array($num));

    return $articles;
}

/**
 * 推荐文章
 */
function Jz52_fthree_Event_GetTuiArticleList() {
    global $zbp;

    $w = array();
    $w[] = array("=", "log_Type", "0");
    $w[] = array("=", "log_Status", "0");

    $ids = $zbp->Config('Jz52_fthree')->side_tui_list;
    $ids = explode(",", $ids);

    $w[] = array("IN", "log_ID", $ids);

    // 利用缓存，把文章预先查询
    $list = $zbp->GetArticleList(array('*'), $w);

    $articles = array();

    // 按$ids的数组排序获取缓存文章
    foreach ($ids as $item) {
        $articles[] = $zbp->GetPostByID($item);
    }

    return $articles;
}

/**
 * 获取最新评论数组对象
 */
function Jz52_fthree_Event_GetNewCommentList($num = 5) {
    global $zbp;

    $w = array();
    $w[] = array("=", "comm_IsChecking", "0");

    $comments = $zbp->GetCommentList(array('*'), $w, array("comm_PostTime" => "DESC"), array($num));

    foreach ($comments as &$comment) {
        if ($comment->ParentID > 0) {
            $comment->Parent = $zbp->GetCommentByID($comment->ParentID);
            $comment->Parent->Content = TransferHTML($comment->Parent->Content, '[nohtml]');
        }
        $comment->Content = TransferHTML($comment->Content, '[nohtml]');
    }

    return $comments;
}

/**
 * 创建相关模块
 */
function Jz52_fthree_Event_CreateModule() {
    global $zbp;
    // 插件模块设定
    $module_list = array(
        array("jz52_fthree_hot_view_article", "side-hot-view-item", "ul", "热门文章"),
        array("jz52_fthree_hot_cmt_article", "side-hot-cmt-item", "ul", "热评文章"),
        array("jz52_fthree_new_article", "side-new-article-item", "ul", "最新文章"),
        array("jz52_fthree_tui_article", "side-tui-article-item", "ul", "推荐文章"),
        array("jz52_fthree_new_comment", "side-new-comment-item", "ul", "最新评论"),
		array("jz52_fthree_new_about", "side-new-about-item", "div", "关于站长")
    );
    // 获得filename为数组，用于查询模块
    $module_filenames = array();
    foreach ($module_list as $item) {
        array_push($module_filenames, $item[0]);
    }
    // 获取模块对象数组
    $modules = $zbp->GetModuleList(array("*"), array(
        array("IN", "mod_FileName", $module_filenames),
    ));

    // 遍历更新内容，同时记录已更新模块
    $has_modules = array();
    foreach ($modules as $item) {
        $item->Content = Jz52_fthree_Event_SideContent($item);
        $item->Save();
        array_push($has_modules, $item->FileName);
    }

    // 遍历查询是否有未创建的模块
    foreach ($module_filenames as $k => $item) {
        if (!array_search($item, $has_modules)) {
            $module = $module_list[$k];
            $t = new Module();
            $t->Name = $module[3];
            $t->FileName = $module[0];
            $t->Source = "theme_Jz52_fthree";
            $t->SidebarID = 0;
            $t->Content = Jz52_fthree_Event_SideContent($t);
            $t->HtmlID = $module[1];
            $t->Type = $module[2];
            $t->Save();
        }
    }
}

/**
 * 删除模块
 */
function Jz52_fthree_Event_DelModule() {
    global $zbp;
    $modules = array('jz52_fthree_hot_view_article', 'jz52_fthree_hot_cmt_article', 'jz52_fthree_new_article', 'jz52_fthree_tui_article', 'jz52_fthree_new_comment', 'jz52_fthree_new_about');
    $w = array();
    $w[] = array('IN', 'mod_FileName', $modules);
    $modules = $zbp->GetModuleList(array('*'),$w);
    foreach ($modules as $item) {
        $item->Del();
    }
}



/**
 * 侧边内容输出
 */
function Jz52_fthree_Event_SideContent(&$module) {
    global $zbp;
    $str = "";
    switch ($module->FileName) {
        case 'jz52_fthree_hot_view_article':
            $num = $module->MaxLi > 0 ? $module->MaxLi : 6;
            $hotArtList = Jz52_fthree_Event_GetHotArticleList($num);
            foreach ($hotArtList as $item) {		
                $str .= '<li class="widget-list-item"><div class="widget-post-list"> <img src="'.Jz52_fthree_IMGC($item).'" alt="'.$item->Title.'"> </div><div class="widget-post-list-item"><div class="list-body"> <a class="list-title" href="'.$item->Url.'" target="_blank" rel="bookmark" title="'.$item->Title.'">'.$item->Title.'</a> </div><div class="list-footer"> <span>'.$item->Time('Y-m-d').'</span> </div></div><div class="clear"></div></li>';
            }	
        break;
        case 'jz52_fthree_hot_cmt_article':
            $num = $module->MaxLi > 0 ? $module->MaxLi : 6;
            $hotArtList = Jz52_fthree_Event_GetHotArticleList($num, "cmt");
            foreach ($hotArtList as $item) {	
                $str .= '<li class="widget-list-item"><div class="widget-post-list"> <img src="'.Jz52_fthree_IMGC($item).'" alt="'.$item->Title.'"> </div><div class="widget-post-list-item"><div class="list-body"> <a class="list-title" href="'.$item->Url.'" target="_blank" rel="bookmark" title="'.$item->Title.'">'.$item->Title.'</a> </div><div class="list-footer"> <span>'.$item->Time('Y-m-d').'</span> </div></div><div class="clear"></div></li>';
            }
        break;
        case 'jz52_fthree_new_article':
            $num = $module->MaxLi > 0 ? $module->MaxLi : 6;
            $hotArtList = GetList($num);
            foreach ($hotArtList as $item) {		
                $str .= '<li class="widget-list-item"><div class="widget-post-list"> <img src="'.Jz52_fthree_IMGC($item).'" alt="'.$item->Title.'"> </div><div class="widget-post-list-item"><div class="list-body"> <a class="list-title" href="'.$item->Url.'" target="_blank" rel="bookmark" title="'.$item->Title.'">'.$item->Title.'</a> </div><div class="list-footer"> <span>'.$item->Time('Y-m-d').'</span> </div></div><div class="clear"></div></li>';
            }
        break;
        case 'jz52_fthree_new_comment':
            $newCmtList = Jz52_fthree_Event_GetNewCommentList(6);
            foreach ($newCmtList as $item) {

                $str .= '<li class="clearfix widget_avatar-comments-item"> <a href="'.$item->Post->Url.'#cmt'.$item->ID.'"><div class="widget_avatar-comments-avatar alignleft"><img alt="'.$item->Author->StaticName.'" src="'.$item->Author->Avatar.'" class="avatar avatar-24 photo" height="24" width="24"></div></a><div class="widget_avatar-comments-entry"> <a href="'.$item->Post->Url.'#cmt'.$item->ID.'">'.$item->Content.'</a></div></li>';
            }
        break;
        case 'jz52_fthree_tui_article':
            $tuiArtList = Jz52_fthree_Event_GetTuiArticleList();
            foreach ($tuiArtList as $item) {
                $str .= '<li class="widget-list-item"><div class="widget-post-list"> <img src="'.Jz52_fthree_IMGC($item).'" alt="'.$item->Title.'"> </div><div class="widget-post-list-item"><div class="list-body"> <a class="list-title" href="'.$item->Url.'" target="_blank" rel="bookmark" title="'.$item->Title.'">'.$item->Title.'</a> </div><div class="list-footer"> <span>'.$item->Time('Y-m-d').'</span> </div></div><div class="clear"></div></li>';
            }
        break;
		
		case 'jz52_fthree_new_about':
                $str .= '<div class="widget-list">
  <div id="about-bg" style="background: url('.$zbp->Config('Jz52_fthree')->aboutimg.') center center no-repeat;background-size:cover;">
    <h2>'.$zbp->Config('Jz52_fthree')->about_tit.'</h2>
    </div>
  <div class="about_des">
    <p>'.$zbp->Config('Jz52_fthree')->about_tittxt.'</p>
  </div>
  <div class="widget-about-image"><img src="'.$zbp->Config('Jz52_fthree')->about_avatar.'" alt="'.$zbp->Config('Jz52_fthree')->about_tit.'"></div>
  <div class="widget-about-intro">
    <ul class="about_list">
	'.$zbp->Config('Jz52_fthree')->about_li.'
    </ul>
<div class="sidebar-navigation">
'.$zbp->Config('Jz52_fthree')->sns.'
</div>
  </div>
</div>'; 
        break;
    }
    return $str;
}