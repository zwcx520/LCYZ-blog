{* Template Name:公用头部模块 *}
<!doctype html>
<html lang="{$language}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
{if $zbp->Config('Jz52_pureblog')->seo}{template:lm-seo}{else}
<title>{$name}-{$title}</title>
{/if}
<meta name="generator" content="{$zblogphp} Themes: GebiLaoli.Com">
<link rel="stylesheet" href="{$host}zb_users/theme/{$theme}/style/style.css">
<script src="{$host}zb_system/script/jquery-latest.min.js"></script> 
<script src="{$host}zb_system/script/zblogphp.js"></script> 
<script src="{$host}zb_system/script/c_html_js_add.php"></script>
{$header}
{if $type=='index'&&$page=='1'}
<link rel="alternate" type="application/rss+xml" href="{$feedurl}" title="{$name}">
{/if}
</head>
<body>
<header>
  <div class="header-inner flex">
	{if $type=='article'||$type=='page'}
      <h2><a href="{$host}">{if $zbp->Config('Jz52_pureblog')->logo}{$zbp->Config('Jz52_pureblog')->logo}{else}{$name}{/if}</a></h2>
	{else}
      <h1><a href="{$host}">{if $zbp->Config('Jz52_pureblog')->logo}{$zbp->Config('Jz52_pureblog')->logo}{else}{$name}{/if}</a></h1>
	{/if}
    <nav>
      <ul>
        {module:navbar}
      </ul>
    </nav>
    <div class="ico flex">
      <div class="header-search flex-center"> <span class="search-icon" id="searchIcon">
        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align:middle;">
          <circle cx="10" cy="10" r="7" stroke-width="2"/>
          <line x1="16.1213" y1="16.1213" x2="20" y2="20" stroke-width="2" stroke-linecap="round"/>
        </svg>
        </span>
        <div class="search-box card" id="searchBox">
          <form name="search" method="post" class="flex" action="{$host}zb_system/cmd.php?act=search">
            <input type="search" maxlength="256" name="q" placeholder="请输入关键字..." autocomplete="off">
            <button type="button" class="btn">搜索</button>
          </form>
        </div>
      </div>
      <div class="hamburger" id="hamburgerBtn">
        <svg class="icon-hamburger" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect y="4" width="22" height="2" rx="1.5"/>
          <rect y="11" width="22" height="2" rx="1.5"/>
          <rect y="18" width="22" height="2" rx="1.5"/>
        </svg>
        <svg class="icon-close" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg" style="display:none;">
          <line x1="4" y1="4" x2="18" y2="18" stroke-width="2" stroke-linecap="round"/>
          <line x1="18" y1="4" x2="4" y2="18" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </div>
    </div>
  </div>
</header>
{if !($type=='index' && $page=='1')}
<div class="breadcrumb card"> <a  title="首页"  href="{$host}">首页</a>{if $type=='article'} <span class="breadcrumb-separator">/</span> <a href="{$article.Category.Url}">{$article.Category.Name}</a> <span class="breadcrumb-separator">/</span> 正文 {elseif $type=='category'} <span class="breadcrumb-separator">/</span> <a href="{$category.Url}">{$category.Name}</a>{else} <span class="breadcrumb-separator">/</span> {$title}{/if} </div>
{/if}