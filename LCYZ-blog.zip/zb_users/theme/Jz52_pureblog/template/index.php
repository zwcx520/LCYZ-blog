{* Template Name:首页列表模板 *}
{template:header}
<main class="container flex">
  <div class="blog-list-wrapper flex">
    <section class="blog-list"> {foreach $articles as $article}
      {php}$description = preg_replace('/[\r\n\s)]|(\s|\&nbsp\;|　|\xc2\xa0)+/', ' ', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),64)).'...');{/php}
      {if $article.IsTop}
      <article class="blog-post card flex"> {Jz52_pureblog_IMG($article)}
        <div class="post-content flex">
          <h2>[顶]<a href="{$article.Url}" >{$article.Title}</a></h2>
          <p>{$description}</p>
          <a href="{$article.Url}" class="read-more btn">阅读全文</a> </div>
      </article>
      {else}
      <article class="blog-post card flex"> {Jz52_pureblog_IMG($article)}
        <div class="post-content flex">
          <h2><a href="{$article.Url}" >{$article.Title}</a></h2>
          <p>{$description}</p>
          <a href="{$article.Url}" class="read-more btn">阅读全文</a> </div>
      </article>
      {/if}
      {/foreach} </section>
    <div class="pagination flex-center"> {template:pagebar} </div>
  </div>
  <aside class="sidebar card"> {if $type=='index'}
    {template:sidebar}
    {elseif $type=='category'}
    {template:sidebar2}
    {else}
    {template:sidebar5}
    {/if} </aside>
</main>
{template:footer}