{* Template Name:单个模块 *}
<div class="module" id="{$module.HtmlID}">
{if (!$module.IsHideTitle)&&($module.Name)}<h3>{$module.Name}</h3>{else}{/if}
{if $module.Type=='div'}
<div>{$module.Content}</div>
{/if}
{if $module.Type=='ul'}
<ul>{$module.Content}</ul>
{/if}
</div>