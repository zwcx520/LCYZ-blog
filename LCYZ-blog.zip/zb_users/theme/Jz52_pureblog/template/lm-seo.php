{* Template Name:SEO文件 *}
{if $type=='article'}
<title>{$title} - {$name}</title>
{php}
$aryTags = array();
foreach($article->Tags as $key){$aryTags[] = $key->Name;}
if(count($aryTags)>0){$keywords = implode(',',$aryTags);} else {$keywords = $zbp->name;}
$description = trim(SubStrUTF8(TransferHTML($article->Content,'[nohtml]'),135)).'...';
{/php}
<meta name="keywords" content="{if $article.Metas.nrgjc && $zbp->Config('Jz52_pureblog')->nseo}{$article.Metas.nrgjc}{else}{$keywords}{/if}">
<meta name="description" content="{if $article.Metas.nrms && $zbp->Config('Jz52_pureblog')->nseo}{$article.Metas.nrms}{else}{$description}{/if},{$name}">
{if $article.Prev}
<link rel="prev" title="{$article.Prev.Title}" href="{$article.Prev.Url}">
{/if}
{if $article.Next}
<link rel="next" title="{$article.Next.Title}" href="{$article.Next.Url}">
{/if}
<link rel="canonical" href="{$article.Url}">
{elseif $type=='page'}
<title>{$title} - {$name}</title>
<meta name="keywords" content="{if $article.Metas.nrgjc && $zbp->Config('Jz52_pureblog')->nseo}{$article.Metas.nrgjc}{else}{$title}{/if}" />
{php}
$description = trim(SubStrUTF8(TransferHTML($article->Content,'[nohtml]'),135)).'...';
{/php}
<meta name="description" content="{if $article.Metas.nrms && $zbp->Config('Jz52_pureblog')->nseo}{$article.Metas.nrms}{else}{$description}{/if},{$name}">
{elseif $type=='index'}
<title>{if $zbp->Config('Jz52_pureblog')->seotitle&&$page=='1'}{$zbp->Config('Jz52_pureblog')->seotitle}{if $subname} - {$subname}{/if}{else}{$name}{if $page>'1'} - 第{$pagebar.PageNow}页{/if}{/if}</title>
{if $zbp->Config('Jz52_pureblog')->seokeywords}
<meta name="keywords" content="{$zbp->Config('Jz52_pureblog')->seokeywords}">
{/if}
{if $zbp->Config('Jz52_pureblog')->seodescription}
<meta name="description" content="{$zbp->Config('Jz52_pureblog')->seodescription}">
{/if}
{elseif $type=='tag'}
<title>{$tag.Name} - {$name}{if $page>'1'} - 第{$pagebar.PageNow}页{/if}</title>
<meta name="keywords" content="{$tag.Name}">
{if $tag.Intro}
<meta name="description" content="{$tag.Intro}">
{/if}
{elseif $type=='category'}
<title>{if $category.Metas.flbt && $zbp->Config('Jz52_pureblog')->nseo}{$category.Metas.flbt}{if $page>'1'} 第{$pagebar.PageNow}页{/if}{else}{$title}{/if} - {$name}</title>
<meta name="keywords" content="{if $category.Metas.flgjc && $zbp->Config('Jz52_pureblog')->nseo}{$category.Metas.flgjc}{else}{$title}{/if},{$name}">
<meta name="description" content="{if $category.Intro}{$category.Intro}{else}{$title}_{$name}{/if}">
{else}
<title>{$title} - {$name}</title>
<meta name="keywords" content="{$title},{$name}" />
<meta name="description" content="{$title}_{$name}{if $page>'1'}_当前是第{$pagebar.PageNow}页{/if}">
{/if}