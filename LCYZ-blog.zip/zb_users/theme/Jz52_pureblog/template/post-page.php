{* Template Name:单页模板 *}
<main class="container flex">
  <section class="article-main flex">
    <article class="article-detail card">
      <h1>{$article.Title}</h1>
      <div class="article-content"> {$article.Content} </div>
    </article>
    {if !$article.IsLock}
    {template:comments}
    {/if} </section>
  <aside class="sidebar card"> {template:sidebar4} </aside>
</main>