{* Template Name:评论发布框 *}
<div class="post" id="divCommentPost">
  <h3>{if $user.ID>0}{$user.StaticName}{/if}发布评论</h3>
  <a rel="nofollow" id="cancel-reply" href="#divCommentPost" style="display:none;"><small>取消回复</small></a>
  <form id="frmSumbit" class="comment-form" target="_self" method="post" action="{$article.CommentPostUrl}" >
    <input type="hidden" name="inpId" id="inpId" value="{$article.ID}" />
    <input type="hidden" name="inpRevID" id="inpRevID" value="0" />
    {if $user.ID>0}
    <input type="hidden" name="inpName" id="inpName" value="{$user.StaticName}" />
    <input type="hidden" name="inpEmail" id="inpEmail" value="{$user.Email}" />
    <input type="hidden" name="inpHomePage" id="inpHomePage" value="{$user.HomePage}" />
    {else}
    <div class="form-row flex">
      <div class="cominp">
        <input type="text" name="inpName" id="inpName" placeholder="昵称*" required tabindex="1">
      </div>
      <div class="cominp">
        <input type="email" name="inpEmail" id="inpEmail" placeholder="邮箱（可选）" tabindex="2">
      </div>
      <div class="cominp">
        <input type="url" name="inpHomePage" id="inpHomePage" placeholder="网站（可选）" tabindex="3">
      </div>
      {if $option['ZC_COMMENT_VERIFY_ENABLE']}
      <div class="cominp inpVerify">
        <input type="text" id="inpVerify" name="inpVerify" placeholder="验证码" tabindex="4">
        <img class="jz-code" src="{$article.ValidCodeUrl}" alt="" title="" onclick="javascript:this.src='{$article.ValidCodeUrl}&amp;tm='+Math.random();"> </div>
      {/if} </div>
    {/if}
    <textarea placeholder="写下你的评论..." rows="4" cols="50" required name="txaArticle" id="txaArticle" tabindex="5"></textarea>
    <button type="submit" class="btn" onclick="return zbp.comment.post()" tabindex="6">发表评论</button>
  </form>
</div>