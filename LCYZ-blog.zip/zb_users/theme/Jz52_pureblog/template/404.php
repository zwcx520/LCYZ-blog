{* Template Name:404 *}
{template:header}
<style>
.post404 h1{font-size:6em;line-height:1.7;text-align:center}.post404 p{font-size:1.2em;text-align:center;padding-bottom:1em}
</style>
<main class="container flex">
  <section class="article-main flex">
    <article class="article-detail card post404">
      <h1>404</h1>
      <div class="article-content">
        <p>没有找到这个页面 <a href="{$host}">返回</a></p>
      </div>
    </article>
  </section>
</main>
{template:footer}