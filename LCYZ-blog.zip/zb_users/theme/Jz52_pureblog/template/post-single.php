{* Template Name:文章模板 *}
<main class="container flex">
  <section class="article-main flex">
    <article class="article-detail card">
      <h1>{$article.Title}</h1>
      <div class="article-meta text-muted"> <span>作者：{$article.Author.StaticName}</span> · <span>{$article.Time('Y-m-d')}</span> · <span>阅读 {$article.ViewNums}</span> </div>
      <div class="article-content"> {$article.Content}
        
        {if count($article.Tags)}
        <div class="article-tags"> {foreach $article.Tags as $tag}<a href="{$tag.Url}" target="_blank" class="tag-item">{$tag.Name}</a> {/foreach} </div>
        {/if} </div>
    </article>
    <section class="author-info">
      <div class="flex" style="align-items:center;"> <img src="{$article.Author.Avatar}" alt="{$article.Author.StaticName}">
        <div>
          <div class="author-name">{$article.Author.StaticName}</div>
          <div class="author-desc text-muted">{if $article.Author.Intro}{$article.Author.Intro}{else}这个人很神秘{/if}</div>
        </div>
      </div>
    </section>
    {if !$article.IsLock}
    {template:comments}
    {/if} </section>
  <aside class="sidebar card"> {template:sidebar3} </aside>
</main>