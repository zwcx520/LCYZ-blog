<?php echo'404';die();?>
{* Template Name:分页 *}
{if $pagebar}
{foreach $pagebar.buttons as $k=>$v}
{if $pagebar.PageNow==$k}
<b class="page-btn btn active">{$k}</b>
{elseif $k=='‹‹' and $pagebar.PageNow!=$pagebar.PageFirst}
<a href="{$v}" class="page-btn btn">首页</a>
{elseif $k=='‹‹' and $pagebar.PageNow==$pagebar.PageFirst}
{elseif $k=='››' and $pagebar.PageNow==$pagebar.PageLast}
{elseif $k=='››' and $pagebar.PageNow!=$pagebar.PageLast}
<a href="{$v}" class="page-btn btn">尾页</a>
{elseif $k=='‹'}
<a href="{$v}" class="page-btn btn">上一页</a>
{elseif $k=='›'}
<a href="{$v}" class="page-btn btn">下一页</a>
{else}
<a href="{$v}" class="page-btn btn">{$k}</a> {/if}
{/foreach}
{/if} 