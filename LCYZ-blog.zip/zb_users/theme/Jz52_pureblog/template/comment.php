{* Template Name:单条评论 *}
<div class="comment-item" id="cmt{$comment.ID}">
  <div class="comment-header flex"> <span class="comment-author">{$comment.Author.StaticName}</span> <span class="comment-time text-muted">{$comment.Time()}</span>
    <button class="reply-btn btn" type="button" onclick="zbp.comment.reply('{$comment.ID}')">回复</button>
  </div>
  <div class="comment-content">{$comment.Content}</div>
  <div class="comment-children"> {foreach $comment.Comments as $comment}
    {template:comment}
    {/foreach} </div>
</div>