{* Template Name:所有评论模板 *}
{if $socialcomment}
{$socialcomment}
{else}
<section class="comments card"> {if $article.CommNums>0}
  <h3>评论列表</h3>
  {/if}
  <div class="comment-list">
    <label id="AjaxCommentBegin"></label>
    <!--评论输出--> 
    {foreach $comments as $key => $comment}
    {template:comment}
    {/foreach} 
    
    <!--评论翻页条输出-->
    <div class="pagebar commentpagebar"> {template:pagebar} </div>
    <label id="AjaxCommentEnd"></label>
  </div>
  <!--评论框--> 
  {template:commentpost} </section>
{/if} 