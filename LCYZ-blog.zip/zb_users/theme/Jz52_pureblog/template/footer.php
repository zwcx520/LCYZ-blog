{* Template Name:公用页脚模块 *}
{Jz52_pureblog_Footer()}
{$footer}
</body>
</html> 