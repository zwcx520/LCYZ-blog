<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';
$zbp->Load();
$action='root';
if (!$zbp->CheckRights($action)) {$zbp->ShowError(6);die();}
if (!$zbp->CheckPlugin('Jz52_pureblog')) {$zbp->ShowError(48);die();}
$blogtitle='主题配置';
$act = "";
if ($_GET['act']){
$act = $_GET['act'] == "" ? 'config' : $_GET['act'];
}
require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
if ( $_POST ) {
  CheckIsRefererValid();
  foreach ( $_POST as $k => $v ) {
    if ( $k == 'csrfToken' ) continue;
    $zbp->Config( 'Jz52_pureblog' )->$k = $v;
  }
  $zbp->SaveConfig( 'Jz52_pureblog' );
  $zbp->SetHint( 'good' );
  redirect( GetVars( 'HTTP_REFERER', 'SERVER' ) );
}
?>
<style>
.lianxi { padding: 10px; }
.lianxi p { line-height: 36px; }
.lianxi a { padding: 0 10px; }
.wiki { padding: 10px; background-color: #f4f4f4; }
.wiki p { line-height: 36px; }
input { margin: 5px 0; }
strong { background-color: #3a6ea5; padding: 5px 10px; color: #ffffff; }
p { margin: 5px 0; }
td { padding: 10px; }
</style>
<div id="divMain">
	<div class="divHeader"><?php echo $blogtitle;?></div>
	<div class="SubMenu jzSubMenu">
	<?php Jz52_pureblog_SubMenu($act);?>
	 <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span class="m-right">更多应用</span></a>
     <a href="https://gebilaoli.com" target="_blank"><span class="m-right">作者网站</span></a>
    </div>
<div id="divMain2">
<?php 
if ($act == 'config') { 
?>
<table name="form1" width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
	<tr>
    <td>	
		<p>ZBLOG建站交流请加群：<a href="http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=UuYs8ZCLdoLmTm6X9L7cD6XmyxTQKz4D&authKey=yrHyw94BUR%2BJUcE79crSCy9Jn%2Bxq8kmar4k6vpVIxRpVW5rAvJmI4x3d6vPDrHgB&noverify=0&group_code=326269799" target="_blank"><img src="https://pub.idqqimg.com/wpa/images/group.png" alt="zblog建站交流" title="zblog建站交流"></a>（验证：zblog）</p>
	</td>
	</tr>	
</table>
<form id="form1" name="form1" method="post">	
    <table width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
	<input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken();?>">
		<tr>
			<th width="15%"><p align="center">选项名称</p></th>
			<th width="50%"><p align="center">选项内容</p></th>
			<th width="25%"><p align="center">选项说明</p></th>
		</tr>
	  <tr>
        <td width="20%"  align="center"><p>logo文字</p></td>
        <td>
          <p><input type="text" name="logo" id="logo" style="width:98%;" value="<?php echo $zbp->Config('Jz52_pureblog')->logo;?>"/></p>
		</td>
		<td><p align="left">logo文字</p></td>
      </tr>
	  <tr>
        <td width="20%"  align="center"><p>备案号</p></td>
        <td>
          <p><input type="text" name="beian" id="beian" style="width:98%;" value="<?php echo $zbp->Config('Jz52_pureblog')->beian;?>"/></p>
		</td>
		<td><p align="left">备案号</p></td>
      </tr>
	  <tr>
        <td width="20%"  align="center"><p>生成缩略图</p></td>
        <td>
          <p align="left"><input type="text" id="Thumb" name="Thumb" class="checkbox" value="<?php echo $zbp->Config('Jz52_pureblog')->Thumb;?>"/></p>
		</td>
		<td><p align="left">启用后生成缩略图，关闭则使用原图</p></td>
      </tr>
	</table>
	<br />
	<input name="submit" type="Submit" class="button" style="width:15%;" value="保存"/>
</form>
<?php } 
if($act == 'seo'){	
?>
<form id="form2" name="form2" method="post">	
    <table width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
	<input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken();?>">
		<tr>
			<th width="15%"><p align="center">选项名称</p></th>
			<th width="50%"><p align="center">选项内容</p></th>
			<th width="25%"><p align="center">选项说明</p></th>
		</tr>
		<tr>
			<td><label for="seo"><p align="center">主题SEO设置</p></label></td>
			<td><p align="left"><input type="text" id="seo" name="seo" class="checkbox" value="<?php echo $zbp->Config('Jz52_pureblog')->seo;?>"/></p></td>
			<td><p align="left">选择是否使用主题自带SEO设置，如果安装了seo插件需关闭。</p></td>
		</tr>
		<tr>
      <td><label for="seotitle">
        <p align="center">站点标题</p>
        </label></td>
      <td><p align="left"><input type="text" name="seotitle" id="seotitle" style="width:80%;" value="<?php echo $zbp->Config('Jz52_pureblog')->seotitle;?>"/><?php  if($zbp->subname){echo ' - ' .$zbp->subname;} ?></p></td>
      <td><p align="left">自定义网站首页标题，副标题在网站设置中设置，留空则不显示</p></td>
    </tr>
		<tr>
			<td><label for="seokeywords"><p align="center">关键词</p></label></td>
			<td><p align="left"><input type="text" name="seokeywords" id="seokeywords" style="width:98%;" value="<?php echo $zbp->Config('Jz52_pureblog')->seokeywords;?>"/></p></td>
			<td><p align="left">自定义网站关键词，多个关键词用英文逗号隔开</p></td>
		</tr>
		<tr>
			 <td><label for="seodescription"><p align="center">网站描述</p></label></td>
			<td><p align="left"><textarea name="seodescription" type="text" id="seodescription" style="width:98%;"><?php echo $zbp->Config('Jz52_pureblog')->seodescription;?></textarea></p></td>
			<td><p align="left">自定义网站描述</p></td>
		</tr>
		<tr>
			<td><label for="nseo"><p align="center">其他SEO</p></label></td>
			<td><p align="left"><input type="text" id="nseo" name="nseo" class="checkbox" value="<?php echo $zbp->Config('Jz52_pureblog')->nseo;?>"/></p></td>
			<td><p align="left">开启后文章、列表可自定义关键词、摘要等，如果安装了seo插件需关闭。</p></td>
		</tr>
	</table>
	<br />
	<input name="submit" type="Submit" class="button" style="width:15%;" value="保存"/>
</form>
<?php
    }	
?>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_pureblog");
</script> 
<?php
if ($zbp->CheckPlugin('UEditor')) {	
	echo '<script type="text/javascript" src="'.$zbp->host.'zb_users/plugin/UEditor/ueditor.config.php"></script>';
	echo '<script type="text/javascript" src="'.$zbp->host.'zb_users/plugin/UEditor/ueditor.all.min.js"></script>';
	echo '<script type="text/javascript" src="'.$zbp->host.'zb_users/theme/Jz52_pureblog/function/js/lib.upload.js"></script>';
	}
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
?>