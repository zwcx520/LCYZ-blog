<?php
#注册插件
RegisterPlugin("Jz52_pureblog","ActivePlugin_Jz52_pureblog");
function ActivePlugin_Jz52_pureblog() {
	global $zbp;
	Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Jz52_pureblog_AddMenu');
	if ($zbp->Config('Jz52_pureblog')->nseo&&$zbp->Config('Jz52_pureblog')->seo){
	Add_Filter_Plugin('Filter_Plugin_Edit_Response5', 'Jz52_pureblog_Filter_Plugin_Edit_Response5');
	Add_Filter_Plugin('Filter_Plugin_Category_Edit_Response', 'Jz52_pureblog_Category_Edit_Response');
	}
	$zbp->lang['msg']['sidebar'] = '首页侧栏';
    $zbp->lang['msg']['sidebar2'] = '列表侧栏';
    $zbp->lang['msg']['sidebar3'] = '文章侧栏';
    $zbp->lang['msg']['sidebar4'] = '单页侧栏';
    $zbp->lang['msg']['sidebar5'] = '其他侧栏';
}
function Jz52_pureblog_AddMenu(&$m) {
	global $zbp;
	$m[] = MakeTopMenu("root", '主题配置', $zbp->host . "zb_users/theme/Jz52_pureblog/main.php?act=config", "", "topmenu_Jz52_pureblog", "icon-x-diamond-fill");
}
function Jz52_pureblog_SubMenu($id){
	$arySubMenu = array(
		0 => array('基本设置', 'config', 'left', false),
		1 => array('SEO设置', 'seo', 'left', false),
	);
	foreach($arySubMenu as $k => $v){
		echo '<a href="?act='.$v[1].'" '.($v[3]==true?'target="_blank"':'').'><span class="m-'.$v[2].' '.($id==$v[1]?'m-now':'').'">'.$v[0].'</span></a>';
	}
}	
function Jz52_pureblog_Category_Edit_Response() {
		global $zbp, $cate;
		echo '<p><span class="title">标题:(主题自带seo功能)</span><br /><input style="width:95%" name="meta_flbt" value="' . $cate->Metas->flbt . '"/></p><p><span class="title">关键词:(主题自带seo功能)</span><br /><input style="width:95%" name="meta_flgjc" value="' . $cate->Metas->flgjc . '"/></p>';
}
function Jz52_pureblog_Filter_Plugin_Edit_Response5() {
		global $zbp, $article;
		echo '<table width="99%"><tr><td width="20%">关键词(主题自带seo)</td><td width="80%"><input style="width:95%" name="meta_nrgjc" value="' . $article->Metas->nrgjc . '"/></td></tr><tr><td>描述(主题自带seo)</td><td><input style="width:95%" name="meta_nrms" value="' . $article->Metas->nrms . '"/></td></tr></table>';
}
function Jz52_pureblog_IMG( $article, $w=400, $h=400, $c=false) {
  global $zbp;

	  if ( $zbp->Config( 'Jz52_pureblog' )->Thumb ) {
		$Thumb = $article->Thumbs( $w, $h, 1, $c);
		if ( isset( $Thumb[ 0 ] ) ) {
		  $img = $Thumb[0];
		} else {
		  if ( $article->ImageCount ) {
			$img = $article->AllImages[0];
		  }else{
			$img = '';
		  }
		}
	  } else {
		if ( $article->ImageCount ) {
		  $img = $article->AllImages[0];
		}else{
		  $img = '';
		}
	  }
	  $imghtml=$img?'<img src="'.$img.'" alt="'.$article->Title.'">':'';
  return $imghtml;
}
function Jz52_pureblog_Footer(){
	global $zbp;

	echo '<footer class="jz52bq"><p class="text-muted">'.$zbp->option['ZC_BLOG_COPYRIGHT'];
	if($zbp->Config('Jz52_pureblog')->beian){
	echo ' <a href="https://beian.miit.gov.cn/" rel="nofollow" target="_blank">'.$zbp->Config('Jz52_pureblog')->beian.'</a>';
	}
	echo $zbp->Config('Jz52_pureblog')->footer;
}
function InstallPlugin_Jz52_pureblog() {
	global $zbp;
	if ( !$zbp->HasConfig('Jz52_pureblog') ) {
		$zbp->Config('Jz52_pureblog')->Version = '1.0.1';

		$zbp->Config('Jz52_pureblog')->logo = '纯粹博客';
        $zbp->Config('Jz52_pureblog')->seotitle = '网站标题';
        $zbp->Config('Jz52_pureblog')->seokeywords = '网站关键字,用英文的逗号隔开';
        $zbp->Config('Jz52_pureblog')->seodescription = '用一段话描述你的网站';
		$zbp->Config('Jz52_pureblog')->footer = ' Powered: <a href="https://www.zblogcn.com/" target="_blank">Z-BlogPHP</a> Themes: <a href="https://gebilaoli.com/" target="_blank" title="隔壁老李">GebiLaoli</a></p></footer><script src="'.$zbp->host.'zb_users/theme/Jz52_pureblog/script/custom.js"></script>';
		$zbp->SaveConfig('Jz52_pureblog');
	}
}
function UninstallPlugin_Jz52_pureblog() {
	global $zbp;
	if ($zbp->Config('Jz52_pureblog')->DelCon){
		$zbp->DelConfig('Jz52_pureblog');
	}
}