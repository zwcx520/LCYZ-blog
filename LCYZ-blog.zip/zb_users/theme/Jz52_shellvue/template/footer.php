{* Template Name:公用页脚模板 *}
</main>
<!-- Terminal Command Input (Vue) -->
<div id="terminal-input-root" class="mt-4 flex-shrink-0"></div>
<!-- Terminal Footer -->
<footer class="border-terminal-dim text-terminal-dim mt-2 flex flex-shrink-0 flex-col justify-between border-t border-dashed py-2 text-xs md:flex-row">
  <div class="flex flex-wrap gap-x-4 gap-y-1">
    <a href="{$host}" class="hover:text-terminal-green inline-flex min-h-10 items-center transition-colors md:min-h-0">[INDEX]</a>
    <a href="{Jz52_shellvue_url('cat')}" class="hover:text-terminal-green inline-flex min-h-10 items-center transition-colors md:min-h-0">[CATEGORY]</a>
    <a href="{Jz52_shellvue_url('tag')}" class="hover:text-terminal-green inline-flex min-h-10 items-center transition-colors md:min-h-0">[TAG]</a>
    <a href="{Jz52_shellvue_url('arch')}" class="hover:text-terminal-green inline-flex min-h-10 items-center transition-colors md:min-h-0">[ARCHIVES]</a>
{if $zbp->Config('Jz52_shellvue')->show_search != '0'}
    <button type="button" data-terminal-action="search" class="hover:text-terminal-green inline-flex min-h-10 cursor-pointer items-center bg-transparent p-0 font-mono text-xs transition-colors md:min-h-0">[SEARCH]</button>
{/if}
{if $zbp->Config('Jz52_shellvue')->api_base_url}
    <button type="button" data-terminal-action="login" class="hover:text-terminal-green inline-flex min-h-10 cursor-pointer items-center bg-transparent p-0 font-mono text-xs transition-colors md:min-h-0">[LOGIN]</button>
{/if}
  </div>
  <div class="flex flex-col text-right md:flex-row md:gap-4 md:text-left">
    <div class="flex gap-4">{Jz52_shellvue_Footer()}</div>
    <div>&copy; {php}echo date('Y');{/php} <a href="{$host}" class="hover:text-terminal-green transition-colors">{$name}</a> · Powered by <a href="https://www.zblogcn.com/" target="_blank" rel="nofollow" class="hover:text-terminal-green transition-colors">Z-BlogPHP</a> · Theme <a href="https://app.zbp.cool/" title="不见桃花不见秋" class="hover:text-terminal-green transition-colors">GebiLaoli</a></div>
  </div>
</footer>
</div>
</div>
{if $zbp->Config('Jz52_shellvue')->custom_head}{$zbp->Config('Jz52_shellvue')->custom_head}{/if}
<style>
.sky-search-modal{position:fixed;inset:0;z-index:100;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.6);padding:1rem;backdrop-filter:blur(4px)}
.sky-search-open{display:flex}
.sky-search-box{width:100%;max-width:42rem;border:1px solid var(--terminal-dim);background:var(--terminal-bg);box-shadow:0 0 40px var(--terminal-glow);padding:1rem}
.sky-search-prompt{font-family:var(--terminal-font-family);font-size:.75rem;color:var(--terminal-dim);margin-bottom:.5rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sky-search-user{color:var(--terminal-text)}
.sky-search-echo{color:var(--terminal-text)}
.sky-search-input{width:100%;background:transparent;border:1px dashed var(--terminal-dim);color:var(--terminal-text);font-family:var(--terminal-font-family);font-size:.75rem;padding:.5rem .75rem;outline:none;margin-bottom:.5rem}
.sky-search-input:focus{border-color:var(--terminal-text);box-shadow:0 0 8px var(--terminal-glow)}
.sky-search-hint{font-family:var(--terminal-font-family);font-size:.625rem;color:var(--terminal-dim)}
</style>
<!-- Terminal Search Modal (Vue) -->
<div id="sky-search-modal-root"></div>
<!-- Terminal Login Modal (Vue) -->
<div id="sky-login-modal-root"></div>
{$footer}
</body>
</html>
