{* Template Name:搜索模板 *}
{template:header}
<div id="app" class="px-2 md:px-0"></div>
{template:footer}
