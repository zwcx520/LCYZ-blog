{* Template Name:文章及独立页面模板 *}
{template:header}
<div id="app" class="min-w-0 px-2 md:px-0"></div>
{template:footer}
