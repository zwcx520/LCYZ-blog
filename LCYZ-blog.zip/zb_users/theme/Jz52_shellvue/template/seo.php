{* Template Name:SEO模板 *}
{php}
$skySeoTitle = '';
$skySeoKeywords = '';
$skySeoDescription = '';
$skySeoUrl = $host;
if ($type == 'index') {
    $skySeoTitle = $zbp->Config('Jz52_shellvue')->seotitle;
    if ($skySeoTitle == '') {
        $skySeoTitle = $zbp->name;
    }
    $skySeoKeywords = $zbp->Config('Jz52_shellvue')->seokeywords;
    $skySeoDescription = $zbp->Config('Jz52_shellvue')->seodescription;
    if ($page != '' && $page != '1') {
        $skySeoTitle = $skySeoTitle . ' - 第' . $page . '页';
    }
} elseif ($type == 'category') {
    $skySeoTitle = $category->Name;
    $skySeoKeywords = $category->Intro;
    $skySeoDescription = $category->Intro;
    if (isset($category->Metas->seotitle) && $category->Metas->seotitle) {
        $skySeoTitle = $category->Metas->seotitle;
    }
    if (isset($category->Metas->seodescription) && $category->Metas->seodescription) {
        $skySeoDescription = $category->Metas->seodescription;
    }
    $skySeoUrl = $category->Url;
} elseif ($type == 'tag') {
    $skySeoTitle = $tag->Name;
    $skySeoKeywords = $tag->Name;
    $skySeoDescription = $tag->Name;
    $skySeoUrl = $tag->Url;
} elseif ($type == 'author') {
    $skySeoTitle = $author->Name;
    $skySeoKeywords = $author->Name;
    $skySeoDescription = $author->Name;
    $skySeoUrl = $author->Url;
} elseif ($type == 'date') {
    $skySeoTitle = $date;
    $skySeoKeywords = '';
    $skySeoDescription = '';
    $skySeoUrl = $host;
} elseif ($type == 'search') {
    $skySeoTitle = '搜索：' . $search;
    $skySeoKeywords = '';
    $skySeoDescription = '';
    $skySeoUrl = $host;
} elseif ($type == 'article' || $type == 'page') {
    $skySeoTitle = $article->Title;
    $skySeoKeywords = '';
    $skySeoDescription = '';
    if ($type == 'page') {
        $skySeoTitle = $article->Title;
    }
    if (isset($article->Tags)) {
        foreach ($article->Tags as $skyT) {
            $skySeoKeywords .= $skyT->Name . ',';
        }
    }
    $skySeoDescription = trim(FormatString($article->Content, '[nohtml]'));
    if (isset($article->Metas->seotitle) && $article->Metas->seotitle) {
        $skySeoTitle = $article->Metas->seotitle;
    }
    if (isset($article->Metas->seokeywords) && $article->Metas->seokeywords) {
        $skySeoKeywords = $article->Metas->seokeywords;
    }
    if (isset($article->Metas->seodescription) && $article->Metas->seodescription) {
        $skySeoDescription = $article->Metas->seodescription;
    }
    $skySeoUrl = $article->Url;
}
if ($skySeoDescription) {
    $skySeoDescription = mb_substr(str_replace(array("\r\n", "\n", "\r", " "), '', $skySeoDescription), 0, 120) . '…';
}
echo '<title>' . htmlspecialchars($skySeoTitle) . ' - ' . htmlspecialchars($zbp->name) . '</title>' . "\n";
if ($skySeoKeywords) {
    echo '<meta name="keywords" content="' . htmlspecialchars($skySeoKeywords) . '">' . "\n";
}
if ($skySeoDescription) {
    echo '<meta name="description" content="' . htmlspecialchars($skySeoDescription) . '">' . "\n";
}
echo '<link rel="canonical" href="' . $skySeoUrl . '">' . "\n";
if ($type == 'index' && ($page == '' || $page == '1')) {
    echo '<link rel="alternate" type="application/rss+xml" href="' . $feedurl . '" title="' . htmlspecialchars($zbp->name) . '">' . "\n";
}
{/php}
