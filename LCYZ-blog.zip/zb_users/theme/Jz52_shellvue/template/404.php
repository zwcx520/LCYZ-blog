{* Template Name:404错误页模板 *}
{php}
$skyPageType = '404';
# 数据源模式（前后端完全分离）：当前站没有对应文章时由本 404 页承载，
# 从 URL 解析文章 ID 注入前端，前端通过同源代理从数据源站拉取并渲染文章。
$sky404PostId = 0;
$sky404Carried = false;
if ($zbp->Config('Jz52_shellvue')->api_base_url != '') {
    $sky404Uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $sky404Path = preg_replace('#\?.*$#', '', $sky404Uri);
    # 常见 Z-Blog 文章 URL：/post/123.html、/post-123.html、/分类别名/123.html、/123.html、?id=123
    if (preg_match('#/(?:post|article|read|view)[-/](\d+)(?:\.html?)?$#i', $sky404Path, $m)
        || preg_match('#/(\d+)(?:\.html?)?$#i', $sky404Path, $m)
        || preg_match('#[?&]id=(\d+)#i', $sky404Uri, $m)) {
        $sky404PostId = (int) $m[1];
        $sky404Carried = true;
        # 文章真实存在于数据源站：HTTP 状态改为 200（内容将由前端渲染）
        if (!headers_sent()) {
            header('HTTP/1.1 200 OK', true);
            header('Status: 200 OK', true);
        }
    }
    # 分类/标签独立页 URL（/category-{ID}.html、/tags-{ID}.html 及别名）也由本 404 页承载，
    # 前端 resolveRemoteParams 解析 ID/别名后从数据源站拉取对应文章列表（HTTP 200，内容前端渲染）
    if (preg_match('#/(?:category|tags?|author)-[^./]+?(?:\.html?)?$#i', $sky404Path)
        || preg_match('#/(?:tag|category|author)/[^/]+?(?:\.html?)?$#i', $sky404Path)) {
        $sky404Carried = true;
        if (!headers_sent()) {
            header('HTTP/1.1 200 OK', true);
            header('Status: 200 OK', true);
        }
    }
}
{/php}
{template:header}
<div id="app" class="min-w-0 px-2 md:px-0"></div>
{if $skyPageType == '404' && ($sky404PostId > 0 || $sky404Carried)}
{else}
<div class="flex min-w-0 flex-col items-center justify-center px-2 py-4 md:px-0">
  <div class="border-terminal-green/60 bg-terminal-black w-full max-w-2xl min-w-0 border shadow-[0_0_30px_var(--terminal-glow)]">
    <div class="border-terminal-green/60 flex items-center justify-between border-b px-3 py-1">
      <span class="text-terminal-green text-xs">SYSTEM RESPONSE</span>
      <span class="text-terminal-dim text-xs">[404]</span>
    </div>
    <div class="p-4 md:p-6">
      <h1 class="text-terminal-green mb-2 text-2xl font-bold md:text-3xl">HTTP 404</h1>
      <p class="text-terminal-dim mb-4 text-xs md:text-sm">The page you are looking for does not exist or has been moved.</p>
      <div class="border-terminal-green/60 mb-4 border p-3 font-mono text-xs md:text-sm">
        <div class="text-terminal-dim">$ <span class="text-terminal-green">ls -la ./page</span></div>
        <div class="text-terminal-green">404: Page not found: No such file or directory</div>
      </div>
      <div class="text-terminal-dim mb-2 font-mono text-xs">RECOVERY OPTIONS:</div>
      <div class="flex flex-wrap gap-3 font-mono text-xs md:text-sm">
        <a href="{$host}" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex items-center border px-4 py-1 transition-colors">cd /</a>
        <button type="button" onclick="window.history.back()" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex cursor-pointer items-center border bg-transparent px-4 py-1 font-mono transition-colors">back</button>
      </div>
    </div>
  </div>
</div>
{/if}
{template:footer}
