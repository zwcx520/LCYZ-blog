{* Template Name:首页及列表页模板 *}
{template:header}
<div id="app" class="px-2 md:px-0"></div>
{template:footer}
