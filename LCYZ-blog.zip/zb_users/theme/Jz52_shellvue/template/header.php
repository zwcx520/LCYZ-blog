{* Template Name:公用页头模板 *}
{php}
# 配色（未配置时为空，自然落入默认绿色分支）
$skyPreset = $zbp->Config('Jz52_shellvue')->color_preset;
$skyPri = '#00ff00';
$skyBg = '#0d0d0d';
if ($skyPreset == 'amber') {
    $skyPri = '#ffb000';
    $skyBg = '#1a0f00';
} elseif ($skyPreset == 'phosphor_blue') {
    $skyPri = '#00ffff';
    $skyBg = '#000814';
} elseif ($skyPreset == 'cyberpunk') {
    $skyPri = '#ff00cc';
    $skyBg = '#110022';
} elseif ($skyPreset == 'alert_blood') {
    $skyPri = '#ff2222';
    $skyBg = '#1c0505';
} elseif ($skyPreset == 'custom') {
    if ($zbp->Config('Jz52_shellvue')->custom_primary_color) {
        $skyPri = $zbp->Config('Jz52_shellvue')->custom_primary_color;
    }
    if ($zbp->Config('Jz52_shellvue')->custom_bg_color) {
        $skyBg = $zbp->Config('Jz52_shellvue')->custom_bg_color;
    }
}
# 开关
$skyFlicker = ($zbp->Config('Jz52_shellvue')->enable_flicker == '1');
$skyScanline = ($zbp->Config('Jz52_shellvue')->enable_scanline != '0');
$skyDebug = ($zbp->Config('Jz52_shellvue')->debug_mode == '1');
$skyShowHeader = ($zbp->Config('Jz52_shellvue')->show_header != '0');
$skyShowLogin = ($zbp->Config('Jz52_shellvue')->show_login != '0');
$skyShowSearch = ($zbp->Config('Jz52_shellvue')->show_search != '0');
$skyCompact = ($zbp->Config('Jz52_shellvue')->compact_mode == '1');
$skyShowScrollbar = ($zbp->Config('Jz52_shellvue')->show_scrollbar == '1');
$skyLsSim = ($zbp->Config('Jz52_shellvue')->show_ls_simulation != '0');
$skyPinned = ($zbp->Config('Jz52_shellvue')->show_pinned_folders != '0');
$skyAsciiTitle = $zbp->Config('Jz52_shellvue')->ascii_title_text;
if ($skyAsciiTitle == '') {
    $skyAsciiTitle = $zbp->name;
}
$skyAsciiFont = $zbp->Config('Jz52_shellvue')->ascii_font;
if ($skyAsciiFont == '') {
    $skyAsciiFont = 'Standard';
}
$skyUser = $user->ID > 0 ? $user->Name : 'guest';
# 独立页模板（时光归档/分类列表/标签列表）由各模板预先设置 $skyPageType；
# 自定义路由（archives.html 等）由 include.php 回调写入 $GLOBALS['sky_page_type']。
$skyPageType = isset($GLOBALS['sky_page_type']) ? $GLOBALS['sky_page_type'] : (isset($skyPageType) ? $skyPageType : '');
$skyCustomPage = $skyPageType ? true : false;
$skyIsReader = ($type == 'article' || ($type == 'page' && !$skyCustomPage));
# 页面类型（独立页模板可预先设置 $skyPageType）
$skyType = 'index';
if ($skyCustomPage) {
    $skyType = $skyPageType;
} elseif ($type == 'category') {
    $skyType = 'category';
} elseif ($type == 'tag') {
    $skyType = 'tag';
} elseif ($type == 'author') {
    $skyType = 'author';
} elseif ($type == 'article') {
    $skyType = 'post';
} elseif ($type == 'page') {
    $skyType = 'page';
} elseif ($type == 'date') {
    $skyType = 'date';
} elseif ($type == 'search') {
    $skyType = 'search';
}
# 分类与标签（终端虚拟目录用；slug 用别名或名称，便于按显示名 cd）
$skyNavSlug = function ($o) {
    return ($o->Alias !== '' && $o->Alias !== null) ? $o->Alias : $o->Name;
};
$skyCats = array();
$skyTags = array();
$skyCatList = $zbp->GetCategoryList();
if (count($skyCatList) > 0) {
    foreach ($skyCatList as $skyC) {
        $skyCats[] = array(
            'metadata' => array('name' => (string) $skyC->ID),
            'spec' => array('displayName' => $skyC->Name, 'slug' => $skyNavSlug($skyC)),
            'status' => array('permalink' => $skyC->Url),
            'postCount' => (int) $skyC->Count,
        );
    }
}
# 当前对象
$skyCurCat = null;
if ($type == 'category' && isset($category)) {
    $skyCurCat = array('id' => (int) $category->ID, 'displayName' => $category->Name, 'permalink' => $category->Url, 'slug' => $skyNavSlug($category), 'count' => (int) $category->Count);
}
$skyCurTag = null;
if ($type == 'tag' && isset($tag)) {
    $skyCurTag = array('id' => (int) $tag->ID, 'displayName' => $tag->Name, 'permalink' => $tag->Url, 'slug' => $skyNavSlug($tag), 'count' => (int) $tag->Count);
}
$skyCurAuthor = null;
if ($type == 'author' && isset($author)) {
    $skyCurAuthor = array('id' => (int) $author->ID, 'displayName' => $author->StaticName, 'permalink' => $author->Url, 'slug' => (string) $author->ID);
}
$skyCurPost = null;
$skyCurPage = null;
$skyNext = null;
$skyPrev = null;
$skyPost = null;
if (($type == 'article' || ($type == 'page' && !$skyCustomPage)) && isset($article)) {
    $skyCur = array('permalink' => $article->Url, 'slug' => Jz52_shellvue_slug($article), 'title' => $article->Title);
    $skyPost = array(
        'id' => (int) $article->ID,
        'title' => $article->Title,
        'url' => $article->Url,
        'lock' => (bool) $article->IsLock,
        'commentPostUrl' => html_entity_decode($article->CommentPostUrl, ENT_QUOTES, 'UTF-8'),
    );
    if ($type == 'article') {
        $skyCurPost = $skyCur;
        if ($article->Prev) {
            $skyPrev = $article->Prev->Url;
        }
        if ($article->Next) {
            $skyNext = $article->Next->Url;
        }
    } else {
        $skyCurPage = $skyCur;
    }
}
# 分页
$skyPagebar = null;
if (isset($pagebar) && $pagebar->PageAll > 1) {
    $skyPagebar = array(
        'hasPrev' => $pagebar->PageNow > 1,
        'hasNext' => $pagebar->PageNow < $pagebar->PageAll,
        'prevUrl' => $pagebar->PageNow > 1 ? $pagebar->PrevButton : null,
        'nextUrl' => $pagebar->PageNow < $pagebar->PageAll ? $pagebar->NextButton : null,
    );
}
$skyPageNow = (isset($pagebar) && $pagebar->PageNow > 1) ? $pagebar->PageNow : 1;
# API 相关：当前页每页数量与服务器分页保持一致（API 上限 50）
$skyDisplay = (int) $zbp->option['ZC_DISPLAY_COUNT'];
if ($skyDisplay < 1) {
    $skyDisplay = 10;
}
if ($skyDisplay > 50) {
    $skyDisplay = 50;
}
$skySearch = '';
if ($type == 'search') {
    $skySearch = GetVars('q', 'GET', '');
}
$skyDate = '';
if ($type == 'date' && isset($date) && $date !== '') {
    $skyDate = $date;
}
$skyUserInfo = null;
if ($user->ID > 0) {
    $skyUserInfo = array(
        'name' => $user->Name,
        'email' => $user->Email,
        'homePage' => $user->HomePage,
        'staticName' => $user->StaticName,
    );
}
# 评论验证码：仅访客且后台开启评论验证码时显示（本地模式读当前站开关；
# 远程模式下以数据源站 basic_info 的 comment_verify_enable 为准，由前端 remoteInit 拉取，此处强制 false 避免误显）
$skyCommentVerify = ((string) $zbp->Config('Jz52_shellvue')->api_base_url === '' && $user->ID == 0 && $zbp->option['ZC_COMMENT_VERIFY_ENABLE'] == 1);
# 数据源模式（前后端完全分离）：后台填写另一个 Z-Blog 站点的 api.php 地址后，
# 前端所有数据（列表/文章/归档/搜索/评论）均通过主题自带同源代理从该站读取。
$skyRemote = ($zbp->Config('Jz52_shellvue')->api_base_url != '');
$skyApiUrl = $skyRemote ? rtrim($zbp->Config('Jz52_shellvue')->api_base_url, '/') : $host . 'zb_system/api.php';
$skyProxyUrl = $skyRemote ? $host . 'zb_users/theme/' . $theme . '/proxy.php' : '';
$skyRemoteRoot = '';
if ($skyRemote) {
    $skyRemoteRoot = preg_replace('#/zb_system/api\.php$#i', '', $skyApiUrl);
}
if ($skyRemote) {
    # 远程模式 404 页（当前站无此文章）：由前端从数据源站渲染，HTTP 状态改为 200
    if ($skyType == '404' && isset($sky404PostId) && $sky404PostId > 0) {
        http_response_code(200);
    }
    # 远程模式：当前站不注入任何内容数据，分类/标签由前端从数据源站 API 拉取
    $skyCats = array();
    $skyTags = array();
    $skyCurCat = null;
    $skyCurTag = null;
    $skyCurAuthor = null;
    $skyCurPost = null;
    $skyCurPage = null;
    $skyPrev = null;
    $skyNext = null;
    $skyPost = null;
}
# 标签分页：仅在标签页注入当前页标签（每页 30），其余页面不注入标签内容；
# 总标签数用 SQL COUNT 获取（不实例化全量 Tag 对象），供首页 ls 计数与分页计算。
# 远程模式保持为空（前端从数据源站 API 按页拉取）。
$skyTagPage = 1;
$skyTagTotal = 0;
$skyTagPageAll = 1;
if (!$skyRemote) {
    if ($skyType == 'tags') {
        $skyTagPage = max(1, (int) GetVars('page', 'GET', '1'));
    }
    $skyTagCountRows = $zbp->db->Query($zbp->db->sql->Count($zbp->table['Tag'], array(array('COUNT', '*', 'num'))));
    $skyTagTotal = (isset($skyTagCountRows[0]['num'])) ? (int) $skyTagCountRows[0]['num'] : 0;
    $skyTagPageAll = max(1, (int) ceil($skyTagTotal / 30));
    if ($skyTagPage > $skyTagPageAll) {
        $skyTagPage = $skyTagPageAll;
    }
    if ($skyType == 'tags' && $skyTagTotal > 0) {
        $skyTagList = $zbp->GetTagList('', '', array('tag_ID' => 'ASC'), array(($skyTagPage - 1) * 30, 30));
        if (count($skyTagList) > 0) {
            foreach ($skyTagList as $skyT) {
                $skyTags[] = array(
                    'metadata' => array('name' => (string) $skyT->ID),
                    'spec' => array('displayName' => $skyT->Name, 'slug' => $skyNavSlug($skyT)),
                    'status' => array('permalink' => $skyT->Url),
                    'postCount' => (int) $skyT->Count,
                );
            }
        }
    }
}
# 汇总 JSON
$skyData = array(
    'apiUrl' => $skyApiUrl,
    'themeUrl' => $host . 'zb_users/theme/' . $theme . '/',
    'remote' => $skyRemote,
    'proxyUrl' => $skyProxyUrl,
    'remoteRoot' => $skyRemoteRoot,
    'categories' => $skyCats,
    'config' => array(
        'debug' => $skyDebug,
        'lsSim' => $skyLsSim,
        'pinned' => $skyPinned,
        'search' => $skyShowSearch,
    ),
    'currentCategory' => $skyCurCat,
    'currentPost' => $skyCurPost,
    'currentPage' => $skyCurPage,
    'currentAuthor' => $skyCurAuthor,
    'currentPosts' => null,
    'currentTag' => $skyCurTag,
    'date' => $skyDate,
    'nextPost' => $skyNext,
    'page' => $skyPageNow,
    'pageTitle' => isset($skyPageTitle) ? $skyPageTitle : '',
    'pageType' => $skyType,
    'siteName' => $zbp->name,
    'postId' => isset($sky404PostId) ? (int) $sky404PostId : 0,
    'pagination' => $skyPagebar,
    'perpage' => $skyDisplay,
    'post' => $skyPost,
    'prevPost' => $skyPrev,
    'search' => $skySearch,
    'tags' => $skyTags,
    'tagPage' => $skyTagPage,
    'tagPageAll' => $skyTagPageAll,
    'tagTotal' => $skyTagTotal,
    'urls' => array(
        'home' => $host,
        'categories' => Jz52_shellvue_url('cat'),
        'tags' => Jz52_shellvue_url('tag'),
        'archives' => Jz52_shellvue_url('arch'),
    ),
    'user' => $skyUser,
    'userId' => (int) $user->ID,
    'userInfo' => $skyUserInfo,
    'commentVerify' => $skyCommentVerify,
    'logoutUrl' => BuildSafeCmdURL('act=logout'),
    'verifyUrl' => $host . 'zb_system/cmd.php?act=verify&csrfToken=' . $zbp->GetCSRFToken('login', 'minute'),
);
$skyJson = json_encode($skyData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
{/php}
<!DOCTYPE html>
<html lang="{$language}" class="terminal-theme color-scheme-dark"{if $skyDebug} data-debug="true"{/if}>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="generator" content="{$zblogphp}">
{if $zbp->Config('Jz52_shellvue')->seo}{template:seo}{else}<title>{$name}-{$title}</title>{/if}
<link rel="stylesheet" href="{$host}zb_users/theme/{$theme}/style/style.css?v={$zbp->themeinfo['version']}">
<link rel="icon" href="{$host}zb_users/theme/{$theme}/style/images/theme-icon.png">
<style data-theme-navigation-style>
:root {
  --theme-color-primary: {$skyPri};
  --theme-color-bg: {$skyBg};
}
{if !$skyFlicker}
body { animation: none !important; }
{/if}
{if !$skyScanline}
body::before { display: none !important; }
{/if}
</style>
<script>
window.SearchWidget = window.SearchWidget || { open: function () { window.dispatchEvent(new CustomEvent('sky:open-search')); } };
</script>
<script src="{$host}zb_system/script/jquery-latest.min.js"></script>
<script src="{$host}zb_system/script/zblogphp.js"></script>
<script src="{$host}zb_system/script/c_html_js_add.php"></script>
<script src="{$host}zb_users/theme/{$theme}/script/vue/vue.global.prod.js?v={$zbp->themeinfo['version']}"></script>
<script src="{$host}zb_users/theme/{$theme}/script/figlet.js?v={$zbp->themeinfo['version']}"></script>
<script src="{$host}zb_users/theme/{$theme}/script/crtshellvue.js?v={$zbp->themeinfo['version']}" defer></script>
{$header}
</head>
<body class="terminal-viewport flex w-full flex-col overflow-hidden font-mono{if !$skyCompact} mx-auto max-w-5xl p-4 md:p-6{/if}">
<div class="mx-auto flex h-full w-full max-w-4xl min-w-0 flex-col">
{if $skyShowHeader}
  <header{if $skyIsReader} style="display:none"{/if} class="mb-2 flex-shrink-0 select-none md:mb-4">
    <div class="text-terminal-dim mb-2 text-xs">Last login: {php}echo date('D M d Y');{/php} on ttys001</div>
    <pre id="sky-ascii-title" data-title="{php}echo htmlspecialchars($skyAsciiTitle, ENT_QUOTES);{/php}" data-font="{$skyAsciiFont}" class="text-terminal-green hidden text-xs leading-none font-bold whitespace-pre opacity-80 md:block md:text-sm"></pre>
{if $skyShowLogin}
    <div class="text-terminal-green mt-1 flex items-center gap-2 md:mt-4">
      <div class="ml-auto flex gap-4 text-xs">
{if $skyRemote}
        <!-- 远程数据源模式：登录状态由前端 SkyAuthBar 接管（数据源站登录态/登出走数据源站 API），
             不再显示当前站后台登录态 -->
        <div id="sky-auth-bar" class="text-terminal-dim flex items-center gap-2 text-xs"></div>
{else}
{if $user.ID > 0}
        <div class="text-terminal-dim"><span class="mr-2">USER: <span class="text-terminal-green">{$user.Name}</span></span><a href="{php}echo BuildSafeCmdURL('act=logout');{/php}" class="hover:text-terminal-green inline-flex min-h-10 items-center md:min-h-0">[LOGOUT]</a></div>
{else}
        <button type="button" class="text-terminal-dim hover:text-terminal-green inline-flex min-h-10 cursor-pointer items-center bg-transparent p-0 font-mono text-xs transition-colors md:min-h-0" data-terminal-action="login">[LOGIN]</button>
{/if}
{/if}
      </div>
    </div>
{/if}
  </header>
{/if}
<p id="navigation-announcer" class="sr-only" role="status" aria-live="polite" aria-atomic="true"></p>
<main id="main" tabindex="{if $skyIsReader}0{else}-1{/if}"{if $skyShowScrollbar} data-show-scrollbar="true"{/if} class="relative min-w-0 flex-1 overflow-auto{if $skyIsReader || $skyShowScrollbar} scrollbar-terminal{else} scrollbar-hide{/if}">
<script id="skyblog-page-data" type="application/json">{$skyJson}</script>
