<?php
if (!defined('ZBP_PATH')) {exit('Access denied');}
return array(
    'menu_appearance' => '外观设置',
    'menu_basic' => '基础设置',
    'menu_features' => '功能开关',
    'menu_footer' => '页面设置',
    'menu_data' => '数据源',
    'menu_seo' => 'SEO设置',
    'menu_about' => '使用教程',
    'settings' => '主题配置',
    'save' => '保存设置',
);
