<?php
if (!defined('ZBP_PATH')) {exit('Access denied');}
return array(
    'menu_appearance' => '外觀設定',
    'menu_basic' => '基礎設定',
    'menu_features' => '功能開關',
    'menu_footer' => '頁面設定',
    'menu_data' => '資料源',
    'menu_seo' => 'SEO設定',
    'menu_about' => '使用教學',
    'settings' => '主題設定',
    'save' => '儲存設定',
);
