<?php
if (!defined('ZBP_PATH')) {exit('Access denied');}
return array(
    'menu_appearance' => 'Appearance',
    'menu_basic' => 'Basic',
    'menu_features' => 'Features',
    'menu_footer' => 'Page',
    'menu_data' => 'Data Source',
    'menu_seo' => 'SEO',
    'menu_about' => 'Help',
    'settings' => 'Theme Settings',
    'save' => 'Save',
);
