/*!
 * 架构：Vue 3（本地内置）+ Z-Blog 内置 JSON API（/zb_system/api.php）
 */
(function () {
'use strict';

/* 数据源站登录 token 的 localStorage 键名（必须在 Sky 初始化前定义：
   var 声明会提升但赋值不会，若放在 Sky.token = skyToken() 之后，
   skyToken() 读取时 SKY_TOKEN_KEY 仍为 undefined，导致永远读不到 token） */
var SKY_TOKEN_KEY = 'crtshellvue_token';

/* ==================== 0. 全局数据（服务端注入） ==================== */
var Sky = {};
(function () {
  var raw = null;
  try {
    var el = document.getElementById('skyblog-page-data');
    if (el && el.textContent) {
      raw = JSON.parse(el.textContent);
    }
  } catch (e) {
    raw = null;
  }
  raw = raw || {};
  Sky.pageType = raw.pageType || 'index';
  Sky.apiUrl = raw.apiUrl || '';
  Sky.remote = !!raw.remote;
  Sky.proxyUrl = raw.proxyUrl || '';
  Sky.remoteRoot = raw.remoteRoot || '';
  Sky.themeUrl = raw.themeUrl || '';
  Sky.home = (raw.urls && raw.urls.home) || (typeof location !== 'undefined' ? location.origin + '/' : '/');
  Sky.siteName = raw.siteName || document.title || '';
  Sky.siteSubname = raw.siteSubname || '';
  Sky.user = Sky.remote ? 'guest' : (raw.user || 'guest');
  Sky.userId = Sky.remote ? 0 : (raw.userId || 0);
  Sky.userInfo = Sky.remote ? null : (raw.userInfo || null);
  Sky.categories = raw.categories || [];
  Sky.tags = raw.tags || [];
  /* 标签分页元数据：仅标签页注入当前页标签（每页 30），tagTotal 为总标签数 */
  Sky.tagPage = raw.tagPage || 1;
  Sky.tagPageAll = raw.tagPageAll || 0;
  Sky.tagTotal = raw.tagTotal || 0;
  Sky.currentCategory = raw.currentCategory || null;
  Sky.currentTag = raw.currentTag || null;
  Sky.currentAuthor = raw.currentAuthor || null;
  Sky.currentPost = raw.currentPost || null;
  Sky.currentPage = raw.currentPage || null;
  Sky.currentPosts = raw.currentPosts || null;
  Sky.nextPost = raw.nextPost || null;
  Sky.prevPost = raw.prevPost || null;
  Sky.pagination = raw.pagination || null;
  Sky.page = raw.page || 1;
  Sky.perpage = raw.perpage || 10;
  Sky.date = raw.date || '';
  Sky.search = raw.search || '';
  Sky.postId = raw.postId || 0;
  Sky.post = raw.post || null;
  Sky.pageTitle = raw.pageTitle || '';
  Sky.commentVerify = !!raw.commentVerify;
  Sky.logoutUrl = raw.logoutUrl || '';
  Sky.verifyUrl = raw.verifyUrl || '';
  Sky.urls = raw.urls || { home: Sky.home, categories: '', tags: '', archives: '' };
  Sky.config = raw.config || {};
  /* 数据源站登录 token（localStorage 持久化；仅远程模式使用） */
  Sky.token = skyToken();
  /* 远程 basic_info（站点名/版权/评论验证码开关等） */
  Sky.siteInfo = null;
  /* 远程单标签名缓存（tag get 接口公开，按需拉取；tags.html 分页后不再全量加载 Sky.tags） */
  Sky.tagNames = {};
  /* 远程数据源站登录态（member get / basic_info.is_logged_in） */
  Sky.remoteLoggedIn = false;
})();

/* 数据源站登录 token 存取 */
function skyToken() {
  try { return window.localStorage.getItem(SKY_TOKEN_KEY) || ''; } catch (e) { return ''; }
}
function skySetToken(t) {
  try {
    if (t) { window.localStorage.setItem(SKY_TOKEN_KEY, t); } else { window.localStorage.removeItem(SKY_TOKEN_KEY); }
  } catch (e) {}
}

/* ==================== 1. 通用工具 ==================== */
function isDesktop() {
  return typeof window.matchMedia === 'function' && window.matchMedia('(min-width: 768px) and (pointer: fine)').matches;
}
function prefersReducedMotion() {
  return typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}
function scrollBehavior() {
  return prefersReducedMotion() ? 'auto' : 'smooth';
}
function scrollMain() {
  return document.getElementById('main');
}
var FOCUSABLE_SELECTOR = 'a[href], audio[controls], button, input, label[for], select, summary, textarea, video[controls], [contenteditable]:not([contenteditable="false"]), [tabindex]:not([tabindex="-1"]), [role="button"], [role="checkbox"], [role="combobox"], [role="link"], [role="listbox"], [role="menuitem"], [role="radio"], [role="slider"], [role="switch"], [role="textbox"]';
function isFocusableWithin(e) {
  var path = (e && e.composedPath) ? e.composedPath() : [e && e.target];
  return path.some(function (n) {
    return n instanceof Element && n !== document.getElementById('main') && n.matches(FOCUSABLE_SELECTOR);
  });
}
function isKeyboardBlocked(e) {
  return e.defaultPrevented || e.isComposing || e.repeat || e.altKey || e.ctrlKey || e.metaKey || isFocusableWithin(e);
}
function go(url) {
  if (url) {
    window.location.href = url;
  }
}
function ts2date(ts) {
  var t = parseInt(ts, 10);
  if (!isFinite(t) || t <= 0) {
    return null;
  }
  return new Date(t * 1000);
}
var MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function pad2(n) {
  return n < 10 ? '0' + n : '' + n;
}
function fmtTime(ts, style) {
  var d = ts2date(ts);
  if (!d) {
    return '—';
  }
  if (style === 'full') {
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
  }
  return MONTHS_SHORT[d.getMonth()] + ' ' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
}

/* ==================== 2. API 客户端 ==================== */
/*
 * Z-Blog API 的 JsonEncode 会递归对所有字符串执行 htmlspecialchars
 * （& < > " ' 均被转义，含正文 HTML 与 URL）。前端必须统一解码还原一次。
 */
function decodeEntities(s) {
  var d = document.createElement('textarea');
  d.innerHTML = String(s);
  return d.value;
}
function decodeDeep(v) {
  if (typeof v === 'string') {
    return decodeEntities(v);
  }
  if (Array.isArray(v)) {
    for (var i = 0; i < v.length; i++) {
      v[i] = decodeDeep(v[i]);
    }
    return v;
  }
  if (v && typeof v === 'object') {
    for (var k in v) {
      if (Object.prototype.hasOwnProperty.call(v, k)) {
        v[k] = decodeDeep(v[k]);
      }
    }
    return v;
  }
  return v;
}
function apiGet(params) {
  var qs = [];
  for (var k in params) {
    if (Object.prototype.hasOwnProperty.call(params, k)) {
      var v = params[k];
      if (v === undefined || v === null || v === '') {
        continue;
      }
      qs.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
    }
  }
  var apiTarget = Sky.apiUrl + (qs.length ? '?' + qs.join('&') : '');
  if (Sky.remote && Sky.proxyUrl) {
    apiTarget = Sky.proxyUrl + '?target=' + encodeURIComponent(apiTarget);
  }
  var reqHeaders = {};
  if (Sky.remote && Sky.token) {
    reqHeaders['X-Sky-Token'] = Sky.token;
  }
  return fetch(apiTarget, { credentials: 'same-origin', headers: reqHeaders })
    .then(function (res) {
      return res.json().catch(function () {
        return { code: res.status, message: 'HTTP ' + res.status, data: null };
      });
    })
    .then(function (j) {
      if (j && j.code === 200) {
        return decodeDeep(j.data);
      }
      var msg = (j && j.message) ? j.message : '接口调用失败';
      if (j && j.code === 503) {
        msg = 'API 接口未启用：请在后台「网站设置 → 全局设置」勾选「启用 API 接口」并清空缓存。';
      }
      var err = new Error(msg);
      err.code = j ? j.code : 0;
      throw err;
    });
}

/* 表单 POST 接口（登录/登出用）：params 为 query 参数，body 为 urlencoded 表单串 */
function apiPost(params, body) {
  var qs = [];
  for (var k in params) {
    if (Object.prototype.hasOwnProperty.call(params, k)) {
      var v = params[k];
      if (v === undefined || v === null || v === '') {
        continue;
      }
      qs.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
    }
  }
  var apiTarget = Sky.apiUrl + (qs.length ? '?' + qs.join('&') : '');
  if (Sky.remote && Sky.proxyUrl) {
    apiTarget = Sky.proxyUrl + '?target=' + encodeURIComponent(apiTarget);
  }
  var postHeaders = { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' };
  if (Sky.remote && Sky.token) {
    postHeaders['X-Sky-Token'] = Sky.token;
  }
  return fetch(apiTarget, { method: 'POST', credentials: 'same-origin', headers: postHeaders, body: body })
    .then(function (res) {
      return res.json().catch(function () {
        return { code: res.status, message: 'HTTP ' + res.status, data: null };
      });
    })
    .then(function (j) {
      if (j && j.code === 200) {
        return decodeDeep(j.data);
      }
      var msg = (j && j.message) ? j.message : '接口调用失败';
      var err = new Error(msg);
      err.code = j ? j.code : 0;
      throw err;
    });
}

/* ==================== 2.5 远程数据源模式 ==================== */
/*
 * 远程模式（后台配置了另一个 Z-Blog 站的 api.php 地址）下：
 *  - 所有 API 请求经 proxyify 改写为同源代理地址（proxy.php），绕过浏览器跨域；
 *  - 当前站服务端不注入任何内容数据，页面参数（文章/分类/作者/日期/搜索）从当前
 *    页面 URL 解析（URL 规则与数据源站保持一致，支持动态规则 post/114.html、
 *    category-1.html、tag-1.html、author-1.html、2026-09.html 及别名/伪静态后缀）。
 */
function proxyify(url) {
  if (!Sky.remote || !Sky.proxyUrl || !url) {
    return url;
  }
  return Sky.proxyUrl + '?target=' + encodeURIComponent(url);
}

/* 远程模式：把数据源站返回的绝对 URL 改写为当前站地址（保留路径/参数），
 * 使列表/分类/标签等导航都在当前站内完成，不跳出到数据源站。 */
function localizeUrl(u) {
  if (!u || !Sky.remote) {
    return u;
  }
  try {
    var p = new URL(u, location.origin);
    return location.origin + p.pathname + p.search + p.hash;
  } catch (e) {
    return u;
  }
}
function localizePost(p) {
  if (p && p.Url) {
    p.Url = localizeUrl(p.Url);
  }
  return p;
}

var remoteParamsCache = null;
function resolveRemoteParams() {
  if (remoteParamsCache) {
    return remoteParamsCache;
  }
  var params = {};
  var path = (typeof location !== 'undefined') ? location.pathname : '';
  var m;
  if ((m = path.match(/\/(?:post|article)\/(\d+)(?:\.html?)?$/i))) {
    params.id = parseInt(m[1], 10);
  } else if ((m = path.match(/(?:^|\/)post-(\d+)(?:\.html?)?$/i))) {
    params.id = parseInt(m[1], 10);
  } else if ((m = (typeof location !== 'undefined') ? location.search.match(/[?&]id=(\d+)/) : null)) {
    params.id = parseInt(m[1], 10);
  } else if ((m = path.match(/\/(\d+)(?:\.html?)?$/))) {
    params.id = parseInt(m[1], 10);
  } else if ((m = path.match(/(?:^|\/)category-([^.\/]+?)(?:\.html?)?$/i))) {
    if (/^\d+$/.test(m[1])) {
      params.cate_id = parseInt(m[1], 10);
    } else {
      params.cate_alias = decodeURIComponent(m[1]);
    }
  } else if ((m = path.match(/(?:^|\/)(?:tag|tags)-(\d+)(?:\.html?)?$/i))) {
    params.tag_id = parseInt(m[1], 10);
  } else if ((m = path.match(/(?:^|\/)author-(\d+)(?:\.html?)?$/i))) {
    params.auth_id = parseInt(m[1], 10);
  } else if ((m = path.match(/(?:^|\/)author-([^.\/]+?)(?:\.html?)?$/i))) {
    params.auth_name = decodeURIComponent(m[1]);
  } else if ((m = path.match(/(\d{4})-(\d{2})(?:-(\d{2}))?(?:\.html?)?$/))) {
    params.date = m[3] ? m[1] + '-' + m[2] + '-' + m[3] : m[1] + '-' + m[2];
  }
  var pg = (typeof URLSearchParams !== 'undefined' && typeof location !== 'undefined') ? new URLSearchParams(location.search).get('page') : null;
  if (pg && /^\d+$/.test(pg)) {
    params.page = parseInt(pg, 10);
  } else if ((m = path.match(/(?:^|\/)page[_-](\d+)(?:\.html?)?$/i))) {
    params.page = parseInt(m[1], 10);
  }
  var q = (typeof URLSearchParams !== 'undefined' && typeof location !== 'undefined') ? new URLSearchParams(location.search).get('q') : null;
  if (q) {
    params.search = q;
  } else if ((m = path.match(/(?:^|\/)search\/([^\/]+?)(?:\.html?)?$/i))) {
    params.search = decodeURIComponent(m[1]);
  }
  remoteParamsCache = params;
  return params;
}

/* 远程模式下统一设置 <title>：所有标题均以数据源站数据为准。
 * 在 remoteInit 的 basic_info / 分类 / 标签各数据就绪后分别调用一次，
 * 覆盖服务端渲染的当前站标题（本地有数据显示本地、没有则 “Good Luck To You!” 均为错误）。
 * 文章页除外：由 SkyPostView 在文章数据加载后设置。 */
function skyApplyTitle() {
  if (!Sky.remote) {
    return;
  }
  var st = Sky.siteName || '';
  var t = '';
  var rp = resolveRemoteParams();
  if (Sky.pageType === 'categories') {
    t = 'categories' + (st ? ' - ' + st : '');
  } else if (Sky.pageType === 'tags') {
    t = 'tags' + (st ? ' - ' + st : '');
  } else if (Sky.pageType === 'archives') {
    t = 'archives' + (st ? ' - ' + st : '');
  } else if (Sky.pageType === 'index') {
    t = st + (Sky.siteSubname ? ' - ' + Sky.siteSubname : '');
  } else if (rp.id) {
    return; /* 文章页：SkyPostView 负责 */
  } else {
    var name = '';
    if (rp.cate_id !== undefined || rp.cate_alias !== undefined) {
      if (rp.cate_alias !== undefined) {
        name = decodeURIComponent(rp.cate_alias);
      } else if (Sky.categories) {
        var mc = Sky.categories.filter(function (c) { return String(c.metadata.name) === String(rp.cate_id); })[0];
        name = mc ? mc.spec.displayName : ('#' + rp.cate_id);
      }
    } else if (rp.tag_id !== undefined) {
      if (Sky.tagNames && Sky.tagNames[rp.tag_id]) {
        name = '#' + Sky.tagNames[rp.tag_id];
      } else if (Sky.tags) {
        var mt = Sky.tags.filter(function (tg) { return String(tg.metadata.name) === String(rp.tag_id); })[0];
        name = mt ? ('#' + mt.spec.displayName) : ('#' + rp.tag_id);
      } else {
        name = '#' + rp.tag_id;
      }
    } else if (rp.auth_id !== undefined || rp.auth_name !== undefined) {
      name = rp.auth_name !== undefined ? decodeURIComponent(rp.auth_name) : ('#' + rp.auth_id);
    } else if (rp.date !== undefined) {
      name = rp.date;
    } else if (rp.search !== undefined) {
      name = '"' + rp.search + '"';
    }
    t = (name ? name + ' - ' : '') + st;
  }
  if (t) {
    document.title = t;
  }
}

/* 远程初始化：前台所有展示数据经数据源 API 获取
 *  - system basic_info：站点名/评论验证码开关/登录态（token 有效时 is_logged_in=true）
 *  - category list：分类列表（公开接口）
 *  - tag list：标签列表（需登录；登录后拉取，未登录留空）
 *  - current_member：登录态恢复（user/userId/userInfo）
 */
function remoteInit() {
  if (!Sky.remote) {
    return;
  }
  apiGet({ mod: 'system', act: 'basic_info' }).then(function (info) {
    Sky.siteInfo = info;
    var zb = (info && info.zbp) ? info.zbp : null;
    if (zb && zb.name) {
      Sky.siteName = zb.name;
    }
    if (zb && zb.subname) {
      Sky.siteSubname = zb.subname;
    }
    if (zb && typeof zb.comment_verify_enable !== 'undefined') {
      Sky.commentVerify = !!zb.comment_verify_enable;
    }
    if (info && info.is_logged_in) {
      Sky.remoteLoggedIn = true;
      if (info.current_member) {
        Sky.user = info.current_member.Name || info.current_member.name || Sky.user;
        Sky.userId = parseInt(info.current_member.ID || info.current_member.id || 0, 10) || 0;
        Sky.userInfo = info.current_member;
      }
    } else {
      Sky.remoteLoggedIn = false;
    }
    skyApplyTitle();
  }).catch(function () {});
  /* 分类列表（公开接口，无需登录） */
  if (Sky.categories.length === 0) {
    apiGet({ mod: 'category', act: 'list', type: 0, perpage: 50 }).then(function (data) {
      var list = (data && data.list) || [];
      Sky.categories = list.map(function (c) {
        return {
          metadata: { name: String(c.ID) },
          spec: { displayName: c.Name, slug: (c.Alias && c.Alias !== '') ? c.Alias : c.Name },
          status: { permalink: localizeUrl(c.Url) },
          postCount: c.Count || 0
        };
      });
      skyApplyTitle();
    }).catch(function () {});
  }
}

/* 标准 MD5（公共域实现，本地模式原生登录 Verify_MD5 需要 md5(明文)） */
function skyMd5(s) {
  function safeAdd(x, y) {
    var lsw = (x & 0xffff) + (y & 0xffff);
    var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
    return (msw << 16) | (lsw & 0xffff);
  }
  function bitRotateLeft(num, cnt) {
    return (num << cnt) | (num >>> (32 - cnt));
  }
  function md5cmn(q, a, b, x, s, t) {
    return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
  }
  function md5ff(a, b, c, d, x, s, t) { return md5cmn((b & c) | (~b & d), a, b, x, s, t); }
  function md5gg(a, b, c, d, x, s, t) { return md5cmn((b & d) | (c & ~d), a, b, x, s, t); }
  function md5hh(a, b, c, d, x, s, t) { return md5cmn(b ^ c ^ d, a, b, x, s, t); }
  function md5ii(a, b, c, d, x, s, t) { return md5cmn(c ^ (b | ~d), a, b, x, s, t); }
  function md5cycle(x, k) {
    var a = x[0], b = x[1], c = x[2], d = x[3];
    a = md5ff(a, b, c, d, k[0], 7, -680876936); d = md5ff(d, a, b, c, k[1], 12, -389564586); c = md5ff(c, d, a, b, k[2], 17, 606105819); b = md5ff(b, c, d, a, k[3], 22, -1044525330);
    a = md5ff(a, b, c, d, k[4], 7, -176418897); d = md5ff(d, a, b, c, k[5], 12, 1200080426); c = md5ff(c, d, a, b, k[6], 17, -1473231341); b = md5ff(b, c, d, a, k[7], 22, -45705983);
    a = md5ff(a, b, c, d, k[8], 7, 1770035416); d = md5ff(d, a, b, c, k[9], 12, -1958414417); c = md5ff(c, d, a, b, k[10], 17, -42063); b = md5ff(b, c, d, a, k[11], 22, -1990404162);
    a = md5ff(a, b, c, d, k[12], 7, 1804603682); d = md5ff(d, a, b, c, k[13], 12, -40341101); c = md5ff(c, d, a, b, k[14], 17, -1502002290); b = md5ff(b, c, d, a, k[15], 22, 1236535329);
    a = md5gg(a, b, c, d, k[1], 5, -165796510); d = md5gg(d, a, b, c, k[6], 9, -1069501632); c = md5gg(c, d, a, b, k[11], 14, 643717713); b = md5gg(b, c, d, a, k[0], 20, -373897302);
    a = md5gg(a, b, c, d, k[5], 5, -701558691); d = md5gg(d, a, b, c, k[10], 9, 38016083); c = md5gg(c, d, a, b, k[15], 14, -660478335); b = md5gg(b, c, d, a, k[4], 20, -405537848);
    a = md5gg(a, b, c, d, k[9], 5, 568446438); d = md5gg(d, a, b, c, k[14], 9, -1019803690); c = md5gg(c, d, a, b, k[3], 14, -187363961); b = md5gg(b, c, d, a, k[8], 20, 1163531501);
    a = md5gg(a, b, c, d, k[13], 5, -1444681467); d = md5gg(d, a, b, c, k[2], 9, -51403784); c = md5gg(c, d, a, b, k[7], 14, 1735328473); b = md5gg(b, c, d, a, k[12], 20, -1926607734);
    a = md5hh(a, b, c, d, k[5], 4, -378558); d = md5hh(d, a, b, c, k[8], 11, -2022574463); c = md5hh(c, d, a, b, k[11], 16, 1839030562); b = md5hh(b, c, d, a, k[14], 23, -35309556);
    a = md5hh(a, b, c, d, k[1], 4, -1530992060); d = md5hh(d, a, b, c, k[4], 11, 1272893353); c = md5hh(c, d, a, b, k[7], 16, -155497632); b = md5hh(b, c, d, a, k[10], 23, -1094730640);
    a = md5hh(a, b, c, d, k[13], 4, 681279174); d = md5hh(d, a, b, c, k[0], 11, -358537222); c = md5hh(c, d, a, b, k[3], 16, -722521979); b = md5hh(b, c, d, a, k[6], 23, 76029189);
    a = md5hh(a, b, c, d, k[9], 4, -640364487); d = md5hh(d, a, b, c, k[12], 11, -421815835); c = md5hh(c, d, a, b, k[15], 16, 530742520); b = md5hh(b, c, d, a, k[2], 23, -995338651);
    a = md5ii(a, b, c, d, k[0], 6, -198630844); d = md5ii(d, a, b, c, k[7], 10, 1126891415); c = md5ii(c, d, a, b, k[14], 15, -1416354905); b = md5ii(b, c, d, a, k[5], 21, -57434055);
    a = md5ii(a, b, c, d, k[12], 6, 1700485571); d = md5ii(d, a, b, c, k[3], 10, -1894986606); c = md5ii(c, d, a, b, k[10], 15, -1051523); b = md5ii(b, c, d, a, k[1], 21, -2054922799);
    a = md5ii(a, b, c, d, k[8], 6, 1873313359); d = md5ii(d, a, b, c, k[15], 10, -30611744); c = md5ii(c, d, a, b, k[6], 15, -1560198380); b = md5ii(b, c, d, a, k[13], 21, 1309151649);
    a = md5ii(a, b, c, d, k[4], 6, -145523070); d = md5ii(d, a, b, c, k[11], 10, -1120210379); c = md5ii(c, d, a, b, k[2], 15, 718787259); b = md5ii(b, c, d, a, k[9], 21, -343485551);
    x[0] = safeAdd(a, x[0]); x[1] = safeAdd(b, x[1]); x[2] = safeAdd(c, x[2]); x[3] = safeAdd(d, x[3]);
  }
  var utf = unescape(encodeURIComponent(s));
  var words = [], i, len = utf.length;
  for (i = 0; i < len; i += 4) {
    words[i >> 2] = utf.charCodeAt(i) | (utf.charCodeAt(i + 1) << 8) | (utf.charCodeAt(i + 2) << 16) | (utf.charCodeAt(i + 3) << 24);
  }
  words[len >> 2] |= 0x80 << ((len % 4) * 8);
  words[(((len + 8) >> 6) << 4) + 14] = len * 8;
  var a0 = 1732584193, b0 = -271733879, c0 = -1732584194, d0 = 271733878;
  for (i = 0; i < words.length; i += 16) {
    var state = [a0, b0, c0, d0];
    md5cycle(state, words.slice(i, i + 16));
    a0 = state[0]; b0 = state[1]; c0 = state[2]; d0 = state[3];
  }
  function hex(n) {
    var s = '', k;
    for (k = 0; k < 4; k++) {
      s += '0123456789abcdef'.charAt((n >>> (k * 8 + 4)) & 15) + '0123456789abcdef'.charAt((n >>> (k * 8)) & 15);
    }
    return s;
  }
  return hex(a0) + hex(b0) + hex(c0) + hex(d0);
}

/* 本地模式登录：Z-Blog 原生登录（cmd.php?act=verify，带 CSRF token）。
   API login 只签发无状态 token、不写 Web 会话 cookie，而本地模式页面登录态
   由服务端 $user 判断，因此必须走原生登录建立会话。 */
function skyLoginLocal(username, password, savedate) {
  var md5pw = skyMd5(password);
  /* VerifyLogin 的 CSRF 校验读取 POST 字段 csrfToken（URL 参数不读），
     BuildSafeCmdURL('act=verify') 生成的 csrfToken 在 URL 中，需提取后随表单提交 */
  var m = String(Sky.verifyUrl || '').match(/csrfToken=([0-9a-f]+)/i);
  var csrf = m ? m[1] : '';
  var body = 'username=' + encodeURIComponent(username) +
    '&password=' + encodeURIComponent(md5pw) +
    '&savedate=' + encodeURIComponent(savedate || '7') +
    '&csrfToken=' + encodeURIComponent(csrf);
  return fetch(Sky.verifyUrl, {
    method: 'POST',
    credentials: 'same-origin',
    redirect: 'manual',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
    body: body
  }).then(function (res) {
    if (res.type === 'opaqueredirect' || (res.status >= 300 && res.status < 400)) {
      return 'ok';
    }
    return res.text().then(function (t) {
      if (/登录失败|error/i.test(t)) {
        var err = new Error('登录失败：用户名或密码错误');
        err.code = 8;
        throw err;
      }
      return 'ok';
    });
  });
}

/* 登录（远程）：POST api member login → token 存 localStorage → 刷新恢复登录态 */
function skyLogin(username, password, savedate) {
  var body = 'username=' + encodeURIComponent(username) +
    '&password=' + encodeURIComponent(password) +
    '&savedate=' + encodeURIComponent(savedate || '7');
  return apiPost({ mod: 'member', act: 'login' }, body).then(function (data) {
    var token = data && data.token;
    if (!token) {
      var err = new Error('登录失败：接口未返回 token');
      err.code = 1;
      throw err;
    }
    if (Sky.remote) {
      skySetToken(token);
      Sky.token = token;
    }
    if (data.user) {
      Sky.user = data.user.Name || data.user.name || Sky.user;
      Sky.userId = parseInt(data.user.ID || data.user.id || 0, 10) || 0;
      Sky.userInfo = data.user;
    }
    Sky.remoteLoggedIn = true;
    return data;
  });
}

/* 登出：调用 logout 接口并清除本地 token（服务端会话由数据源站管理） */
function skyLogout() {
  return apiPost({ mod: 'member', act: 'logout' }, '').then(function () {
    skySetToken('');
    Sky.token = '';
    Sky.remoteLoggedIn = false;
    Sky.user = 'guest';
    Sky.userId = 0;
    Sky.userInfo = null;
  }).catch(function () {
    skySetToken('');
    Sky.token = '';
    Sky.remoteLoggedIn = false;
    Sky.user = 'guest';
    Sky.userId = 0;
    Sky.userInfo = null;
  });
}

/* ==================== 3. 终端虚拟文件系统 ==================== */
function entryName(e) {
  return (e.spec && e.spec.displayName) ? e.spec.displayName : ((e.spec && e.spec.slug) ? e.spec.slug : (e.metadata && e.metadata.name) || 'unknown');
}
function entrySlug(e) {
  return (e.spec && e.spec.slug) || (e.metadata && e.metadata.name) || entryName(e);
}
function entryTitle(e) {
  return (e.spec && e.spec.title) || (e.spec && e.spec.slug) || (e.metadata && e.metadata.name) || 'untitled';
}
function entryFileSlug(e) {
  return (e.spec && e.spec.slug) || (e.metadata && e.metadata.name) || entryTitle(e);
}
function ocSlug(e) {
  return String(e || 'unknown').replace(/\//g, '-');
}
function joinUrl(e, t) {
  return (e.endsWith('/') ? e.slice(0, -1) : e) + '/' + encodeURIComponent(t);
}
function curSlug(e) {
  return ocSlug(e && (e.slug || e.title || e.displayName) || 'unknown');
}
function userName() {
  return Sky.user || 'user';
}
/* API 文章 → 终端文件条目 */
function postEntries(list) {
  return (list || []).map(function (e) {
    return {
      date: e.PostTime || null,
      name: entryTitle(e),
      permalink: e.Url || null,
      slug: entryFileSlug(e),
      type: 'file'
    };
  });
}
function homeDirEntries() {
  var files = (Sky.pageType === 'index') ? postEntries(Sky.currentPosts) : [];
  return [
    { name: 'categories', type: 'dir', count: Sky.categories.length },
    { name: 'tags', type: 'dir', count: Sky.tagTotal },
    { name: 'archives', type: 'dir' }
  ].concat(files);
}
function mergeIndexEntries() {
  var main = document.getElementById('main');
  var dirs = homeDirEntries().filter(function (t) {
    return t.type === 'dir' && (t.name === 'categories' || t.name === 'tags') && main && main.querySelector('#link-' + t.name);
  });
  return dirs.concat(postEntries(Sky.currentPosts || []));
}
/* dirList(path) → 目录条目列表（undefined=未加载，null=不存在） */
function dirList(path) {
  if (path === '~/blog') {
    return homeDirEntries();
  }
  if (path === '~/blog/archives') {
    return Sky.pageType === 'archives' ? postEntries(Sky.currentPosts) : null;
  }
  if (path === '~/blog/categories') {
    return (Sky.categories || []).map(function (e) {
      return { count: e.postCount || 0, date: null, name: entryName(e), permalink: e.status && e.status.permalink, slug: entrySlug(e), type: 'dir' };
    });
  }
  if (path === '~/blog/tags') {
    return (Sky.tags || []).map(function (e) {
      return { count: e.postCount || 0, date: null, name: entryName(e), permalink: e.status && e.status.permalink, slug: entrySlug(e), type: 'dir' };
    });
  }
  if (path.indexOf('~/blog/categories/') === 0) {
    var cs = path.slice(18);
    return Sky.pageType === 'category' && curSlug(Sky.currentCategory) === cs ? postEntries(Sky.currentPosts) : null;
  }
  if (path.indexOf('~/blog/tags/') === 0) {
    var ts = path.slice(12);
    return Sky.pageType === 'tag' && curSlug(Sky.currentTag) === ts ? postEntries(Sky.currentPosts) : null;
  }
  if (path.indexOf('~/blog/authors/') === 0) {
    var as = path.slice(15);
    return Sky.pageType === 'author' && curSlug(Sky.currentAuthor) === as ? postEntries(Sky.currentPosts) : null;
  }
  return null;
}
/* normalizePath(path) → 规范化绝对路径 */
function normalizePath(path) {
  var t = path;
  if (t === '~') {
    t = '~/blog';
  } else if (t.indexOf('~/') === 0 && t.indexOf('~/blog') !== 0) {
    t = '~/blog' + t.slice(1);
  }
  if (t.indexOf('~/blog') !== 0) {
    t = t.indexOf('/') === 0 ? '~/blog' + t : '~/blog/' + t;
  }
  var parts = [];
  t.split('/').forEach(function (seg) {
    if (seg && seg !== '.') {
      if (seg === '..') {
        if (parts.length > 2) {
          parts.pop();
        }
        return;
      }
      parts.push(seg);
    }
  });
  return parts.length < 2 ? '~/blog' : parts.join('/');
}
/* resolvePath(rel, base) → 绝对路径 */
function resolvePath(rel, base) {
  if (rel.indexOf('/') === 0 || rel.indexOf('~') === 0) {
    return normalizePath(rel);
  }
  return normalizePath((base.endsWith('/') ? base : base + '/') + rel);
}
/* parentPath(path) → 父路径 */
function parentPath(path) {
  if (path === '~/blog') {
    return '~/blog';
  }
  var parts = path.split('/');
  parts.pop();
  return parts.length < 2 ? '~/blog' : parts.join('/');
}
/* pathUrl(path) → URL（未知返回 null） */
function pathUrl(path) {
  if (path === '~/blog') {
    return Sky.urls.home || '/';
  }
  if (path === '~/blog/categories') {
    return Sky.urls.categories || '/';
  }
  if (path === '~/blog/tags') {
    return Sky.urls.tags || '/';
  }
  if (path === '~/blog/archives') {
    return Sky.urls.archives || '/';
  }
  if (path.indexOf('~/blog/categories/') === 0) {
    var cs = path.slice(18);
    var cat = (Sky.categories || []).filter(function (e) { return entrySlug(e) === cs; })[0];
    return (cat && cat.status && cat.status.permalink) || joinUrl(Sky.urls.categories || '/categories', cs);
  }
  if (path.indexOf('~/blog/tags/') === 0) {
    var ts = path.slice(12);
    var tag = (Sky.tags || []).filter(function (e) { return entrySlug(e) === ts; })[0];
    return (tag && tag.status && tag.status.permalink) || joinUrl(Sky.urls.tags || '/tags', ts);
  }
  if (path.indexOf('~/blog/authors/') === 0) {
    var as = path.slice(15);
    return Sky.currentAuthor && curSlug(Sky.currentAuthor) === as && Sky.currentAuthor.permalink ? Sky.currentAuthor.permalink : null;
  }
  if (path.indexOf('~/blog/pages/') === 0) {
    var ps = path.slice(13);
    var obj = Sky.currentPage || Sky.currentPost;
    return obj && curSlug(obj) === ps && obj.permalink ? obj.permalink : null;
  }
  if (path.indexOf('~/blog/') === 0) {
    var rest = path.slice(7);
    if (!rest || rest.indexOf('/') >= 0) {
      return null;
    }
    var cur = Sky.currentPost;
    if (cur && curSlug(cur) === rest && cur.permalink) {
      return cur.permalink;
    }
    var hit = (Sky.currentPosts || []).filter(function (e) { return ocSlug(entryFileSlug(e)) === rest || ocSlug(entryTitle(e)) === rest; })[0];
    return hit && hit.permalink ? hit.permalink : null;
  }
  return null;
}
/* currentPath() → 当前页面路径 */
function currentPath() {
  switch (Sky.pageType) {
    case 'archives':
      return '~/blog/archives';
    case 'author':
      return Sky.currentAuthor ? '~/blog/authors/' + curSlug(Sky.currentAuthor) : '~/blog/authors';
    case 'categories':
      return '~/blog/categories';
    case 'category':
      return '~/blog/categories/' + curSlug(Sky.currentCategory);
    case 'post':
      return '~/blog/' + curSlug(Sky.currentPost);
    case 'page': {
      var obj = Sky.currentPage || Sky.currentPost;
      return obj ? '~/blog/pages/' + curSlug(obj) : '~/blog/pages';
    }
    case 'tag':
      return '~/blog/tags/' + curSlug(Sky.currentTag);
    case 'tags':
      return '~/blog/tags';
    default:
      return '~/blog';
  }
}
/* 文件日期格式化（终端 ls 用） */
function fileDate(e) {
  if (!e) {
    return '—';
  }
  var d = new Date(e);
  if (isNaN(d.getTime())) {
    return '—';
  }
  var parts = new Intl.DateTimeFormat(document.documentElement.lang || 'zh-CN', {
    day: '2-digit', hour: '2-digit', hourCycle: 'h23', minute: '2-digit', month: 'short'
  }).formatToParts(d);
  var val = function (t) {
    var hit = parts.filter(function (p) { return p.type === t; })[0];
    return hit ? hit.value : '';
  };
  var mi = parts.map(function (p) { return p.type; }).indexOf('month');
  var sep = (parts[mi + 1] && parts[mi + 1].type === 'literal') ? parts[mi + 1].value.trim() : '';
  return val('month') + sep + ' ' + val('day') + ' ' + val('hour') + ':' + val('minute');
}

/* ==================== 4. 命令实现 ==================== */
var LIST_COMMANDS = ['cd', 'ls', 'll', 'pd', 'pu', 'npage', 'ppage', 'back', 'help', 'clear', 'top', 'bottom', 'search'];
var POST_COMMANDS = ['cd', 'next', 'prev', 'back', 'toc', 'jump', 'top', 'bottom', 'copy', 'help', 'clear', 'search'];
var NO_ARG_COMMANDS = new Set(['help', 'clear', 'back', 'next', 'prev', 'pd', 'pu', 'npage', 'ppage', 'ls', 'll', 'top', 'bottom', 'toc', 'copy']);
var DIR_COMMANDS = new Set(['cd', 'ls', 'll']);

function completeCandidates(input, basePath, isPost) {
  var cmd = input.toLowerCase();
  if (input.indexOf(' ') < 0) {
    return (isPost ? POST_COMMANDS : LIST_COMMANDS).filter(function (c) { return c.indexOf(cmd) === 0; }).map(function (c) {
      return NO_ARG_COMMANDS.has(c) ? c : c + ' ';
    });
  }
  var sp = input.indexOf(' ');
  var head = input.slice(0, sp).toLowerCase();
  var arg = input.slice(sp + 1);
  if (!DIR_COMMANDS.has(head)) {
    return [];
  }
  var lastSlash = arg.lastIndexOf('/');
  var prefix = lastSlash >= 0 ? arg.slice(0, lastSlash + 1) : '';
  var tail = (lastSlash >= 0 ? arg.slice(lastSlash + 1) : arg).toLowerCase();
  var dir = prefix ? resolvePath(prefix, basePath) : basePath;
  var entries = dirList(dir);
  if (!entries) {
    return [];
  }
  var source = (!prefix && dir === '~/blog' && Sky.pageType === 'index')
    ? homeDirEntries().filter(function (e) { return e.type === 'dir'; }).concat(mergeIndexEntries().filter(function (e) { return e.type === 'file'; }))
    : entries;
  var out = [];
  source.forEach(function (e) {
    var name = e.slug || e.name;
    if (String(name).toLowerCase().indexOf(tail) !== 0) {
      return;
    }
    out.push(head + ' ' + prefix + name + (e.type === 'dir' ? '/' : ''));
  });
  if (!prefix && String('..').indexOf(tail) === 0) {
    out.push(head + ' ../');
  }
  if (!prefix && String('~').indexOf(tail) === 0) {
    out.push(head + ' ~/');
  }
  return out;
}

var LIST_HELP = 'List Page Commands:\n' +
  '  ls            - List directory contents\n' +
  '  cd <path>     - Navigate to path\n' +
  '  pd / npage    - Next page\n' +
  '  pu / ppage    - Previous page\n' +
  '  back          - Browser back\n' +
  '  help          - Show this help\n' +
  '  clear         - Clear output\n' +
  '  top           - Scroll to top\n' +
  '  bottom        - Scroll to bottom\n' +
  '  search        - Open search\n\n' +
  'Navigation:\n' +
  '  ↑/↓           - Command history\n' +
  '  Tab           - Auto-complete\n' +
  '  Enter         - Execute';
var POST_HELP = 'Post Page Commands:\n' +
  '  cd ..         - Go back to list\n' +
  '  next          - Next article\n' +
  '  prev          - Previous article\n' +
  '  back          - Browser back\n' +
  '  toc           - Show article table of contents\n' +
  '  jump <n>      - Jump to TOC item number\n' +
  '  top           - Scroll to top\n' +
  '  bottom        - Scroll to bottom\n' +
  '  copy          - Copy article link\n' +
  '  search        - Open search\n' +
  '  help          - Show this help\n' +
  '  clear         - Clear output\n\n' +
  'Navigation:\n' +
  '  ↑/↓           - Command history\n' +
  '  Tab           - Auto-complete\n' +
  '  Enter         - Execute';

function isPostPageType() {
  return Sky.pageType === 'post';
}

/* cd */
function cmdCd(arg, base) {
  if (!arg || arg === '.') {
    return {};
  }
  if (arg === '..' || arg === '../') {
    var p = parentPath(base);
    var u = pathUrl(p);
    return u ? { navigate: u } : { newPath: p };
  }
  var resolved = resolvePath(arg, base);
  var url = pathUrl(resolved);
  var isSingle = resolved.indexOf('~/blog/') === 0 && resolved.slice(7).indexOf('/') < 0;
  var isSpecial = ['~/blog/archives', '~/blog/categories', '~/blog/tags'].indexOf(resolved) >= 0;
  if (!url && isSingle && !isSpecial && Sky.pageType !== 'index') {
    /* 当前列表数据未就绪时不刷新（源主题此处等待局部刷新，本主题为整页导航） */
  }
  if (url) {
    return { navigate: url };
  }
  var entries = dirList(resolved);
  if (entries === undefined) {
    return { output: "cd: '" + resolved + "' is not loaded on this page" };
  }
  if (entries) {
    return { newPath: resolved };
  }
  return { output: 'cd: no such file or directory: ' + arg };
}
/* ls / ll */
function cmdLs(arg, base) {
  var path = arg ? resolvePath(arg, base) : base;
  var useIndexMerge = !arg && path === '~/blog' && Sky.pageType === 'index';
  var entries = useIndexMerge ? mergeIndexEntries() : dirList(path);
  if (entries === null && arg) {
    var parent = parentPath(path);
    var tail = path.slice(parent.length + 1);
    var parentEntries = dirList(parent) || [];
    var merged = (parent === '~/blog' && Sky.pageType === 'index') ? mergeIndexEntries().filter(function (e) { return e.type === 'file'; }).concat(parentEntries) : parentEntries;
    var hit = merged.filter(function (e) { return (e.slug || e.name) === tail; })[0];
    if (hit && hit.type === 'file') {
      entries = [hit];
    } else if (hit && hit.type === 'dir') {
      return "ls: '" + path + "' is not loaded on this page; use 'cd " + path + "' to open it";
    }
  }
  if (entries === undefined) {
    return "ls: '" + path + "' is not loaded on this page; use 'cd " + path + "' to open it";
  }
  if (entries === null) {
    return "ls: cannot access '" + path + "': No such file or directory";
  }
  if (entries.length === 0) {
    return '(empty directory)';
  }
  var lines = entries.map(function (e) {
    var perm = e.type === 'dir' ? 'drwxr-xr-x' : '-rw-r--r--';
    var size = e.type === 'dir' ? '-' : '4.0K';
    var date = fileDate(e.date);
    return perm + '  ' + size + ' ' + userName() + '  staff  ' + date + '  ' + e.name + (e.type === 'dir' ? '/' : '');
  });
  return 'Showing ' + entries.length + ' ' + (entries.length === 1 ? 'entry' : 'entries') + (arg ? ' in ' + path : ' on this page') + '\n' + lines.join('\n');
}
/* next / prev */
function cmdNextPrev(which) {
  var target = which === 'next' ? Sky.nextPost : Sky.prevPost;
  return target ? { navigate: target } : { output: which === 'next' ? 'No next article available.' : 'No previous article available.' };
}
/* pd / pu */
function cmdPage(next) {
  if (document.querySelector('[data-empty-page]')) {
    return { output: 'No items on this page. Use the first-page link to return.' };
  }
  var p = Sky.pagination;
  if (!p) {
    return { output: 'Pagination not available on this page.' };
  }
  var url = next ? p.nextUrl : p.prevUrl;
  return url ? { navigate: url } : { output: next ? 'Already at the last page.' : 'Already at the first page.' };
}
/* search */
function cmdSearch() {
  window.SearchWidget && window.SearchWidget.open();
  return { output: 'Search widget opened. Type keyword in the search box.' };
}
/* toc */
function tocHeadings() {
  var root = document.querySelector('.terminal-content');
  if (!root) {
    return [];
  }
  var out = [];
  root.querySelectorAll('h2, h3').forEach(function (h, i) {
    var text = (h.textContent || '').trim();
    if (!text) {
      return;
    }
    if (!h.id) {
      h.id = 'toc-' + (text.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '') || 'section') + '-' + (i + 1);
    }
    out.push({ id: h.id, level: Number(h.tagName.slice(1)), text: text });
  });
  return out;
}
function cmdToc() {
  if (!isPostPageType()) {
    return 'toc: only available on post pages';
  }
  var items = tocHeadings();
  if (items.length === 0) {
    return 'toc: no headings found in this article';
  }
  return items.map(function (e, i) {
    var indent = e.level > 2 ? '  ' : '';
    return String(i + 1).padStart(2, '0') + '. ' + indent + e.text;
  }).join('\n');
}
function cmdJump(n) {
  var idx = parseInt(n, 10);
  if (!isFinite(idx) || idx < 1) {
    return { output: 'jump: usage: jump <number>' };
  }
  if (!isPostPageType()) {
    return { output: 'jump: only available on post pages' };
  }
  var item = tocHeadings()[idx - 1];
  if (!item) {
    return { output: 'jump: heading ' + idx + ' not found' };
  }
  var el = document.getElementById(item.id);
  if (el) {
    el.scrollIntoView({ behavior: scrollBehavior(), block: 'start' });
  }
  return {};
}
function scrollTop() {
  var m = scrollMain();
  if (m) {
    m.scrollTo({ behavior: scrollBehavior(), top: 0 });
  }
}
function scrollBottom() {
  var m = scrollMain();
  if (m) {
    m.scrollTo({ behavior: scrollBehavior(), top: m.scrollHeight });
  }
}
function cmdCopy() {
  if (!isPostPageType()) {
    return 'copy: only available on post pages';
  }
  var url = new URL((Sky.currentPost && Sky.currentPost.permalink) || window.location.href, window.location.href).href;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(url).then(function () {
      return 'Copied current article link.';
    }).catch(function () {
      return 'Copy unavailable. Link: ' + url;
    });
  }
  return Promise.resolve('Copy unavailable. Link: ' + url);
}

var COMMANDS = {
  back: function () { window.history.back(); return {}; },
  cd: function (arg, base) { return cmdCd(arg, base); },
  clear: function () { return {}; },
  bottom: function () { scrollBottom(); return {}; },
  copy: function () { return { output: cmdCopy() }; },
  help: function () { return { showHelp: true }; },
  jump: function (arg) { return cmdJump(arg); },
  ll: function (arg, base) { return { output: cmdLs(arg, base) }; },
  ls: function (arg, base) { return { output: cmdLs(arg, base) }; },
  next: function () { return cmdNextPrev('next'); },
  npage: function () { return cmdPage(true); },
  pd: function () { return cmdPage(true); },
  ppage: function () { return cmdPage(false); },
  prev: function () { return cmdNextPrev('prev'); },
  pu: function () { return cmdPage(false); },
  search: function () { return cmdSearch(); },
  toc: function () { return { output: cmdToc() }; },
  top: function () { scrollTop(); return {}; }
};
function runCommand(name, arg, base) {
  var fn = COMMANDS[name.toLowerCase()];
  if (!fn) {
    return { output: "bash: " + name + ": command not found. Type 'help' for available commands." };
  }
  var r = fn(arg, base);
  if (r && r.output && typeof r.output.then === 'function') {
    return r.output.then(function (text) { return { output: text }; });
  }
  return r;
}

/* ==================== 5. Vue 组件 ==================== */
var VueLib = window.Vue;

/* ---- 5.1 ASCII 艺术字（figlet） ---- */
var fontCache = {};
function loadFigletFont(name) {
  var safe = ['Banner', 'Big', 'Block', 'Doom', 'Lean', 'Mini', 'Script', 'Shadow', 'Slant', 'Small', 'Speed', 'Standard'].indexOf(name) >= 0 ? name : 'Standard';
  if (fontCache[safe]) {
    return fontCache[safe];
  }
  fontCache[safe] = fetch(Sky.themeUrl + 'script/fonts/' + safe + '.flf').then(function (res) {
    if (!res.ok) {
      throw new Error('Figlet font request returned HTTP ' + res.status + '.');
    }
    return res.text();
  }).then(function (text) {
    window.figlet.parseFont(safe, text);
    return safe;
  }).catch(function (err) {
    delete fontCache[safe];
    throw err;
  });
  return fontCache[safe];
}
function renderAsciiTitle() {
  var pre = document.getElementById('sky-ascii-title');
  if (!pre) {
    return;
  }
  var title = pre.getAttribute('data-title') || '';
  var font = pre.getAttribute('data-font') || 'Standard';
  if (!title) {
    return;
  }
  var fallback = function () { pre.textContent = title; };
  if (!window.figlet || !title.match(/^[\x00-\x7F]+$/)) {
    fallback();
    return;
  }
  loadFigletFont(font).then(function () {
    window.figlet.text(title, { font: font, horizontalLayout: 'default', verticalLayout: 'default' }, function (err, art) {
      pre.textContent = (!err && art) ? art : title;
    });
  }).catch(fallback);
}

/* ---- 5.2 打字机 ---- */
var SkyTyping = {
  name: 'sky-typing',
  props: {
    text: { type: String, default: '' },
    speed: { type: Number, default: 35 }
  },
  data: function () {
    return { display: '', timer: null };
  },
  watch: {
    text: function () {
      this.start();
    }
  },
  mounted: function () {
    this.start();
  },
  beforeUnmount: function () {
    if (this.timer !== null) {
      window.clearInterval(this.timer);
      this.timer = null;
    }
  },
  methods: {
    start: function () {
      var self = this;
      if (this.timer !== null) {
        window.clearInterval(this.timer);
        this.timer = null;
      }
      if (prefersReducedMotion()) {
        this.display = this.text;
        return;
      }
      var i = 0;
      this.display = '';
      var ms = Number.isFinite(this.speed) ? Math.max(1, this.speed) : 35;
      this.timer = window.setInterval(function () {
        if (i < self.text.length) {
          self.display += self.text.charAt(i);
          i += 1;
        } else if (self.timer !== null) {
          window.clearInterval(self.timer);
          self.timer = null;
        }
      }, ms);
    }
  },
  template: '<span class="typing-effect flex-shrink-0 whitespace-nowrap">{{ display }}</span>'
};

/* ---- 5.3 列表键盘导航（混入：selectedKey 方案，避免模板中依赖 $el） ---- */
var fileListNavMixin = {
  data: function () {
    return {
      navItems: [],
      selectedIndex: -1,
      selectedKey: '',
      navKeydownHandler: null,
      navFocusInHandler: null
    };
  },
  mounted: function () {
    var self = this;
    this.refreshNavItems();
    this.navKeydownHandler = function (e) { self.handleNavKeydown(e); };
    this.navFocusInHandler = function (e) { self.handleNavFocusIn(e); };
    window.addEventListener('keydown', this.navKeydownHandler);
    window.addEventListener('focusin', this.navFocusInHandler);
  },
  updated: function () {
    var self = this;
    this.$nextTick(function () {
      self.refreshNavItems();
    });
  },
  beforeUnmount: function () {
    if (this.navKeydownHandler) {
      window.removeEventListener('keydown', this.navKeydownHandler);
    }
    if (this.navFocusInHandler) {
      window.removeEventListener('focusin', this.navFocusInHandler);
    }
  },
  methods: {
    refreshNavItems: function () {
      var els = Array.prototype.slice.call(this.$el.querySelectorAll('[data-nav-item]'));
      this.navItems = els;
      if (this.selectedIndex < 0 && els.length > 0) {
        this.selectedIndex = 0;
        this.syncSelectedKey();
      }
    },
    syncSelectedKey: function () {
      var item = this.navItems[this.selectedIndex];
      this.selectedKey = item ? (item.getAttribute('data-nav-key') || '') : '';
    },
    handleNavFocusIn: function (e) {
      var t = e.target;
      var item = t instanceof Element ? t.closest('[data-nav-item]') : null;
      if (item) {
        var idx = this.navItems.indexOf(item);
        if (idx >= 0) {
          this.selectedIndex = idx;
          this.syncSelectedKey();
        }
        return;
      }
      if (isFocusableWithin(e)) {
        this.selectedIndex = -1;
        this.selectedKey = '';
      }
    },
    handleNavKeydown: function (e) {
      if (e.defaultPrevented || e.isComposing || e.repeat || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) {
        return;
      }
      var t = e.target;
      var inside = t instanceof Element && this.$el.contains(t) && t.closest('[data-nav-item]');
      if ((isKeyboardBlocked(e) && !inside) || this.navItems.length === 0) {
        return;
      }
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        this.selectedIndex = (this.selectedIndex + 1) % this.navItems.length;
        this.scrollToNavSelected();
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        this.selectedIndex = this.selectedIndex < 0 ? this.navItems.length - 1 : (this.selectedIndex - 1 + this.navItems.length) % this.navItems.length;
        this.scrollToNavSelected();
        return;
      }
      if (e.key !== 'Enter') {
        return;
      }
      e.preventDefault();
      if (this.selectedIndex < 0 || this.selectedIndex >= this.navItems.length) {
        return;
      }
      var row = this.navItems[this.selectedIndex];
      var a = row instanceof HTMLAnchorElement ? row : row.querySelector('a');
      if (a && a.href) {
        go(a.href);
      }
    },
    scrollToNavSelected: function () {
      var row = this.navItems[this.selectedIndex];
      this.syncSelectedKey();
      if (!row) {
        return;
      }
      var focusable = row instanceof HTMLAnchorElement ? row : row.querySelector('a[href], button, [tabindex]:not([tabindex="-1"])');
      if (focusable) {
        focusable.focus({ preventScroll: true });
      }
      row.scrollIntoView({ behavior: scrollBehavior(), block: 'nearest' });
    },
    isNavSelected: function (key) {
      return this.selectedKey === key;
    }
  }
};

/* ---- 5.4 行渲染辅助 ---- */
function rowPerm(post) {
  return (Sky.userId > 0 && Sky.userId === Number(post.AuthorID)) ? '-rwxr-xr-x' : '-rw-r--r--';
}
function authorOf(post) {
  return (post.Author && (post.Author.StaticName || post.Author.Name)) || '—';
}

/* ---- 5.5 列表视图（index/category/tag/author/date/search） ---- */
var SkyListView = {
  name: 'sky-list-view',
  mixins: [fileListNavMixin],
  data: function () {
    return {
      posts: [],
      loading: true,
      error: '',
      count: 0,
      pagebar: null
    };
  },
  computed: {
    user: function () { return Sky.user; },
    siteName: function () { return Sky.siteName; },
    navUser: function () { return Sky.userId > 0 ? Sky.user : 'root'; },
    nowShort: function () {
      var d = new Date();
      return MONTHS_SHORT[d.getMonth()] + ' ' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
    },
    urls: function () { return Sky.urls; },
    promptPath: function () {
      switch (Sky.pageType) {
        case 'category':
          return '~/blog/categories/' + (Sky.currentCategory ? curSlug(Sky.currentCategory) : '');
        case 'tag':
          return '~/blog/tags/' + (Sky.currentTag ? curSlug(Sky.currentTag) : '');
        case 'author':
          return '~/blog/authors/' + (Sky.currentAuthor ? curSlug(Sky.currentAuthor) : '');
        default:
          return '~/blog';
      }
    },
    typingText: function () {
      if (Sky.pageType === 'search') {
        return 'find ./posts -type f';
      }
      if (Sky.pageType === 'index') {
        return 'ls -la ./posts';
      }
      return 'ls -la';
    },
    showBanner: function () {
      return ['category', 'tag', 'author', 'date', 'search'].indexOf(Sky.pageType) >= 0;
    },
    bannerLabel: function () {
      switch (Sky.pageType) {
        case 'category': return 'Category:';
        case 'tag': return 'Tag:';
        case 'author': return 'Author:';
        case 'date': return 'Date:';
        case 'search': return 'Search:';
        default: return '';
      }
    },
    bannerValue: function () {
      var rp = Sky.remote ? resolveRemoteParams() : null;
      switch (Sky.pageType) {
        case 'category':
          if (Sky.currentCategory) { return Sky.currentCategory.displayName; }
          if (rp && (rp.cate_id !== undefined || rp.cate_alias !== undefined)) {
            if (rp.cate_alias !== undefined) { return decodeURIComponent(rp.cate_alias); }
            if (Sky.categories) {
              var mc = Sky.categories.filter(function (c) { return String(c.metadata.name) === String(rp.cate_id); })[0];
              if (mc) { return mc.spec.displayName; }
            }
            return '#' + rp.cate_id;
          }
          return '';
        case 'tag':
          if (Sky.currentTag) { return '#' + Sky.currentTag.displayName; }
          if (rp && rp.tag_id !== undefined) {
            if (Sky.tagNames && Sky.tagNames[rp.tag_id]) { return '#' + Sky.tagNames[rp.tag_id]; }
            if (Sky.tags) {
              var mt = Sky.tags.filter(function (t) { return String(t.metadata.name) === String(rp.tag_id); })[0];
              if (mt) { return '#' + mt.spec.displayName; }
            }
            return '#' + rp.tag_id;
          }
          return '';
        case 'author':
          if (Sky.currentAuthor) { return Sky.currentAuthor.displayName; }
          if (rp && rp.auth_id !== undefined) { return '#' + rp.auth_id; }
          return '';
        case 'date': return Sky.date || (rp && rp.date ? rp.date : '');
        case 'search': return '"' + (Sky.search || (rp && rp.search ? rp.search : '')) + '"';
        default: return '';
      }
    },
    bannerCountLabel: function () {
      return Sky.pageType === 'search' ? 'Files:' : 'Posts:';
    },
    showPinned: function () {
      return Sky.config.pinned && Sky.pageType === 'index' && Sky.page === 1;
    },
    pagination: function () {
      /* 远程模式：分页必须基于数据源站 post list 返回的 pagebar 计算
         （服务端注入的 Sky.pagination 是当前站的数据，文章数不同会导致
           “最后一页”不是数据源站的最后一页） */
      if (Sky.remote) {
        var rpb = this.pagebar;
        if (!rpb) {
          return null;
        }
        var rPageAll = parseInt(rpb.PageAll, 10) || 0;
        var rPageNow = parseInt(rpb.PageNow, 10) || 1;
        if (rPageAll <= 1) {
          return null;
        }
        var mkUrl = function (p) {
          if (p <= 1) {
            return Sky.urls.home;
          }
          var base = location.pathname.replace(/\/$/, '');
          return base + '?page=' + p;
        };
        return {
          hasPrev: rPageNow > 1,
          hasNext: rPageNow < rPageAll,
          prevUrl: rPageNow > 1 ? mkUrl(rPageNow - 1) : null,
          nextUrl: rPageNow < rPageAll ? mkUrl(rPageNow + 1) : null
        };
      }
      return Sky.pagination;
    },
    showLsSim: function () {
      return Sky.config.lsSim;
    },
    isListLevel: function () {
      return ['category', 'tag', 'author', 'date'].indexOf(Sky.pageType) >= 0;
    },
    parentUrl: function () {
      if (Sky.pageType === 'category') {
        return Sky.urls.categories;
      }
      if (Sky.pageType === 'tag') {
        return Sky.urls.tags;
      }
      return Sky.urls.home;
    },
    emptyText: function () {
      return Sky.pageType === 'search' ? 'No files matched your search. Use the footer [SEARCH] entry to try again.' : 'No posts yet.';
    }
  },
  mounted: function () {
    this.fetchPosts();
  },
  methods: {
    fetchPosts: function () {
      var self = this;
      this.loading = true;
      this.error = '';
      var params = {
        mod: 'post',
        act: 'list',
        type: 0,
        perpage: Sky.perpage,
        page: Sky.page,
        sortby: 'PostTime',
        order: 'desc',
        without_content: 1,
        with_relations: 'Author'
      };
      if (Sky.remote) {
        var rp = resolveRemoteParams();
        params.page = rp.page || Sky.page || 1;
        if (rp.cate_id !== undefined) { params.cate_id = rp.cate_id; }
        if (rp.cate_alias !== undefined) { params.cate_alias = rp.cate_alias; }
        if (rp.tag_id !== undefined) { params.tag_id = rp.tag_id; }
        if (rp.auth_id !== undefined) { params.auth_id = rp.auth_id; }
        if (rp.auth_name !== undefined) { params.auth_name = rp.auth_name; }
        if (rp.date !== undefined) { params.date = rp.date; }
        if (rp.search !== undefined) { params.search = rp.search; }
        /* 远程 tag 页：Sky.tags 不再全量加载，用公开 tag get 接口按需补拉标签名
           （供列表 banner 与 <title> 显示 #标签名） */
        if (rp.tag_id !== undefined && (!Sky.tagNames || !Sky.tagNames[rp.tag_id])) {
          apiGet({ mod: 'tag', act: 'get', id: rp.tag_id }).then(function (td) {
            var tg = td && td.tag;
            if (tg && tg.Name) {
              if (!Sky.tagNames) { Sky.tagNames = {}; }
              Sky.tagNames[rp.tag_id] = tg.Name;
              skyApplyTitle();
            }
          }).catch(function () {});
        }
      } else if (Sky.pageType === 'category' && Sky.currentCategory) {
        params.cate_id = Sky.currentCategory.id;
      } else if (Sky.pageType === 'tag' && Sky.currentTag) {
        params.tag_id = Sky.currentTag.id;
      } else if (Sky.pageType === 'author' && Sky.currentAuthor) {
        params.auth_id = Sky.currentAuthor.id;
      } else if (Sky.pageType === 'date') {
        params.date = Sky.date;
      } else if (Sky.pageType === 'search') {
        params.search = Sky.search;
      }
      apiGet(params).then(function (data) {
        self.posts = (data && data.list) || [];
        if (Sky.remote) {
          self.posts.forEach(localizePost);
        }
        self.pagebar = (data && data.pagebar) || null;
        self.count = data && data.pagebar ? parseInt(data.pagebar.AllCount, 10) || 0 : self.posts.length;
        Sky.currentPosts = self.posts;
        /* 远程模式：<title> 必须以数据源站数据为准（当前站没有的数据会退化成
           “Good Luck To You!” 默认标题，本地有的数据又会串成当前站标题） */
        if (Sky.remote) {
          var st = Sky.siteName || '';
          if (Sky.pageType === 'index') {
            document.title = st + (Sky.siteSubname ? ' - ' + Sky.siteSubname : '');
          } else {
            var bv = self.bannerValue;
            document.title = (bv ? bv + ' - ' : '') + st;
          }
        }
        self.loading = false;
      }).catch(function (err) {
        self.error = err.message || String(err);
        self.loading = false;
        console.error('[CRTShellVue] 列表数据加载失败:', err);
      });
    },
    rowPerm: rowPerm,
    authorOf: authorOf,
    fmtTime: function (ts) { return fmtTime(ts, 'short'); }
  },
  template:
    '<div>' +
      '<div v-if="showLsSim" class="text-terminal-green mb-3 flex min-w-0 items-center gap-2 md:mb-6">' +
        '<span class="text-terminal-dim min-w-0 truncate">{{ user }}@<span>{{ siteName }}</span>:<span class="text-terminal-green">{{ promptPath }}</span>$</span>' +
        '<sky-typing :text="typingText" :speed="35"></sky-typing>' +
      '</div>' +
      '<div v-if="showBanner" class="border-terminal-dim bg-terminal-green/20 mb-2 flex min-h-10 flex-wrap items-center gap-x-2 border px-2 py-2 text-xs md:mb-4 md:block md:p-3">' +
        '<span class="text-terminal-dim">{{ bannerLabel }}</span><h1 class="text-terminal-green inline font-bold break-words">{{ bannerValue }}</h1><span class="text-terminal-dim md:ml-4">{{ bannerCountLabel }}</span><span class="text-terminal-green">{{ count }}</span>' +
      '</div>' +
      '<div v-if="error" class="text-terminal-dim border-terminal-dim border border-dashed p-3 text-xs md:p-4">{{ error }}</div>' +
      '<div v-else-if="loading" class="text-terminal-dim border-terminal-dim border border-dashed p-3 text-xs md:p-4">Loading...</div>' +
      '<div v-else>' +
        '<ul class="font-mono text-xs md:space-y-1 md:text-sm">' +
          '<li class="hidden select-none px-1 text-terminal-dim md:grid md:grid-cols-12 md:gap-2" aria-hidden="true">' +
            '<span class="col-span-2">PERMISSIONS</span><span class="col-span-2">USER</span><span class="col-span-2">DATE</span><span class="col-span-6">NAME</span>' +
          '</li>' +
          '<li v-if="showPinned" data-nav-item data-nav-key="pinned-cat" :class="{ \'!bg-terminal-green !text-terminal-black\': isNavSelected(\'pinned-cat\') }" class="group text-terminal-green hover:text-terminal-dim grid min-h-10 cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-x-2 px-1 transition-colors md:min-h-0 md:grid-cols-12 md:gap-2 md:py-0">' +
            '<div class="hidden whitespace-nowrap md:col-span-2 md:col-start-1 md:row-start-1 md:block">drwxr-xr-x</div>' +
            '<div class="hidden md:col-span-2 md:col-start-3 md:row-start-1 md:block">{{ navUser }}</div>' +
            '<div class="text-terminal-dim col-start-2 row-start-1 justify-self-end whitespace-nowrap md:col-span-2 md:col-start-5 md:justify-self-auto">{{ nowShort }}</div>' +
            '<div class="col-start-1 row-start-1 min-w-0 md:col-span-6 md:col-start-7"><a id="link-categories" :href="urls.categories" class="flex min-h-10 min-w-0 items-center py-1 break-words text-inherit md:block md:min-h-0 md:py-0">categories/</a></div>' +
          '</li>' +
          '<li v-if="showPinned" data-nav-item data-nav-key="pinned-tag" :class="{ \'!bg-terminal-green !text-terminal-black\': isNavSelected(\'pinned-tag\') }" class="group text-terminal-green hover:text-terminal-dim grid min-h-10 cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-x-2 px-1 transition-colors md:min-h-0 md:grid-cols-12 md:gap-2 md:py-0">' +
            '<div class="hidden whitespace-nowrap md:col-span-2 md:col-start-1 md:row-start-1 md:block">drwxr-xr-x</div>' +
            '<div class="hidden md:col-span-2 md:col-start-3 md:row-start-1 md:block">{{ navUser }}</div>' +
            '<div class="text-terminal-dim col-start-2 row-start-1 justify-self-end whitespace-nowrap md:col-span-2 md:col-start-5 md:justify-self-auto">{{ nowShort }}</div>' +
            '<div class="col-start-1 row-start-1 min-w-0 md:col-span-6 md:col-start-7"><a id="link-tags" :href="urls.tags" class="flex min-h-10 min-w-0 items-center py-1 break-words text-inherit md:block md:min-h-0 md:py-0">tags/</a></div>' +
          '</li>' +
          '<li v-if="isListLevel" data-nav-item data-nav-key="parent" :class="{ \'!bg-terminal-green !text-terminal-black\': isNavSelected(\'parent\') }" class="group text-terminal-green hover:text-terminal-dim grid min-h-10 cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-x-2 px-1 transition-colors md:min-h-0 md:grid-cols-12 md:gap-2 md:py-0">' +
            '<div class="hidden whitespace-nowrap md:col-span-2 md:col-start-1 md:row-start-1 md:block">drwxr-xr-x</div>' +
            '<div class="hidden md:col-span-2 md:col-start-3 md:row-start-1 md:block">{{ navUser }}</div>' +
            '<div class="text-terminal-dim col-start-2 row-start-1 justify-self-end whitespace-nowrap md:col-span-2 md:col-start-5 md:justify-self-auto">{{ nowShort }}</div>' +
            '<div class="col-start-1 row-start-1 min-w-0 md:col-span-6 md:col-start-7"><a :href="parentUrl" class="flex min-h-10 min-w-0 items-center py-1 break-words text-inherit md:block md:min-h-0 md:py-0">../</a></div>' +
          '</li>' +
          '<li v-for="post in posts" :key="post.ID" data-nav-item :data-nav-key="\'post-\' + post.ID" :class="{ \'!bg-terminal-green !text-terminal-black\': isNavSelected(\'post-\' + post.ID) }" class="group text-terminal-green hover:text-terminal-dim grid min-h-10 cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-x-2 px-1 transition-colors md:min-h-0 md:grid-cols-12 md:gap-2 md:py-0">' +
            '<div class="hidden whitespace-nowrap opacity-70 group-hover:opacity-100 md:col-span-2 md:col-start-1 md:row-start-1 md:block">{{ rowPerm(post) }}</div>' +
            '<div class="hidden opacity-70 group-hover:opacity-100 md:col-span-2 md:col-start-3 md:row-start-1 md:block">{{ authorOf(post) }}</div>' +
            '<div class="col-start-2 row-start-1 justify-self-end whitespace-nowrap opacity-70 group-hover:opacity-100 md:col-span-2 md:col-start-5 md:justify-self-auto">{{ fmtTime(post.PostTime) }}</div>' +
            '<div class="col-start-1 row-start-1 min-w-0 md:col-span-6 md:col-start-7"><a :href="post.Url" class="flex min-h-10 min-w-0 items-center py-1 break-words text-inherit md:block md:min-h-0 md:truncate md:py-0">{{ post.Title }}</a></div>' +
          '</li>' +
          '<li v-if="posts.length === 0" data-empty-page class="text-terminal-dim border-terminal-dim mt-2 border border-dashed px-2 py-3">{{ emptyText }}</li>' +
        '</ul>' +
        '<div v-if="pagination" class="mt-2 flex gap-4 font-mono text-xs md:mt-4">' +
          '<a v-if="pagination.hasPrev" :href="pagination.prevUrl" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex min-h-10 cursor-pointer items-center border bg-transparent px-4 py-1 transition-colors md:min-h-0">[PREV]</a>' +
          '<a v-if="pagination.hasNext" :href="pagination.nextUrl" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex min-h-10 cursor-pointer items-center border bg-transparent px-4 py-1 transition-colors md:min-h-0">[NEXT]</a>' +
        '</div>' +
        '<div class="text-terminal-dim mt-2 text-xs md:mt-4">{{ count }} files found.</div>' +
      '</div>' +
    '</div>'
};

/* ---- 5.6 评论表单组件（含回复抓取契约） ---- */
var SkyCommentForm = {
  name: 'sky-comment-form',
  props: {
    postId: { type: [Number, String], required: true },
    action: { type: String, default: '' },
    replyId: { type: [Number, String], default: 0 },
    showVerify: { type: Boolean, default: false },
    verifyCodeUrl: { type: String, default: '' },
    loggedIn: { type: Boolean, default: false },
    userInfo: { type: Object, default: null },
    posting: { type: Boolean, default: false },
    formError: { type: String, default: '' }
  },
  data: function () {
    return {
      name: '',
      email: '',
      homePage: '',
      verifySrc: ''
    };
  },
  computed: {
    promptUser: function () {
      return Sky.userId > 0 ? Sky.user : 'guest';
    },
    siteName: function () { return Sky.siteName; },
    loggedName: function () {
      return (Sky.userInfo && Sky.userInfo.staticName) || Sky.user;
    },
    logoutUrl: function () {
      return Sky.logoutUrl || '';
    }
  },
  mounted: function () {
    var self = this;
    var p = window.zbp && window.zbp.plugin;
    if (p) {
      p.on('comment.post.success', 'crtshellvue-form', function () {
        self.content = '';
        self.$nextTick(function () {
          var ta = document.getElementById('txaArticle');
          if (ta) { ta.value = ''; }
        });
      });
    }
  },
  watch: {
    userInfo: {
      handler: function (v) {
        if (v) {
          this.name = v.name || '';
          this.email = v.email || '';
          this.homePage = v.homePage || '';
        }
      },
      immediate: true
    },
    verifyCodeUrl: {
      handler: function (v) {
        this.verifySrc = v || '';
      },
      immediate: true
    }
  },
  methods: {
    submitComment: function () {
      /* 远程模式已登录：评论走数据源站 API（mod=comment&act=post，带 X-Sky-Token），
         数据源站以 token 识别登录用户身份，无需再填 name/email；
         cmd.php?act=cmt 走的是数据源站 cookie 会话，识别不了 API token */
      if (Sky.remote && Sky.remoteLoggedIn) {
        var contentEl = document.getElementById('txaArticle');
        var content = contentEl ? contentEl.value : '';
        if (!content || !content.trim()) {
          return;
        }
        var body = 'postid=' + encodeURIComponent(this.postId) +
          '&content=' + encodeURIComponent(content) +
          '&replyid=' + encodeURIComponent(this.replyId || 0) +
          '&name=&email=&homepage=';
        return apiPost({ mod: 'comment', act: 'post' }, body).then(function () {
          window.location.reload();
        }).catch(function (err) {
          alert('评论失败：' + (err.message || String(err)));
        });
      }
      return window.zbp && window.zbp.comment.post();
    },
    refreshVerify: function () {
      var base = this.verifyCodeUrl || '';
      this.verifySrc = base + (base.indexOf('?') >= 0 ? '&' : '?') + 'tm=' + Math.random();
    },
    cancelReply: function () {
      var p = window.zbp && window.zbp.plugin;
      if (p) {
        p.emit('comment.reply.cancel');
      }
    }
  },
  template:
    '<div id="comment">' +
      '<h2 class="text-terminal-green mb-4 font-mono text-xs">[WRITE_COMMENT]' +
        '<button v-if="Number(replyId) > 0" type="button" id="cancel-reply" class="text-terminal-dim hover:text-terminal-green ml-2 cursor-pointer bg-transparent p-0 font-mono text-xs underline-offset-2 hover:underline" @click="cancelReply">[CANCEL_REPLY]</button>' +
      '</h2>' +
      '<form id="frmSumbit" name="frmSumbit" method="post" :action="action">' +
        '<input type="hidden" name="inpId" id="inpId" :value="postId">' +
        '<input type="hidden" name="inpRevID" id="inpRevID" :value="replyId">' +
        '<template v-if="loggedIn">' +
          '<input type="hidden" name="inpName" id="inpName" :value="name">' +
          '<input type="hidden" name="inpEmail" id="inpEmail" :value="email">' +
          '<input type="hidden" name="inpHomePage" id="inpHomePage" :value="homePage">' +
          '<p class="text-terminal-dim mb-3 font-mono text-xs">Logged in as <b class="text-terminal-green">{{ loggedName }}</b> <a class="hover:text-terminal-green" :href="logoutUrl">[LOGOUT]</a></p>' +
        '</template>' +
        '<template v-else>' +
          '<div class="mb-3 grid gap-2 md:grid-cols-3">' +
            '<input class="border-terminal-dim bg-transparent px-2 py-1 font-mono text-xs text-terminal-green outline-none" type="text" name="inpName" id="inpName" v-model="name" placeholder="Name (required)" maxlength="32" tabindex="1">' +
            '<input class="border-terminal-dim bg-transparent px-2 py-1 font-mono text-xs text-terminal-green outline-none" type="email" name="inpEmail" id="inpEmail" v-model="email" placeholder="Email (required, private)" maxlength="96" tabindex="2">' +
            '<input class="border-terminal-dim bg-transparent px-2 py-1 font-mono text-xs text-terminal-green outline-none" type="url" name="inpHomePage" id="inpHomePage" v-model="homePage" placeholder="Website (optional)" maxlength="128" tabindex="3">' +
          '</div>' +
          '<div v-if="showVerify" class="mb-3 flex items-center gap-2">' +
            '<label class="sr-only" for="inpVerify">Verify code</label>' +
            '<input class="border-terminal-dim bg-transparent px-2 py-1 font-mono text-xs text-terminal-green outline-none" type="text" name="inpVerify" id="inpVerify" placeholder="Verify code" tabindex="6" maxlength="8">' +
            '<img class="h-8 cursor-pointer" :src="verifySrc" alt="Verify code" title="Click to refresh" @click="refreshVerify">' +
          '</div>' +
        '</template>' +
        '<div class="mb-3">' +
          '<textarea class="border-terminal-dim bg-transparent w-full px-2 py-2 font-mono text-xs text-terminal-green outline-none" name="txaArticle" id="txaArticle" rows="5" placeholder="Type your comment..." tabindex="4" required></textarea>' +
        '</div>' +
        '<div v-if="formError" class="text-terminal-dim mb-3 border border-dashed p-2 text-xs">{{ formError }}</div>' +
        '<div class="flex items-center justify-between gap-3">' +
          '<span class="text-terminal-dim font-mono text-xs">{{ promptUser }}@{{ siteName }}:~$ cat comment.txt</span>' +
          '<button type="submit" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex cursor-pointer items-center border bg-transparent px-4 py-1 font-mono text-xs transition-colors" tabindex="5" :disabled="posting" @click.prevent="submitComment()">[SUBMIT]</button>' +
        '</div>' +
      '</form>' +
    '</div>'
};

/* ---- 5.7 评论列表组件 ---- */
var SkyComments = {
  name: 'sky-comments',
  props: {
    post: { type: Object, required: true }
  },
  data: function () {
    return {
      comments: [],
      total: 0,
      loading: true,
      error: '',
      page: 1,
      replyTarget: null,
      posting: false,
      formError: '',
      commentMap: {}
    };
  },

  mounted: function () {
    this.bindZbpEvents();
    this.fetchAll();
  },
  beforeUnmount: function () {
    this.unbindZbpEvents();
  },
  methods: {
    bindZbpEvents: function () {
      var self = this;
      var p = window.zbp && window.zbp.plugin;
      if (!p) {
        return;
      }
      this.handlers = {
        replyStart: function (id) {
          self.replyTarget = id;
          self.formError = '';
          self.$nextTick(function () {
            var box = document.getElementById('sky-comment-form');
            if (box) {
              box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
          });
        },
        replyCancel: function () {
          self.replyTarget = null;
          self.formError = '';
        },
        postStart: function () {
          self.posting = true;
          self.formError = '';
        },
        postSuccess: function (data, res) {
          self.posting = false;
          self.replyTarget = null;
          var newId = res && res.data && res.data.ID ? res.data.ID : 0;
          self.fetchAll(function () {
            if (newId) {
              var el = document.getElementById('cmt' + newId);
              if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }
            }
          });
        },
        postError: function (err) {
          self.posting = false;
          self.formError = (err && err.message) || '评论提交失败，请重试。';
        },
        postDone: function () {
          self.posting = false;
        }
      };
      p.on('comment.reply.start', 'crtshellvue', this.handlers.replyStart);
      p.on('comment.reply.cancel', 'crtshellvue', this.handlers.replyCancel);
      p.on('comment.post.start', 'crtshellvue', this.handlers.postStart);
      p.on('comment.post.success', 'crtshellvue', this.handlers.postSuccess);
      p.on('comment.post.error', 'crtshellvue', this.handlers.postError);
      p.on('comment.post.done', 'crtshellvue', this.handlers.postDone);
    },
    unbindZbpEvents: function () {
      var p = window.zbp && window.zbp.plugin;
      if (!p || !this.handlers) {
        return;
      }
      p.unbind('comment.reply.start', 'crtshellvue');
      p.unbind('comment.reply.cancel', 'crtshellvue');
      p.unbind('comment.post.start', 'crtshellvue');
      p.unbind('comment.post.success', 'crtshellvue');
      p.unbind('comment.post.error', 'crtshellvue');
      p.unbind('comment.post.done', 'crtshellvue');
    },
    fetchAll: function (done) {
      var self = this;
      var all = [];
      var page = 1;
      this.loading = true;
      this.error = '';
      var next = function () {
        apiGet({
          mod: 'comment',
          act: 'list',
          post_id: self.post.ID,
          page: page,
          perpage: 50,
          sortby: 'PostTime',
          order: 'asc',
          with_relations: 'Author'
        }).then(function (data) {
          var list = (data && data.list) || [];
          all = all.concat(list);
          self.comments = all;
          self.total = data && data.pagebar ? parseInt(data.pagebar.AllCount, 10) || all.length : all.length;
          self.commentMap = {};
          all.forEach(function (c) { self.commentMap[c.ID] = c; });
          var pagebar = data && data.pagebar;
          if (pagebar && page < parseInt(pagebar.PageAll, 10) && all.length < 1000) {
            page += 1;
            next();
          } else {
            self.loading = false;
            if (done) { done(); }
          }
        }).catch(function (err) {
          self.error = err.message || String(err);
          self.loading = false;
          if (done) { done(); }
        });
      };
      next();
    },
    replyTo: function (c) {
      if (window.zbp && window.zbp.comment) {
        window.zbp.comment.reply(c.ID);
      }
    },
    parentName: function (c) {
      var parent = this.commentMap[c.ParentID];
      if (!parent) {
        return '';
      }
      return parent.Author ? (parent.Author.StaticName || parent.Author.Name) : (parent.Name || '');
    },
    commentAuthorName: function (c) {
      if (c.Author) {
        return c.Author.StaticName || c.Author.Name;
      }
      return c.Name || '';
    },
    isRoot: function (c) {
      return Number(c.AuthorID) > 0 && Number(this.post.AuthorID) > 0 && Number(c.AuthorID) === Number(this.post.AuthorID);
    },
    floorOf: function (c) {
      var n = 0;
      var hit = null;
      this.comments.forEach(function (item) {
        if (Number(item.ParentID) === 0) {
          n += 1;
          if (item.ID === c.ID) {
            hit = n;
          }
        }
      });
      return hit;
    },
    fmtTime: function (ts) { return fmtTime(ts, 'short'); }
  },
  template:
    '<section id="comments" class="border-terminal-dim mb-8 border border-dashed p-3 md:p-4">' +
      '<h2 class="text-terminal-green mb-4 font-mono text-xs">[COMMENTS] ({{ total }})</h2>' +
      '<div v-if="error" class="text-terminal-dim mb-4 border border-dashed p-2 text-xs">{{ error }}</div>' +
      '<div v-else-if="loading" class="text-terminal-dim mb-4 text-xs">Loading comments...</div>' +
      '<div v-else>' +
        '<ul class="mb-4 space-y-1 font-mono text-xs md:text-sm">' +
          '<label id="AjaxCommentBegin"></label>' +
          '<template v-for="c in comments" :key="c.ID">' +
            '<li :id="\'cmt\' + c.ID" class="group grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-2 px-1 py-1 text-terminal-green transition-colors md:grid-cols-12 md:gap-2">' +
              '<div class="hidden whitespace-nowrap md:col-span-2 md:col-start-1 md:block">{{ isRoot(c) ? \'root\' : \'user\' }}</div>' +
              '<time class="text-terminal-dim col-start-2 row-start-1 justify-self-end whitespace-nowrap md:col-span-2 md:col-start-3 md:justify-self-auto">{{ fmtTime(c.PostTime) }}</time>' +
              '<div class="col-start-1 row-start-1 min-w-0 md:col-span-8 md:col-start-5">' +
                '<a v-if="Number(c.ParentID) > 0" :href="\'#cmt\' + c.ParentID" class="text-terminal-dim hover:text-terminal-green underline-offset-2 hover:underline" :title="\'回复自 #cmt\' + c.ParentID">@{{ parentName(c) }}</a>' +
                '<span class="text-terminal-green">{{ commentAuthorName(c) }}: </span>' +
                '<span class="break-words text-inherit">{{ c.Content }}</span>' +
                '<span v-if="c.IsChecking" class="text-terminal-dim ml-2">[Pending]</span>' +
                '<span v-if="Number(c.ParentID) === 0 && floorOf(c)" class="text-terminal-dim ml-2">#{{ floorOf(c) }}</span>' +
                '<button type="button" class="text-terminal-dim hover:text-terminal-green ml-2 cursor-pointer bg-transparent p-0 font-mono text-xs underline-offset-2 hover:underline" @click="replyTo(c)">Reply</button>' +
              '</div>' +
            '</li>' +
            '<label :id="\'AjaxComment\' + c.ID"></label>' +
            '<li v-if="replyTarget === c.ID" id="sky-comment-form" class="mt-2 border-t border-dashed pt-2">' +
              '<sky-comment-form :post-id="post.ID" :action="commentAction" :reply-id="replyTarget" :show-verify="commentVerify" :verify-code-url="verifyUrl" :logged-in="loggedIn" :user-info="userInfo" :posting="posting" :form-error="formError"></sky-comment-form>' +
            '</li>' +
          '</template>' +
          '<label id="AjaxCommentEnd"></label>' +
          '<li v-if="comments.length === 0" class="text-terminal-dim font-mono text-xs">No comments yet.</li>' +
        '</ul>' +
      '</div>' +
      '<sky-comment-form v-if="replyTarget === null" :post-id="post.ID" :action="commentAction" :reply-id="0" :show-verify="commentVerify" :verify-code-url="verifyUrl" :logged-in="loggedIn" :user-info="userInfo" :posting="posting" :form-error="formError"></sky-comment-form>' +
    '</section>',
  computed: {
    user: function () { return Sky.user; },
    siteName: function () { return Sky.siteName; },
    loggedIn: function () {
      /* 远程模式：登录态以数据源站为准（remoteLoggedIn），登录后评论表单显示已登录、免填 name */
      if (Sky.remote) {
        return Sky.remoteLoggedIn;
      }
      return Sky.userId > 0;
    },
    userInfo: function () {
      if (Sky.remote) {
        return Sky.userInfo;
      }
      return Sky.userInfo;
    },
    commentVerify: function () {
      /* 远程模式：验证码开关以数据源站 basic_info 的 comment_verify_enable 为准
         （remoteInit 已写入 Sky.commentVerify），而不是文章接口的 ValidCodeUrl 字段——
         源站关闭评论验证码后 ValidCodeUrl 仍会返回，按字段判断会错误显示验证码 */
      return Sky.commentVerify;
    },
    commentAction: function () {
      if (Sky.remote) {
        var p = this.post;
        if (p && p.ID && p.CommentPostKey) {
          return proxyify(Sky.remoteRoot + '/zb_system/cmd.php?act=cmt&postid=' + p.ID + '&key=' + encodeURIComponent(p.CommentPostKey));
        }
        return '';
      }
      return (Sky.post && Sky.post.commentPostUrl) || '';
    },
    verifyUrl: function () {
      var v = this.post.ValidCodeUrl || '';
      return Sky.remote ? proxyify(v) : v;
    }
  }
};

/* ---- 5.8 文章视图（文章/独立页） ---- */
var SkyPostView = {
  name: 'sky-post-view',
  data: function () {
    return {
      post: null,
      loading: true,
      error: '',
      progress: 0,
      scrollHandler: null,
      keydownHandler: null
    };
  },
  computed: {
    user: function () { return Sky.user; },
    siteName: function () { return Sky.siteName; },
    urls: function () { return Sky.urls; },
    currentPathStr: function () { return currentPath(); },
    isArticle: function () {
      return Sky.pageType === 'post';
    },
    showLsSim: function () {
      return Sky.config.lsSim;
    },
    catCommand: function () {
      var title = (this.post && this.post.Title) || '';
      return '"' + String(title).replace(/"/g, '') + '.md"';
    },
    chars: function () {
      if (!this.post || !this.post.Content) {
        return 0;
      }
      return String(this.post.Content).replace(/<[^>]*>/g, '').length;
    },
    authorName: function () {
      return this.post && this.post.Author ? (this.post.Author.StaticName || this.post.Author.Name) : '—';
    },
    detailsOpen: function () {
      return isDesktop();
    }
  },
  watch: {
    /* 远程模式：fetchPost 可能早于 remoteInit 完成，站名尚未更新为数据源站；
       站名就绪后重新设置 <title>（文章标题不变，仅校正站名） */
    siteName: function (v) {
      if (Sky.remote && this.post && this.post.Title) {
        document.title = this.post.Title + (v ? ' - ' + v : '');
      }
    }
  },
  mounted: function () {
    var self = this;
    var id = Sky.post ? Sky.post.id : 0;
    if (Sky.remote && !id) {
      id = resolveRemoteParams().id || 0;
    }
    if (!id) {
      this.error = '缺少文章 ID。';
      this.loading = false;
      return;
    }
    apiGet({ mod: 'post', act: 'get', id: id, with_relations: 'Author,Category,Tags' }).then(function (data) {
      self.post = (data && data.post) || null;
      self.loading = false;
      if (self.post) {
        /* 远程模式（含 404 承载页）：文章加载成功后同步页面标题与描述 */
        if (Sky.remote) {
          var st = Sky.siteName || '';
          document.title = self.post.Title + (st ? ' - ' + st : '');
          var meta = document.querySelector('meta[name="description"]');
          if (meta && self.post.Intro) {
            meta.setAttribute('content', String(self.post.Intro).replace(/<[^>]*>/g, '').slice(0, 200));
          }
        }
        self.$nextTick(function () {
          self.bindScroll();
          self.buildTocAnchors();
        });
      }
    }).catch(function (err) {
      self.error = err.message || String(err);
      self.loading = false;
      console.error('[CRTShellVue] 文章数据加载失败:', err);
    });
    this.keydownHandler = function (e) { self.handlePostKeydown(e); };
    window.addEventListener('keydown', this.keydownHandler);
  },
  beforeUnmount: function () {
    if (this.keydownHandler) {
      window.removeEventListener('keydown', this.keydownHandler);
    }
    this.unbindScroll();
  },
  methods: {
    handlePostKeydown: function (e) {
      if (isKeyboardBlocked(e)) {
        return;
      }
      var main = scrollMain();
      if (!main) {
        return;
      }
      switch (e.key) {
        case 'ArrowDown':
        case 'j':
          e.preventDefault();
          main.scrollBy({ behavior: scrollBehavior(), top: 100 });
          break;
        case 'ArrowUp':
        case 'k':
          e.preventDefault();
          main.scrollBy({ behavior: scrollBehavior(), top: -100 });
          break;
        case 'PageDown':
          e.preventDefault();
          main.scrollBy({ behavior: scrollBehavior(), top: main.clientHeight * 0.8 });
          break;
        case ' ':
          e.preventDefault();
          main.scrollBy({ behavior: scrollBehavior(), top: (e.shiftKey ? -1 : 1) * main.clientHeight * 0.8 });
          break;
        case 'End':
          e.preventDefault();
          main.scrollTo({ behavior: scrollBehavior(), top: main.scrollHeight });
          break;
        case 'Home':
          e.preventDefault();
          main.scrollTo({ behavior: scrollBehavior(), top: 0 });
          break;
        case 'PageUp':
          e.preventDefault();
          main.scrollBy({ behavior: scrollBehavior(), top: -main.clientHeight * 0.8 });
          break;
      }
    },
    bindScroll: function () {
      var self = this;
      var main = scrollMain();
      if (!main) {
        return;
      }
      this.scrollHandler = function () {
        var top = main.scrollTop;
        var max = main.scrollHeight - main.clientHeight;
        self.progress = max > 0 ? Math.min(100, Math.max(0, Math.round(top / max * 100))) : 100;
      };
      main.addEventListener('scroll', this.scrollHandler, { passive: true });
      this.scrollHandler();
    },
    unbindScroll: function () {
      var main = scrollMain();
      if (main && this.scrollHandler) {
        main.removeEventListener('scroll', this.scrollHandler);
      }
      this.scrollHandler = null;
    },
    buildTocAnchors: function () {
      var root = this.$el.querySelector('.terminal-content');
      if (!root) {
        return;
      }
      root.querySelectorAll('h2, h3').forEach(function (h, i) {
        var text = (h.textContent || '').trim();
        if (!h.id) {
          h.id = 'toc-' + (text.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '') || 'section') + '-' + (i + 1);
        }
      });
    },
    tocItems: function () {
      return tocHeadings();
    },
    jumpToHeading: function (id) {
      var el = document.getElementById(id);
      if (el) {
        el.scrollIntoView({ behavior: scrollBehavior(), block: 'start' });
      }
    },
    back: function () {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        go(Sky.urls.home);
      }
    },
    fmtFull: function (ts) { return fmtTime(ts, 'full'); }
  },
  template:
    '<div v-if="error" class="text-terminal-dim border-terminal-dim border border-dashed p-3 text-xs md:p-4">{{ error }}</div>' +
    '<div v-else-if="loading" class="text-terminal-dim border-terminal-dim border border-dashed p-3 text-xs md:p-4">Loading...</div>' +
    '<div v-else>' +
      '<div v-if="showLsSim" class="text-terminal-green mb-3 flex min-w-0 flex-col items-start gap-1 md:mb-4 md:flex-row md:items-center md:gap-2">' +
        '<span class="text-terminal-dim min-w-0 break-all">{{ user }}@<span>{{ siteName }}</span>:<span class="text-terminal-green">{{ currentPathStr }}</span>$</span>' +
        '<sky-typing :text="isArticle ? catCommand : \'cat page.md\'" :speed="30" class="min-w-0 break-words"></sky-typing>' +
      '</div>' +
      '<template v-if="isArticle">' +
        '<article class="prose prose-invert max-w-none min-w-0">' +
          '<h1 class="border-terminal-green mb-4 border-b-2 border-dashed pb-4 text-3xl break-words md:mb-6">{{ post.Title }}</h1>' +
          '<div class="border-terminal-dim text-terminal-dim mb-4 border border-dashed p-2 font-mono text-xs">' +
            '<div class="mb-1 flex items-center justify-between">' +
              '<span>READ_PROGRESS</span>' +
              '<span>{{ progress }}%</span>' +
            '</div>' +
            '<div class="bg-terminal-green/10 h-1 overflow-hidden">' +
              '<div class="bg-terminal-green h-full transition-[width]" :style="\'width: \' + progress + \'%\'"></div>' +
            '</div>' +
          '</div>' +
          '<div class="border-terminal-green bg-terminal-green/20 relative mb-4 overflow-hidden border p-3 font-mono text-xs md:mb-6 md:p-4">' +
            '<div class="bg-terminal-green animate-scanline absolute top-0 left-0 h-1 w-full opacity-20"></div>' +
            '<div class="grid grid-cols-1 gap-2 break-words sm:grid-cols-2">' +
              '<div><span class="text-terminal-dim">File:</span> <span>{{ post.Title }}.md</span></div>' +
              '<div><span class="text-terminal-dim">Characters:</span> <span>{{ chars }}</span></div>' +
              '<div><span class="text-terminal-dim">Author:</span> <span>{{ authorName }}</span></div>' +
              '<div><span class="text-terminal-dim">Published:</span> <time>{{ fmtFull(post.PostTime) }}</time></div>' +
            '</div>' +
          '</div>' +
          '<details v-if="tocItems().length > 0" :open="detailsOpen" class="border-terminal-dim text-terminal-dim mb-4 border border-dashed px-4 font-mono text-xs md:mb-6">' +
            '<summary class="text-terminal-green hover:text-terminal-green inline-flex min-h-10 cursor-pointer items-center py-2 md:min-h-0" aria-label="Article table of contents">[TOC]</summary>' +
            '<nav aria-label="Article table of contents">' +
              '<ol class="space-y-1 pb-3">' +
                '<li v-for="(item, index) in tocItems()" :key="item.id" :class="{ \'pl-4\': item.level > 2 }">' +
                  '<button type="button" class="hover:text-terminal-green inline-flex min-h-10 cursor-pointer items-center bg-transparent p-0 text-left font-mono text-inherit transition-colors md:min-h-0" @click="jumpToHeading(item.id)"><span>{{ String(index + 1).padStart(2, \'0\') }}</span>.<span>{{ item.text }}</span></button>' +
                '</li>' +
              '</ol>' +
            '</nav>' +
          '</details>' +
          '<div class="terminal-content max-w-full min-w-0" v-html="post.Content"></div>' +
        '</article>' +
        '<div class="text-terminal-dim mt-12 mb-8 animate-pulse text-center">*** END OF FILE ***</div>' +
        '<sky-comments v-if="!post.IsLock" :post="post"></sky-comments>' +
        '<div class="mb-8 flex flex-wrap gap-3">' +
          '<button type="button" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex min-h-10 cursor-pointer items-center border bg-transparent px-4 py-1 font-mono transition-colors" @click="back">[BACK]</button>' +
          '<a :href="urls.home" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex min-h-10 items-center border px-4 py-1 font-mono transition-colors">cd ..</a>' +
        '</div>' +
      '</template>' +
      '<template v-else>' +
        '<article class="prose prose-invert max-w-none min-w-0">' +
          '<div class="terminal-content max-w-full min-w-0">' +
            '<h1 class="border-terminal-green mb-8 border-b-2 border-dashed pb-4 text-3xl break-words">{{ post.Title }}</h1>' +
            '<div v-html="post.Content"></div>' +
          '</div>' +
        '</article>' +
        '<div class="mb-8">' +
          '<a :href="urls.home" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-block border px-4 py-1 font-mono transition-colors">cd /</a>' +
        '</div>' +
      '</template>' +
    '</div>'
};

/* ---- 5.9 归档视图 ---- */
var SkyArchivesView = {
  name: 'sky-archives-view',
  mixins: [fileListNavMixin],
  data: function () {
    return { groups: [], loading: true, error: '', total: 0 };
  },
  computed: {
    showLsSim: function () { return Sky.config.lsSim; },
    user: function () { return Sky.user; },
    siteName: function () { return Sky.siteName; },
    pageTitle: function () { return Sky.pageTitle || 'ARCHIVES'; }
  },
  mounted: function () {
    var self = this;
    if (Sky.remote) {
      document.title = 'archives' + (Sky.siteName ? ' - ' + Sky.siteName : '');
    }
    var all = [];
    var page = 1;
    var maxPages = 20;
    this.loading = true;
    var next = function () {
      if (page > maxPages || all.length >= 1000) {
        self.finish(all);
        return;
      }
      apiGet({
        mod: 'post', act: 'list', type: 0, perpage: 50, page: page,
        sortby: 'PostTime', order: 'desc', without_content: 1, with_relations: 'Author'
      }).then(function (data) {
        var list = (data && data.list) || [];
        all = all.concat(list);
        var pagebar = data && data.pagebar;
        if (pagebar && page < parseInt(pagebar.PageAll, 10)) {
          page += 1;
          next();
        } else {
          self.finish(all);
        }
      }).catch(function (err) {
        self.error = err.message || String(err);
        self.loading = false;
      });
    };
    next();
  },
  methods: {
    finish: function (all) {
      var self = this;
      if (Sky.remote) {
        all.forEach(localizePost);
      }
      Sky.currentPosts = all;
      this.total = all.length;
      var map = {};
      all.forEach(function (p) {
        var d = ts2date(p.PostTime);
        if (!d) {
          return;
        }
        var y = String(d.getFullYear());
        var m = String(d.getMonth() + 1);
        if (!map[y]) {
          map[y] = {};
        }
        if (!map[y][m]) {
          map[y][m] = [];
        }
        map[y][m].push(p);
      });
      var years = Object.keys(map).sort(function (a, b) { return Number(b) - Number(a); });
      var groups = [];
      years.forEach(function (y) {
        var months = Object.keys(map[y]).sort(function (a, b) { return Number(b) - Number(a); });
        var monthList = [];
        months.forEach(function (m) {
          monthList.push({ month: Number(m), posts: map[y][m] });
        });
        groups.push({ year: Number(y), months: monthList });
      });
      this.groups = groups;
      this.loading = false;
      this.$nextTick(function () {
        self.refreshNavItems();
      });
    },
    rowPerm: rowPerm,
    authorOf: authorOf,
    fmtShort: function (ts) { return fmtTime(ts, 'short'); }
  },
  template:
    '<div>' +
      '<div v-if="showLsSim" class="text-terminal-green mb-3 flex min-w-0 items-center gap-2 md:mb-6">' +
        '<span class="text-terminal-dim min-w-0 truncate">{{ user }}@<span>{{ siteName }}</span>:~/blog/archives$</span>' +
        '<sky-typing text="find ./posts -type f" :speed="35"></sky-typing>' +
      '</div>' +
      '<h1 class="border-terminal-green mb-3 border-b-2 border-dashed pb-2 text-xl break-words md:mb-6 md:pb-3 md:text-2xl">{{ pageTitle }}</h1>' +
      '<div v-if="error" class="text-terminal-dim border-terminal-dim border border-dashed p-3 text-xs md:p-4">{{ error }}</div>' +
      '<div v-else-if="loading" class="text-terminal-dim border-terminal-dim border border-dashed p-3 text-xs md:p-4">Loading...</div>' +
      '<div v-else-if="total === 0" class="text-terminal-dim border-terminal-dim border border-dashed p-3 text-xs md:p-4">No archived posts found.</div>' +
      '<div v-else>' +
        '<section v-for="g in groups" :key="g.year" class="mb-4 md:mb-8">' +
          '<h2 class="text-terminal-green mb-1 text-lg font-bold md:mb-3 md:text-xl">[{{ g.year }}]</h2>' +
          '<section v-for="m in g.months" :key="g.year + \'-\' + m.month" class="mb-3 md:mb-5">' +
            '<h3 class="text-terminal-dim mb-1 text-sm md:mb-2">MONTH {{ m.month }}</h3>' +
            '<ul class="font-mono text-xs md:space-y-1 md:text-sm">' +
              '<li v-for="post in m.posts" :key="post.ID" data-nav-item :data-nav-key="\'arch-\' + post.ID" :class="{ \'!bg-terminal-green !text-terminal-black\': isNavSelected(\'arch-\' + post.ID) }" class="group text-terminal-green hover:text-terminal-dim grid min-h-10 cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-x-2 px-1 transition-colors md:min-h-0 md:grid-cols-[8rem_minmax(0,1fr)] md:py-0">' +
                '<time class="text-terminal-dim col-start-2 row-start-1 justify-self-end whitespace-nowrap opacity-70 group-hover:opacity-100 md:col-start-1 md:justify-self-auto">{{ fmtShort(post.PostTime) }}</time>' +
                '<a :href="post.Url" class="col-start-1 row-start-1 flex min-h-10 min-w-0 items-center py-1 break-words text-inherit md:col-start-2 md:block md:min-h-0 md:truncate md:py-0">{{ post.Title }}</a>' +
              '</li>' +
            '</ul>' +
          '</section>' +
        '</section>' +
        '<div class="text-terminal-dim mt-2 text-xs md:mt-4">{{ total }} files found.</div>' +
      '</div>' +
    '</div>'
};

/* ---- 5.10 分类视图 / 标签视图 ---- */
var SkyCategoriesView = {
  name: 'sky-categories-view',
  mixins: [fileListNavMixin],
  computed: {
    showLsSim: function () { return Sky.config.lsSim; },
    user: function () { return Sky.user; },
    siteName: function () { return Sky.siteName; },
    pageTitle: function () { return Sky.pageTitle || 'CATEGORIES'; },
    urls: function () { return Sky.urls; },
    cats: function () {
      return (Sky.categories || []).map(function (e) {
        return { key: entrySlug(e), name: entryName(e), url: localizeUrl(e.status && e.status.permalink), count: e.postCount || 0 };
      });
    }
  },
  mounted: function () {
    if (Sky.remote) {
      document.title = 'categories' + (Sky.siteName ? ' - ' + Sky.siteName : '');
    }
  },
  template:
    '<div>' +
      '<div v-if="showLsSim" class="text-terminal-green mb-3 flex min-w-0 items-center gap-2 md:mb-6">' +
        '<span class="text-terminal-dim min-w-0 truncate">{{ user }}@<span>{{ siteName }}</span>:~/blog$</span>' +
        '<sky-typing text="ls -la ./categories" :speed="35"></sky-typing>' +
      '</div>' +
      '<h1 class="border-terminal-green mb-3 border-b-2 border-dashed pb-2 text-xl break-words md:mb-6 md:pb-3 md:text-2xl">{{ pageTitle }}</h1>' +
      '<ul class="font-mono text-xs md:space-y-1 md:text-sm">' +
        '<li class="hidden select-none px-1 text-terminal-dim md:grid md:grid-cols-12 md:gap-2" aria-hidden="true">' +
          '<span class="col-span-2">PERMISSIONS</span><span class="col-span-2">POSTS</span><span class="col-span-8">NAME</span>' +
        '</li>' +
        '<li data-nav-item data-nav-key="cat-parent" :class="{ \'!bg-terminal-green !text-terminal-black\': isNavSelected(\'cat-parent\') }" class="group text-terminal-green hover:text-terminal-dim grid min-h-10 cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-x-2 px-1 transition-colors md:min-h-0 md:grid-cols-12 md:gap-2 md:py-0">' +
          '<div class="hidden whitespace-nowrap md:col-span-2 md:block">drwxr-xr-x</div>' +
          '<div class="hidden md:col-span-2 md:block">-</div>' +
          '<div class="col-start-1 row-start-1 min-w-0 md:col-span-8 md:col-start-5"><a :href="urls.home" class="flex min-h-10 min-w-0 items-center py-1 break-words text-inherit md:block md:min-h-0 md:py-0">../</a></div>' +
        '</li>' +
        '<li v-for="cat in cats" :key="cat.key" data-nav-item :data-nav-key="\'cat-\' + cat.key" :class="{ \'!bg-terminal-green !text-terminal-black\': isNavSelected(\'cat-\' + cat.key) }" class="group text-terminal-green hover:text-terminal-dim grid min-h-10 cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-x-2 px-1 transition-colors md:min-h-0 md:grid-cols-12 md:gap-2 md:py-0">' +
          '<div class="hidden whitespace-nowrap opacity-70 group-hover:opacity-100 md:col-span-2 md:block">drwxr-xr-x</div>' +
          '<div class="hidden opacity-70 group-hover:opacity-100 md:col-span-2 md:block">{{ cat.count }}</div>' +
          '<div class="col-start-2 row-start-1 justify-self-end whitespace-nowrap opacity-70 group-hover:opacity-100 md:hidden">{{ cat.count }} posts</div>' +
          '<div class="col-start-1 row-start-1 min-w-0 md:col-span-8 md:col-start-5"><a :href="cat.url" class="flex min-h-10 min-w-0 items-center py-1 break-words text-inherit md:block md:min-h-0 md:truncate md:py-0">{{ cat.name }}/</a></div>' +
        '</li>' +
      '</ul>' +
      '<div class="text-terminal-dim mt-2 text-xs md:mt-4">{{ cats.length }} directories found.</div>' +
    '</div>'
};
var SkyTagsView = {
  name: 'sky-tags-view',
  mixins: [fileListNavMixin],
  data: function () {
    return {
      items: [],   /* 远程：当前页标签（30 个/页，按需拉取） */
      loading: false,
      error: '',
      page: 1,
      pageAll: 0,
      total: 0
    };
  },
  computed: {
    showLsSim: function () { return Sky.config.lsSim; },
    user: function () { return Sky.user; },
    siteName: function () { return Sky.siteName; },
    pageTitle: function () { return Sky.pageTitle || 'TAGS'; },
    urls: function () { return Sky.urls; },
    tags: function () {
      /* 远程：当前页数据按 30 个/页从数据源站 API 拉取；
         本地：服务端仅在标签页注入当前页标签（每页 30），同样存于 items */
      return this.items;
    },
    hasPrev: function () { return this.page > 1; },
    hasNext: function () { return this.pageAll > this.page; },
    remoteLocked: function () {
      return Sky.remote && !Sky.remoteLoggedIn && Sky.userId <= 0;
    },
    filesText: function () {
      /* 本地：Sky.tagTotal 为服务端注入的总标签数（不随注入体积增大） */
      return Sky.remote ? this.total : Sky.tagTotal;
    }
  },
  methods: {
    goPage: function (p) {
      if (Sky.remote) {
        if (p < 1) { p = 1; }
        if (this.pageAll > 0 && p > this.pageAll) { p = this.pageAll; }
        if (p === this.page) { return; }
        this.fetchTags(p);
      } else {
        /* 本地：服务端只注入当前页标签，翻页必须重新请求页面（tags.html?page=N） */
        if (p < 1) { p = 1; }
        if (this.pageAll > 0 && p > this.pageAll) { p = this.pageAll; }
        if (p === this.page) { return; }
        var base = (Sky.urls && Sky.urls.tags) || '/tags.html';
        window.location.href = base + '?page=' + p;
      }
    },
    fetchTags: function (page) {
      var self = this;
      self.loading = true;
      self.error = '';
      apiGet({ mod: 'tag', act: 'list', perpage: 30, page: page }).then(function (data) {
        self.loading = false;
        self.page = page;
        self.items = ((data && data.list) || []).map(function (tg) {
          return {
            key: String(tg.ID),
            name: (tg.Alias && tg.Alias !== '') ? tg.Alias : tg.Name,
            url: localizeUrl(tg.Url),
            count: tg.Count || 0
          };
        });
        var pb = data && data.pagebar;
        self.pageAll = pb ? (parseInt(pb.PageAll, 10) || 0) : 0;
        self.total = pb ? (parseInt(pb.AllCount, 10) || 0) : self.items.length;
        if (Sky.remote) {
          document.title = 'tags' + (Sky.siteName ? ' - ' + Sky.siteName : '');
        }
      }).catch(function (err) {
        self.loading = false;
        if (Sky.remote && !Sky.remoteLoggedIn) {
          /* 未登录：不显示接口错误，由模板 remoteLocked 提示登录 */
          self.error = '';
        } else {
          self.error = err.message || String(err);
        }
      });
    }
  },
  mounted: function () {
    if (Sky.remote) {
      document.title = 'tags' + (Sky.siteName ? ' - ' + Sky.siteName : '');
      /* 无条件尝试拉取第一页：已登录直接成功；未登录会 401，
         由 catch 分支静默（模板显示 remoteLocked 登录提示），登录成功后页面刷新重拉 */
      this.fetchTags(1);
    } else {
      /* 本地：直接使用服务端注入的当前页标签（30 个/页）与分页元数据 */
      this.items = (Sky.tags || []).map(function (e) {
        return { key: entrySlug(e), name: entryName(e), url: localizeUrl(e.status && e.status.permalink), count: e.postCount || 0 };
      });
      this.page = Sky.tagPage || 1;
      this.pageAll = Sky.tagPageAll || 0;
      this.total = Sky.tagTotal || 0;
    }
  },
  template:
    '<div>' +
      '<div v-if="showLsSim" class="text-terminal-green mb-3 flex min-w-0 items-center gap-2 md:mb-6">' +
        '<span class="text-terminal-dim min-w-0 truncate">{{ user }}@<span>{{ siteName }}</span>:~/blog$</span>' +
        '<sky-typing text="ls -la ./tags" :speed="35"></sky-typing>' +
      '</div>' +
      '<div v-if="remoteLocked" class="border-terminal-dim bg-terminal-green/20 text-terminal-green mb-3 flex min-h-10 flex-wrap items-center gap-x-2 border px-2 py-2 text-xs md:mb-4 md:p-3">' +
        '<span>标签列表接口需登录数据源后可见。</span>' +
        '<button type="button" data-terminal-action="login" class="hover:text-terminal-black cursor-pointer bg-transparent p-0 font-mono text-xs underline underline-offset-2">[LOGIN]</button>' +
      '</div>' +
      '<div v-if="error" class="text-terminal-dim border-terminal-dim border border-dashed p-3 text-xs md:p-4">{{ error }}</div>' +
      '<h1 class="border-terminal-green mb-3 border-b-2 border-dashed pb-2 text-xl break-words md:mb-6 md:pb-3 md:text-2xl">{{ pageTitle }}</h1>' +
      '<ul class="font-mono text-xs md:space-y-1 md:text-sm">' +
        '<li class="hidden select-none px-1 text-terminal-dim md:grid md:grid-cols-12 md:gap-2" aria-hidden="true">' +
          '<span class="col-span-2">PERMISSIONS</span><span class="col-span-2">POSTS</span><span class="col-span-8">NAME</span>' +
        '</li>' +
        '<li data-nav-item data-nav-key="tag-parent" :class="{ \'!bg-terminal-green !text-terminal-black\': isNavSelected(\'tag-parent\') }" class="group text-terminal-green hover:text-terminal-dim grid min-h-10 cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-x-2 px-1 transition-colors md:min-h-0 md:grid-cols-12 md:gap-2 md:py-0">' +
          '<div class="hidden whitespace-nowrap md:col-span-2 md:block">drwxr-xr-x</div>' +
          '<div class="hidden md:col-span-2 md:block">-</div>' +
          '<div class="col-start-1 row-start-1 min-w-0 md:col-span-8 md:col-start-5"><a :href="urls.home" class="flex min-h-10 min-w-0 items-center py-1 break-words text-inherit md:block md:min-h-0 md:py-0">../</a></div>' +
        '</li>' +
        '<li v-for="tag in tags" :key="tag.key" data-nav-item :data-nav-key="\'tag-\' + tag.key" :class="{ \'!bg-terminal-green !text-terminal-black\': isNavSelected(\'tag-\' + tag.key) }" class="group text-terminal-green hover:text-terminal-dim grid min-h-10 cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-center gap-x-2 px-1 transition-colors md:min-h-0 md:grid-cols-12 md:gap-2 md:py-0">' +
          '<div class="hidden whitespace-nowrap opacity-70 group-hover:opacity-100 md:col-span-2 md:block">drwxr-xr-x</div>' +
          '<div class="hidden opacity-70 group-hover:opacity-100 md:col-span-2 md:block">{{ tag.count }}</div>' +
          '<div class="col-start-2 row-start-1 justify-self-end whitespace-nowrap opacity-70 group-hover:opacity-100 md:hidden">{{ tag.count }} posts</div>' +
          '<div class="col-start-1 row-start-1 min-w-0 md:col-span-8 md:col-start-5"><a :href="tag.url" class="flex min-h-10 min-w-0 items-center py-1 break-words text-inherit md:block md:min-h-0 md:truncate md:py-0">#{{ tag.name }}</a></div>' +
        '</li>' +
      '</ul>' +
      '<div class="text-terminal-dim mt-2 flex flex-wrap items-center justify-between gap-x-4 gap-y-1 text-xs md:mt-4">' +
        '<span>{{ filesText }} files found.</span>' +
        '<span class="flex items-center gap-3">' +
          '<a v-if="hasPrev" href="#" @click.prevent="goPage(page - 1)" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex min-h-10 cursor-pointer items-center border bg-transparent px-4 py-1 transition-colors md:min-h-0">[PREV]</a>' +
          '<a v-if="hasNext" href="#" @click.prevent="goPage(page + 1)" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex min-h-10 cursor-pointer items-center border bg-transparent px-4 py-1 transition-colors md:min-h-0">[NEXT]</a>' +
          '<span v-if="pageAll > 1" class="text-terminal-dim">Page {{ page }}/{{ pageAll }}</span>' +
        '</span>' +
      '</div>' +
    '</div>'
};

/* ---- 5.11 终端输入 ---- */
var SkyTerminalInput = {
  name: 'sky-terminal-input',
  data: function () {
    return {
      command: '',
      currentPath: '~/blog',
      history: [],
      historyIndex: -1,
      output: '',
      showHelp: false,
      completionState: { candidates: [], index: 0 },
      executionId: 0
    };
  },
  computed: {
    user: function () { return Sky.user; },
    siteName: function () { return Sky.siteName; },
    promptUser: function () {
      return Sky.userId > 0 ? Sky.user : 'guest';
    },
    helpText: function () {
      return isPostPageType() ? POST_HELP : LIST_HELP;
    }
  },
  mounted: function () {
    var self = this;
    this.currentPath = currentPath();
    if (isDesktop() && ['post', 'page'].indexOf(Sky.pageType) < 0) {
      this.$nextTick(function () {
        if (self.$refs.cmdInput) {
          self.$refs.cmdInput.focus();
        }
      });
    }
  },
  methods: {
    focusInput: function () {
      if (this.$refs.cmdInput) {
        this.$refs.cmdInput.focus();
      }
    },
    isPostPage: function () {
      return isPostPageType();
    },
    autoComplete: function () {
      var candidates = this.completionState.candidates;
      var idx = this.completionState.index;
      if (candidates.length > 0 && this.command === candidates[idx]) {
        this.completionState.index = (idx + 1) % candidates.length;
      } else {
        this.completionState.candidates = completeCandidates(this.command, String(this.currentPath), this.isPostPage());
        this.completionState.index = 0;
      }
      if (this.completionState.candidates.length > 0) {
        this.command = this.completionState.candidates[this.completionState.index];
      }
    },
    executeCommand: function () {
      var self = this;
      var raw = this.command.trim();
      if (!raw) {
        return;
      }
      if (this.history[this.history.length - 1] !== raw) {
        this.history.push(raw);
      }
      this.historyIndex = this.history.length;
      var execId = ++this.executionId;
      var parts = raw.split(/\s+/);
      var name = parts[0];
      var arg = parts.slice(1).join(' ');
      this.command = '';
      this.completionState.candidates = [];
      this.completionState.index = 0;
      this.showHelp = false;
      this.output = '';
      var result = runCommand(name, arg, String(this.currentPath));
      if (result && typeof result.then === 'function') {
        result.then(function (r) {
          if (execId !== self.executionId) {
            return;
          }
          self.applyResult(r);
        }).catch(function (err) {
          if (execId !== self.executionId) {
            return;
          }
          console.error('[CRTShellVue] 终端命令执行失败:', err);
          self.output = 'Command failed unexpectedly. Please try again.';
        });
      } else {
        this.applyResult(result);
      }
    },
    applyResult: function (r) {
      if (r.navigate) {
        go(r.navigate);
      } else if (r.newPath) {
        this.currentPath = r.newPath;
        this.output = '';
      } else if (r.showHelp) {
        this.showHelp = true;
      } else if (r.output) {
        this.output = r.output;
      }
    },
    handleKeydown: function (e) {
      if (e.isComposing) {
        return;
      }
      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          this.navigateHistory(1);
          break;
        case 'ArrowUp':
          e.preventDefault();
          this.navigateHistory(-1);
          break;
        case 'Enter':
          e.preventDefault();
          this.executeCommand();
          break;
        case 'Escape':
          e.preventDefault();
          this.command = '';
          this.output = '';
          this.showHelp = false;
          if (this.$refs.cmdInput) {
            this.$refs.cmdInput.blur();
          }
          break;
        case 'Tab':
          e.preventDefault();
          this.autoComplete();
          break;
      }
    },
    navigateHistory: function (dir) {
      if (this.history.length === 0) {
        return;
      }
      this.historyIndex += dir;
      if (this.historyIndex < 0) {
        this.historyIndex = 0;
      }
      if (this.historyIndex >= this.history.length) {
        this.historyIndex = this.history.length;
        this.command = '';
        return;
      }
      this.command = this.history[this.historyIndex];
    }
  },
  template:
    '<div class="border-terminal-dim border-t border-dashed pt-2">' +
      '<div class="relative" @click="focusInput">' +
        '<div class="text-terminal-green flex items-center gap-2 overflow-hidden text-sm">' +
          '<span class="text-terminal-dim flex-shrink-0">{{ promptUser }}@<span>{{ siteName }}</span>:<span>{{ currentPath }}</span>$</span>' +
          '<div class="flex items-center">' +
            '<span class="font-mono whitespace-pre">{{ command }}</span>' +
            '<span class="animate-cursor text-terminal-green">█</span>' +
          '</div>' +
        '</div>' +
        '<label for="terminal-command-input" class="sr-only">Terminal command</label>' +
        '<input id="terminal-command-input" ref="cmdInput" v-model="command" @keydown="handleKeydown($event)" type="text" class="absolute inset-0 h-full w-full cursor-text opacity-0" autocomplete="off" spellcheck="false" aria-describedby="terminal-command-help">' +
      '</div>' +
      '<div v-if="output" class="text-terminal-dim mt-1 pl-4 font-mono text-xs whitespace-pre-wrap" role="status" aria-live="polite" aria-atomic="true">{{ output }}</div>' +
      '<pre v-if="showHelp" id="terminal-command-help" class="text-terminal-dim mt-2 pl-4 text-xs whitespace-pre-wrap">{{ helpText }}</pre>' +
    '</div>'
};

/* ---- 5.12 搜索弹窗 ---- */
var SkySearchModal = {
  name: 'sky-search-modal',
  data: function () {
    return { open: false, query: '' };
  },
  computed: {
    user: function () { return Sky.user; },
    siteName: function () { return Sky.siteName; }
  },
  mounted: function () {
    var self = this;
    this.openHandler = function () {
      self.open = true;
      self.query = '';
      self.$nextTick(function () {
        if (self.$refs.input) {
          self.$refs.input.focus();
        }
      });
    };
    window.addEventListener('sky:open-search', this.openHandler);
  },
  beforeUnmount: function () {
    if (this.openHandler) {
      window.removeEventListener('sky:open-search', this.openHandler);
    }
  },
  methods: {
    close: function () {
      this.open = false;
    },
    submit: function () {
      var q = this.query.trim();
      if (q) {
        go(Sky.urls.home + 'search.php?q=' + encodeURIComponent(q));
      }
    }
  },
  template:
    '<div class="sky-search-modal" :class="{ \'sky-search-open\': open }" role="dialog" aria-modal="true" aria-label="站内搜索" @click.self="close">' +
      '<div class="sky-search-box">' +
        '<p class="sky-search-prompt"><span class="sky-search-user">{{ user }}@{{ siteName }}</span>:~/blog$ find ./posts -type f -name "<span class="sky-search-echo">{{ query }}</span>"</p>' +
        '<input ref="input" v-model="query" class="sky-search-input" type="text" placeholder="输入关键词后回车搜索" autocomplete="off" spellcheck="false" @keydown.enter="submit" @keydown.esc="close">' +
        '<p class="sky-search-hint">[Enter] 搜索　[Esc] 关闭</p>' +
      '</div>' +
    '</div>'
};

/* ---- 5.13 登录弹窗 ---- */
var SkyLoginModal = {
  name: 'sky-login-modal',
  data: function () {
    return {
      open: false,
      username: '',
      password: '',
      savedate: '7',
      posting: false,
      error: '',
      notice: ''
    };
  },
  computed: {
    user: function () { return Sky.user; },
    siteName: function () { return Sky.siteName; },
    loggedIn: function () { return Sky.remoteLoggedIn || Sky.userId > 0; },
    loggedName: function () {
      return (Sky.userInfo && (Sky.userInfo.staticName || Sky.userInfo.Name || Sky.userInfo.name)) || Sky.user || 'user';
    }
  },
  mounted: function () {
    var self = this;
    this.openHandler = function () {
      self.open = true;
      self.error = '';
      self.notice = '';
      self.$nextTick(function () {
        if (self.$refs.userInput) {
          self.$refs.userInput.focus();
        }
      });
    };
    window.addEventListener('sky:open-login', this.openHandler);
  },
  beforeUnmount: function () {
    if (this.openHandler) {
      window.removeEventListener('sky:open-login', this.openHandler);
    }
  },
  methods: {
    close: function () { this.open = false; },
    submit: function () {
      var self = this;
      var u = this.username.trim();
      var pw = this.password;
      if (!u) { this.error = '请输入用户名'; return; }
      if (!pw) { this.error = '请输入密码'; return; }
      this.posting = true;
      this.error = '';
      var p = Sky.remote ? skyLogin(u, pw, this.savedate) : skyLoginLocal(u, pw, this.savedate);
      p.then(function () {
        self.posting = false;
        self.notice = '登录成功，正在刷新...';
        window.location.reload();
      }).catch(function (err) {
        self.posting = false;
        self.error = err.message || String(err);
      });
    },
    logout: function () {
      var self = this;
      if (!Sky.remote) {
        /* 本地模式：Z-Blog 原生登出（BuildSafeCmdURL('act=logout')，带 CSRF token） */
        window.location.href = Sky.logoutUrl || (Sky.urls.home + 'zb_system/cmd.php?act=logout');
        return;
      }
      this.posting = true;
      this.error = '';
      skyLogout().then(function () {
        self.posting = false;
        window.location.reload();
      }).catch(function (err) {
        self.posting = false;
        self.error = err.message || String(err);
      });
    }
  },
  template:
    '<div class="sky-search-modal" :class="{ \'sky-search-open\': open }" role="dialog" aria-modal="true" aria-label="数据源登录" @click.self="close">' +
      '<div class="sky-search-box">' +
        '<template v-if="!loggedIn">' +
          '<p class="sky-search-prompt"><span class="sky-search-user">{{ user }}@{{ siteName }}</span>:~$ login</p>' +
          '<form @submit.prevent="submit">' +
            '<input ref="userInput" v-model="username" class="sky-search-input" type="text" placeholder="用户名 (Username)" autocomplete="username" spellcheck="false">' +
            '<input v-model="password" class="sky-search-input" type="password" placeholder="密码 (Password)" autocomplete="current-password">' +
            '<div class="text-terminal-dim mb-2 flex items-center gap-2 font-mono text-xs">' +
              '<label>保存</label>' +
              '<select v-model="savedate" class="border-terminal-dim bg-transparent px-1 py-1 font-mono text-xs text-terminal-green outline-none">' +
                '<option value="1">1 天</option>' +
                '<option value="7">7 天</option>' +
                '<option value="30">30 天</option>' +
                '<option value="365">1 年</option>' +
              '</select>' +
            '</div>' +
            '<p v-if="error" class="text-terminal-dim mb-2 border border-dashed p-2 text-xs">{{ error }}</p>' +
            '<p v-if="notice" class="text-terminal-green mb-2 border border-dashed p-2 text-xs">{{ notice }}</p>' +
            '<div class="flex items-center justify-between gap-3">' +
              '<button type="button" class="border-terminal-dim text-terminal-dim hover:text-terminal-green inline-flex min-h-10 cursor-pointer items-center border bg-transparent px-4 py-1 font-mono text-xs transition-colors" @click="close">[CANCEL]</button>' +
              '<button type="submit" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex min-h-10 cursor-pointer items-center border bg-transparent px-4 py-1 font-mono text-xs transition-colors" :disabled="posting">[LOGIN]</button>' +
            '</div>' +
          '</form>' +
        '</template>' +
        '<template v-else>' +
          '<p class="sky-search-prompt"><span class="sky-search-user">{{ loggedName }}@{{ siteName }}</span>:~$ whoami</p>' +
          '<p class="text-terminal-dim mb-3 font-mono text-xs">已登录数据源：<b class="text-terminal-green">{{ loggedName }}</b></p>' +
          '<div class="flex items-center justify-between gap-3">' +
            '<button type="button" class="border-terminal-dim text-terminal-dim hover:text-terminal-green inline-flex min-h-10 cursor-pointer items-center border bg-transparent px-4 py-1 font-mono text-xs transition-colors" @click="close">[CLOSE]</button>' +
            '<button type="button" class="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-terminal-black inline-flex min-h-10 cursor-pointer items-center border bg-transparent px-4 py-1 font-mono text-xs transition-colors" :disabled="posting" @click="logout">[LOGOUT]</button>' +
          '</div>' +
        '</template>' +
      '</div>' +
    '</div>'
};

/* ---- 5.14 页头登录态栏（远程模式：显示数据源站登录态，登出走数据源站） ---- */
var SkyAuthBar = {
  name: 'sky-auth-bar',
  data: function () {
    return { posting: false };
  },
  computed: {
    loggedIn: function () {
      return Sky.remoteLoggedIn || Sky.userId > 0;
    },
    userName: function () {
      return (Sky.userInfo && (Sky.userInfo.staticName || Sky.userInfo.Name || Sky.userInfo.name)) || Sky.user || 'user';
    }
  },
  methods: {
    login: function () {
      window.dispatchEvent(new CustomEvent('sky:open-login'));
    },
    logout: function () {
      var self = this;
      if (!Sky.remote) {
        /* 本地模式：Z-Blog 原生登出（BuildSafeCmdURL('act=logout')，带 CSRF token）；
           API logout 不带 CSRF 会报 419 非法访问 */
        window.location.href = Sky.logoutUrl || (Sky.urls.home + 'zb_system/cmd.php?act=logout');
        return;
      }
      this.posting = true;
      skyLogout().then(function () {
        window.location.reload();
      }).catch(function () {
        self.posting = false;
        window.location.reload();
      });
    }
  },
  template:
    '<template v-if="loggedIn">' +
      '<div class="text-terminal-dim"><span class="mr-2">USER: <span class="text-terminal-green">{{ userName }}</span></span>' +
        '<button type="button" class="hover:text-terminal-green inline-flex min-h-10 cursor-pointer items-center bg-transparent p-0 font-mono text-xs transition-colors md:min-h-0" :disabled="posting" @click="logout">[LOGOUT]</button>' +
      '</div>' +
    '</template>' +
    '<template v-else>' +
      '<button type="button" class="text-terminal-dim hover:text-terminal-green inline-flex min-h-10 cursor-pointer items-center bg-transparent p-0 font-mono text-xs transition-colors md:min-h-0" @click="login">[LOGIN]</button>' +
    '</template>'
};

/* ==================== 6. 启动 ==================== */
function boot() {
  /* Sky 转为 Vue 响应式：remoteInit / 登录等异步更新 siteName/user/categories/tags 时，
     Vue 组件（computed 读取 Sky 属性）能即时重渲染。必须在任何 Vue 组件创建前完成。 */
  if (typeof VueLib !== 'undefined' && VueLib.reactive) {
    Sky = VueLib.reactive(Sky);
  }

  /* 页脚 [SEARCH] 等 data-terminal-action 按钮 */
  document.addEventListener('click', function (e) {
    var btn = e.target && e.target.closest ? e.target.closest('[data-terminal-action]') : null;
    if (!btn) {
      return;
    }
    var action = btn.getAttribute('data-terminal-action');
    if (action === 'search') {
      window.dispatchEvent(new CustomEvent('sky:open-search'));
    } else if (action === 'login') {
      window.dispatchEvent(new CustomEvent('sky:open-login'));
    } else if (action === 'source-back') {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        go(btn.getAttribute('data-home-url') || Sky.urls.home);
      }
    }
  });

  renderAsciiTitle();

  remoteInit();

  if (!window.Vue) {
    console.error('[CRTShellVue] Vue 库未加载，页面内容无法渲染。');
    return;
  }

  /* 根应用：页面内容 */
  var appRoot = document.getElementById('app');
  if (appRoot) {
    /* 数据源模式 404 页：URL 含文章 ID 时转为 post 视图，
       由 SkyPostView 经同源代理从数据源站拉取并渲染文章 */
    if (Sky.pageType === '404' && Sky.remote) {
      var rp404 = resolveRemoteParams();
      if (rp404.id) {
        Sky.pageType = 'post';
      } else if (rp404.cate_id !== undefined || rp404.cate_alias !== undefined) {
        Sky.pageType = 'category';
      } else if (rp404.tag_id !== undefined) {
        Sky.pageType = 'tag';
      } else if (rp404.auth_id !== undefined || rp404.auth_name !== undefined) {
        Sky.pageType = 'author';
      } else if (rp404.date !== undefined) {
        Sky.pageType = 'date';
      } else if (rp404.search !== undefined) {
        Sky.pageType = 'search';
      }
    }
    var viewMap = {
      index: 'sky-list-view',
      category: 'sky-list-view',
      tag: 'sky-list-view',
      author: 'sky-list-view',
      date: 'sky-list-view',
      search: 'sky-list-view',
      post: 'sky-post-view',
      page: 'sky-post-view',
      archives: 'sky-archives-view',
      categories: 'sky-categories-view',
      tags: 'sky-tags-view'
    };
    var rootApp = VueLib.createApp({
      data: function () {
        return { pageType: Sky.pageType };
      },
      computed: {
        view: function () {
          return viewMap[this.pageType] || null;
        }
      },
      template: '<component :is="view" v-if="view"></component>'
    });
    rootApp.component('sky-typing', SkyTyping);
    rootApp.component('sky-list-view', SkyListView);
    rootApp.component('sky-post-view', SkyPostView);
    rootApp.component('sky-comments', SkyComments);
    rootApp.component('sky-comment-form', SkyCommentForm);
    rootApp.component('sky-archives-view', SkyArchivesView);
    rootApp.component('sky-categories-view', SkyCategoriesView);
    rootApp.component('sky-tags-view', SkyTagsView);
    rootApp.mount('#app');
  }

  /* 终端输入 */
  var terminalRoot = document.getElementById('terminal-input-root');
  if (terminalRoot) {
    VueLib.createApp(SkyTerminalInput).mount('#terminal-input-root');
  }

  /* 搜索弹窗 */
  var modalRoot = document.getElementById('sky-search-modal-root');
  if (modalRoot) {
    VueLib.createApp(SkySearchModal).mount('#sky-search-modal-root');
  }

  /* 登录弹窗 */
  var loginRoot = document.getElementById('sky-login-modal-root');
  if (loginRoot) {
    var loginApp = VueLib.createApp(SkyLoginModal);
    var loginVm = loginApp.mount('#sky-login-modal-root');
    window.LoginWidget = loginVm;
  }

  /* 页头登录态栏（远程模式占位 #sky-auth-bar） */
  var authRoot = document.getElementById('sky-auth-bar');
  if (authRoot) {
    VueLib.createApp(SkyAuthBar).mount('#sky-auth-bar');
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}

})();
