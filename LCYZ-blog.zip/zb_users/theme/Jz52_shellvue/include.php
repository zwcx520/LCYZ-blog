<?php
if (!defined('ZBP_PATH')) {
    exit('Access denied');
}

RegisterPlugin("Jz52_shellvue", "ActivePlugin_Jz52_shellvue");

function ActivePlugin_Jz52_shellvue()
{
    global $zbp;
    $zbp->LoadLanguage('theme', 'Jz52_shellvue');
    Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Jz52_shellvue_AddMenu');
    if ($zbp->Config('Jz52_shellvue')->seo && $zbp->Config('Jz52_shellvue')->nseo) {
        Add_Filter_Plugin('Filter_Plugin_Edit_Response5', 'Jz52_shellvue_Article_Edit_Response5');
        Add_Filter_Plugin('Filter_Plugin_Category_Edit_Response', 'Jz52_shellvue_Category_Edit_Response');
    }
    Add_Filter_Plugin('Filter_Plugin_Html_Js_ZbpConfig', 'Jz52_shellvue_ZbpConfig');
    Add_Filter_Plugin('Filter_Plugin_Zbp_PreLoad', 'Jz52_shellvue_RegRoutes');
}

# 自定义路由
function Jz52_shellvue_RegRoutes()
{
    global $zbp;
    $routes = array(
        array('name' => 'skyblog_archives', 'page' => 'archives', 'path' => 'archives'),
        array('name' => 'skyblog_categories', 'page' => 'categories', 'path' => 'categories'),
        array('name' => 'skyblog_tags', 'page' => 'tags', 'path' => 'tags'),
    );
    foreach ($routes as $r) {
        # prepend=true：插到路由表最前，避免 archives.html 等被文章别名路由（{%alias%}.html）抢先匹配
        $zbp->RegRoute(array(
            'type' => 'rewrite',
            'name' => $r['name'],
            'call' => 'Jz52_shellvue_ViewCustomPage',
            'urlrule_regex' => '#^' . preg_quote($r['path'], '#') . '(?:\.html?)?$#i',
            'urlrule' => '{%host%}' . $r['path'] . '.html',
            'args' => array(),
            'args_with' => array(),
            'page' => $r['page'],
        ), true);
    }
}

# 路由回调函数
function Jz52_shellvue_ViewCustomPage($object = array())
{
    global $zbp;
    $route = isset($object['_route']) && is_array($object['_route']) ? $object['_route'] : array();
    $name = isset($route['name']) ? $route['name'] : '';
    $page = isset($route['page']) ? $route['page'] : 'archives';
    if ($name === 'skyblog_categories') {
        $page = 'categories';
    } elseif ($name === 'skyblog_tags') {
        $page = 'tags';
    }
	$skyTitles = array('archives' => '时光归档', 'categories' => '分类列表', 'tags' => '标签列表');
    $GLOBALS['sky_page_type'] = $page;
    $template = $zbp->template;
    $template->SetTemplate('index');
	$template->SetTags('title', isset($skyTitles[$page]) ? $skyTitles[$page] : $zbp->name);
    $template->Display();
    return null;
}

# 后台菜单
function Jz52_shellvue_AddMenu(&$m)
{
    global $zbp;
    $m[] = MakeTopMenu('root', '主题配置', $zbp->host . 'zb_users/theme/Jz52_shellvue/main.php?act=config', '', 'topmenu_Jz52_shellvue', 'icon-zblog');
}

function Jz52_shellvue_SubMenu($id)
{
    global $zbp;
    $lang = $zbp->lang['Jz52_shellvue'];
    $arySubMenu = array(
        0 => array(isset($lang['menu_appearance']) ? $lang['menu_appearance'] : '外观设置', 'config', 'left', false),
        1 => array(isset($lang['menu_basic']) ? $lang['menu_basic'] : '基础设置', 'basic', 'left', false),
        2 => array(isset($lang['menu_features']) ? $lang['menu_features'] : '功能开关', 'features', 'left', false),
        3 => array(isset($lang['menu_footer']) ? $lang['menu_footer'] : '页面设置', 'footer', 'left', false),
        4 => array(isset($lang['menu_data']) ? $lang['menu_data'] : '数据源', 'data', 'left', false),
        5 => array(isset($lang['menu_seo']) ? $lang['menu_seo'] : 'SEO设置', 'seo', 'left', false),
        6 => array(isset($lang['menu_about']) ? $lang['menu_about'] : '使用教程', 'about', 'left', false),
    );
    foreach ($arySubMenu as $k => $v) {
        echo '<a href="?act=' . $v[1] . '" ' . ($v[3] == true ? 'target="_blank"' : '') . '><span class="m-' . $v[2] . ' ' . ($id == $v[1] ? 'm-now' : '') . '">' . $v[0] . '</span></a>';
    }
}

# zbp 前端配置钩子：Vue 渲染评论列表，禁用系统默认的 useDefaultEvents 处理器，
# 避免提交成功后系统向 DOM 插入未受 Vue 管理的节点与 Vue 虚拟 DOM 冲突。
function Jz52_shellvue_ZbpConfig()
{
    echo "zbpConfig.comment.useDefaultEvents = false;";
}

# 文章
function Jz52_shellvue_Article_Edit_Response5()
{
    global $article;
    $seoTitle = isset($article->Metas->seotitle) ? $article->Metas->seotitle : '';
    $seoKeywords = isset($article->Metas->seokeywords) ? $article->Metas->seokeywords : '';
    $seoDescription = isset($article->Metas->seodescription) ? $article->Metas->seodescription : '';
    echo '<div class="panel panel-default" style="margin-top:12px;">
        <div class="panel-heading">SEO 设置（Jz52_shellvue）</div>
        <div class="panel-body"><table class="table table-bordered">
        <tr><th style="width:15%">SEO标题</th><td><input type="text" name="meta_seotitle" value="' . htmlspecialchars($seoTitle) . '" class="form-control"></td></tr>
        <tr><th>SEO关键词</th><td><input type="text" name="meta_seokeywords" value="' . htmlspecialchars($seoKeywords) . '" class="form-control"></td></tr>
        <tr><th>SEO描述</th><td><textarea name="meta_seodescription" class="form-control" rows="3">' . htmlspecialchars($seoDescription) . '</textarea></td></tr>
        </table></div></div>';
}

# 分类
function Jz52_shellvue_Category_Edit_Response()
{
    global $category;
    $seoTitle = isset($category->Metas->seotitle) ? $category->Metas->seotitle : '';
    $seoDescription = isset($category->Metas->seodescription) ? $category->Metas->seodescription : '';
    echo '<div class="panel panel-default" style="margin-top:12px;">
        <div class="panel-heading">SEO 设置（Jz52_shellvue）</div>
        <div class="panel-body"><table class="table table-bordered">
        <tr><th style="width:15%">SEO标题</th><td><input type="text" name="meta_seotitle" value="' . htmlspecialchars($seoTitle) . '" class="form-control"></td></tr>
        <tr><th>SEO描述</th><td><textarea name="meta_seodescription" class="form-control" rows="3">' . htmlspecialchars($seoDescription) . '</textarea></td></tr>
        </table></div></div>';
}

# 别名优先（兼容空别名）
function Jz52_shellvue_slug($obj)
{
    $alias = isset($obj->Alias) ? $obj->Alias : '';
    if ($alias !== '' && $alias !== null) {
        return $alias;
    }

    return (string) $obj->ID;
}

# 页面 URL（分类页/标签页/归档页）自定义路由
function Jz52_shellvue_url($key)
{
    global $zbp;
    $defaults = array('cat' => 'categories.html', 'tag' => 'tags.html', 'arch' => 'archives.html');
    if (isset($defaults[$key])) {
        return $zbp->host . $defaults[$key];
    }

    return $zbp->host;
}

# 页脚
function Jz52_shellvue_Footer()
{
    global $zbp;
    $s = '';
    $icp = $zbp->Config('Jz52_shellvue')->icp;
    if ($icp) {
        $s .= '<a class="hover:text-terminal-green transition-colors" href="https://beian.miit.gov.cn/" target="_blank" rel="nofollow">' . htmlspecialchars($icp) . '</a>';
    }
    $policeIcp = $zbp->Config('Jz52_shellvue')->police_icp;
    if ($policeIcp) {
        $s .= '<a class="hover:text-terminal-green transition-colors" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=' . urlencode($policeIcp) . '" target="_blank" rel="nofollow">' . htmlspecialchars($policeIcp) . '</a>';
    }

    return $s;
}

function InstallPlugin_Jz52_shellvue()
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_shellvue');
    if (!$cfg->HasKey('Version')) {
        $cfg->Version = '1.0.0';
        $cfg->color_preset = 'classic_green';
        $cfg->custom_primary_color = '#00ff00';
        $cfg->custom_bg_color = '#0d0d0d';
        $cfg->enable_scanline = '1';
        $cfg->enable_flicker = '0';
        $cfg->ascii_title_text = 'CRT Shell';
        $cfg->ascii_font = 'Standard';
        $cfg->show_search = '1';
        $cfg->show_login = '1';
        $cfg->show_header = '1';
        $cfg->show_scrollbar = '0';
        $cfg->show_ls_simulation = '1';
        $cfg->show_pinned_folders = '1';
        $cfg->compact_mode = '0';
        $cfg->debug_mode = '0';
        $cfg->api_base_url = '';
        $cfg->icp = '';
        $cfg->police_icp = '';
        $cfg->custom_head = '';
        $cfg->seo = '0';
        $cfg->nseo = '0';
        $cfg->seotitle = '';
        $cfg->seokeywords = '';
        $cfg->seodescription = '';
        $cfg->DelConfig = '0';
        $zbp->SaveConfig('Jz52_shellvue');
    }
}

function UninstallPlugin_Jz52_shellvue()
{
    global $zbp;
    if ($zbp->Config('Jz52_shellvue')->DelConfig == '1') {
        $zbp->DelConfig('Jz52_shellvue');
    }
}
