<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action = 'root';
if (!$zbp->CheckRights($action)) {
    $zbp->ShowError(6);
    die();
}
if (!$zbp->CheckPlugin('Jz52_shellvue')) {
    $zbp->ShowError(48);
    die();
}

$blogtitle = '主题配置';
$act = 'config';
if (isset($_GET['act']) && $_GET['act'] != '') {
    $act = $_GET['act'];
}
if (!in_array($act, array('config', 'basic', 'features', 'footer', 'data', 'seo', 'about'))) {
    $act = 'config';
}

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<style>
.jz-cfg .jz-tip { background: #f0f4ff; border: 1px solid #d6e0ff; color: #3a5fc8; padding: 10px 14px; margin: 14px 0; line-height: 1.8; }
.jz-cfg .jz-tip a { color: #2f54b8; text-decoration: underline; }
.jz-cfg table td { padding: 10px 8px; vertical-align: top; }
.jz-cfg table th { background: #f7f8fa; padding: 10px 8px; }
.jz-cfg .jz-desc { color: #888; font-size: 12px; line-height: 1.7; }
.jz-cfg input[type="text"], .jz-cfg textarea, .jz-cfg select { width: 95%; max-width: 560px; }
.jz-cfg input[type="radio"] { margin-right: 4px; }
</style>
<div id="divMain">
    <div class="divHeader"><?php echo $blogtitle; ?></div>
    <div class="SubMenu"><?php Jz52_shellvue_SubMenu($act); ?><a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span class="m-right">更多应用</span></a><a href="https://gebilaoli.com" target="_blank"><span class="m-right">作者网站</span></a></div>
    <div id="divMain2">
        <div class="jz-cfg">
            <?php if ($act == 'config') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_shellvue');
                $cfg->color_preset = in_array(trim((string) $_POST['color_preset']), array('classic_green', 'amber', 'phosphor_blue', 'cyberpunk', 'alert_blood', 'custom')) ? $_POST['color_preset'] : 'classic_green';
                $cfg->custom_primary_color = trim((string) $_POST['custom_primary_color']);
                $cfg->custom_bg_color = trim((string) $_POST['custom_bg_color']);
                $cfg->enable_scanline = isset($_POST['enable_scanline']) && $_POST['enable_scanline'] == '1' ? '1' : '0';
                $cfg->enable_flicker = isset($_POST['enable_flicker']) && $_POST['enable_flicker'] == '1' ? '1' : '0';
                $cfg->DelConfig = isset($_POST['DelConfig']) && $_POST['DelConfig'] == '1' ? '1' : '0';
                $zbp->SaveConfig('Jz52_shellvue');
                $zbp->SetHint('good');
                Redirect('./main.php?act=config');
            }
            $cfg = $zbp->Config('Jz52_shellvue');
            ?>
            <div class="jz-tip">当前主题版本 v<?php echo htmlspecialchars($zbp->themeinfo['version']); ?>。复古终端单栏主题：CRT 特效、终端命令导航、文件列表式文章、阅读进度与文章目录。本主题基于 Vue 3 + Z-Blog JSON API 实现，前台内容由 API 渲染，需在后台「全局设置」开启 API 接口。</div>
            <form id="form1" name="form1" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr>
                        <td align="center"><p>终端配色方案</p></td>
                        <td><p><?php ZbpForm::select('color_preset', array('classic_green' => '经典骇客（Classic Green）', 'amber' => '复古琥珀（Amber）', 'phosphor_blue' => '深海科技（Phosphor Blue）', 'cyberpunk' => '赛博朋克（Cyberpunk）', 'alert_blood' => '警报控制（Alert Blood）', 'custom' => '完全自定义'), $cfg->color_preset); ?></p></td>
                        <td><p class="jz-desc">终端主色调与背景色预设</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>自定义主色调</p></td>
                        <td><p><?php ZbpForm::text('custom_primary_color', htmlspecialchars($cfg->custom_primary_color), '95%', '#00ff00'); ?></p></td>
                        <td><p class="jz-desc">配色方案选择「完全自定义」时生效</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>自定义背景色</p></td>
                        <td><p><?php ZbpForm::text('custom_bg_color', htmlspecialchars($cfg->custom_bg_color), '95%', '#0d0d0d'); ?></p></td>
                        <td><p class="jz-desc">配色方案选择「完全自定义」时生效</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>CRT 扫描线效果</p></td>
                        <td><p><?php ZbpForm::radio('enable_scanline', array('否', '是'), (int) $cfg->enable_scanline); ?></p></td>
                        <td><p class="jz-desc">全屏扫描线 CRT 特效</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>CRT 闪烁动画</p></td>
                        <td><p><?php ZbpForm::radio('enable_flicker', array('否', '是'), (int) $cfg->enable_flicker); ?></p></td>
                        <td><p class="jz-desc">屏幕轻微闪烁的 CRT 动画</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>卸载时删除配置</p></td>
                        <td><p><?php ZbpForm::radio('DelConfig', array('否', '是'), (int) $cfg->DelConfig); ?></p></td>
                        <td><p class="jz-desc">切换/卸载主题时自动删除主题配置</p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'basic') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_shellvue');
                $cfg->ascii_title_text = trim((string) $_POST['ascii_title_text']);
                $cfg->ascii_font = in_array(trim((string) $_POST['ascii_font']), array('Standard', 'Banner', 'Big', 'Block', 'Doom', 'Lean', 'Mini', 'Script', 'Shadow', 'Slant', 'Small', 'Speed')) ? $_POST['ascii_font'] : 'Standard';
                $zbp->SaveConfig('Jz52_shellvue');
                $zbp->SetHint('good');
                Redirect('./main.php?act=basic');
            }
            $cfg = $zbp->Config('Jz52_shellvue');
            ?>
            <div class="jz-tip">终端顶部 ASCII 艺术字设置。中文内容无法渲染为 Figlet 字符，建议填写英文标题。</div>
            <form id="form2" name="form2" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr>
                        <td align="center"><p>ASCII 艺术字文本</p></td>
                        <td><p><?php ZbpForm::text('ascii_title_text', htmlspecialchars($cfg->ascii_title_text), '95%', '留空则使用网站名称'); ?></p></td>
                        <td><p class="jz-desc">显示在终端顶部的 ASCII 艺术字内容</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>ASCII 艺术字风格</p></td>
                        <td><p><?php ZbpForm::select('ascii_font', array('Standard' => 'Standard', 'Banner' => 'Banner', 'Big' => 'Big', 'Block' => 'Block', 'Doom' => 'Doom', 'Lean' => 'Lean', 'Mini' => 'Mini', 'Script' => 'Script', 'Shadow' => 'Shadow', 'Slant' => 'Slant', 'Small' => 'Small', 'Speed' => 'Speed'), $cfg->ascii_font); ?></p></td>
                        <td><p class="jz-desc">12 种 Figlet 字体风格</p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'features') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_shellvue');
                $cfg->show_search = isset($_POST['show_search']) && $_POST['show_search'] == '1' ? '1' : '0';
                $cfg->show_login = isset($_POST['show_login']) && $_POST['show_login'] == '1' ? '1' : '0';
                $cfg->show_header = isset($_POST['show_header']) && $_POST['show_header'] == '1' ? '1' : '0';
                $cfg->show_scrollbar = isset($_POST['show_scrollbar']) && $_POST['show_scrollbar'] == '1' ? '1' : '0';
                $cfg->show_ls_simulation = isset($_POST['show_ls_simulation']) && $_POST['show_ls_simulation'] == '1' ? '1' : '0';
                $cfg->show_pinned_folders = isset($_POST['show_pinned_folders']) && $_POST['show_pinned_folders'] == '1' ? '1' : '0';
                $cfg->compact_mode = isset($_POST['compact_mode']) && $_POST['compact_mode'] == '1' ? '1' : '0';
                $cfg->debug_mode = isset($_POST['debug_mode']) && $_POST['debug_mode'] == '1' ? '1' : '0';
                $zbp->SaveConfig('Jz52_shellvue');
                $zbp->SetHint('good');
                Redirect('./main.php?act=features');
            }
            $cfg = $zbp->Config('Jz52_shellvue');
            ?>
            <form id="form3" name="form3" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr><td align="center"><p>显示搜索入口</p></td><td><p><?php ZbpForm::radio('show_search', array('否', '是'), (int) $cfg->show_search); ?></p></td><td><p class="jz-desc">页脚 [SEARCH] 按钮，跳转站内搜索</p></td></tr>
                    <tr><td align="center"><p>显示登录入口</p></td><td><p><?php ZbpForm::radio('show_login', array('否', '是'), (int) $cfg->show_login); ?></p></td><td><p class="jz-desc">顶部 [LOGIN]/[LOGOUT] 入口</p></td></tr>
                    <tr><td align="center"><p>显示顶部 Header</p></td><td><p><?php ZbpForm::radio('show_header', array('否', '是'), (int) $cfg->show_header); ?></p></td><td><p class="jz-desc">Last login 与 ASCII 艺术字区域</p></td></tr>
                    <tr><td align="center"><p>显示滚动条</p></td><td><p><?php ZbpForm::radio('show_scrollbar', array('否', '是'), (int) $cfg->show_scrollbar); ?></p></td><td><p class="jz-desc">默认隐藏滚动条，开启后始终显示</p></td></tr>
                    <tr><td align="center"><p>显示终端命令模拟行</p></td><td><p><?php ZbpForm::radio('show_ls_simulation', array('否', '是'), (int) $cfg->show_ls_simulation); ?></p></td><td><p class="jz-desc">页首 ls/cat 等命令打字动画</p></td></tr>
                    <tr><td align="center"><p>显示首页置顶目录</p></td><td><p><?php ZbpForm::radio('show_pinned_folders', array('否', '是'), (int) $cfg->show_pinned_folders); ?></p></td><td><p class="jz-desc">首页列表顶部的 categories/、tags/ 目录</p></td></tr>
                    <tr><td align="center"><p>紧凑模式</p></td><td><p><?php ZbpForm::radio('compact_mode', array('否', '是'), (int) $cfg->compact_mode); ?></p></td><td><p class="jz-desc">取消终端外页边距</p></td></tr>
                    <tr><td align="center"><p>开发者调试模式</p></td><td><p><?php ZbpForm::radio('debug_mode', array('否', '是'), (int) $cfg->debug_mode); ?></p></td><td><p class="jz-desc">输出 data-debug 标记</p></td></tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'footer') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_shellvue');
                $cfg->icp = trim((string) $_POST['icp']);
                $cfg->police_icp = trim((string) $_POST['police_icp']);
                $cfg->custom_head = trim((string) $_POST['custom_head']);
                $zbp->SaveConfig('Jz52_shellvue');
                $zbp->SetHint('good');
                Redirect('./main.php?act=footer');
            }
            $cfg = $zbp->Config('Jz52_shellvue');
            ?>
            <div class="jz-tip">分类页 / 标签页 / 归档页由主题自定义路由自动提供，无需在后台创建页面：<br>· 分类列表 <b>categories.html</b> · 标签列表 <b>tags.html</b> · 时光归档 <b>archives.html</b>（伪静态开启时直接访问，未开启时由 404 承载自动识别）。</div>
            <form id="form4" name="form4" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr><td align="center"><p>ICP 备案号</p></td><td><p><?php ZbpForm::text('icp', htmlspecialchars($cfg->icp), '95%', '如：京ICP备00000000号'); ?></p></td><td><p class="jz-desc">填写后页脚显示备案链接</p></td></tr>
                    <tr><td align="center"><p>公安联网备案号</p></td><td><p><?php ZbpForm::text('police_icp', htmlspecialchars($cfg->police_icp), '95%', '如：11010802000000'); ?></p></td><td><p class="jz-desc">填写后页脚显示公安备案链接</p></td></tr>
                    <tr><td align="center"><p>自定义底部代码</p></td><td><p><?php ZbpForm::textarea('custom_head', htmlspecialchars($cfg->custom_head), '95%', '80px', '统计代码/脚本等'); ?></p></td><td><p class="jz-desc">输出在页面底部</p></td></tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'seo') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_shellvue');
                $cfg->seo = isset($_POST['seo']) && $_POST['seo'] == '1' ? '1' : '0';
                $cfg->nseo = isset($_POST['nseo']) && $_POST['nseo'] == '1' ? '1' : '0';
                $cfg->seotitle = trim((string) $_POST['seotitle']);
                $cfg->seokeywords = trim((string) $_POST['seokeywords']);
                $cfg->seodescription = trim((string) $_POST['seodescription']);
                $zbp->SaveConfig('Jz52_shellvue');
                $zbp->SetHint('good');
                Redirect('./main.php?act=seo');
            }
            $cfg = $zbp->Config('Jz52_shellvue');
            ?>
            <div class="jz-tip">主题自带基础 SEO：可为首页设置标题/关键词/描述，为文章和分类设置独立关键词与描述。若已安装独立 SEO 插件，请关闭以下开关避免冲突。注意：页面内容由前端浏览器渲染，SEO 设置仅对页面壳层（title/keywords/description 标签）生效，远程数据源模式下请优先在数据源站配置 SEO。</div>
            <form id="form5" name="form5" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr><td align="center"><p>启用主题 SEO</p></td><td><p><?php ZbpForm::radio('seo', array('否', '是'), (int) $cfg->seo); ?></p></td><td><p class="jz-desc">使用主题自带的标题、关键词、描述输出</p></td></tr>
                    <tr><td align="center"><p>文章/分类自定义 SEO</p></td><td><p><?php ZbpForm::radio('nseo', array('否', '是'), (int) $cfg->nseo); ?></p></td><td><p class="jz-desc">在文章编辑页与分类编辑页增加关键词、描述字段</p></td></tr>
                    <tr><td align="center"><p>首页标题</p></td><td><p><?php ZbpForm::text('seotitle', htmlspecialchars($cfg->seotitle), '95%', '留空则使用网站名称'); ?></p></td><td><p class="jz-desc">留空则使用网站名称</p></td></tr>
                    <tr><td align="center"><p>首页关键词</p></td><td><p><?php ZbpForm::text('seokeywords', htmlspecialchars($cfg->seokeywords), '95%', '多个关键词用英文逗号隔开'); ?></p></td><td><p class="jz-desc">多个关键词用英文逗号隔开</p></td></tr>
                    <tr><td align="center"><p>首页描述</p></td><td><p><?php ZbpForm::textarea('seodescription', htmlspecialchars($cfg->seodescription), '95%', '80px', '一段话描述网站内容'); ?></p></td><td><p class="jz-desc">一段话描述网站内容</p></td></tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'data') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_shellvue');
                $v = trim((string) $_POST['api_base_url']);
                if ($v !== '') {
                    $vParts = parse_url($v);
                    if (!preg_match('#^https?://#i', $v) || !isset($vParts['host']) || $vParts['host'] === '') {
                        $v = '';
                        $zbp->SetHint('bad');
                    }
                }
                $cfg->api_base_url = rtrim($v, '/');
                $zbp->SaveConfig('Jz52_shellvue');
                $zbp->SetHint('good');
                Redirect('./main.php?act=data');
            }
            $cfg = $zbp->Config('Jz52_shellvue');
            $isRemote = ($cfg->api_base_url != '');
            ?>
            <div class="jz-tip">
                <strong>数据源模式：</strong>本主题前端由 Vue 3 通过 Z-Blog JSON API 渲染，可实现前后端完全分离——当前站只负责展示，文章/分类/标签/评论等全部数据来自 API。<br>
                默认（留空）使用本站数据。若填写另一个 Z-Blog 站点的 API 地址，当前站将<strong>全部改用该数据源站的数据</strong>（列表、文章、分类、标签、归档、搜索、评论、登录），并通过主题自带的同源代理转发，无需数据源站开启跨域（CORS）。<br>
                要求：数据源站需在「网站设置 → 全局设置」勾选「启用 API 接口」；数据源站建议关闭「启用评论验证码」以便评论跨站提交（或保留验证码，代理会透传验证码会话）。当前站无需任何内容数据。<br>
                登录/标签：数据源站会员可点击页脚 [LOGIN] 登录（token 保存在浏览器本地，仅本主题使用）。登录后：标签聚合（<strong>标签列表接口需登录</strong>）、作者页等受权限限制的数据方可正常展示；[LOGOUT] 登出即清除本地登录态。<br>
                独立单页：本主题通过 Z-Blog 自定义路由（Zbp_PreLoad 注册）提供 <strong>archives.html（时光归档）/ categories.html（分类列表）/ tags.html（标签列表）</strong> 三个独立页；伪静态（REWRITE）模式下直接命中路由，未开伪静态时由 404 承载模板兜底识别。
            </div>
            <?php if ($isRemote) { ?>
            <div class="jz-tip" style="border-color:#ffe0a3;background:#fff8ef;color:#8a5a00;">当前处于<strong>远程数据源模式</strong>：数据源地址为 <strong><?php echo htmlspecialchars($cfg->api_base_url); ?></strong>。当前站的文章数据将不再被读取，前台所有数据（文章/分类/标签/归档/搜索/评论/登录）均经数据源 API 获取；登录需使用数据源站的会员账号（Z-Blog 无前台公开注册接口，注册请到数据源站后台建号）。</div>
            <?php } ?>
            <form id="form6" name="form6" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr><td align="center"><p>数据源 API 地址</p></td><td><p><?php ZbpForm::text('api_base_url', htmlspecialchars($cfg->api_base_url), '95%', 'https://你的数据源域名/zb_system/api.php'); ?></p></td><td><p class="jz-desc">留空 = 使用本站数据；填写另一个 Z-Blog 站点的 api.php 完整地址后保存</p></td></tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'about') { ?>
            <style>
            .jz-help { line-height: 1.9; font-size: 13px; color: #333; }
            .jz-help h3 { border-bottom: 1px solid #e5e5e5; padding-bottom: 8px; margin: 22px 0 12px; color: #222; }
            .jz-help h3:first-child { margin-top: 0; }
            .jz-help h4 { margin: 16px 0 6px; color: #444; }
            .jz-help table { width: 100%; border-collapse: collapse; margin: 8px 0 14px; }
            .jz-help table th, .jz-help table td { border: 1px solid #e5e5e5; padding: 6px 10px; text-align: left; }
            .jz-help table th { background: #f7f8fa; width: 26%; font-weight: normal; white-space: nowrap; }
            .jz-help .jz-cmd { background: #f2f4f7; border: 1px solid #e0e3e8; padding: 1px 5px; border-radius: 3px; font-family: Consolas, Monaco, monospace; font-size: 12px; color: #c7254e; }
            .jz-help .jz-kbd { background: #f2f4f7; border: 1px solid #d0d4db; border-bottom-width: 2px; padding: 0 5px; border-radius: 3px; font-family: Consolas, Monaco, monospace; font-size: 12px; }
            .jz-help p { margin: 6px 0; }
            .jz-help ul { margin: 6px 0 6px 20px; padding: 0; }
            .jz-help ul li { list-style: disc; }
            </style>
            <div class="jz-tip">当前主题版本 v<?php echo htmlspecialchars($zbp->themeinfo['version']); ?>。复古终端单栏主题，由 <a href="https://gebilaoli.com" target="_blank">不见桃花不见秋</a> 以 Vue 3 + Z-Blog JSON API 开发，适用于 Z-BlogPHP 1.7.3+。以下为完整使用教程。</div>
            <div class="jz-help">

            <h3>一、主题简介</h3>
            <p>整站模拟经典终端（CRT 显示器）操作：文件列表式文章展示、命令行导航、ASCII 艺术字、扫描线与闪烁特效。单栏布局，无侧栏，移动端自动适配。支持 5 套终端配色预设，可自定义主色与背景色。</p>
            <p><b>架构说明：</b>本主题前端由 Vue 3 驱动，页面内容（文章列表、文章详情、评论、归档等）通过 Z-Blog 内置 JSON API（<span class="jz-cmd">/zb_system/api.php</span>）在浏览器端获取渲染；页面壳层（终端框架、SEO 标题与关键词、主题配置）仍由服务端输出，以保证标题/描述对搜索引擎可见（数据源模式无效）。</p>

            <h3>二、快速开始</h3>
            <h4>1. 启用前：开启 API 接口（必做）</h4>
            <ul>
                <li>后台「网站设置 → 全局设置」勾选 <b>启用 API 接口</b>（ZC_API_ENABLE），保存。API 是主题数据调用的前提，未开启时页面内容区会提示错误。</li>
                <li>进入本主题「外观设置」：选择配色方案（经典骇客 / 复古琥珀 / 深海科技 / 赛博朋克 / 警报控制 / 完全自定义），开关 CRT 扫描线与闪烁特效。</li>
                <li>「基础设置」可自定义顶部 ASCII 艺术字文本与字体风格（<b>Figlet 仅支持英文字母与数字，中文不会渲染</b>，留空则显示网站名称）。</li>
            </ul>
            <h4>2. 分类 / 标签 / 归档页</h4>
            <ul>
                <li>三个独立页由主题自定义路由自动提供：<span class="jz-cmd">categories.html</span>（分类列表）、<span class="jz-cmd">tags.html</span>（标签列表）、<span class="jz-cmd">archives.html</span>（时光归档）。</li>
                <li>伪静态（REWRITE）开启时直接访问；未开启时由 404 承载自动识别，同样正常渲染。</li>
                <li>页脚 <span class="jz-cmd">[CATEGORY]</span>、<span class="jz-cmd">[TAG]</span>、<span class="jz-cmd">[ARCHIVES]</span> 入口自动指向这三个页面。</li>
            </ul>
            <h4>3. 导航与 SEO</h4>
            <ul>
                <li>本主题无顶部导航栏，站内跳转通过终端命令与页脚入口完成。</li>
                <li>「SEO设置」可输出首页标题/关键词/描述，并为文章与分类设置独立 SEO 字段；若已装独立 SEO 插件请关闭主题 SEO 开关。</li>
            </ul>

            <h3>三、终端交互（核心玩法）</h3>
            <p>每个页面底部都有终端提示符（如 <span class="jz-cmd">admin@你的站点:~/blog$</span>），在输入框中输入命令后按 <span class="jz-kbd">Enter</span> 执行，输出显示在提示符上方。宽屏桌面体验最佳。</p>
            <h4>1. 输入技巧</h4>
            <table>
                <tr><th><span class="jz-kbd">Tab</span></th><td>自动补全：补全命令名与目录路径（如 <span class="jz-cmd">cd cat</span> + Tab 补全为 <span class="jz-cmd">cd categories/</span>），再次按 Tab 在候选中循环</td></tr>
                <tr><th><span class="jz-kbd">↑</span> / <span class="jz-kbd">↓</span></th><td>浏览命令历史（先按 <span class="jz-kbd">↑</span> 取出上一条，回车可直接再次执行）</td></tr>
                <tr><th><span class="jz-kbd">Enter</span></th><td>执行当前命令</td></tr>
                <tr><th><span class="jz-kbd">Esc</span></th><td>清空输入与输出、关闭帮助面板、取消输入焦点</td></tr>
            </table>
            <h4>2. 列表页命令（首页 / 分类 / 标签 / 搜索 / 归档）</h4>
            <table>
                <tr><th><span class="jz-cmd">ls</span> / <span class="jz-cmd">ll</span></th><td>列出当前目录内容（文章列表），效果同页面文章列表</td></tr>
                <tr><th><span class="jz-cmd">cd &lt;path&gt;</span></th><td>切换目录：<span class="jz-cmd">cd categories/</span> 进入分类页、<span class="jz-cmd">cd tags/</span> 进入标签页、<span class="jz-cmd">cd archives/</span> 进入归档页、<span class="jz-cmd">cd ..</span> 返回上级、<span class="jz-cmd">cd ~/</span> 回到首页</td></tr>
                <tr><th><span class="jz-cmd">pd</span> / <span class="jz-cmd">npage</span></th><td>下一页</td></tr>
                <tr><th><span class="jz-cmd">pu</span> / <span class="jz-cmd">ppage</span></th><td>上一页</td></tr>
                <tr><th><span class="jz-cmd">top</span> / <span class="jz-cmd">bottom</span></th><td>滚动到页面顶部 / 底部</td></tr>
                <tr><th><span class="jz-cmd">back</span></th><td>浏览器后退</td></tr>
                <tr><th><span class="jz-cmd">search</span></th><td>打开站内搜索</td></tr>
                <tr><th><span class="jz-cmd">help</span></th><td>显示全部命令帮助</td></tr>
                <tr><th><span class="jz-cmd">clear</span></th><td>清空输出</td></tr>
            </table>
            <h4>3. 文章页命令</h4>
            <table>
                <tr><th><span class="jz-cmd">cd ..</span></th><td>返回文章列表</td></tr>
                <tr><th><span class="jz-cmd">next</span> / <span class="jz-cmd">prev</span></th><td>下一篇 / 上一篇</td></tr>
                <tr><th><span class="jz-cmd">toc</span></th><td>列出文章目录（标题带编号，如 01. 引言）</td></tr>
                <tr><th><span class="jz-cmd">jump &lt;n&gt;</span></th><td>跳到目录第 n 个标题（如 <span class="jz-cmd">jump 2</span>）</td></tr>
                <tr><th><span class="jz-cmd">copy</span></th><td>复制当前文章链接到剪贴板</td></tr>
                <tr><th><span class="jz-cmd">top</span> / <span class="jz-cmd">bottom</span> / <span class="jz-cmd">back</span> / <span class="jz-cmd">search</span> / <span class="jz-cmd">help</span> / <span class="jz-cmd">clear</span></th><td>同列表页</td></tr>
            </table>
            <h4>4. 文件列表键盘导航（列表页）</h4>
            <table>
                <tr><th><span class="jz-kbd">↑</span> / <span class="jz-kbd">↓</span></th><td>在文章行之间移动选中（选中行反色高亮）</td></tr>
                <tr><th><span class="jz-kbd">Enter</span></th><td>打开当前选中的文章 / 目录</td></tr>
                <tr><th>鼠标点击</th><td>直接点击文章标题链接即可打开</td></tr>
            </table>
            <h4>5. 文章阅读键盘（文章页）</h4>
            <table>
                <tr><th><span class="jz-kbd">↓</span> / <span class="jz-kbd">j</span></th><td>向下滚动</td></tr>
                <tr><th><span class="jz-kbd">↑</span> / <span class="jz-kbd">k</span></th><td>向上滚动</td></tr>
                <tr><th><span class="jz-kbd">PageDown</span> / <span class="jz-kbd">空格</span></th><td>向下翻一屏（<span class="jz-kbd">Shift</span>+<span class="jz-kbd">空格</span> 向上）</td></tr>
                <tr><th><span class="jz-kbd">PageUp</span></th><td>向上翻一屏</td></tr>
                <tr><th><span class="jz-kbd">Home</span> / <span class="jz-kbd">End</span></th><td>回到文章顶部 / 底部</td></tr>
            </table>
            <h4>6. 其他阅读辅助</h4>
            <ul>
                <li>文章页顶部有阅读进度条；<span class="jz-cmd">[TOC]</span> 按钮展开/收起文章目录，点击目录项跳转对应标题。</li>
                <li>文章末尾 <span class="jz-cmd">[BACK]</span> 返回、<span class="jz-cmd">cd ..</span> 回到列表。</li>
            </ul>

            <h3>四、常见问题</h3>
            <ul>
                <li><b>页面内容区提示 API 错误：</b>未开启 API。后台「网站设置 → 全局设置」勾选「启用 API 接口」并保存，然后「清空缓存并重新编译模板」。</li>
                <li><b>ASCII 艺术字不显示/显示为网站名：</b>Figlet 字体只支持英文，中文文本不会渲染；请填写英文标题或留空。</li>
                <li><b>页脚 [CATEGORY]/[TAG]/[ARCHIVES] 无反应：</b>请确认访问 <span class="jz-cmd">categories.html / tags.html / archives.html</span> 能正常渲染；若为 404 请检查伪静态规则或改用 404 承载兜底（本主题已内置）。</li>
                <li><b>移动端体验：</b>窄屏/触屏设备自动隐藏终端输入与命令模拟，保留文章列表与阅读功能，桌面宽屏体验完整终端效果。</li>
            </ul>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_shellvue");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
