<?php
/**
 * Jz52_shellvue 数据源代理（同源转发）
 *
 * 数据源模式（后台「数据源」配置了另一个 Z-Blog 站点的 api.php 地址）下，
 * 前端所有 API 请求统一打到本文件，由服务端转发到数据源站，从而绕过浏览器
 * 跨域限制：数据源站无需开启 CORS，只需开启「启用 API 接口」。
 *
 * 访问方式：proxy.php?target=<urlencode(数据源站完整 URL)>
 *   - GET  ：转发 JSON（文章/分类/标签/评论列表）或图片字节（验证码）
 *   - POST ：转发表单（评论提交），并透传数据源站验证码会话（cookie jar）
 *
 * 安全：仅允许转发到后台配置的数据源 host，杜绝 SSRF。
 */

require dirname(__FILE__) . '/../../../zb_system/function/c_system_base.php';

$zbp->Load();

$cfg = $zbp->Config('Jz52_shellvue');
$base = trim((string) $cfg->api_base_url);

# 未配置数据源：代理不可用
if ($base === '') {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo '{"code":403,"message":"proxy disabled: no api_base_url configured"}';
    exit;
}

$srcHost = parse_url($base, PHP_URL_HOST);
if (!$srcHost) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo '{"code":403,"message":"proxy disabled: invalid api_base_url"}';
    exit;
}

$target = isset($_GET['target']) ? trim((string) $_GET['target']) : '';
if ($target === '') {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo '{"code":400,"message":"missing target"}';
    exit;
}

$parts = parse_url($target);
if (!$parts || !isset($parts['scheme'], $parts['host'])) {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo '{"code":400,"message":"invalid target"}';
    exit;
}
$scheme = strtolower($parts['scheme']);
if ($scheme !== 'http' && $scheme !== 'https') {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo '{"code":400,"message":"scheme not allowed"}';
    exit;
}
# SSRF 防护：目标 host 必须与配置的数据源 host 一致
if (strcasecmp($parts['host'], $srcHost) !== 0) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo '{"code":403,"message":"target host not allowed"}';
    exit;
}

$method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : 'GET';
$postBody = '';
if ($method === 'POST') {
    $postBody = file_get_contents('php://input');
}

# 数据源站会话 cookie jar（存当前站 session，用于验证码图片→提交的会话透传）
if (session_id() === '') {
    session_start();
}
$jarKey = 'sky_proxy_cookies';
$jar = isset($_SESSION[$jarKey]) && is_array($_SESSION[$jarKey]) ? $_SESSION[$jarKey] : array();

# 登录 token：前端登录成功后把数据源站返回的 token 放在 X-Sky-Token 请求头，
# 代理转发时改写为 Authorization: Bearer <token>，使远程 API 携带数据源站登录态。
$skyToken = isset($_SERVER['HTTP_X_SKY_TOKEN']) ? trim((string) $_SERVER['HTTP_X_SKY_TOKEN']) : '';
if (strlen($skyToken) > 256) {
    $skyToken = '';
}

$headers = array();
$body = '';
$remoteContentType = '';

if (function_exists('curl_init')) {
    $ch = curl_init($target);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    # 显式禁用代理：避免继承服务器环境代理变量导致内网/直连请求失败
    curl_setopt($ch, CURLOPT_PROXY, '');
    curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, false);
    if ($skyToken !== '') {
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer ' . $skyToken));
    }
    if (count($jar) > 0) {
        curl_setopt($ch, CURLOPT_COOKIE, implode('; ', $jar));
    }
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postBody);
    }
    curl_setopt($ch, CURLOPT_HEADERFUNCTION, function ($c, $line) use (&$jar, &$headers) {
        $trimmed = trim($line);
        if (stripos($trimmed, 'set-cookie:') === 0) {
            $raw = trim(substr($trimmed, 11));
            $semi = strpos($raw, ';');
            $pair = $semi === false ? $raw : substr($raw, 0, $semi);
            $eq = strpos($pair, '=');
            if ($eq !== false && $eq > 0) {
                $name = trim(substr($pair, 0, $eq));
                $value = trim(substr($pair, $eq + 1));
                $replaced = false;
                foreach ($jar as $i => $old) {
                    if (strpos($old, $name . '=') === 0) {
                        $jar[$i] = $name . '=' . $value;
                        $replaced = true;
                        break;
                    }
                }
                if (!$replaced) {
                    $jar[] = $name . '=' . $value;
                }
            }
        } elseif (stripos($trimmed, 'content-type:') === 0) {
            $headers[] = $trimmed;
        }
        return strlen($line);
    });
    $body = curl_exec($ch);
    $errno = curl_errno($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $remoteContentType = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);
    if ($errno !== 0) {
        http_response_code(502);
        header('Content-Type: application/json; charset=utf-8');
        echo '{"code":502,"message":"proxy upstream error: ' . addslashes(curl_strerror($errno)) . '"}';
        exit;
    }
} else {
    # fallback：stream context
    $reqHeaders = array();
    if ($skyToken !== '') {
        $reqHeaders[] = 'Authorization: Bearer ' . $skyToken;
    }
    if (count($jar) > 0) {
        $reqHeaders[] = 'Cookie: ' . implode('; ', $jar);
    }
    $http = array(
        'method' => $method,
        'ignore_errors' => true,
        'timeout' => 20,
    );
    if ($method === 'POST') {
        $http['header'] = $reqHeaders;
        $http['content'] = $postBody;
    } else {
        $http['header'] = $reqHeaders;
    }
    $ctx = stream_context_create(array('http' => $http));
    $body = @file_get_contents($target, false, $ctx);
    if ($body === false) {
        http_response_code(502);
        header('Content-Type: application/json; charset=utf-8');
        echo '{"code":502,"message":"proxy upstream error"}';
        exit;
    }
    $status = 200;
    if (isset($http_response_header)) {
        foreach ($http_response_header as $h) {
            if (preg_match('#^HTTP/\S+\s+(\d+)#i', $h, $mm)) {
                $status = (int) $mm[1];
            }
            if (stripos($h, 'set-cookie:') === 0) {
                $raw = trim(substr($h, 11));
                $semi = strpos($raw, ';');
                $pair = $semi === false ? $raw : substr($raw, 0, $semi);
                $eq = strpos($pair, '=');
                if ($eq !== false && $eq > 0) {
                    $name = trim(substr($pair, 0, $eq));
                    $value = trim(substr($pair, $eq + 1));
                    $replaced = false;
                    foreach ($jar as $i => $old) {
                        if (strpos($old, $name . '=') === 0) {
                            $jar[$i] = $name . '=' . $value;
                            $replaced = true;
                            break;
                        }
                    }
                    if (!$replaced) {
                        $jar[] = $name . '=' . $value;
                    }
                }
            } elseif (stripos($h, 'content-type:') === 0) {
                $remoteContentType = trim(substr($h, 13));
            }
        }
    }
}

$_SESSION[$jarKey] = $jar;

http_response_code($status > 0 ? $status : 502);
# 响应头白名单：仅透传 JSON/文本/常见图片类型，避免上游异常响应头注入
$safeContentType = '';
if ($remoteContentType !== '') {
    $ctLower = strtolower(trim($remoteContentType));
    $ctBase = preg_replace('#;.*$#', '', $ctLower);
    if (in_array($ctBase, array(
        'application/json', 'text/json', 'text/plain', 'text/html',
        'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp',
    ), true)) {
        $safeContentType = preg_replace('/[\r\n]/', '', $remoteContentType);
    } else {
        $safeContentType = 'application/json; charset=utf-8';
    }
}
if ($safeContentType !== '') {
    header('Content-Type: ' . $safeContentType);
}
echo $body;
