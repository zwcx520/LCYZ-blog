<?php
RegisterPlugin("Jz52_meteor", "ActivePlugin_Jz52_meteor");

function ActivePlugin_Jz52_meteor()
{
    global $zbp;
    Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Jz52_meteor_AddMenu');
    Add_Filter_Plugin('Filter_Plugin_Misc_Begin', 'Jz52_meteor_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostModule_Succeed', 'Jz52_meteor_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostComment_Succeed', 'Jz52_meteor_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostComment_Del', 'Jz52_meteor_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostArticle_Succeed', 'Jz52_meteor_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostArticle_Del', 'Jz52_meteor_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_Edit_Response5', 'Jz52_meteor_Article_Edit_Response5');
    Add_Filter_Plugin('Filter_Plugin_Cmd_Ajax', 'Jz52_meteor_Cmd_Ajax');
}

# 后台菜单
function Jz52_meteor_AddMenu(&$m)
{
    global $zbp;
    $m[] = MakeTopMenu("root", '主题配置', $zbp->host . "zb_users/theme/Jz52_meteor/admin/config.php", "", "topmenu_Jz52_meteor", "icon-zblog");
}

function Jz52_meteor_SubMenu($id)
{
    $arySubMenu = array(
        0 => array('基本设置', 'config.php', 'left', false),
        1 => array('首页模块', 'home.php', 'left', false),
        2 => array('页脚设置', 'footer.php', 'left', false),
        3 => array('SEO设置', 'seo.php', 'left', false),
        4 => array('关于主题', 'about.php', 'left', false),
    );
    foreach ($arySubMenu as $v) {
        echo '<a href="' . $v[1] . '" ' . ($v[3] == true ? 'target="_blank"' : '') . '><span class="m-' . $v[2] . ' ' . ($id == $v[1] ? 'm-now' : '') . '">' . $v[0] . '</span></a>';
    }
}

function Jz52_meteor_Cmd_Ajax($src)
{
    global $zbp;
    $result = array();
    switch ($src) {
        case 'meteor_rand':
            $num = (int) GetVars('number', 'GET');
            if ($num <= 0 || $num > 10) {
                $num = 4;
            }
            $result = array('code' => 0, 'data' => Jz52_meteor_rand_html($num));
            break;
    }
    if (count($result) > 0) {
        JsonReturn($result);
    }
}

# 创建侧栏模块
function Jz52_meteor_Event_CreateModule()
{
    global $zbp;
    $module_list = array(
        array('jz52_meteor_search', 'widget-search', 'div', '搜索', '0'),
        array('jz52_meteor_catalog', 'widget-catalog', 'ul', '文章分类', '0'),
        array('jz52_meteor_hot', 'widget-hot', 'ul', '热门文章', '0'),
        array('jz52_meteor_previous', 'widget-previous', 'ul', '最新文章', '0'),
        array('jz52_meteor_tags', 'widget-tags', 'div', '标签云', '0'),
        array('jz52_meteor_comments', 'widget-comments', 'div', '最新评论', '0'),
    );
    $module_filenames = array();
    foreach ($module_list as $item) {
        array_push($module_filenames, $item[0]);
    }
    $modules = $zbp->GetModuleList(array('*'), array(array('IN', 'mod_FileName', $module_filenames)));
    $has_modules = array();
    foreach ($modules as $item) {
        $item->Content = Jz52_meteor_Event_SideContent($item);
        $item->Save();
        array_push($has_modules, $item->FileName);
    }
    foreach ($module_filenames as $k => $item) {
        if (!in_array($item, $has_modules)) {
            $module = $module_list[$k];
            $t = new Module();
            $t->Name = $module[3];
            $t->IsHideTitle = $module[4];
            $t->FileName = $module[0];
            $t->Source = "theme_Jz52_meteor";
            $t->SidebarID = 0;
            $t->Content = Jz52_meteor_Event_SideContent($t);
            $t->HtmlID = $module[1];
            $t->Type = $module[2];
            $t->Save();
        }
    }
}

# 删除侧栏模块
function Jz52_meteor_Event_DelModule()
{
    global $zbp;
    $modules = array('jz52_meteor_search', 'jz52_meteor_catalog', 'jz52_meteor_hot', 'jz52_meteor_previous', 'jz52_meteor_tags', 'jz52_meteor_comments');
    $modules = $zbp->GetModuleList(array('*'), array(array('IN', 'mod_FileName', $modules)));
    foreach ($modules as $item) {
        $item->Del();
    }
}

# 侧栏模块内容
function Jz52_meteor_Event_SideContent(&$module)
{
    global $zbp;
    $str = '';
    switch ($module->FileName) {
        case 'jz52_meteor_search':
            $str .= '<form role="search" method="post" class="zb-block-search" action="' . $zbp->host . 'zb_system/cmd.php?act=search">
                <div class="zb-block-search__inside-wrapper">
                    <input class="zb-block-search__input" type="search" placeholder="输入关键词搜索..." value="" name="q" required="required">
                    <button type="submit" class="zb-element-button">搜索</button>
                </div>
            </form>';
            break;
        case 'jz52_meteor_catalog':
            $str .= '<ul class="zb-block-categories">';
            $cates = $zbp->categorys;
            foreach ($cates as $cate) {
                if ($cate->Count > 0) {
                    $str .= '<li><a href="' . $cate->Url . '" title="' . $cate->Name . '">' . $cate->Name . '</a><span>' . $cate->Count . '</span></li>';
                }
            }
            $str .= '</ul>';
            break;
        case 'jz52_meteor_hot':
            $num = $module->MaxLi > 0 ? $module->MaxLi : 8;
            $artList = GetList(array('count' => $num, 'order_custom' => array('log_ViewNums' => 'DESC', 'log_PostTime' => 'DESC')));
            $i = 0;
            foreach ($artList as $item) {
                $i++;
                $str .= '<li><span><em></em></span><a href="' . $item->Url . '" title="' . $item->Title . '">' . $item->Title . '</a></li>';
            }
            break;
        case 'jz52_meteor_previous':
            $num = $module->MaxLi > 0 ? $module->MaxLi : 5;
            $artList = GetList(array('count' => $num));
            foreach ($artList as $item) {
                $thumb = Jz52_meteor_IMG($item);
                $str .= '<li><div class="zb-block-latest-posts__featured-image"><a href="' . $item->Url . '"><img src="' . $thumb . '" alt="' . $item->Title . '"></a></div>'
                    . '<a class="zb-block-latest-posts__post-title" href="' . $item->Url . '" title="' . $item->Title . '">' . $item->Title . '</a>'
                    . '<time class="zb-block-latest-posts__post-date">' . $item->Time('Y-m-d') . '</time></li>';
            }
            break;
        case 'jz52_meteor_tags':
            $num = $module->MaxLi > 0 ? $module->MaxLi : 25;
            $str .= '<div class="zb-block-tag-cloud">';
            $tags = Jz52_meteor_Event_TagList($num);
            foreach ($tags as $tag) {
                $str .= '<a target="_blank" title="' . $tag->Name . ' (' . $tag->Count . ')" href="' . $tag->Url . '">' . $tag->Name . '</a>';
            }
            $str .= '</div>';
            break;
        case 'jz52_meteor_comments':
            $num = $module->MaxLi > 0 ? $module->MaxLi : 5;
            $str .= '<ul class="comment-list">';
            $newCmtList = Jz52_meteor_Event_GetNewCommentList($num);
            foreach ($newCmtList as $item) {
                $str .= '<li>
                    <div class="comments-box">
                        <div class="avatar-box"><img class="avatar" src="' . $item->Author->Avatar . '" alt="' . $item->Author->StaticName . '"></div>
                        <div class="comment-article">
                            <div class="comment-head">
                                <p class="comment-author"><strong>' . $item->Author->StaticName . '</strong></p>
                                <span class="comment-link"><a href="' . $item->Post->Url . '#cmt' . $item->ID . '">' . $item->Time('Y-m-d') . '</a></span>
                            </div>
                            <div class="comments-content"><p>' . $item->Content . '</p></div>
                        </div>
                    </div>
                </li>';
            }
            $str .= '</ul>';
            break;
    }
    return $str;
}

# 标签云
function Jz52_meteor_Event_TagList($num = 25)
{
    global $zbp;
    $array = $zbp->GetTagList(
        '*',
        array(array('=', 'tag_Type', 0)),
        array('tag_Count' => 'DESC'),
        $num,
        null
    );
    $array2 = array();
    foreach ($array as $tag) {
        $array2[$tag->ID] = $tag;
    }
    ksort($array2);
    $urls = array();
    foreach ($array2 as $tag) {
        $urls[] = $tag;
    }
    return $urls;
}

# 最新评论
function Jz52_meteor_Event_GetNewCommentList($num = 5)
{
    global $zbp;
    $w = array();
    $w[] = array("=", "comm_IsChecking", "0");
    $comments = $zbp->GetCommentList(array('*'), $w, array("comm_PostTime" => "DESC"), array($num));
    foreach ($comments as &$comment) {
        if ($comment->ParentID > 0) {
            $comment->Parent = $zbp->GetCommentByID($comment->ParentID);
            $comment->Parent->Content = TransferHTML($comment->Parent->Content, '[nohtml]');
        }
        $comment->Content = TransferHTML($comment->Content, '[nohtml]');
    }
    return $comments;
}

# 文章字段：自定义缩略图
function Jz52_meteor_Article_Edit_Response5()
{
    global $article;
    echo '<table width="99%"><tr><td width="20%">自定义缩略图</td><td width="80%"><input style="width:95%" type="text" name="meta_meteor_thumb" value="' . htmlspecialchars($article->Metas->meteor_thumb) . '" placeholder="填写图片地址，留空则自动取文章内第一张图" /></td></tr></table>';
}

function Jz52_meteor_ranIMG($id = 0)
{
    global $zbp;
    $dir = $zbp->path . 'zb_users/theme/Jz52_meteor/style/images/random/';
    $files = array();
    if (is_dir($dir)) {
        foreach (scandir($dir) as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) == 'jpg') {
                $files[] = $file;
            }
        }
    }
    $num = count($files);
    if ($num > 0) {
        return $zbp->host . 'zb_users/theme/Jz52_meteor/style/images/random/' . $files[$id % $num];
    }
    return $zbp->host . 'zb_users/theme/Jz52_meteor/style/images/nothumb.png';
}

function Jz52_meteor_IMG($article)
{
    global $zbp;
    $thumb = $article->Metas->meteor_thumb;
    if (!$thumb) {
		if ( $article->ImageCount ) {
			$thumb = $article->AllImages[0];
		}
    }
    if (!$thumb) {
        $thumb = Jz52_meteor_ranIMG($article->ID);
    }
    return $thumb;
}

# 文章摘要
function Jz52_meteor_postdesc($article, $len = 80)
{
    $intro = trim(TransferHTML($article->Intro, '[nohtml]'));
    if ($intro == '') {
        $intro = trim(TransferHTML($article->Content, '[nohtml]'));
    }
    $intro = preg_replace('/\s+/', ' ', $intro);
    if (function_exists('mb_strlen') && mb_strlen($intro, 'UTF-8') > $len) {
        return mb_substr($intro, 0, $len, 'UTF-8') . '…';
    }
    return $intro;
}

# 今日精选
function Jz52_meteor_rand_html($num = 4)
{
    global $zbp;
    $str = '';
    $artList = GetList(array('count' => $num, 'random' => $num));
    foreach ($artList as $article) {
        $str .= Jz52_meteor_aplsm($article);
    }
    return $str;
}

# 今日精选单条
function Jz52_meteor_aplsm($article)
{
    $str = '<div class="item-min"><div class="jxbox">'
        . '<div class="thumb"><a href="' . $article->Url . '"><div class="thumb-inner"><img src="' . Jz52_meteor_IMG($article) . '" alt="' . $article->Title . '"></div></a>'
        . '<div class="sortbox"><a href="' . $article->Category->Url . '" class="sort sort-' . $article->Category->ID . '">' . $article->Category->Name . '</a></div></div>'
        . '<div class="subtitle"><h5 class="line-tow"><a href="' . $article->Url . '" title="' . $article->Title . '">' . $article->Title . '</a></h5>'
        . '<div class="pmbox"><div class="l"><span class="time">' . $article->Time('Y-m-d') . '</span></div></div></div>'
        . '</div></div>';
    return $str;
}

# 首页轮播列表
function Jz52_meteor_slide_list()
{
    global $zbp;
    $list = array();
    $ids = trim($zbp->Config('Jz52_meteor')->home_slide_ids);
    if ($ids != '') {
        foreach (explode(',', $ids) as $id) {
            $id = (int) trim($id);
            if ($id <= 0) {
                continue;
            }
            $article = $zbp->GetPostByID($id);
            if ($article->ID > 0) {
                $list[] = $article;
            }
        }
    }
    return $list;
}

# 首页热点推荐
function Jz52_meteor_hotspot_list()
{
    global $zbp;
    $list = array();
    $ids = trim($zbp->Config('Jz52_meteor')->home_press_ids);
    if ($ids != '') {
        foreach (explode(',', $ids) as $id) {
            $id = (int) trim($id);
            if ($id <= 0) {
                continue;
            }
            $article = $zbp->GetPostByID($id);
            if ($article->ID > 0) {
                $list[] = $article;
            }
        }
    }
    return $list;
}

# 延伸阅读（同分类文章）
function Jz52_meteor_related($article, $num = 5)
{
    global $zbp;
    $list = array();
    if ($article->Category->ID > 0) {
        $list = GetList(array(
            'count' => $num + 1,
            'cate' => $article->Category->ID,
            'where_custom' => array(array('<>', 'log_ID', $article->ID)),
        ));
        if (count($list) == $num + 1) {
            array_pop($list);
        }
    }
    if (count($list) < $num) {
        $more = GetList(array('count' => $num - count($list)));
        foreach ($more as $a) {
            if ($a->ID != $article->ID) {
                $list[] = $a;
            }
        }
        if (count($list) > $num) {
            $list = array_slice($list, 0, $num);
        }
    }
    return $list;
}

function Jz52_meteor_home_slide()
{
    global $zbp;
    return $zbp->Config('Jz52_meteor')->home_slide == 'one';
}

# 首页是否开启自定义推荐
function Jz52_meteor_home_custom()
{
    global $zbp;
    return $zbp->Config('Jz52_meteor')->home_custom == '1';
}

# 首页是否开启热点推荐
function Jz52_meteor_home_press()
{
    global $zbp;
    return $zbp->Config('Jz52_meteor')->home_press == '1';
}

# 首页自定义推荐数据
function Jz52_meteor_customdata()
{
    global $zbp;
    $data = $zbp->Config('Jz52_meteor')->home_customdata;
    if ($data) {
        $data = @unserialize($data);
    }
    if (!is_array($data)) {
        $data = array();
    }
    return $data;
}

# 页脚导航数据
function Jz52_meteor_footnav()
{
    global $zbp;
    $data = $zbp->Config('Jz52_meteor')->foot_navdata;
    if ($data) {
        $data = @unserialize($data);
    }
    if (!is_array($data)) {
        $data = array();
    }
    return $data;
}

# 安装
function InstallPlugin_Jz52_meteor()
{
    global $zbp;
	if(!$zbp->HasConfig('Jz52_meteor')){
        $cfg = $zbp->Config('Jz52_meteor');
        $cfg->Version = '1.0.0';
        # 基本设置
        $cfg->logo = $zbp->host . 'zb_users/theme/Jz52_meteor/style/images/logo.png';
        $cfg->logo_dark = $zbp->host . 'zb_users/theme/Jz52_meteor/style/images/logo-dark.png';
        $cfg->favicon = '';
        $cfg->live_url = 'live.html';
        $cfg->home_slide = 'one';
        $cfg->home_slide_ids = '';
        $cfg->home_custom = '1';
        $cfg->home_customdata = '';
        $cfg->home_press = '1';
        $cfg->home_press_ids = '';
        $cfg->home_press_desc = '今日热点';
        $cfg->home_press_right = 'none';
        # 页脚
        $cfg->foot_nav = '1';
        $cfg->foot_navdata = '';
        $cfg->foot_desc = '';
        $cfg->foot_icp = '';
        $cfg->foot_ga = '';
        # SEO
        $cfg->seo = '0';
        $cfg->nseo = '0';
        $cfg->seotitle = '';
        $cfg->seokeywords = '';
        $cfg->seodescription = '';
        $cfg->DelConfig = '0';
        $zbp->SaveConfig('Jz52_meteor');
    }
    Jz52_meteor_Event_CreateModule();
}

# 卸载
function UninstallPlugin_Jz52_meteor()
{
    global $zbp;
    Jz52_meteor_Event_DelModule();
    if ($zbp->Config('Jz52_meteor')->DelConfig) {
        $zbp->DelConfig('Jz52_meteor');
    }
}
