<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_meteor/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_meteor_SubMenu('seo.php'); ?>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken') {
                continue;
            }
            $zbp->Config('Jz52_meteor')->$k = $v;
        }
        $zbp->SaveConfig('Jz52_meteor');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">SEO 设置</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>SEO开关</p></td>
          <td><p><?php ZbpForm::radio('seo', array('1' => '开启', '0' => '关闭'), $zbp->Config('Jz52_meteor')->seo); ?></p></td>
          <td><p class="jz-desc">开启后按页面类型输出关键词/描述 Meta（文章页自动取标签与摘要）</p></td>
        </tr>
        <tr>
          <td align="center"><p>首页SEO标题</p></td>
          <td><p><?php ZbpForm::text('seotitle', $zbp->Config('Jz52_meteor')->seotitle, '300px', ''); ?></p></td>
          <td><p class="jz-desc">留空则使用系统标题（站点名 - 副标题）</p></td>
        </tr>
        <tr>
          <td align="center"><p>首页关键词</p></td>
          <td><p><?php ZbpForm::text('seokeywords', $zbp->Config('Jz52_meteor')->seokeywords, '300px', ''); ?></p></td>
          <td><p class="jz-desc">多个关键词用英文逗号分隔</p></td>
        </tr>
        <tr>
          <td align="center" valign="top"><p>首页描述</p></td>
          <td><p><?php ZbpForm::textarea('seodescription', $zbp->Config('Jz52_meteor')->seodescription, '350px', '80px', ''); ?></p></td>
          <td><p class="jz-desc">站点描述，150 字以内为宜</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_meteor");
$(document).ready(function() {
    $(document).on('keydown', function(e) {
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            $('input[name="submit"]').click();
        }
    });
});
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
