<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_meteor/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_meteor_SubMenu('home.php'); ?>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken' || $k == 'home_customdata') {
                continue;
            }
            $zbp->Config('Jz52_meteor')->$k = $v;
        }
        $custom = isset($_POST['home_customdata']) ? $_POST['home_customdata'] : '[]';
        $custom = json_decode($custom, true);
        if (!is_array($custom)) {
            $custom = array();
        }
        $zbp->Config('Jz52_meteor')->home_customdata = serialize($custom);
        $zbp->SaveConfig('Jz52_meteor');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    $custom = Jz52_meteor_customdata();
    $custom_json = json_encode($custom, JSON_UNESCAPED_UNICODE);
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">首页轮播推送</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>轮播开关</p></td>
          <td><p><?php ZbpForm::radio('home_slide', array('one' => '开启', 'none' => '关闭'), $zbp->Config('Jz52_meteor')->home_slide); ?></p></td>
          <td><p class="jz-desc">开启后首页顶部显示 Swiper 轮播</p></td>
        </tr>
        <tr>
          <td align="center"><p>轮播文章ID</p></td>
          <td><p><?php ZbpForm::text('home_slide_ids', $zbp->Config('Jz52_meteor')->home_slide_ids, '300px', ''); ?></p></td>
          <td><p class="jz-desc">填写文章 ID，多个用英文逗号分隔（如 114,115,116），按填写顺序展示；留空则显示提示文字</p></td>
        </tr>
      </table>
      <div class="jztit">首页自定义推荐（四宫格）</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>推荐开关</p></td>
          <td><p><?php ZbpForm::radio('home_custom', array('1' => '开启', '0' => '关闭'), $zbp->Config('Jz52_meteor')->home_custom); ?></p></td>
          <td><p class="jz-desc">开启后首页轮播下方显示 4 个自定义图文推荐位</p></td>
        </tr>
        <tr>
          <td align="center" valign="top"><p>推荐内容</p></td>
          <td>
            <input type="hidden" name="home_customdata" id="home_customdata" value='<?php echo htmlspecialchars($custom_json); ?>'>
            <div id="custom-box"></div>
            <button type="button" class="button" id="custom-add" style="margin-top:8px;">+ 添加推荐位</button>
          </td>
          <td><p class="jz-desc">图片(60x60)、圆角样式、标题、描述、链接地址、新窗口打开。建议 4 个一组，最少 1 个</p></td>
        </tr>
      </table>
      <div class="jztit">首页热点推荐</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>热点开关</p></td>
          <td><p><?php ZbpForm::radio('home_press', array('1' => '开启', '0' => '关闭'), $zbp->Config('Jz52_meteor')->home_press); ?></p></td>
          <td><p class="jz-desc">开启后"最新文章"上方显示热点推荐</p></td>
        </tr>
        <tr>
          <td align="center"><p>推荐文章ID</p></td>
          <td><p><?php ZbpForm::text('home_press_ids', $zbp->Config('Jz52_meteor')->home_press_ids, '300px', ''); ?></p></td>
          <td><p class="jz-desc">填写文章 ID，多个用英文逗号分隔，按填写顺序展示（首条大图样式）；留空则显示提示文字</p></td>
        </tr>
        <tr>
          <td align="center"><p>热点副标题</p></td>
          <td><p><?php ZbpForm::text('home_press_desc', $zbp->Config('Jz52_meteor')->home_press_desc, '200px', '今日热点'); ?></p></td>
          <td><p class="jz-desc">模块标题右侧的说明文字，留空不显示</p></td>
        </tr>
        <tr>
          <td align="center"><p>标题右侧样式</p></td>
          <td><p><?php ZbpForm::select('home_press_right', array('none' => '无', 'color' => '彩色圆点'), $zbp->Config('Jz52_meteor')->home_press_right); ?></p></td>
          <td><p class="jz-desc">标题右侧装饰样式</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
    <script type="text/javascript">
    $(function(){
        var $box = $('#custom-box');
        var IMG_TYPES = {'': '默认(方形)', 'fillet': '圆角', 'round': '圆形'};
        function rowHtml(d){
            d = d || {};
            d.image = d.image || '';
            d.imagetype = d.imagetype || '';
            d.title = d.title || '';
            d.desc = d.desc || '';
            d.url = d.url || '';
            d.target = d.target ? 'checked' : '';
            var opts = '';
            $.each(IMG_TYPES, function(v, t){
                opts += '<option value="' + v + '"' + (d.imagetype === v ? ' selected' : '') + '>' + t + '</option>';
            });
            return '<div class="custom-row" style="border:1px solid #eee;padding:10px;margin-bottom:10px;border-radius:4px;">'
                + '<div style="margin-bottom:6px;"><label style="width:70px;display:inline-block;">图片地址</label><input type="text" class="c-image" value="' + $('<div>').text(d.image).html() + '" style="width:260px;"></div>'
                + '<div style="margin-bottom:6px;"><label style="width:70px;display:inline-block;">图片样式</label><select class="c-imagetype" style="width:120px;">' + opts + '</select>'
                + '<label style="width:50px;display:inline-block;margin-left:10px;">标题</label><input type="text" class="c-title" value="' + $('<div>').text(d.title).html() + '" style="width:200px;"></div>'
                + '<div style="margin-bottom:6px;"><label style="width:70px;display:inline-block;">描述</label><input type="text" class="c-desc" value="' + $('<div>').text(d.desc).html() + '" style="width:340px;"></div>'
                + '<div style="margin-bottom:6px;"><label style="width:70px;display:inline-block;">链接地址</label><input type="text" class="c-url" value="' + $('<div>').text(d.url).html() + '" style="width:340px;"></div>'
                + '<div><label style="width:70px;display:inline-block;">打开方式</label><label><input type="checkbox" class="c-target" ' + d.target + '> 新窗口打开</label>'
                + '<button type="button" class="c-del" style="float:right;border:0;background:#d9534f;color:#fff;padding:2px 12px;cursor:pointer;">删除</button></div>'
                + '</div>';
        }
        var data = [];
        try { data = JSON.parse($('#home_customdata').val() || '[]'); } catch(e) { data = []; }
        function render(){
            $box.empty();
            $.each(data, function(i, d){ $box.append(rowHtml(d)); });
        }
        $('#custom-add').click(function(){
            data.push({image:'', imagetype:'', title:'', desc:'', url:'', target:''});
            render();
        });
        $box.on('click', '.c-del', function(){
            var idx = $(this).closest('.custom-row').index();
            data.splice(idx, 1);
            render();
        });
        $box.on('change', '.c-imagetype', function(){ data[$(this).closest('.custom-row').index()].imagetype = $(this).val(); });
        $box.on('input', '.c-image', function(){ data[$(this).closest('.custom-row').index()].image = $(this).val(); });
        $box.on('input', '.c-title', function(){ data[$(this).closest('.custom-row').index()].title = $(this).val(); });
        $box.on('input', '.c-desc', function(){ data[$(this).closest('.custom-row').index()].desc = $(this).val(); });
        $box.on('input', '.c-url', function(){ data[$(this).closest('.custom-row').index()].url = $(this).val(); });
        $box.on('change', '.c-target', function(){ data[$(this).closest('.custom-row').index()].target = $(this).prop('checked') ? 1 : ''; });
        $('form.jzadmin').submit(function(){
            $('#home_customdata').val(JSON.stringify(data));
        });
        render();
    });
    </script>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_meteor");
$(document).ready(function() {
    $(document).on('keydown', function(e) {
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            $('input[name="submit"]').click();
        }
    });
});
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
