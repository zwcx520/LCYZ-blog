<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_meteor/admin/Admin_header.php';
?>
<link rel="stylesheet" href="<?php echo $bloghost; ?>zb_users/theme/Jz52_meteor/style/css/jzicon.css" type="text/css" media="screen"/>
<div class="SubMenu jzSubMenu">
  <?php Jz52_meteor_SubMenu('about.php'); ?>
</div>
<div id="divMain2">
<?php
    $cssFile = $blogpath . 'zb_users/theme/Jz52_meteor/style/css/jzicon.css';
    $icons = array();
    if (is_file($cssFile)) {
        $css = file_get_contents($cssFile);
        preg_match_all('/\.(jzicon-[\w-]+):before\s*\{[^}]*content:\s*"([^"]+)"/', $css, $m, PREG_SET_ORDER);
        foreach ($m as $x) {
            $icons[$x[1]] = $x[2];
        }
        ksort($icons);
    }
    ?>
    <div class="jztit">内置字体图标（jzicon，共 <?php echo count($icons); ?> 个）</div>
    <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
      <tr>
        <td>
          <p>主题内置图标字体，前端与后台均可直接使用。调用方式：<code>&lt;i class="jzicon jzicon-类名"&gt;&lt;/i&gt;</code>，如：<code>&lt;i class="jzicon jzicon-search"&gt;&lt;/i&gt;</code>。点击下方任意图标可复制类名。</p>
          <div class="jzicon-search">
            <input type="text" id="jzIconSearch" placeholder="输入类名关键词过滤，如 search / zan / arrow" />
          </div>
          <div class="jzicon-grid" id="jzIconGrid">
            <?php foreach ($icons as $cls => $uni) { ?>
            <div class="jzicon-item" data-cls="<?php echo $cls; ?>" title="点击复制 <?php echo $cls; ?>">
              <i class="jzicon <?php echo $cls; ?>"></i>
              <code><?php echo $cls; ?></code>
              <small>\<?php echo $uni; ?></small>
            </div>
            <?php } ?>
          </div>
        </td>
      </tr>
    </table>
    <script type="text/javascript">
    (function(){
      var input = document.getElementById('jzIconSearch');
      var items = document.querySelectorAll('#jzIconGrid .jzicon-item');
      if (input) {
        input.addEventListener('input', function(){
          var k = this.value.trim().toLowerCase();
          for (var i = 0; i < items.length; i++) {
            items[i].style.display = (!k || items[i].getAttribute('data-cls').indexOf(k) >= 0) ? '' : 'none';
          }
        });
      }
      var grid = document.getElementById('jzIconGrid');
      if (grid) {
        grid.addEventListener('click', function(e){
          var item = e.target.closest ? e.target.closest('.jzicon-item') : null;
          if (!item) return;
          var cls = item.getAttribute('data-cls');
          if (!cls) return;
          if (document.execCommand) {
            var ta = document.createElement('textarea');
            ta.value = cls;
            ta.style.position = 'fixed'; ta.style.opacity = '0';
            document.body.appendChild(ta); ta.select();
            try { document.execCommand('copy'); } catch (err) {}
            document.body.removeChild(ta);
          }
        });
      }
    })();
    </script>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_meteor");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
