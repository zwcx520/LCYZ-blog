<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_meteor/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_meteor_SubMenu('footer.php'); ?>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken' || $k == 'foot_navdata') {
                continue;
            }
            $zbp->Config('Jz52_meteor')->$k = $v;
        }
        # 页脚导航（JSON 转序列化数组存储）
        $nav = isset($_POST['foot_navdata']) ? $_POST['foot_navdata'] : '[]';
        $nav = json_decode($nav, true);
        if (!is_array($nav)) {
            $nav = array();
        }
        $zbp->Config('Jz52_meteor')->foot_navdata = serialize($nav);
        $zbp->SaveConfig('Jz52_meteor');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    $nav = Jz52_meteor_footnav();
    $nav_json = json_encode($nav, JSON_UNESCAPED_UNICODE);
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">页脚导航</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>导航开关</p></td>
          <td><p><?php ZbpForm::radio('foot_nav', array('1' => '开启', '0' => '关闭'), $zbp->Config('Jz52_meteor')->foot_nav); ?></p></td>
          <td><p class="jz-desc">开启后页脚顶部显示一排导航链接</p></td>
        </tr>
        <tr>
          <td align="center" valign="top"><p>导航内容</p></td>
          <td>
            <input type="hidden" name="foot_navdata" id="foot_navdata" value='<?php echo htmlspecialchars($nav_json); ?>'>
            <div id="footnav-box"></div>
            <button type="button" class="button" id="footnav-add" style="margin-top:8px;">+ 添加导航</button>
          </td>
          <td><p class="jz-desc">名称、链接地址、新窗口打开。可添加友情链接、关于等</p></td>
        </tr>
      </table>
      <div class="jztit">页脚说明与版权</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center" valign="top"><p>站点描述</p></td>
          <td><p><?php ZbpForm::textarea('foot_desc', $zbp->Config('Jz52_meteor')->foot_desc, '350px', '80px', ''); ?></p></td>
          <td><p class="jz-desc">页脚导航下方的站点说明文字，留空不显示</p></td>
        </tr>
        <tr>
          <td align="center"><p>备案号</p></td>
          <td><p><?php ZbpForm::text('foot_icp', $zbp->Config('Jz52_meteor')->foot_icp, '200px', ''); ?></p></td>
          <td><p class="jz-desc">如：京ICP备12345678号，自动加链接到工信部备案查询</p></td>
        </tr>
        <tr>
          <td align="center"><p>统计代码</p></td>
          <td><p><?php ZbpForm::text('foot_ga', $zbp->Config('Jz52_meteor')->foot_ga, '200px', ''); ?></p></td>
          <td><p class="jz-desc">如百度统计 ID 或自定义文字，显示在备案号旁</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
    <script type="text/javascript">
    $(function(){
        var $box = $('#footnav-box');
        function rowHtml(d){
            d = d || {};
            d.name = d.name || '';
            d.url = d.url || '';
            d.target = d.target ? 'checked' : '';
            return '<div class="footnav-row" style="border:1px solid #eee;padding:10px;margin-bottom:10px;border-radius:4px;">'
                + '<div style="margin-bottom:6px;"><label style="width:60px;display:inline-block;">名称</label><input type="text" class="f-name" value="' + $('<div>').text(d.name).html() + '" style="width:240px;">'
                + '<label style="width:60px;display:inline-block;margin-left:10px;">链接</label><input type="text" class="f-url" value="' + $('<div>').text(d.url).html() + '" style="width:280px;"></div>'
                + '<div><label style="width:60px;display:inline-block;">打开方式</label><label><input type="checkbox" class="f-target" ' + d.target + '> 新窗口打开</label>'
                + '<button type="button" class="f-del" style="float:right;border:0;background:#d9534f;color:#fff;padding:2px 12px;cursor:pointer;">删除</button></div>'
                + '</div>';
        }
        var data = [];
        try { data = JSON.parse($('#foot_navdata').val() || '[]'); } catch(e) { data = []; }
        function render(){
            $box.empty();
            $.each(data, function(i, d){ $box.append(rowHtml(d)); });
        }
        $('#footnav-add').click(function(){
            data.push({name:'', url:'', target:''});
            render();
        });
        $box.on('click', '.f-del', function(){
            var idx = $(this).closest('.footnav-row').index();
            data.splice(idx, 1);
            render();
        });
        $box.on('input', '.f-name', function(){ data[$(this).closest('.footnav-row').index()].name = $(this).val(); });
        $box.on('input', '.f-url', function(){ data[$(this).closest('.footnav-row').index()].url = $(this).val(); });
        $box.on('change', '.f-target', function(){ data[$(this).closest('.footnav-row').index()].target = $(this).prop('checked') ? 1 : ''; });
        $('form.jzadmin').submit(function(){
            $('#foot_navdata').val(JSON.stringify(data));
        });
        render();
    });
    </script>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_meteor");
$(document).ready(function() {
    $(document).on('keydown', function(e) {
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            $('input[name="submit"]').click();
        }
    });
});
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
