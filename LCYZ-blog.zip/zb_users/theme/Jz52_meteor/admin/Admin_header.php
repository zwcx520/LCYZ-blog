<?php
require $blogpath . 'zb_system/function/c_system_admin.php';
$zbp->Load();
if (!$zbp->CheckRights('root') || !$zbp->CheckPlugin('Jz52_meteor')) {
    $zbp->ShowError(6);
    die();
}
$blogtitle = '主题配置';
require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<link rel="stylesheet" href="<?php echo $bloghost; ?>zb_users/theme/Jz52_meteor/admin/jzadmin.css" type="text/css" media="screen"/>
<script type="text/javascript" src="<?php echo $bloghost; ?>zb_users/theme/Jz52_meteor/admin/js/lib.upload.js"></script>
<div id="divMain">
  <div class="divHeader"><?php echo $blogtitle; ?></div>
