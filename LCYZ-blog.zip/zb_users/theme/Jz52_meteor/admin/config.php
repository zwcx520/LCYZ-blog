<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_meteor/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_meteor_SubMenu('config.php'); ?>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken') {
                continue;
            }
            $zbp->Config('Jz52_meteor')->$k = $v;
        }
        $zbp->SaveConfig('Jz52_meteor');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">LOGO 与站点标识</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>LOGO图片（浅色）</p></td>
          <td>
            <div class="cfg-preview" id="logo-prev"><img src="<?php echo $zbp->Config('Jz52_meteor')->logo; ?>" alt="" onerror="this.style.display='none'" style="height:40px;"></div>
            <div class="cfg-upload uploadimg" data-id="logo-prev">
              <?php ZbpForm::text('logo', $zbp->Config('Jz52_meteor')->logo, '280px', '图片地址或点击浏览'); ?><strong>浏览文件</strong>
            </div>
          </td>
          <td><p class="jz-desc">页头浅色模式 LOGO，留空则只显示网站名</p></td>
        </tr>
        <tr>
          <td align="center"><p>LOGO图片（深色）</p></td>
          <td>
            <div class="cfg-preview" id="logo-dark-prev"><img src="<?php echo $zbp->Config('Jz52_meteor')->logo_dark; ?>" alt="" onerror="this.style.display='none'" style="height:40px;"></div>
            <div class="cfg-upload uploadimg" data-id="logo-dark-prev">
              <?php ZbpForm::text('logo_dark', $zbp->Config('Jz52_meteor')->logo_dark, '280px', '图片地址或点击浏览'); ?><strong>浏览文件</strong>
            </div>
          </td>
          <td><p class="jz-desc">深色模式下显示的 LOGO（建议使用浅色/白色系图片）</p></td>
        </tr>
        <tr>
          <td align="center"><p>Favicon地址</p></td>
          <td>
            <div class="cfg-preview" id="favicon-prev"><img src="<?php echo $zbp->Config('Jz52_meteor')->favicon; ?>" alt="" onerror="this.style.display='none'" style="height:24px;"></div>
            <div class="cfg-upload uploadimg" data-id="favicon-prev">
              <?php ZbpForm::text('favicon', $zbp->Config('Jz52_meteor')->favicon, '280px', '图片地址或点击浏览'); ?><strong>浏览文件</strong>
            </div>
          </td>
          <td><p class="jz-desc">浏览器标签页小图标，留空则不输出</p></td>
        </tr>
      </table>
      <div class="jztit">卸载设置</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>卸载清除配置</p></td>
          <td><p><?php ZbpForm::radio('DelConfig', array('1' => '是', '0' => '否'), $zbp->Config('Jz52_meteor')->DelConfig); ?></p></td>
          <td><p class="jz-desc">卸载主题时是否同时删除主题配置数据</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_meteor");
$(document).ready(function() {
    $(document).on('keydown', function(e) {
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            $('input[name="submit"]').click();
        }
    });
});
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
