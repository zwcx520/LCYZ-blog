$(function(){
	var UP_URL = bloghost+'zb_users/theme/Jz52_meteor/admin/upload.php';

	var token = $('meta[name="csrfToken"]').attr('content');

	function doUpload($box, file){
		if (!/^image\//.test(file.type)) { alert('只允许上传图片文件'); return; }
		var fd = new FormData();
		fd.append('file', file);
		fd.append('csrfToken', token);
		var $btn = $box.find('strong').first();
		var oldText = $btn.text();
		$btn.text('上传中…').prop('disabled', true);
		var xhr = new XMLHttpRequest();
		xhr.open('POST', UP_URL, true);
		xhr.onload = function(){
			$btn.text(oldText).prop('disabled', false);
			var res = null;
			try { res = JSON.parse(xhr.responseText); } catch(e) {}
			if (res && res.state === 'success' && res.url) {
				$box.find('.uplod_img, input[type="text"]').first().val(res.url);
				var tid = $box.attr('data-id');
				if (tid) {
					var $target = $('#' + tid);
					var $ti = $target.find('img');
					if ($ti.length) {
						$ti.attr('src', res.url).show();
					} else {
						$target.append('<img src="' + res.url + '" alt=""/>');
					}
				}
			} else {
				alert((res && res.msg) ? res.msg : '上传失败，可能是图片尺寸过大');
			}
		};
		xhr.onerror = function(){ $btn.text(oldText).prop('disabled', false); alert('上传失败：网络错误'); };
		xhr.send(fd);
	}
	function pickAndUpload($box){
		var fileInput = document.createElement('input');
		fileInput.type = 'file';
		fileInput.accept = 'image/*';
		fileInput.style.display = 'none';
		document.body.appendChild(fileInput);
		fileInput.addEventListener('change', function(){
			var file = fileInput.files && fileInput.files[0];
			if (file) { doUpload($box, file); }
		});
		fileInput.click();
	}
	$(document).on('click', '.uploadimg strong', function(e){
		e.preventDefault();
		pickAndUpload($(this).closest('.uploadimg'));
	});
});
