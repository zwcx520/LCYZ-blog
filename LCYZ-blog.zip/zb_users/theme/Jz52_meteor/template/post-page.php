{* Template Name:独立页模板 *}
<article id="post-{$article.ID}" class="post post-content page">
    <header class="post-header">
        <h1 class="post-title mt-3 mb-4 fs-2">{$article.Title}</h1>
    </header>
    <div class="article-body mb-4">
        {$article.Content}
    </div>
    {if $article.CommNums>=0}
    <section class="comments">
        {template:comments}
    </section>
    {/if}
</article>
