{* Template Name:搜索页模板 *}
{template:header}

<!-- 搜索页 Banner -->
<div class="banner trem-banner mb-4">
    <div class="container-xl">
        <div class="trem-headbox bordered">
            <div class="bgimage"></div>
            <div class="trem-data">
                <h1 class="page-title mb-3 fs-2">{php}echo '搜索：' . htmlspecialchars(GetVars('q', 'GET'));{/php}</h1>
                <div class="taxonomy-description">{if $articles}共找到 {php}echo count($articles);{/php} 条相关结果{else}未找到与您的搜索词相关的内容{/if}</div>
            </div>
        </div>
    </div>
</div>

<!-- 主内容区 -->
<section class="wi widget-coltow">
    <div class="container-xl">
        <div class="row cxrow">
            <div class="col-left">
                <div class="rowleft mb-4">
                    <div class="module-content px--1">
                        {if $articles}
                        {foreach $articles as $article}
                        {template:post-multi}
                        {/foreach}
                        {else}
                        <div class="nonebox"><div class="iconsvg"></div><p>暂无内容!</p></div>
                        {/if}
                    </div>
                    {template:pagebar}
                </div>
            </div>

            <div class="col-right" id="sidebar">
                <div class="rowright">
                    <aside class="side-area">
                        {template:sidebar5}
                    </aside>
                </div>
            </div>
        </div>
    </div>
</section>

{template:footer}
