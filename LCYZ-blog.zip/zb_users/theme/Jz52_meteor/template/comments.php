{* Template Name:评论模块 *}
{if $socialcomment}
{$socialcomment}
{else}
<div class="comment-area">
    <div class="mso nobg">
        <div class="module-tit item-center noborder">
            <h3 style="font-size:1rem"><i class="cxline"></i>评论（{$article.CommNums}）:</h3>
            <p></p>
        </div>
        <div class="module-content">
            <div class="comments-list">
                <label id="AjaxCommentBegin"></label>
                {if $article.CommNums>0}
                {foreach $comments as $key=>$comment}
                {template:comment}
                {/foreach}
                {/if}
                <label id="AjaxCommentEnd"></label>
                {if isset($commentspagebar)&&$commentspagebar}
                <div class="comments-pagination">{template:pagebar}</div>
                {/if}
            </div>
        </div>
    </div>
    {template:commentpost}
</div>
{/if}
