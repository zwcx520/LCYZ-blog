{* Template Name:公用页脚模块 *}
</main><!-- main.end -->

<footer class="footer-s1">
    <div class="linebox bg-auto"></div>
    <div class="foottop">
        <div class="container-xl">
            <div class="footmain-box">
                {if $zbp->Config('Jz52_meteor')->foot_nav=='1'}
                <div class="aboutus_link">
                    {php}
                    $navstr = '';
                    $foot_navdata = Jz52_meteor_footnav();
                    if (empty($foot_navdata)) {
                        echo '<p>请到后台主题配置-页脚设置中添加导航项目!</p>';
                    } else {
                        foreach ($foot_navdata as $navdata) {
                            if (!isset($navdata['url']) || empty($navdata['url'])) continue;
                            if (!isset($navdata['name']) || empty($navdata['name'])) $navdata['name'] = 'Links';
                            $navstr .= '<a href="' . $navdata['url'] . '"' . (!empty($navdata['target']) ? ' target="_blank"' : '') . '>' . $navdata['name'] . '</a>';
                        }
                        echo $navstr;
                    }
                    {/php}
                </div>
                {/if}
                {if $zbp->Config('Jz52_meteor')->foot_desc}
                <div class="footer-desc">{$zbp->Config('Jz52_meteor')->foot_desc}</div>
                {/if}
                <div class="foot-copyright" id="footer">
                    <p>© {php}echo date('Y');{/php} <a href="{$host}">{$name}</a> Powered by <a href="https://www.zblogcn.com/" title="Z-BlogPHP" target="_blank" rel="noopener noreferrer">Z-BlogPHP</a> · Theme <a href="https://app.zbp.cool/"  title="隔壁老李">GebiLaoli</a></p>
                </div>
                {if $zbp->Config('Jz52_meteor')->foot_icp || $zbp->Config('Jz52_meteor')->foot_ga}
                <div class="foot-icp mb-4 fs-6 opacity-50">
                    {if $zbp->Config('Jz52_meteor')->foot_ga}<span>{$zbp->Config('Jz52_meteor')->foot_ga}</span>{/if}
                    {if $zbp->Config('Jz52_meteor')->foot_icp && $zbp->Config('Jz52_meteor')->foot_ga}<span class="px-1"></span>{/if}
                    {if $zbp->Config('Jz52_meteor')->foot_icp}<a href="http://beian.miit.gov.cn/" target="_blank" rel="noreferrer noopener nofollow">{$zbp->Config('Jz52_meteor')->foot_icp}</a>{/if}
                </div>
                {/if}
            </div>
        </div>
    </div>
</footer>
<!-- 弹出层代码 -->
<div class="popbg-box trans_2ms" id="popbgBox"></div>
<div class="search-popup trans_2ms" id="searchPopup">
    <button type="button" class="btn-close" aria-label="Close" data-meteor-close></button>
    <div class="search-content">
        <div class="search-form-box">
            <form class="d-flex search-form" role="search" method="post" action="{$host}zb_system/cmd.php?act=search">
                <input class="form-control me-2" placeholder="搜索并按回车键..." type="search" name="q" id="search" value="" aria-label="搜索">
                <button class="btn btn-default btn-lg" type="submit"><i class="jzicon jzicon-search"></i></button>
            </form>
        </div>
    </div>
</div>
<!-- .end -->
</div>
<!--.site-wrapper-->
{$footer}
<script src="{$host}zb_users/theme/Jz52_meteor/script/swiper-bundle.min.js"></script>
<script src="{$host}zb_users/theme/Jz52_meteor/script/theme.min.js?v=1.0.2"></script>
</body>
</html>
