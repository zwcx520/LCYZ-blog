{* Template Name:首页及列表页模板 *}
{template:header}

{if $type=='index'&&$page==1}
<!-- 首页轮播 + 今日精选 -->
{if Jz52_meteor_home_slide()}
<section class="wi widget-so">
    <div class="container-xl">
        <div class="row">
            <div class="col-lg-8 col-12">
                <div class="plbox">
                    <div class="swiper slide-s1" id="slide-s1" data-obj='{"effect":"fade","fadeEffect":{"crossFade":true},"autoplay":{"delay":5000},"navigation":{"nextEl":".s1-next","prevEl":".s1-prev"},"pagination":{"el":".s1-pagination","type":"progressbar"}}'>
                        <div class="swiper-wrapper">
                            {php}
                            $slide_list = Jz52_meteor_slide_list();
                            if (empty($slide_list)) {
                                echo '<div class="swiper-slide"><div class="apl apl-slide"><div class="thumb none-archive">暂无符合推送的内容！</div></div></div>';
                            } else {
                                foreach ($slide_list as $article) {
                                    echo '<div class="swiper-slide"><div class="apl apl-slide"><div class="thumb"><a href="' . $article->Url . '"><div class="thumb-inner shade"><img src="' . Jz52_meteor_IMG($article) . '" width="280" height="180" alt="' . $article->Title . '"></div></a></div><div class="subtitle"><div class="sortbox"><a href="' . $article->Category->Url . '" class="sort sort-' . $article->Category->ID . '">' . $article->Category->Name . '</a></div><h3 class="post-title line-one"><a href="' . $article->Url . '">' . $article->Title . '</a></h3><div class="pmbox pdesc"><div class="l"><a class="author" href="' . $article->Author->Url . '"><i class="jzicon jzicon-user-black font-inherit"></i> ' . $article->Author->StaticName . '</a> <i class="jzicon jzicon-dian color-grad"></i> <span class="time text-white">' . $article->Time('Y-m-d') . '</span></div></div></div></div></div>';
                                }
                            }
                            {/php}
                        </div>
                        <div class="swiper-button-next s1-next"></div>
                        <div class="swiper-button-prev s1-prev"></div>
                        <div class="s1-pagination"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-12 mt-4 mt-lg-0">
                <!-- 今日精选 -->
                <div class="mso nobg post-tabs index-ht bordered">
                    <div class="module-tit">
                        <h3 class="fali"><span>今日</span>精选</h3>
                        <p></p>
                        <div class="hyh-ajax" id="meteorRandBtn">
                            <span><i class="jzicon jzicon-gengxin" id="meteorRandIcon"></i> 换一批</span>
                        </div>
                    </div>
                    <div class="tab-content anim" id="meteorRandBox">
                        {php}echo Jz52_meteor_rand_html(4);{/php}
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
{/if}

<!-- 首页自定义推荐 -->
{if Jz52_meteor_home_custom()}
<section class="wi widget-categ">
    <div class="container-xl">
        <div class="row">
            {php}
            $home_customdata = Jz52_meteor_customdata();
            if (empty($home_customdata)) {
                echo '<div class="nonebox"><div class="iconsvg"></div><p>暂无内容[首页自定义推荐模块]!</p></div>';
            } else {
                foreach ($home_customdata as $customdata) {
                    if (empty($customdata['url'])) continue;
                    if (empty($customdata['title'])) $customdata['title'] = 'Links';
                    $target = !empty($customdata['target']) ? ' target="_blank"' : '';
                    $item_href = 'href="' . $customdata['url'] . '" title="' . $customdata['title'] . '"' . $target;
                    $thumb_class = ($customdata['imagetype'] == 'fillet' || $customdata['imagetype'] == 'round') ? 'thumb ' . $customdata['imagetype'] : 'thumb';
                    $thumb_html = '<div class="' . $thumb_class . '"><a ' . $item_href . '><div class="thumb-inner"><img loading="lazy" decoding="async" src="' . $customdata['image'] . '" width="60" height="60" alt="' . $customdata['title'] . '"></div></a></div>';
                    echo '<div class="col-12 col-md-6 col-lg-3"><div class="item-eg bordered"><div class="egbox">'
                        . $thumb_html
                        . '<div class="subtitle"><h4><a class="item-href" ' . $item_href . '>' . $customdata['title'] . '</a></h4><p class="pdesc">' . $customdata['desc'] . '</p></div>'
                        . '</div></div></div>';
                }
            }
            {/php}
        </div>
    </div>
</section>
{/if}
{/if}

{if $type!='index'}
<!-- 列表页 Banner -->
<div class="banner trem-banner mb-4">
    <div class="container-xl">
        <div class="trem-headbox bordered">
            <div class="bgimage"></div>
            <div class="trem-data">
                {if $type=='category'}
                <h1 class="page-title mb-3 fs-2">{$category.Name}</h1>
                {if $category.Intro}<div class="taxonomy-description">{$category.Intro}</div>{/if}
                {elseif $type=='tag'}
                <h1 class="page-title mb-3 fs-2">#{$tag.Name}</h1>
                {if $tag.Intro}<div class="taxonomy-description">{$tag.Intro}</div>{/if}
                {elseif $type=='author'}
                <h1 class="page-title mb-3 fs-2">{$author.StaticName}</h1>
                {if $author.Intro}<div class="taxonomy-description">{$author.Intro}</div>{/if}
                {elseif $type=='date'}
                <h1 class="page-title mb-3 fs-2">{$title}</h1>
                <div class="taxonomy-description">按月归档</div>
                {/if}
            </div>
        </div>
    </div>
</div>
{/if}

<!-- 主内容区 -->
<section class="wi widget-coltow">
    <div class="container-xl">
        <div class="row cxrow">
            <div class="col-left">
                <div class="rowleft">
                    {if $type=='index'&&$page==1&&Jz52_meteor_home_press()}
                    <!-- 热点推荐 -->
                    <div class="swi widget-jxbox">
                        <div class="mso jxtainer bordered">
                            <div class="module-tit">
                                <h3 class="fali"><span>热点</span>推荐</h3>
                                {if $zbp->Config('Jz52_meteor')->home_press_desc}<p>{$zbp->Config('Jz52_meteor')->home_press_desc}</p>{/if}
                                {if $zbp->Config('Jz52_meteor')->home_press_right=='color'}<div class="more-round"><i></i></div>{/if}
                            </div>
                            <div class="module-content">
                                {php}
                                $hotspot_list = Jz52_meteor_hotspot_list();
                                if (empty($hotspot_list)) {
                                    echo '<div class="nonebox"><div class="iconsvg"></div><p>暂无内容!</p></div>';
                                } else {
                                    $i = 0;
                                    foreach ($hotspot_list as $article) {
                                        $i++;
                                        if ($i == 1) {
                                            echo '<div class="item-jx item-blog maxthumb"><div class="jxbox"><div class="thumb"><a href="' . $article->Url . '"><div class="thumb-inner"><img loading="lazy" decoding="async" src="' . Jz52_meteor_IMG($article) . '" width="280" height="180" alt="' . $article->Title . '"></div></a><div class="sortbox"><a href="' . $article->Category->Url . '" class="sort sort-' . $article->Category->ID . '">' . $article->Category->Name . '</a></div></div><div class="subtitle"><h5 class="line-tow"><a href="' . $article->Url . '">' . $article->Title . '</a></h5><p class="pdesc">' . Jz52_meteor_postdesc($article, 60) . '</p><div class="pmbox"><div class="l"><a class="author" href="' . $article->Author->Url . '"><figure class="figure-avatar btn-default userid-' . $article->Author->ID . '"><img src="' . $article->Author->Avatar . '"></figure>' . $article->Author->StaticName . '</a> <i class="jzicon jzicon-dian color-grad"></i> <span class="time">' . $article->Time('Y-m-d') . '</span></div><div class="r d-sm-inline"><a href="' . $article->Url . '" title="' . $article->Title . '" class="more-link"><i class="jzicon jzicon-caidan-h"></i></a></div></div></div></div></div>';
                                        } else {
                                            echo '<div class="item-jx item-min"><div class="jxbox"><div class="thumb"><a href="' . $article->Url . '"><div class="thumb-inner"><img loading="lazy" decoding="async" src="' . Jz52_meteor_IMG($article) . '" width="280" height="180" alt="' . $article->Title . '"></div></a></div><div class="subtitle"><h5 class="line-tow"><a href="' . $article->Url . '">' . $article->Title . '</a></h5><div class="pmbox pdesc"><div class="l"><a class="author" href="' . $article->Author->Url . '">' . $article->Author->StaticName . '</a> <i class="jzicon jzicon-dian color-grad"></i> <span class="time">' . $article->Time('Y-m-d') . '</span></div><div class="r d-sm-inline"></div></div></div></div></div>';
                                        }
                                    }
                                }
                                {/php}
                            </div>
                        </div>
                    </div>
                    {/if}

                    {if $type=='index'}
                    <div class="swi widget-postbox">
                        <div class="mso nobg potainer">
                            <div class="module-tit noborder">
                                <h3 class="fali"><span>最新</span>文章</h3>
                                <p>精心为您推荐...</p>
                            </div>
                            <div class="module-content">
                    {/if}
                                {if $articles}
                                {foreach $articles as $article}
                                {if $article.TopType&&$type=='index'&&$page==1}
                                {template:post-istop}
                                {else}
                                {template:post-multi}
                                {/if}
                                {/foreach}
                                {else}
                                <div class="nonebox"><div class="iconsvg"></div><p>暂无内容!</p></div>
                                {/if}
                    {if $type=='index'}
                            </div>
                            {template:pagebar}
                        </div>
                    </div>
                    {else}
                    <div class="rowleft mb-4">
                        {template:pagebar}
                    </div>
                    {/if}
                </div>
            </div>

            <div class="col-right" id="sidebar">
                <div class="rowright">
                    <aside class="side-area">
                        {if $type=='index'}
                        {template:sidebar}
                        {elseif $type=='category'||$type=='tag'||$type=='author'||$type=='date'}
                        {template:sidebar2}
                        {else}
                        {template:sidebar5}
                        {/if}
                    </aside>
                </div>
            </div>
        </div>
    </div>
</section>

{template:footer}
