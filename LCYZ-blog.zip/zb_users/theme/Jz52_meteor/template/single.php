{* Template Name:内容页模板（文章/独立页） *}
{template:header}

<div class="banner trem-banner mb-4">
    <div class="container-xl">
        <ul class="breadcrumb">
            <li><a href="{$host}">首页</a></li>
            {if $article.Type==0}
            <li><a href="{$article.Category.Url}">{$article.Category.Name}</a></li>
            {/if}
            <li><a class="active" href="{$article.Url}">{$article.Title}</a></li>
        </ul>
    </div>
</div>

<!-- 主内容区 -->
<section class="wi widget-coltow">
    <div class="container-xl">
        <div class="row cxrow">
            <div class="col-left">
                <div class="rowleft">
                    <div class="main-content pe-xl-4">
                        {if $article.Type==0}
                        {template:post-single}
                        {else}
                        {template:post-page}
                        {/if}
                    </div>
                </div>
            </div>

            <div class="col-right" id="sidebar">
                <div class="rowright">
                    <aside class="side-area">
                        {if $article.Type==0}
                        {template:sidebar3}
                        {else}
                        {template:sidebar4}
                        {/if}
                    </aside>
                </div>
            </div>
        </div>
    </div>
</section>

{template:footer}
