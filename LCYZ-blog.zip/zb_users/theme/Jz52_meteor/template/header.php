{* Template Name:公用页头模块 *}
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{$title}{if $type=='index'&&$page==1} - {$name}{/if}</title>
{if $zbp->Config('Jz52_meteor')->seo=='1'}
{php}
$seotitle = '';
$seokeywords = '';
$seodescription = '';
$cfg = $zbp->Config('Jz52_meteor');
if ($type == 'index' && $page == 1) {
    $seotitle = $cfg->seotitle;
    $seokeywords = $cfg->seokeywords;
    $seodescription = $cfg->seodescription;
} elseif ($type == 'category' && isset($category)) {
    $seotitle = $category->Name;
    $seokeywords = $category->Name;
    $seodescription = TransferHTML($category->Intro, '[nohtml]');
} elseif ($type == 'tag' && isset($tag)) {
    $seotitle = $tag->Name;
    $seokeywords = $tag->Name;
    $seodescription = TransferHTML($tag->Intro, '[nohtml]');
} elseif (($type == 'article' || $type == 'page') && isset($article)) {
    $seotitle = $article->Title;
    $seokeywords = $article->Tags->Name;
    $seodescription = Jz52_meteor_postdesc($article, 120);
}
echo '<meta name="keywords" content="' . htmlspecialchars($seokeywords) . '">' . "\n";
echo '<meta name="description" content="' . htmlspecialchars($seodescription) . '">' . "\n";
{/php}
{/if}
{if $zbp->Config('Jz52_meteor')->favicon}<link rel="icon" href="{$zbp->Config('Jz52_meteor')->favicon}" type="image/x-icon">{/if}
<meta name="generator" content="Z-BlogPHP">
{if $type=='index'&&$page==1}
<link rel="alternate" type="application/rss+xml" href="{$feedurl}" title="{$name}">
{/if}
<link rel="stylesheet" href="{$host}zb_users/theme/Jz52_meteor/style/css/bootstrap.min.css">
<link rel="stylesheet" href="{$host}zb_users/theme/Jz52_meteor/style/css/swiper-bundle.min.css">
<link rel="stylesheet" href="{$host}zb_users/theme/Jz52_meteor/style/css/jzicon.css">
<link rel="stylesheet" href="{$host}zb_users/theme/Jz52_meteor/style/style.css?v=1.0.1">
{$header}
<script src="{$host}zb_system/script/jquery-latest.min.js?v={$version}"></script>
<script src="{$host}zb_system/script/zblogphp.js?v={$version}"></script>
<script src="{$host}zb_system/script/c_html_js_add.php?hash={$html_js_hash}&v={$version}"></script>
<script>
window.meteorConfig = {host:"{$host}", theme:"{$host}zb_users/theme/Jz52_meteor/"};
</script>
</head>
<body class="{$type} headernav-top cxtheme-body">
<div class="site-wrapper">
<header class="header-s1" id="header">
  <div class="headnav">
    <div class="container-xl h-container">
      <div class="cxlogo">
        <a href="{$host}">
          <img data-logo-light="{$zbp->Config('Jz52_meteor')->logo}" data-logo-dark="{$zbp->Config('Jz52_meteor')->logo_dark}" src="{$zbp->Config('Jz52_meteor')->logo}" alt="{$name}">
        </a>
      </div>
      <nav class="head-menu d-lg-flex">
        <ul class="navbar-nav" id="mainNav">
          {module:navbar}
        </ul>
      </nav>
      <div class="header-r">
        <ul class="h-btnbox sm-cnone">
          <li class="list-inline-item">
            <a href="javascript:;" class="meteor-dark-btn" title="深浅色切换">
              <i class="jzicon jzicon-sunlight me-0 c-light"></i>
              <i class="jzicon jzicon-moon me-0 c-dark"></i>
            </a>
          </li>
        </ul>
        <div class="h-buttons">
          <button type="button" class="search btn-default icon-button meteor-search-btn" title="搜索"><i class="jzicon jzicon-search me-0"></i></button>
          <button type="button" class="search btn-default icon-button meteor-menu-btn" title="菜单"><i class="jzicon jzicon-menu3 me-0"></i></button>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- 移动端抽屉菜单 -->
<div class="mobile-navbox trans_2ms" id="mobileNavbox">
  <button type="button" class="btn-close" aria-label="关闭" data-meteor-close></button>
  <div class="m-menulogo p-4 pt-3">
    <a href="{$host}"><img data-logo-light="{$zbp->Config('Jz52_meteor')->logo}" data-logo-dark="{$zbp->Config('Jz52_meteor')->logo_dark}" src="{$zbp->Config('Jz52_meteor')->logo}" alt="{$name}"></a>
  </div>
  <div class="m-navbox p-4 pt-0">
    <ul class="m-nav pe-4" id="mobileNav">
      {module:navbar}
    </ul>
  </div>
</div>
<main class="main-container">
