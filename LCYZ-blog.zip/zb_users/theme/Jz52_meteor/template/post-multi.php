{* Template Name:列表文章项(博客样式) *}
<div class="item-jx item-blog">
    <div class="jxbox">
        <div class="thumb">
            <a href="{$article.Url}">
                <div class="thumb-inner">
                    <img loading="lazy" decoding="async" src="{php}echo Jz52_meteor_IMG($article);{/php}" width="280" height="180" alt="{$article.Title}">
                </div>
            </a>
            {if $article.Category.ID>0}
            <div class="sortbox"><a href="{$article.Category.Url}" class="sort sort-{$article.Category.ID}">{$article.Category.Name}</a></div>
            {/if}
        </div>
        <div class="subtitle">
            <h2 class="line-tow"><a href="{$article.Url}" title="{$article.Title}">{$article.Title}</a></h2>
            <p class="pdesc">{php}echo Jz52_meteor_postdesc($article, 60);{/php}</p>
            <div class="pmbox">
                <div class="l">
                    <a class="author" href="{$article.Author.Url}"><figure class="figure-avatar btn-default userid-{$article.Author.ID}"><img src="{$article.Author.Avatar}"></figure>{$article.Author.StaticName}</a>
                    <i class="jzicon jzicon-dian color-grad"></i>
                    <span class="time">{$article.Time('Y-m-d')}</span>
                </div>
                <div class="r d-sm-inline">
                    <a href="{$article.Url}" title="{$article.Title}" class="more-link"><i class="jzicon jzicon-caidan-h"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
