{* Template Name:分页模板 *}
{if $pagebar}
<nav class="navigation pagination" aria-label="分页">
    <div class="nav-links">
        {foreach $pagebar->buttons as $key=>$url}
        {if $pagebar->PageNow==$key}
        <span class="page-numbers current">{$key}</span>
        {elseif $key=='‹‹'}
        {elseif $key=='‹'}
        <a class="prev page-numbers" href="{$url}" title="上一页"><span class="nav-prev-text"><i class="jzicon jzicon-jtleft"></i></span></a>
        {elseif $key=='›'}
        <a class="next page-numbers" href="{$url}" title="下一页"><span class="nav-next-text"><i class="jzicon jzicon-jtright"></i></span></a>
        {elseif $key=='››'}
        {elseif $key=='...'}
        <span class="page-numbers dots">…</span>
        {else}
        <a class="page-numbers" href="{$url}">{$key}</a>
        {/if}
        {/foreach}
    </div>
</nav>
{/if}
