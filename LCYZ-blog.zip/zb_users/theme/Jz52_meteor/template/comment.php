{* Template Name:评论项 *}
<div class="comment-item" id="cmt{$comment.ID}">
    <div class="comment-avatar"><img src="{$comment.Author.Avatar}" alt="{$comment.Author.StaticName}"></div>
    <div class="comment-content">
        <div class="comment-meta">
            <span class="comment-author">{if $comment.Author.HomePage}<a href="{$comment.Author.HomePage}" rel="nofollow" target="_blank">{$comment.Author.StaticName}</a>{else}{$comment.Author.StaticName}{/if}</span>
            <span class="comment-date">{$comment.Time()}</span>
        </div>
        <div class="comment-text">{$comment.Content}</div>
        <div class="comment-actions">
            <a class="comment-reply-link" href="javascript:;" data-cmtid="{$comment.ID}"><i class="jzicon jzicon-caidan-h"></i>回复</a>
        </div>
        {if count($comment.Comments)}
        <div class="child-comments">
            {foreach $comment.Comments as $comment}
            {template:comment}
            {/foreach}
        </div>
        {/if}
    </div>
</div>
<label id="AjaxComment{$comment.ID}"></label>
