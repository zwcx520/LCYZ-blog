{* Template Name:导航栏子项 *}
<li class="nav-item{if count($item.subs)} has-sub{/if}">
  <a href="{$item.href}" target="{$item.target}" title="{$item.title}">{$item.ico}{$item.text}</a>
  {if count($item.subs)}
  <ul class="sub-menu">
    {foreach $item.subs as $item}
    {template:lm-module-navbar}
    {/foreach}
  </ul>
  {/if}
</li>
