{* Template Name:评论表单 *}
<span id="respondAnchor"></span>
<div class="comment-respond mso nobg" id="respond">
    <div class="module-tit item-center noborder">
        <h3 style="font-size:1rem"><i class="cxline"></i>发表评论:</h3>
        <p></p>
        <div class="comment-cancel-wrap">
            <button type="button" class="btn btn-xsm btn-outline-secondary" id="cancelReply" style="display:none"><i class="jzicon jzicon-guanbi"></i> 取消回复</button>
        </div>
    </div>
    <div class="module-content">
        <div id="comment-message" class="comment-message"></div>
        <form id="commentform" name="commentform" method="post" action="{$article.CommentPostUrl}">
            <input type="hidden" name="inpId" id="inpId" value="{$article.ID}">
            <input type="hidden" name="inpRevID" id="inpRevID" value="0">
            {if $user.ID>0}
            <input type="hidden" name="inpName" id="inpName" value="{$user.StaticName}">
            <input type="hidden" name="inpEmail" id="inpEmail" value="{$user.Email}">
            <input type="hidden" name="inpHomePage" id="inpHomePage" value="{$user.HomePage}">
            <div class="comment-userinfo">
                <img class="comment-user-avatar" src="{$user.Avatar}" alt="{$user.StaticName}">
                <span class="comment-user-name">{$user.StaticName}</span>
                <span class="comment-user-tip">当前状态：已登录</span>
            </div>
            {else}
            <div class="comment-fields">
                <input id="inpName" name="inpName" class="form-control" type="text" placeholder="昵称 *" maxlength="20">
                <input id="inpEmail" name="inpEmail" class="form-control" type="email" placeholder="邮箱 *">
                <input id="inpHomePage" name="inpHomePage" class="form-control" type="url" placeholder="网址(选填)">
            </div>
            {/if}
            <div class="comment-form-comment">
                <textarea id="txaArticle" name="txaArticle" placeholder="写下您的评论..." rows="4" required></textarea>
                {if $option['ZC_COMMENT_VERIFY_ENABLE']&&!$zbp.CheckRights('NoValidCode')}
                <div class="comment-verify mt-2">
                    <span>验证码:</span>
                    <input name="inpVerify" id="inpVerify" class="form-control d-inline-block w-auto" type="text" size="6" tabindex="4" style="width:100px;display:inline-block;">
                    <img src="{$article.ValidCodeUrl}" alt="验证码" onclick="this.src='{$article.ValidCodeUrl}&amp;tm='+Math.random();" style="cursor:pointer;">
                </div>
                {/if}
                <div class="form-submit text-end">
                    <button type="submit" name="sumbit" id="submit" class="btn btn-default" onclick="return zbp.comment.post()"><i class="jzicon jzicon-feiji-black font-inherit"></i> 发表评论</button>
                </div>
            </div>
        </form>
    </div>
</div>
