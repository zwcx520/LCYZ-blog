{* Template Name:404页模板 *}
{template:header}

<section class="wi widget-coltow">
    <div class="container-xl">
        <div class="row">
            <div class="col-12">
                <div class="nonebox pt-5 pb-5">
                    <div class="iconsvg" style="width:160px;height:160px"></div>
                    <p>抱歉，没有找到您要的内容！</p>
                    <p><a class="btn btn-default" href="{$host}">返回首页</a></p>
                </div>
            </div>
        </div>
    </div>
</section>

{template:footer}
