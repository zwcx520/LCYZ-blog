{* Template Name:侧栏一(首页) *}
{if !$sidebar}
<div class="widget"><div class="module-tit"><h3 class="widget-title">侧栏提示</h3></div><div class="widget-body"><p class="pdesc">请到后台 [模块管理] 为侧栏添加模块！</p></div></div>
{else}
{foreach $sidebar as $module}
{template:module}
{/foreach}
{/if}
