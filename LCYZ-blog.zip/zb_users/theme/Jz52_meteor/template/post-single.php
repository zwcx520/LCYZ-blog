{* Template Name:文章页模板 *}
<article id="post-{$article.ID}" class="post is-single post-content status-publish">
    <!-- 文章标题 -->
    <header class="post-header">
        <h1 class="post-title mt-3 mb-4 fs-2">{$article.Title}</h1>
        <!-- 文章元信息 -->
        <div class="article-meta">
            <ul class="meta-itembox">
                <li class="list-inline-item"><a class="author me-0" href="{$article.Author.Url}"><figure class="figure-avatar btn-default userid-{$article.Author.ID}"><img src="{$article.Author.Avatar}"></figure>{$article.Author.StaticName}</a></li>
                {if $article.Category.ID>0}<li class="list-inline-item"><a href="{$article.Category.Url}">{$article.Category.Name}</a></li>{/if}
                <li class="list-inline-item">{$article.Time('Y-m-d')}</li>
            </ul>
        </div>
    </header>

    <!-- 文章正文 -->
    <div class="article-body mb-4">
        {$article.Content}
    </div>

    <!-- 底部元信息 -->
    <div class="post-footmeta mb-4">
        <div class="row d-flex align-items-center">
            <div class="col-md-6 col-12">
                <div class="post-share justify-content-sm-start mb-3 mb-sm-0">
                    <ul class="social-icons" data-share="{php}echo Jz52_meteor_IMG($article);{/php}">
                        <li class="list-inline-item">
                            <a href="javascript:;" title="分享到微博" class="meteor-share-weibo"><i class="jzicon jzicon-weibo"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:;" title="分享到QQ" class="meteor-share-qq"><i class="jzicon jzicon-qq"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-12 text-center text-md-end">
                <div class="tags">
                    {if $article.Tags}
                    {foreach $article.Tags as $tag}
                    <a href="{$tag.Url}" rel="tag">#{$tag.Name}</a>
                    {/foreach}
                    {/if}
                </div>
            </div>
        </div>
    </div>

    <!-- 作者名片 -->
    <div class="about-author p-4 mt-5 flex-sm-row">
        <div class="thumb"><a class="author" href="{$article.Author.Url}"><figure class="figure-avatar btn-default userid-{$article.Author.ID}"><img src="{$article.Author.Avatar}"></figure></a></div>
        <div class="details ps-sm-4 mt-3 mt-sm-0 text-sm-start">
            <h4 class="name"><a href="{$article.Author.Url}">{$article.Author.StaticName}</a></h4>
            <p>{if $article.Author.Intro}{$article.Author.Intro}{else}暂无介绍....{/if}</p>
            <ul class="social-icons list-unstyled list-inline mb-0">
                <li class="list-inline-item">
                    <a href="{$article.Author.Url}" class="author-link">TA的主页 <i class="jzicon jzicon-jtright font-inherit"></i></a>
                </li>
            </ul>
        </div>
    </div>

    <!-- 上一篇/下一篇 -->
    <div class="row nextprev-post-wrapper mb-4">
        <div class="col-md-6 col-12 mb-3 mb-sm-0">
            <div class="nextprev-post prev">
                <span class="nextprev-text">上一篇</span>
                <h5 class="post-title">
                    {php}
                    $prev_post = GetList(array('count' => 1, 'where_custom' => array(array('<', 'log_ID', $article->ID))));
                    if (isset($prev_post[0])) {
                        echo '<a href="' . $prev_post[0]->Url . '">' . $prev_post[0]->Title . '</a>';
                    } else {
                        echo '没有啦 (Ｔ▽Ｔ)';
                    }
                    {/php}
                </h5>
            </div>
        </div>
        <div class="col-md-6 col-12">
            <div class="nextprev-post next text-sm-end">
                <span class="nextprev-text">下一篇</span>
                <h5 class="post-title">
                    {php}
                    $next_post = GetList(array('count' => 1, 'where_custom' => array(array('>', 'log_ID', $article->ID))));
                    if (isset($next_post[0])) {
                        echo '<a href="' . $next_post[0]->Url . '">' . $next_post[0]->Title . '</a>';
                    } else {
                        echo '没有啦 (Ｔ▽Ｔ)';
                    }
                    {/php}
                </h5>
            </div>
        </div>
    </div>

    <!-- 评论区 -->
    <section class="comments">
        {template:comments}
    </section>

    <!-- 延伸阅读 -->
    <div class="mso nobg">
        <div class="module-tit item-center noborder">
            <h3 style="font-size:1rem"><i class="cxline"></i>延伸阅读:</h3>
            <p></p>
        </div>
        <div class="module-content">
            {php}
            $related_list = Jz52_meteor_related($article, 5);
            if (empty($related_list)) {
                echo '<div class="nonebox"><div class="iconsvg"></div><p>暂无内容!</p></div>';
            } else {
                foreach ($related_list as $article) {
                    echo '<div class="item-jx item-blog small"><div class="jxbox"><div class="thumb"><a href="' . $article->Url . '"><div class="thumb-inner"><img loading="lazy" decoding="async" src="' . Jz52_meteor_IMG($article) . '" width="280" height="180" alt="' . $article->Title . '"></div></a><div class="sortbox"><a href="' . $article->Category->Url . '" class="sort sort-' . $article->Category->ID . '">' . $article->Category->Name . '</a></div></div><div class="subtitle"><h2><a href="' . $article->Url . '">' . $article->Title . '</a></h2><p class="pdesc">' . Jz52_meteor_postdesc($article, 60) . '</p><div class="pmbox"><div class="l"><a class="author" href="' . $article->Author->Url . '"><figure class="figure-avatar btn-default userid-' . $article->Author->ID . '"><img src="' . $article->Author->Avatar . '"></figure>' . $article->Author->StaticName . '</a> <i class="jzicon jzicon-dian color-grad"></i> <span class="time">' . $article->Time('Y-m-d') . '</span></div><div class="r"><a href="' . $article->Url . '" class="more-link"><i class="jzicon jzicon-caidan-h"></i></a></div></div></div></div></div>';
                }
            }
            {/php}
        </div>
    </div>
</article>
