{* Template Name:单个模块 *}
<div class="widget" id="{$module.HtmlID}">
    {if (!$module.IsHideTitle)&&($module.Name)}<div class="module-tit"><h3 class="widget-title">{$module.Name}</h3></div>{/if}
    {if $module.Type=='div'}
    <div class="widget-body">{$module.Content}</div>
    {/if}
    {if $module.Type=='ul'}
    <ul class="widget-body{if $module.HtmlID=='widget-catalog'} zb-block-categories{/if}{if $module.HtmlID=='widget-previous'} zb-block-latest-posts{/if}{if $module.HtmlID=='widget-hot'} widget_postlist{/if}">{$module.Content}</ul>
    {/if}
</div>
