{* Template Name:SEO *}
{if $type=='article'}
<title>{$title}_{$article.Category.Name}_{$name}</title>
{php}
$aryTags = array();
foreach($article->Tags as $key){$aryTags[] = $key->Name;}
if(count($aryTags)>0){$keywords = implode(',',$aryTags);} else {$keywords = $zbp->name;}
$description = trim(SubStrUTF8(TransferHTML($article->Content,'[nohtml]'),135)).'...';
{/php}
<meta name="keywords" content="{$keywords}" />
<meta name="description" content="{$description}" />
{if $article.Prev}
<link rel="prev" title="{$article.Prev.Title}" href="{$article.Prev.Url}"/>
{/if}
{if $article.Next}
<link rel="next" title="{$article.Next.Title}" href="{$article.Next.Url}"/>
{/if}
<link rel="canonical" href="{$article.Url}"/>
{elseif $type=='page'}
<title>{$title}_{$name}_{$subname}</title>
<meta name="keywords" content="{$title},{$name}" />
{php}
$description = trim(SubStrUTF8(TransferHTML($article->Content,'[nohtml]'),135)).'...';
{/php}
<meta name="description" content="{$description}" />
{elseif $type=='index'}
<title>{if $zbp->Config('Jz52_onepage')->seotitle&&$page=='1'}{$zbp->Config('Jz52_onepage')->seotitle}{else}{$name}{if $page>'1'}_第{$pagebar.PageNow}页{/if}_{$subname}{/if}</title>
{if $zbp->Config('Jz52_onepage')->seokeywords}
<meta name="Keywords" content="{$zbp->Config('Jz52_onepage')->seokeywords}" />
{/if}
{if $zbp->Config('Jz52_onepage')->seodescription}
<meta name="description" content="{$zbp->Config('Jz52_onepage')->seodescription}" />
{/if}
{elseif $type=='tag'}
<title>{$tag.Name}_{$name}{if $page>'1'}_第{$pagebar.PageNow}页{/if}_{$subname}</title>
<meta name="Keywords" content="{$tag.Name}">
{if $tag.Intro}
<meta name="description" content="{$tag.Intro}">
{/if}
{elseif $type=='category'}
<title>{$title}_{$name}{if $page>'1'}_第{$pagebar.PageNow}页{/if}</title>
<meta name="Keywords" content="{$title},{$name}" />
<meta name="description" content="{$title}_{$name}{if $page>'1'}_第{$pagebar.PageNow}页{/if}" />
{else}
<title>{$title}_{$name}</title>
<meta name="Keywords" content="{$title},{$name}" />
<meta name="description" content="{$title}_{$name}{if $page>'1'}_当前是第{$pagebar.PageNow}页{/if}" />
{/if}