<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';
$zbp->Load();
$action='root';
if (!$zbp->CheckRights($action)) {$zbp->ShowError(6);die();}
if (!$zbp->CheckPlugin('Jz52_newthree')) {$zbp->ShowError(48);die();}
$blogtitle='主题配置';
$act = "";
if ($_GET['act']){
$act = $_GET['act'] == "" ? 'config' : $_GET['act'];
}
require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<style>
.jzadmin th{height:38px;text-align:center}.jzadmin td{padding:10px;text-align:center}.jzadmin td p{text-align:left}.jzadmin input{height:35px;padding:5px 10px;border:1px solid #ddd}strong{background-color:#3a6ea5;padding:8px 10px;color:#fff;border-radius:2px}
</style>
<div id="divMain">
	<div class="divHeader"><?php echo $blogtitle;?></div>
	<div class="SubMenu">
	 <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span>更多应用</span></a>
     <a href="https://yeelz.com" target="_blank"><span>技术支持</span></a>
    </div>
<div id="divMain2">
<?php 
if ($act == 'config') { 
if(isset($_POST['logo']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])){	
	//基本配置
	$zbp->Config('Jz52_newthree')->logo = $_POST['logo'];
	$zbp->Config('Jz52_newthree')->nlogo = $_POST['nlogo'];
	$zbp->Config('Jz52_newthree')->listimg = $_POST['listimg'];
	$zbp->Config('Jz52_newthree')->botico = $_POST['botico'];
	$zbp->Config('Jz52_newthree')->avatar = $_POST['avatar'];
	$zbp->Config('Jz52_newthree')->celanh = $_POST['celanh'];
	$zbp->Config('Jz52_newthree')->celant = $_POST['celant'];
	$zbp->Config('Jz52_newthree')->celanbut = $_POST['celanbut'];
	$zbp->Config('Jz52_newthree')->celanbutu = $_POST['celanbutu'];
	$zbp->Config('Jz52_newthree')->celanico = $_POST['celanico'];
	$zbp->SaveConfig('Jz52_newthree');
	$zbp->ShowHint('good');	
	Jz52_newthree_Build();
}
?>
<form id="form1" name="form1" method="post" class="jzadmin">	
    <table width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
	<input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken();?>">
		<tr>
			<th width="15%"><p align="center">选项名称</p></th>
			<th width="50%"><p align="center">选项内容</p></th>
			<th width="25%"><p align="center">选项说明</p></th>
		</tr>
        <tr>
          <td width="20%"  align="center">LOGO地址</td>
          <td><p><img src="<?php echo $zbp->Config('Jz52_newthree')->logo;?>" alt="logo" style = "height:40px;"/></p>
            <p class="uploadimg">
              <input name="logo" id="logo" type="text" class="uplod_img" style="width:68%;" value="<?php echo $zbp->Config('Jz52_newthree')->logo;?>" />
              <strong>浏览文件</strong> </p></td>
          <td><p align="left">LOGO图片地址</p></td>
        </tr>
		<tr>
          <td width="20%"  align="center">底部LOGO地址</td>
          <td><p><img src="<?php echo $zbp->Config('Jz52_newthree')->nlogo;?>" alt="logo" style = "height:40px;"/></p>
            <p class="uploadimg">
              <input name="nlogo" id="nlogo" type="text" class="uplod_img" style="width:68%;" value="<?php echo $zbp->Config('Jz52_newthree')->nlogo;?>" />
              <strong>浏览文件</strong> </p></td>
          <td><p align="left">底部LOGO图片地址</p></td>
        </tr>
	  <tr>
        <td width="20%"  align="center">文章列表显示图片封面</td>
        <td>
          <p align="left"><input type="text" id="listimg" name="listimg" class="checkbox" value="<?php echo $zbp->Config('Jz52_newthree')->listimg;?>"/></p>
		</td>
		<td><p align="left">启用后文章列表显示文章第一张图</p></td>
      </tr>
	  <tr>
        <td width="20%"  align="center">侧栏头像</td>
		<td><p><img src="<?php echo $zbp->Config('Jz52_newthree')->avatar;?>" alt="logo" style = "height:40px;"/></p>
            <p class="uploadimg">
              <input name="avatar" id="avatar" type="text" class="uplod_img" style="width:68%;" value="<?php echo $zbp->Config('Jz52_newthree')->avatar;?>" />
              <strong>浏览文件</strong> </p></td>
		<td><p align="left">侧栏站点信息选项卡头像</p></td>
      </tr>
	  <tr>
          <td width="20%" align="center">侧栏标题</td>
          <td>
            <p align="left">
              <input name="celanh" id="celanh" type="text" style="width:98%;" value="<?php echo $zbp->Config('Jz52_newthree')->celanh;?>" />
            </p></td>
          <td><p align="left">侧栏站点信息选项卡标题</p></td>
      </tr>
	  <tr>
          <td width="20%" align="center">侧栏说明</td>
          <td>
            <p align="left">
              <input name="celant" id="celant" type="text" style="width:98%;" value="<?php echo $zbp->Config('Jz52_newthree')->celant;?>" />
            </p></td>
          <td><p align="left">侧栏站点信息选项卡说明</p></td>
      </tr>
	  <tr>
          <td width="20%" align="center">侧栏按钮文字</td>
          <td>
            <p align="left">
              <input name="celanbut" id="celanbut" type="text" style="width:98%;" value="<?php echo $zbp->Config('Jz52_newthree')->celanbut;?>" />
            </p></td>
          <td><p align="left">侧栏站点信息按钮文字</p></td>
      </tr>
	  <tr>
          <td width="20%" align="center">侧栏按钮链接</td>
          <td>
            <p align="left">
              <input name="celanbutu" id="celanbutu" type="text" style="width:98%;" value="<?php echo $zbp->Config('Jz52_newthree')->celanbutu;?>" />
            </p></td>
          <td><p align="left">侧栏站点信息按钮链接</p></td>
      </tr>
	  <tr>
        <td width="20%"  align="center">侧栏社交图标</td>
        <td>
          <p align="left"><textarea name="celanico" type="text" id="celanico" style="width:98%;"><?php echo htmlspecialchars($zbp->Config('Jz52_newthree')->celanico);?></textarea></p>
		</td>
		<td><p align="left">侧栏站点信息社交图标</p></td>
      </tr>
	  <tr>
        <td width="20%"  align="center">底部社交图标</td>
        <td>
          <p align="left"><textarea name="botico" type="text" id="botico" style="width:98%;"><?php echo htmlspecialchars($zbp->Config('Jz52_newthree')->botico);?></textarea></p>
		</td>
		<td><p align="left">底部社交图标</p></td>
      </tr>
	</table>
	<br />
	<input name="submit" type="Submit" class="button" style="width:15%;" value="保存"/>
</form>
<?php } ?>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_newthree");
</script> 
<?php
if ($zbp->CheckPlugin('UEditor')) {	
	echo '<script type="text/javascript" src="'.$zbp->host.'zb_users/plugin/UEditor/ueditor.config.php"></script>';
	echo '<script type="text/javascript" src="'.$zbp->host.'zb_users/plugin/UEditor/ueditor.all.min.js"></script>';
	echo '<script type="text/javascript" src="'.$zbp->host.'zb_users/theme/Jz52_newthree/function/js/lib.upload.js"></script>';
	}
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
?>