{foreach $articles as $article}
<article class="media">
	{if $zbp->Config('Jz52_newthree')->listimg}
  <figure class="media-left"><a class="image" href="{$article.Url}"><img src="{$article.Img}" alt="{$article.Title}"></a></figure>
	{/if}
  <div class="media-content">
    <p class="date">
      <time>{$article.Time('Y-m-d')}</time>
    </p>
    <h3 class="title"><a href="{$article.Url}">{$article.Title}</a></h3>
  </div>
</article>
{/foreach}