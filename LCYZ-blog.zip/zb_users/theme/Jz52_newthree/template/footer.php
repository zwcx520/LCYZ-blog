{* Template Name:公用页脚模块 *}
<footer class="footer fadebox" id="footer">
  <div class="container">
    <div class="level">
      <div class="level-start"><a class="footer-logo is-block mb-2" href="{$host}"><img src="{$zbp->Config('Jz52_newthree')->logo}" alt="{$name}" height="28"></a>
		{Jz52_newthree_Footer()}
      </div>
      <div class="level-end">
        <div class="field has-addons">
		{$zbp->Config('Jz52_newthree')->botico}
        </div>
      </div>
    </div>
  </div>
</footer>
<a id="back-to-top" title="回到顶端" href="javascript:;"><i class="fas fa-chevron-up"></i></a>
<div class="searchbox">
<div class="searchbox-container">
<div class="searchbox-header">
<div class="searchbox-input-container">
<form action="{$host}search.php"  class="b-nav-search_wrap" target="_blank">
<input class="searchbox-input" type="search" name="q" placeholder="请输入关键字...">
</form>
</div>
<a class="searchbox-close" href="javascript:;">×</a></div>
<div class="searchbox-body">
  <section class="searchbox-result-section">
    <header>热门文章</header>
        {foreach $zbp->GetArticleList(array('*'),null,array('log_CommNums' => 'DESC'),array(6),null,true) as $related}
			<a class="searchbox-result-item" href="{$related.Url}"> <span class="searchbox-result-icon"> <i class="fa fa-file"></i> </span> <span class="searchbox-result-content"> <span class="searchbox-result-title">{$related.Category.Name}</span> <span class="searchbox-result-preview">{$related.Title}</span> </span> </a>
        {/foreach}
	</section>
	<section class="searchbox-result-section">
    <header>热门标签</header>
    	{foreach $zbp->GetTagList('','',array('tag_Count'=>'DESC'),array(6),'') as $stag}
			<a class="searchbox-result-item" href="{$stag.Url}"> <span class="searchbox-result-icon"> <i class="fa fa-tag"></i> </span> <span class="searchbox-result-content"> <span class="searchbox-result-title">{$stag.Name}<span class="searchbox-result-title-secondary"> {$stag->Count}篇文章 </span> </span> </span> </a>
		{/foreach}
	</section>
</div>
</div>
</div>
</body>
</html>