<?php echo'404';die();?>
{* Template Name:分页 *}
{if $pagebar}
{foreach $pagebar.buttons as $k=>$v}
{if $pagebar.PageNow==$k}
{elseif $k=='‹'}
 <div class="pagination-previous"><a href="{$v}">前一页</a></div>
{elseif $k=='›'}
 <div class="pagination-next"><a href="{$v}">后一页</a></div>
{/if}
{/foreach}
<ul class="pagination-list is-hidden-mobile">
{foreach $pagebar.buttons as $k=>$v}
{if $pagebar.PageNow==$k}
 <li class="pagination-link is-current" ><b>{$k}</b></li>
{elseif $k=='‹‹' and $pagebar.PageNow!=$pagebar.PageFirst}
{elseif $k=='‹‹' and $pagebar.PageNow==$pagebar.PageFirst}
{elseif $k=='››' and $pagebar.PageNow==$pagebar.PageLast}
{elseif $k=='››' and $pagebar.PageNow!=$pagebar.PageLast}
{elseif $k=='‹'}
{elseif $k=='›'}
{else}
 <li  class="pagination-link" ><a href="{$v}">{$k}</a></li> {/if}
{/foreach}
</ul>
{/if} 