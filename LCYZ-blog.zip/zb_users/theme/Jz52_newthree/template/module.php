{* Template Name:单个模块 *}

<div class="card widget"  id="{$module.HtmlID}">
  <div class="card-content">
    <div class="menu">
      {if (!$module.IsHideTitle)&&($module.Name)}<h3 class="menu-label">{$module.Name}</h3>{else}<h3></h3>{/if}
	  
{if $module.Type=='div'}
<div class="field is-grouped is-grouped-multiline">{$module.Content}</div>
{/if}
{if $module.Type=='ul'}
<ul class="menu-list">{$module.Content}</ul>
{/if}

	  
    </div>
  </div>
</div>