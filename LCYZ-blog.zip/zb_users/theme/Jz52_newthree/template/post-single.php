{* Template Name:文章模板 *}
<section class="section">
  <div class="container">
    <div class="columns">
      <div class="column order-2 column-main is-8-tablet is-8-desktop is-8-widescreen">
        <div class="card">
          <article class="card-content article">
            <div class="article-meta is-size-7 is-uppercase level is-mobile">
              <div class="level-left"><span class="level-item">{$article.Author.StaticName} 于 {$article.Time('Y-m-d')} 发表在&nbsp;<a href="{$article.Category.Url}">{$article.Category.Name}</a></span> <span class="level-item">大约{iconv_strlen(trim(Transferhtml($article->Content,'[nohtml]')), 'utf-8')}个字</span></div>
            </div>
            <h1 class="title is-3 is-size-4-mobile">{$article.Title}</h1>
            <div class="content">
             {$article.Content}
			</div>
			{if count($article.Tags)}
            <div class="article-tags is-size-7 mb-4">
			<span class="mr-2">#</span>
			{foreach $article.Tags as $tag}<a href="{$tag.Url}"  class="link-muted mr-2"  target="_blank">{$tag.Name}</a>{/foreach}
			</div>
			{/if} 
            <div class="sharethis-inline-share-buttons"></div>
          </article>
        </div>
        <nav class="post-navigation mt-4 level is-mobile prne">
		{if $article.Prev}
          <div class="level-start"><a class="article-nav-prev level level-item link-muted" href="{$article.Prev.Url}"><i class="level-item fas fa-chevron-left"></i><span class="level-item">{$article.Prev.Title}</span></a></div>
		  {/if}
		  {if $article.Next}
          <div class="level-end"><a class="article-nav-next level level-item link-muted" href="{$article.Next.Url}"><span class="level-item">{$article.Next.Title}</span><i class="level-item fas fa-chevron-right"></i></a></div>
		  {/if} 
        </nav>
		{if !$article.IsLock}
		 <div class="card comments">
          <article class="card-content article">
          {template:comments} 
          </article>
        </div>
		{/if}
		</div>
      <div class="column column-left is-4-tablet is-4-desktop is-4-widescreen  order-1 is-sticky">
		{template:lm-sidebaravatar}
		{template:sidebar3}
      </div>
	</div>
  </div>
</section>