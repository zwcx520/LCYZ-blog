{* Template Name:评论提交模块 *}
<div id="divCommentPost" class="comment-respond">
	<h3 id="reply-title" class="comment-reply-title">{if $user.ID>0}{$user.StaticName}{/if} 发表评论 <small><a rel="nofollow" id="cancel-reply" href="#divCommentPost" style="display:none;">取消回复</a></small></h3>
	<form class="comment-form" id="frmSumbit" target="_self" method="post" action="{$article.CommentPostUrl}" >
	<input type="hidden" name="inpId" id="inpId" value="{$article.ID}">
	<input type="hidden" name="inpRevID" id="inpRevID" value="0">
{if $user.ID>0}
	<input type="hidden" name="inpName" id="inpName" value="{$user.Name}">
	<input type="hidden" name="inpEmail" id="inpEmail" value="{$user.Email}">
	<input type="hidden" name="inpHomePage" id="inpHomePage" value="{$user.HomePage}">
{else}
	{if $option['ZC_COMMENT_VERIFY_ENABLE']}
	<p class="comment-form-author comment-form50">
        <input type="text" name="inpName" id="inpName" placeholder="昵称" value="" tabindex="1">
    </p>
	<p class="comment-form-email comment-form50">
        <input type="text" name="inpEmail" id="inpEmail" placeholder="邮箱" value="" tabindex="2">
    </p>
	<p class="comment-form-url comment-form50">
        <input type="url" name="inpHomePage" id="inpHomePage" placeholder="站点" value="" tabindex="3">
    </p>
	<p class="comment-form-code">
		<input type="text" name="inpVerify" id="inpVerify" value="" size="28" placeholder="验证码" tabindex="4">
		<img style="width:{$option['ZC_VERIFYCODE_WIDTH']}px;height:{$option['ZC_VERIFYCODE_HEIGHT']}px;cursor:pointer;" src="{$article.ValidCodeUrl}" alt="" title="" onclick="javascript:this.src='{$article.ValidCodeUrl}&amp;tm='+Math.random();">
	</p>
	{else}
	<p class="comment-form-author">
        <input type="text" name="inpName" id="inpName" placeholder="昵称" value="" tabindex="1">
    </p>
	<p class="comment-form-email">
        <input type="text" name="inpEmail" id="inpEmail" placeholder="邮箱" value="" tabindex="2">
    </p>
	<p class="comment-form-url">
        <input type="url" name="inpHomePage" id="inpHomePage" placeholder="站点" value="" tabindex="3">
    </p>
	{/if}
{/if}
	<textarea class="error" name="txaArticle" id="txaArticle" tabindex="5" placeholder="输入评论内容..." ></textarea>
	<div class="no-touch"></div>
	<p class="form-submit">
	<input name="sumbit" type="submit" tabindex="6" id="submit" class="submit" value="提交评论" onclick="return zbp.comment.post()" />
	</p>
	</form>
</div>