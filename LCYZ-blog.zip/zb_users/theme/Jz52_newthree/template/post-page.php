{* Template Name:页面模板 *}
<section class="section">
  <div class="container">
    <div class="columns">
      <div class="column order-2 column-main is-8-tablet is-8-desktop is-8-widescreen">
        <div class="card">
          <article class="card-content article">
            <h1 class="title is-3 is-size-4-mobile">{$article.Title}</h1>
            <div class="content">
             {$article.Content}
			</div>
            <div class="sharethis-inline-share-buttons"></div>
          </article>
        </div>
		{if !$article.IsLock}
		 <div class="card comments">
          <article class="card-content article">
          {template:comments} 
          </article>
        </div>
		{/if}
		</div>
      <div class="column column-left is-4-tablet is-4-desktop is-4-widescreen  order-1 is-sticky">
		{template:lm-sidebaravatar}
		{template:sidebar3}
      </div>
	</div>
  </div>
</section>