{* Template Name:评论模块 *}
{if $socialcomment}
{$socialcomment}
{else}
<h3 class="title is-3 is-size-4-mobile">{if $article.CommNums>0}{$article.CommNums} 条评论{else}暂无评论{/if}</h3>
<div class="comment-list">
<label id="AjaxCommentBegin"></label>
<!--评论输出-->
{foreach $comments as $key => $comment}
{template:comment}
{/foreach}
<!--评论翻页条输出-->
<div class="pagination">
{template:pagebar}
</div>
<label id="AjaxCommentEnd"></label>
</div>
<!--评论框-->
{template:commentpost}
{/if}