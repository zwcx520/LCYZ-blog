{foreach $tags as $tag}
<div class="control"><a class="tags has-addons" href="{$tag.Url}"><span class="tag">{$tag.Name}</span><span class="tag">{$tag.Count}</span></a></div>
{/foreach}