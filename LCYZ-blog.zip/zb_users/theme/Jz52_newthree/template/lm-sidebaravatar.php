<div class="card widget" data-type="profile">
          <div class="card-content">
            <nav class="level">
              <div class="level-item has-text-centered flex-shrink-1">
                <div>
                  <figure class="image is-128x128 mx-auto mb-2"><img class="avatar" src="{$zbp->Config('Jz52_newthree')->avatar}" alt="{$zbp->Config('Jz52_newthree')->celanh}"></figure>
                  <p class="title is-size-4 is-block" style="line-height:inherit;">{$zbp->Config('Jz52_newthree')->celanh}</p>
                  <p class="is-size-6 is-block">{$zbp->Config('Jz52_newthree')->celant}</p>
                </div>
              </div>
            </nav>
            <nav class="level is-mobile">
              <div class="level-item has-text-centered is-marginless">
                <div>
                  <p class="heading">文章</p>
                  <p class="title">{Jz52_newthree_all_artiles()}</p>
                </div>
              </div>
              <div class="level-item has-text-centered is-marginless">
                <div>
                  <p class="heading">分类</p>
                  <p class="title">{Jz52_newthree_all_categorys()}</p>
                </div>
              </div>
              <div class="level-item has-text-centered is-marginless">
                <div>
                  <p class="heading">标签</p>
                  <p class="title">{Jz52_newthree_all_tags()}</p>
                </div>
              </div>
            </nav>
            <div class="level"><a class="level-item button is-primary is-rounded" href="{$zbp->Config('Jz52_newthree')->celanbutu}" target="_blank" rel="noopener">{$zbp->Config('Jz52_newthree')->celanbut}</a></div>
            <div class="level is-mobile">
			{$zbp->Config('Jz52_newthree')->celanico}
			</div>
          </div>
        </div>