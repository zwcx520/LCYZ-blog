{* Template Name:首页列表模板 *}
{template:header}
<section class="section fadebox">
  <div class="container">
    <div class="columns">
      <div class="column order-2 column-main is-8-tablet is-8-desktop is-6-widescreen">
      {foreach $articles as $article}
      {if $article.IsTop}
		<div class="card">
		  {if $zbp->Config('Jz52_newthree')->listimg}
          <div class="card-image"><a class="image is-7by3" href="{$article.Url}">
		  <img class="fill" src="{$article.Img}" alt="{$article.Title}">
		  </a></div>
		  {/if}
          <article class="card-content article">
            <div class="article-meta is-size-7 is-uppercase level is-mobile">
              <div class="level-left"><span class="level-item">{$article.Author.StaticName} 于 {$article.Time('Y-m-d')} 发表在&nbsp;<a href="{$article.Category.Url}">{$article.Category.Name}</a></span><span class="level-item">大约{iconv_strlen(trim(Transferhtml($article->Content,'[nohtml]')), 'utf-8')}个字</span></div>
            </div>
            <h2 class="title is-3 is-size-4-mobile"><a class="link-muted" href="{$article.Url}">[顶]{$article.Title}</a></h2>
            <div class="content">
              <p>{php}$description = preg_replace('/[\r\n\s)]|(\s|\&nbsp\;|　|\xc2\xa0)+/', ' ', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),128)).'...');{/php}{$description}</p>
            </div>
            <a class="article-more button is-small is-size-7" href="{$article.Url}">查看详情</a></article>
        </div>
      {else}
		<div class="card">
		  {if $zbp->Config('Jz52_newthree')->listimg}
          <div class="card-image"><a class="image is-7by3" href="{$article.Url}">
		  <img class="fill" src="{$article.Img}" alt="{$article.Title}">
		  </a></div>
		  {/if}
          <article class="card-content article">
            <div class="article-meta is-size-7 is-uppercase level is-mobile">
              <div class="level-left"><span class="level-item">{$article.Author.StaticName} 于 {$article.Time('Y-m-d')} 发表在&nbsp;<a href="{$article.Category.Url}">{$article.Category.Name}</a></span><span class="level-item">大约{iconv_strlen(trim(Transferhtml($article->Content,'[nohtml]')), 'utf-8')}个字</span></div>
            </div>
            <h2 class="title is-3 is-size-4-mobile"><a class="link-muted" href="{$article.Url}">{$article.Title}</a></h2>
            <div class="content">
              <p>{php}$description = preg_replace('/[\r\n\s)]|(\s|\&nbsp\;|　|\xc2\xa0)+/', ' ', trim(SubStrUTF8(TransferHTML($article->Intro,'[nohtml]'),128)).'...');{/php}{$description}</p>
            </div>
            <a class="article-more button is-small is-size-7" href="{$article.Url}">查看详情</a></article>
        </div>
      {/if}
      {/foreach}
        <nav class="pagination">
		  {template:pagebar}
        </nav>
      </div>
      <div class="column column-left is-4-tablet is-4-desktop is-3-widescreen  order-1">
		{template:lm-sidebaravatar}
		{template:sidebar}
        <div class="column-right-shadow is-hidden-widescreen"></div>
      </div>
      <div class="column column-right is-4-tablet is-4-desktop is-3-widescreen is-hidden-touch is-hidden-desktop-only order-3">
		{template:sidebar2}
      </div>
    </div>
  </div>
</section>
{template:footer}