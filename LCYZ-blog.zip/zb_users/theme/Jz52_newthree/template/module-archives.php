{if $style==1}
<select id="slArchives" onchange="window.location=this.options[this.selectedIndex].value">
{foreach $urls as $url}
<option value="{$url.Url}">{$url.Name} ({$url.Count})</option>
{/foreach}
</select>
{else}
{foreach $urls as $url}
<li><a class="level is-mobile" href="{$url.Url}"><span class="level-start"><span class="level-item">{$url.Name}</span></span><span class="level-end"><span class="level-item tag">{$url.Count}</span></span></a></li>
{/foreach}
{/if}
