{* Template Name:公用头部模块 *}
<!doctype html>
<html lang="{$language}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
<title>{$name}-{$title}</title>
<meta name="generator" content="{$zblogphp} Themes: Yeelz.Com">
<link rel="stylesheet" href="{$host}zb_users/theme/{$theme}/style/style.css">
<script src="{$host}zb_system/script/jquery-2.2.4.min.js"></script> 
<script src="{$host}zb_system/script/zblogphp.js"></script> 
<script src="{$host}zb_system/script/c_html_js_add.php"></script>
<script src="{$host}zb_users/theme/{$theme}/script/custom.js"></script>
{$header}
{if $type=='index'&&$page=='1'}
<link rel="alternate" type="application/rss+xml" href="{$feedurl}" title="{$name}">
{/if}
</head>
<body class="{if $type=='article'}is-2-column{else}is-3-column{/if}">
<nav class="navbar navbar-main">
  <div class="container fadebox">
    <div class="navbar-brand justify-content-center"><a class="navbar-item navbar-logo" href="{$host}"><img src="{$zbp->Config('Jz52_newthree')->logo}" alt="{$name}" height="28"></a></div>
    <div class="navbar-menu">
      <ul class="navbar-start">
	  {module:navbar}
	  </ul>
      <div class="navbar-end">
	  <a class="navbar-item search" title="Search" href="javascript:;"><i class="fas fa-search"></i></a></div>
    </div>
  </div>
</nav>