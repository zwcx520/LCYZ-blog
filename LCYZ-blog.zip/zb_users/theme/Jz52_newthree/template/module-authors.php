{foreach $authors as $author}
<li><a class="level is-mobile" href="{$author->Url}"><span class="level-start"><span class="level-item">{$author->Name}</span></span><span class="level-end"><span class="level-item tag">{$author->Articles}</span></span></a></li>
{/foreach}