<?php
#注册插件
RegisterPlugin("Jz52_newthree","ActivePlugin_Jz52_newthree");
function ActivePlugin_Jz52_newthree() {
	global $zbp;
	Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Jz52_newthree_AddMenu');
	Add_Filter_Plugin('Filter_Plugin_Post_Get', 'Jz52_newthree_Post_Get');
}
function Jz52_newthree_AddMenu(&$m) {
	global $zbp;
	$m[] = MakeTopMenu("root", '主题配置', $zbp->host . "zb_users/theme/Jz52_newthree/main.php?act=config", "", "topmenu_Jz52_newthree", "icon-x-diamond-fill");
} 			     
function Jz52_newthree_SubMenu($id){
	$arySubMenu = array(
		0 => array('基本设置', 'config', 'left', false),
		1 => array('其他', 'other', 'left', false),
	);
	foreach($arySubMenu as $k => $v){
		echo '<a href="?act='.$v[1].'" '.($v[3]==true?'target="_blank"':'').'><span class="m-'.$v[2].' '.($id==$v[1]?'m-now':'').'">'.$v[0].'</span></a>';
	}
}

#底部版权 前台
function Jz52_newthree_Footer(){
	global $zbp;
	echo '<p class="is-size-7">';
	echo $zbp->option['ZC_BLOG_COPYRIGHT'];
	echo ' Powered: <a href="http://www.zblogcn.com/" target="_blank">Z-BlogPHP</a> Themes: <a href="https://gebilaoli.com" target="_blank">GeBiLaoLi</a> &amp; <a href="https://github.com/ppoffice/hexo-theme-icarus" target="_blank" >Icarus</a>';
	echo '</p>';
}
#列表图片
function Jz52_newthree_Post_Get(&$post, $method) {
	global $zbp;
	$temp=mt_rand(1,3);
	if ($method !== 'Img') return;

	if ($post->ImageCount) {
		$temp = $post->AllImages[0];
	} else {
		$temp = $zbp->host.'zb_users/theme/Jz52_newthree/style/img/'.$temp.'.svg';
	}
	$GLOBALS['hooks']['Filter_Plugin_Post_Get']['Jz52_newthree_Post_Get'] = PLUGIN_EXITSIGNAL_RETURN;
	return $temp;
}
/**
 * 站点信息
 */
#文章总数
function Jz52_newthree_all_artiles() {
    global $zbp;
	$all_artiles = GetValueInArrayByCurrent($zbp->db->Query('SELECT COUNT(*) AS num FROM ' . $GLOBALS['table']['Post'] . ' WHERE log_Type=\'0\''), 'num');
	return $all_artiles;
}
#分类总数
function Jz52_newthree_all_categorys() {
    global $zbp;
	$all_categorys = GetValueInArrayByCurrent($zbp->db->Query('SELECT COUNT(*) AS num FROM ' . $GLOBALS['table']['Category']), 'num');
	return $all_categorys;
}
#标签总数
function Jz52_newthree_all_tags() {
    global $zbp;
	$all_tags = GetValueInArrayByCurrent($zbp->db->Query('SELECT COUNT(*) as num FROM ' . $GLOBALS['table']['Tag']), 'num');
	return $all_tags;
}
#评论总数
function Jz52_newthree_all_comments() {
    global $zbp;
	$all_comments = $zbp->cache->all_comment_nums;
	return $all_comments;
}
// 重建模块
function Jz52_newthree_Build() {
    global $zbp;
	$zbp->BuildTemplate();
	$mod = $zbp->modulesbyfilename["tags"];
	$mod->Type = "div";
	$mod->Build();
	$mod->Save();
	$mod = $zbp->modulesbyfilename["previous"];
	$mod->Type = "div";
	$mod->Build();
	$mod->Save();
	$zbp->LoadCategories();
	$zbp->AddBuildModule("previous");
	$zbp->AddBuildModule("navbar");
	$zbp->AddBuildModule("tags");
	$zbp->BuildModule();
}
// 恢复模块
function Jz52_newthree_BuildHF() {
	global $zbp;
    $mod = $zbp->modulesbyfilename["tags"];
	$mod->Type = "ul";
	$mod->Build();
	$mod->Save();
	$mod = $zbp->modulesbyfilename["previous"];
	$mod->Type = "ul";
	$mod->Build();
	$mod->Save();
}

function InstallPlugin_Jz52_newthree() {
	global $zbp;
	Jz52_newthree_Build();
	if(!$zbp->HasConfig('Jz52_newthree')){
		$zbp->Config('Jz52_newthree')->Version = '1.0.7';
		$zbp->Config('Jz52_newthree')->logo = $zbp->host.'zb_users/theme/Jz52_newthree/style/img/logo.svg';
		$zbp->Config('Jz52_newthree')->nlogo = $zbp->host.'zb_users/theme/Jz52_newthree/style/img/logo.svg';
		$zbp->Config('Jz52_newthree')->avatar = $zbp->host.'zb_users/theme/Jz52_newthree/style/img/avatar.png';
		$zbp->Config('Jz52_newthree')->celanh = '隔壁老李';
		$zbp->Config('Jz52_newthree')->celant = '我住隔壁我姓李';
		$zbp->Config('Jz52_newthree')->celanbut = '关注我';
		$zbp->Config('Jz52_newthree')->celanbutu = '#';
		$zbp->Config('Jz52_newthree')->celanico = '<a class="level-item button is-transparent is-marginless" target="_blank" href="#"><i class="fab fa-qq"></i></a>
<a class="level-item button is-transparent is-marginless" target="_blank" href="#"><i class="fab fa-weixin"></i></a>
<a class="level-item button is-transparent is-marginless" target="_blank" href="#"><i class="fab fa-weibo"></i></a>
<a class="level-item button is-transparent is-marginless" target="_blank" href="#"><i class="fab fa-github"></i></a>
<a class="level-item button is-transparent is-marginless" target="_blank" href="#"><i class="fas fa-rss"></i></a>';
		$zbp->Config('Jz52_newthree')->botico = '<p class="control"><a class="button is-transparent is-large" target="_blank" href="#"><i class="fab fa-qq"></i></a></p>
<p class="control"><a class="button is-transparent is-large" target="_blank" href="#"><i class="fab fa-weixin"></i></a></p>
<p class="control"><a class="button is-transparent is-large" target="_blank" href="#"><i class="fab fa-weibo"></i></a></p>
<p class="control"><a class="button is-transparent is-large" target="_blank" href="#"><i class="fab fa-github"></i></a></p>';
		$zbp->SaveConfig('Jz52_newthree');
	}
}
function UninstallPlugin_Jz52_newthree() {
	global $zbp;
	Jz52_newthree_BuildHF();
}