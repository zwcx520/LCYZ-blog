{* Template Name:单条评论模板 *}
<li class="qs-comment-item{if $comment.AuthorID > 0 && $article.AuthorID > 0 && $comment.AuthorID == $article.AuthorID} is-owner{/if}" id="cmt{$comment.ID}">
  <div class="qs-comment-avatar">
    <img src="{$comment.Author.Avatar}" alt="{$comment.Author.StaticName}" loading="lazy">
  </div>
  <div class="qs-comment-main">
    <div class="qs-comment-meta">
      <span class="qs-comment-name">
        {if $comment.Author.HomePage}<a href="{$comment.Author.HomePage}" rel="nofollow" target="_blank">{$comment.Author.StaticName}</a>{else}{$comment.Author.StaticName}{/if}
      </span>
      <time class="qs-comment-time">{$comment.Time('Y-m-d H:i')}</time>
      <span class="qs-comment-floor">#{if $comment.FloorID > 0}{$comment.FloorID}{else}{$comment.ID}{/if}</span>
      <a class="qs-comment-reply" href="#comment" data-cmtid="{$comment.ID}" data-cmtname="{$comment.Author.StaticName}">回复</a>
    </div>
    {if $comment.ParentID > 0 && $comment.Parent}
    <div class="qs-comment-quote"><span>@{$comment.Parent.Author.StaticName}</span> {$comment.Parent.Content}</div>
    {/if}
    <div class="qs-comment-content">{$comment.Content}</div>
    {if $comment.Comments}
    <ul class="qs-comment-children">
      {foreach $comment.Comments as $comment}
      {template:comment}
      {/foreach}
    </ul>
    {/if}
  </div>
</li>
<label id="AjaxComment{$comment.ID}"></label>
