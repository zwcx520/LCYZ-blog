{* Template Name:首页及列表模板（首页/分类/标签/搜索/作者/日期） *}
{template:header}
{if $type=='index' && (empty($page) || $page=='1')}
<section class="qs-home-hero">
  <div class="qs-container">
    <h1 class="qs-hero-title">
      <span class="qs-hero-mark">
        <em>{if $zbp->Config('Jz52_qingshan')->hero_title}{$zbp->Config('Jz52_qingshan')->hero_title}{else}青山{/if}</em>
        {if $zbp->Config('Jz52_qingshan')->hero_poem}
        <small>{$zbp->Config('Jz52_qingshan')->hero_poem}</small>
        {else}
        <small>醉里青山日月亏<br />浮云老<br />照影共执杯</small>
        {/if}
      </span>
    </h1>
    {if $zbp->Config('Jz52_qingshan')->hero_summary}
    <p class="qs-hero-summary">{$zbp->Config('Jz52_qingshan')->hero_summary}</p>
    {/if}
  </div>
</section>
{/if}
<main class="qs-main">
  <div class="qs-container">
    {if $type=='category' || $type=='tag' || $type=='search' || $type=='author' || $type=='date'}
    <header class="qs-page-head">
      <p class="qs-page-kicker">
        {if $type=='category'}分类{elseif $type=='tag'}标签{elseif $type=='search'}搜索{elseif $type=='author'}作者{elseif $type=='date'}日期{/if}
        {if $page>'1'} · 第{$page}页{/if}
      </p>
      <h1>
        {if $type=='category'}{$category.Name}
        {elseif $type=='tag'}{$tag.Name}
        {elseif $type=='search'}搜索：{$search}
        {elseif $type=='author'}{$author.StaticName}
        {elseif $type=='date'}{$title}
        {/if}
      </h1>
      {if $type=='category' && $category.Intro}<p class="qs-page-desc">{$category.Intro}</p>{/if}
      {if $type=='tag' && $tag.Intro}<p class="qs-page-desc">{$tag.Intro}</p>{/if}
      {if $type=='search'}<p class="qs-page-desc">共找到与“{$search}”相关的内容</p>{/if}
    </header>
    {/if}
    <section class="qs-posts" id="qs-posts">
      <header class="qs-posts-header">
        <p class="qs-kicker">00 · 文章</p>
        {if isset($articles) && count($articles)>0}
        <p class="qs-posts-count">共 <strong>{if $type=='index'}{$zbp->cache->normal_article_nums}{elseif $type=='category'}{$category.Count}{elseif $type=='tag'}{$tag.Count}{else}{count($articles)}{/if}</strong> 篇</p>
        {/if}
      </header>
      {php}$GLOBALS['jz_qs_no'] = isset($page) && $page > 1 ? ($page - 1) * $zbp->option['ZC_DISPLAY_COUNT'] : 0;{/php}
      {if isset($articles) && count($articles)>0}
      <ul class="qs-post-list">
        {foreach $articles as $article}
        {php}$GLOBALS['jz_qs_no']++;{/php}
        {if $article.IsTop}{template:post-istop}{else}{template:post-multi}{/if}
        {/foreach}
      </ul>
      {else}
      <p class="qs-empty">尚无文章，静候落笔。</p>
      {/if}
      {template:pagebar}
    </section>
  </div>
</main>
{template:footer}
