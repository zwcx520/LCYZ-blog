{* Template Name:时光归档 * Template Type:page *}
{template:header}
{php}
$jzArch = Jz52_qingshan_ArchiveData();
$jzTotal = $jzArch['total'];
$jzYears = $jzArch['years'];
{/php}
<main class="qs-main">
  <div class="qs-container">
    <header class="qs-page-head">
      <p class="qs-page-kicker">archives · 归档</p>
      <h1>{$article.Title}</h1>
      <p class="qs-page-desc">共 {$jzTotal} 篇文章</p>
    </header>
    {foreach $jzYears as $jzYear => $jzMonths}
    <section class="qs-archive-year">
      <h2>{$jzYear}</h2>
      {foreach $jzMonths as $jzMonth => $jzArts}
      <h3>{$jzYear}-{$jzMonth}</h3>
      <ul class="qs-post-list">
        {foreach $jzArts as $jzA}
        <li class="qs-post-item qs-archive-item">
          <h3 class="qs-post-title"><a href="{$jzA['url']}">{$jzA['title']}</a></h3>
          <p class="qs-post-meta"><time datetime="{$jzA['date']}">{$jzA['date']}</time></p>
        </li>
        {/foreach}
      </ul>
      {/foreach}
    </section>
    {/foreach}
  </div>
</main>
{template:footer}
