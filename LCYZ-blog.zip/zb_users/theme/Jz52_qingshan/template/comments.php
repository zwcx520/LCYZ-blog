{* Template Name:评论模块 *}
<div class="qs-comment-card">
  <div class="qs-comment-head">
    <h3 class="qs-comment-title">评论 <span class="qs-comment-count">{$article.CommNums}</span></h3>
    <a rel="nofollow" id="cancel-reply" href="#comment" style="display:none;"><small>取消回复</small></a>
  </div>
  {if $article.CommNums > 0}
  <ul class="qs-comment-list" id="cmtlist">
    <label id="AjaxCommentBegin"></label>
    {foreach $comments as $comment}
    {template:comment}
    {/foreach}
    <label id="AjaxCommentEnd"></label>
  </ul>
  {else}
  <ul class="qs-comment-list" id="cmtlist">
    <label id="AjaxCommentBegin"></label>
    <label id="AjaxCommentEnd"></label>
  </ul>
  <p class="qs-comments-empty">还没有评论，静候知音。</p>
  {/if}
  {if isset($commentspagebar) && $commentspagebar}
  <div class="qs-comment-page">{template:pagebar}</div>
  {/if}
  {template:commentpost}
</div>
