{* Template Name:分页模板 *}
{if $pagebar}
<nav class="qs-pagination" aria-label="分页">
  {foreach $pagebar.buttons as $k=>$v}
  {if $pagebar.PageNow==$k}
  <span class="qs-page qs-page-current" aria-current="page">{$k}</span>
  {elseif $k=='‹‹' and $pagebar.PageNow!=$pagebar.PageFirst}
  <a class="qs-page" href="{$v}">首页</a>
  {elseif $k=='‹‹' and $pagebar.PageNow==$pagebar.PageFirst}
  <span class="qs-page qs-page-disabled">首页</span>
  {elseif $k=='››' and $pagebar.PageNow==$pagebar.PageLast}
  <span class="qs-page qs-page-disabled">尾页</span>
  {elseif $k=='››' and $pagebar.PageNow!=$pagebar.PageLast}
  <a class="qs-page" href="{$v}">尾页</a>
  {elseif $k=='‹'}
  <a class="qs-page qs-page-prev" href="{$v}">← 上一页</a>
  {elseif $k=='›'}
  <a class="qs-page qs-page-next" href="{$v}">下一页 →</a>
  {else}
  <a class="qs-page" href="{$v}">{$k}</a>
  {/if}
  {/foreach}
</nav>
{/if}
