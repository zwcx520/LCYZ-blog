{* Template Name:单页模板 *}
<main class="qs-main">
  <div class="qs-container">
    <article class="qs-article qs-page">
      <header class="qs-article-header">
        <h1 class="qs-article-title">{$article.Title}</h1>
        <p class="qs-post-meta qs-article-meta">
          <span class="qs-post-meta-item"><time datetime="{$article.Time('Y-m-d')}">{$article.Time('Y.m.d')}</time></span>
          <span class="qs-post-meta-item">阅读量 <span>{$article.ViewNums}</span></span>
        </p>
      </header>
      <div class="qs-article-content">{$article.Content}</div>
    </article>
    {if !$article.IsLock}
    <section class="qs-comments" id="comments">
      <p class="qs-kicker">评论</p>
      {template:comments}
    </section>
    {/if}
  </div>
</main>
