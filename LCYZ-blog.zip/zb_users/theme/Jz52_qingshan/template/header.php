{* Template Name:公用头部模块 *}
<!DOCTYPE html>
<html lang="{$language}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="{$zbp->Config('Jz52_qingshan')->background_color}">
{if $zbp->Config('Jz52_qingshan')->seo}{template:seo}{else}<title>{$name}{if $title != $name} - {$title}{/if}</title>{/if}
<meta name="generator" content="{$zblogphp}">
<link rel="stylesheet" href="{$host}zb_users/theme/{$theme}/style/lxgw-wenkai-lite-webfont/style.css" />
<link rel="stylesheet" href="{$host}zb_users/theme/{$theme}/style/style.css?v={$zbp->themeinfo['version']}">
<style>
:root{--qs-paper:{$zbp->Config('Jz52_qingshan')->background_color};--qs-accent:{$zbp->Config('Jz52_qingshan')->primary_color};}
{php}
$jzCfg = $zbp->Config('Jz52_qingshan');
$jzBgUrl = '';
if ($jzCfg->background_image) {
    $jzBgUrl = $jzCfg->background_image;
} elseif ($jzCfg->background_preset) {
    $jzBgFile = $zbp->path . 'zb_users/theme/' . $zbp->theme . '/style/images/bgs/' . $jzCfg->background_preset;
    if (is_file($jzBgFile)) {
        $jzBgUrl = $zbp->host . 'zb_users/theme/' . $zbp->theme . '/style/images/bgs/' . $jzCfg->background_preset;
    }
}
{/php}
{if $jzBgUrl}
.qs-home-hero{--qs-home-bg:url('{$jzBgUrl}');}
{/if}
</style>
<script src="{$host}zb_system/script/jquery-latest.min.js?v={$version}"></script>
<script src="{$host}zb_system/script/zblogphp.js?v={$version}"></script>
<script src="{$host}zb_system/script/c_html_js_add.php?v={$version}"></script>
{$header}
{if $type=='index' && isset($page) && $page=='1'}
<link rel="alternate" type="application/rss+xml" href="{$feedurl}" title="{$name}">
{/if}
</head>
<body class="qs-body is-{$type}">
{if $type=='article'}
<div class="qs-reading-progress" aria-hidden="true"><span></span></div>
{/if}
<header class="qs-header" id="qsHeader">
  <div class="qs-container qs-header-inner">
    <div class="qs-logo">
      {php}$jzLogoFile = $zbp->path . 'zb_users/theme/' . $zbp->theme . '/style/images/logo.png';{/php}
      {if $zbp->Config('Jz52_qingshan')->logo_type == '1' && file_exists($jzLogoFile)}
      <a href="{$host}" class="qs-logo-img" title="{$name}"><img src="{$host}zb_users/theme/{$theme}/style/images/logo.png?v={php}echo filemtime($jzLogoFile);{/php}" alt="{$name}"></a>
      {else}
      <a href="{$host}" title="{$name}">{if $type=='index' && isset($page) && $page=='1'}<h1>{$name}</h1>{else}{$name}{/if}</a>
      {/if}
    </div>
    <nav class="qs-nav" id="qsNav" aria-label="主导航">
      <button type="button" class="qs-nav-close" id="qsNavClose" aria-label="关闭菜单">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><line x1="6" y1="6" x2="18" y2="18"></line><line x1="18" y1="6" x2="6" y2="18"></line></svg>
      </button>
      <ul class="qs-nav-list" id="qsNavList">
        {module:navbar}
      </ul>
    </nav>
    <div class="qs-header-actions">
      <button type="button" class="qs-btn qs-search-toggle" id="qsSearchToggle" aria-label="搜索" aria-expanded="false">
        <svg class="qs-ico-search" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></svg>
        <svg class="qs-ico-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><line x1="6" y1="6" x2="18" y2="18"></line><line x1="18" y1="6" x2="6" y2="18"></line></svg>
      </button>
      <button type="button" class="qs-btn qs-menu-toggle" id="qsMenuToggle" aria-label="打开菜单" aria-expanded="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
      </button>
    </div>
  </div>
  <div class="qs-search-panel" id="qsSearchPanel" aria-hidden="true">
    <div class="qs-container">
      <form class="qs-search-form" role="search" method="get" action="{$host}search.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></svg>
        <input type="search" name="q" placeholder="搜索文章…" autocomplete="off" maxlength="256">
        <button type="submit">搜索</button>
      </form>
    </div>
  </div>
</header>
