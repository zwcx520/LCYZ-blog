{* Template Name:公用页脚模块 *}
<footer class="qs-footer">
  <div class="qs-container">
    {Jz52_qingshan_Footer()}
  </div>
</footer>
<a href="#" class="qs-back-top" id="qsBackTop" aria-label="回到顶部">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
</a>
<div class="qs-nav-mask" id="qsNavMask"></div>
<script src="{$host}zb_users/theme/{$theme}/script/qingshan.js?v={$zbp->themeinfo['version']}"></script>
{if $type=='article' || $type=='page'}
<script src="{$host}zb_users/theme/{$theme}/script/comments.js?v={$zbp->themeinfo['version']}"></script>
{/if}
{$footer}
</body>
</html>
