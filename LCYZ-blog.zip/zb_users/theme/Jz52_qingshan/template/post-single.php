{* Template Name:文章模板 *}
<main class="qs-main">
  <div class="qs-container">
    <div class="qs-article-layout">
      <article class="qs-article">
        <header class="qs-article-header">
          <p class="qs-article-kicker">
            <a href="{$host}">文章</a>
            <i aria-hidden="true">·</i>
            <a href="{$article.Category.Url}">{$article.Category.Name}</a>
          </p>
          <h1 class="qs-article-title">{$article.Title}</h1>
          <p class="qs-post-meta qs-article-meta">
            <span class="qs-post-meta-item"><time datetime="{$article.Time('Y-m-d')}">{$article.Time('Y.m.d')}</time></span>
            <span class="qs-post-meta-item">阅读量 <span>{$article.ViewNums}</span></span>
            {if $article.CommNums}<span class="qs-post-meta-item">评论 <span>{$article.CommNums}</span></span>{/if}
            <span class="qs-post-meta-item" data-reading-stats hidden></span>
            {if $article.Tags}
            <span class="qs-post-meta-tags">
              {foreach $article.Tags as $tag}
              <a class="qs-post-tag-badge" href="{$tag.Url}">#{$tag.Name}</a>
              {/foreach}
            </span>
            {/if}
          </p>
        </header>
        {php}$jzCover = Jz52_qingshan_thumb($article);{/php}
        {if $jzCover}
        <figure class="qs-article-cover"><img src="{$jzCover}" alt="{$article.Title}" decoding="async"></figure>
        {/if}
        <aside class="qs-article-toc" data-toc hidden>
          <details class="qs-article-toc-inner">
            <summary>目录</summary>
            <nav aria-label="文章目录"><ol data-toc-list></ol></nav>
          </details>
        </aside>
        <div class="qs-article-content">{$article.Content}</div>
        <p class="qs-article-end" aria-hidden="true"><span>完</span></p>
        <nav class="qs-post-nav" aria-label="上下篇">
          {if $article.Prev}
          <a class="qs-post-nav-item qs-post-nav-prev" href="{$article.Prev.Url}">
            <small>← 上一篇</small>
            <span>{$article.Prev.Title}</span>
          </a>
          {else}
          <span class="qs-post-nav-item qs-post-nav-empty"></span>
          {/if}
          {if $article.Next}
          <a class="qs-post-nav-item qs-post-nav-next" href="{$article.Next.Url}">
            <small>下一篇 →</small>
            <span>{$article.Next.Title}</span>
          </a>
          {else}
          <span class="qs-post-nav-item qs-post-nav-empty"></span>
          {/if}
        </nav>
      </article>
      {if !$article.IsLock}
      <section class="qs-comments" id="comments">
        <p class="qs-kicker">评论</p>
        {template:comments}
      </section>
      {/if}
    </div>
  </div>
</main>
