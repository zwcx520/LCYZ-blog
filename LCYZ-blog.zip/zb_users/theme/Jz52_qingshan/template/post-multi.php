{* Template Name:列表文章项 *}
{php}$jzCover = $zbp->Config('Jz52_qingshan')->listimg ? Jz52_qingshan_thumb($article) : '';{/php}
<li class="qs-post-item{if !$jzCover} qs-post-item-nocover{/if}">
  <p class="qs-post-index">{php}echo str_pad($GLOBALS['jz_qs_no'], 2, '0', STR_PAD_LEFT);{/php}</p>
  <div class="qs-post-body">
    <h3 class="qs-post-title">
      {if $article.IsTop}<span class="qs-post-pinned" title="置顶">顶</span>{/if}
      <a href="{$article.Url}">{$article.Title}</a>
    </h3>
    <p class="qs-post-meta">
      <span class="qs-post-meta-item qs-post-meta-date"><time datetime="{$article.Time('Y-m-d')}">{$article.Time('Y.m.d')}</time></span>
      <span class="qs-post-meta-item">阅读量 <span>{$article.ViewNums}</span></span>
      <span class="qs-post-meta-item qs-post-meta-cate"><a href="{$article.Category.Url}">{$article.Category.Name}</a></span>
      {if $article.Tags}
      <span class="qs-post-meta-tags">
        {foreach $article.Tags as $tag}
        <a class="qs-post-tag-badge" href="{$tag.Url}">#{$tag.Name}</a>
        {/foreach}
      </span>
      {/if}
    </p>
    {php}$jzExcerpt = trim(SubStrUTF8(TransferHTML($article->Intro, '[nohtml]'), 120));{/php}
    {if $jzExcerpt}<p class="qs-post-excerpt">{$jzExcerpt}</p>{/if}
    <a class="qs-post-more" href="{$article.Url}" aria-hidden="true" tabindex="-1">阅读全文</a>
  </div>
  {if $jzCover}
  <figure class="qs-post-cover">
    <a href="{$article.Url}"><img src="{$jzCover}" alt="{$article.Title}" loading="lazy" decoding="async"></a>
  </figure>
  {/if}
</li>
