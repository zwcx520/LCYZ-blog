{* Template Name:404模板 *}
{template:header}
<main class="qs-main">
  <div class="qs-container">
    <div class="qs-404">
      <p class="qs-404-code">404</p>
      <p class="qs-404-text">抱歉，你访问的页面不存在或已被移除。</p>
      <div class="qs-404-actions">
        <a class="qs-btn-primary" href="{$host}">返回首页</a>
        <button type="button" class="qs-btn-ghost" id="qsBack">返回上页</button>
      </div>
    </div>
  </div>
</main>
{template:footer}
