<?php
if (!defined('ZBP_PATH')) {exit('Access denied');}

RegisterPlugin("Jz52_qingshan", "ActivePlugin_Jz52_qingshan");

function ActivePlugin_Jz52_qingshan()
{
    global $zbp;
    $zbp->LoadLanguage('theme', 'Jz52_qingshan');
    Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Jz52_qingshan_AddMenu');
    if ($zbp->Config('Jz52_qingshan')->seo && $zbp->Config('Jz52_qingshan')->nseo) {
        Add_Filter_Plugin('Filter_Plugin_Edit_Response5', 'Jz52_qingshan_Filter_Plugin_Edit_Response5');
        Add_Filter_Plugin('Filter_Plugin_Category_Edit_Response', 'Jz52_qingshan_Category_Edit_Response');
    }
    # 时光归档缓存：发布/更新、删除文章时清除缓存文件
    Add_Filter_Plugin('Filter_Plugin_PostArticle_Succeed', 'Jz52_qingshan_ArchiveCacheClear');
    Add_Filter_Plugin('Filter_Plugin_DelArticle_Succeed', 'Jz52_qingshan_ArchiveCacheClear');
}

function Jz52_qingshan_AddMenu(&$m)
{
    global $zbp;
    $m[] = MakeTopMenu("root", $zbp->lang['Jz52_qingshan']['menu'], $zbp->host . "zb_users/theme/Jz52_qingshan/main.php?act=config", "", "topmenu_Jz52_qingshan", "icon-zblog");
}

function Jz52_qingshan_SubMenu($id)
{
    global $zbp;
    $L = $zbp->lang['Jz52_qingshan'];
    $arySubMenu = array(
        0 => array($L['t_config'], 'config', 'left', false),
        1 => array($L['t_home'], 'home', 'left', false),
        2 => array($L['t_style'], 'style', 'left', false),
        3 => array($L['t_seo'], 'seo', 'left', false),
        4 => array($L['t_about'], 'about', 'left', false),
    );
    foreach ($arySubMenu as $k => $v) {
        echo '<a href="?act=' . $v[1] . '" ' . ($v[3] == true ? 'target="_blank"' : '') . '><span class="m-' . $v[2] . ' ' . ($id == $v[1] ? 'm-now' : '') . '">' . $v[0] . '</span></a>';
    }
}

function Jz52_qingshan_Category_Edit_Response()
{
    global $zbp, $cate;
    $L = $zbp->lang['Jz52_qingshan'];
    echo '<p><span class="title">' . $L['cate_seo_title'] . '</span><br /><input style="width:95%" name="meta_flbt" value="' . htmlspecialchars($cate->Metas->flbt) . '"/></p>'
        . '<p><span class="title">' . $L['cate_seo_keywords'] . '</span><br /><input style="width:95%" name="meta_flgjc" value="' . htmlspecialchars($cate->Metas->flgjc) . '"/></p>';
}

function Jz52_qingshan_Filter_Plugin_Edit_Response5()
{
    global $zbp, $article;
    $L = $zbp->lang['Jz52_qingshan'];
    echo '<table width="99%"><tr><td width="20%">' . $L['post_seo_keywords'] . '</td><td width="80%"><input style="width:95%" name="meta_nrgjc" value="' . htmlspecialchars($article->Metas->nrgjc) . '"/></td></tr>'
        . '<tr><td>' . $L['post_seo_desc'] . '</td><td><input style="width:95%" name="meta_nrms" value="' . htmlspecialchars($article->Metas->nrms) . '"/></td></tr></table>';
}

function Jz52_qingshan_thumb($article)
{
    if ($article->ImageCount > 0) {
        $thumbs = $article->Thumbs(640, 400, 1, false);
        if (isset($thumbs[0]) && $thumbs[0]) {
            return $thumbs[0];
        }
    }
    return '';
}

function Jz52_qingshan_Footer()
{
    global $zbp;
    echo '<p class="qs-footer-copy">' . $zbp->option['ZC_BLOG_COPYRIGHT'];
    if ($zbp->Config('Jz52_qingshan')->beian) {
        echo ' · <a href="https://beian.miit.gov.cn/" rel="nofollow" target="_blank">' . $zbp->Config('Jz52_qingshan')->beian . '</a>';
    }
    echo '</p>';
    if ($zbp->Config('Jz52_qingshan')->footer) {
        echo '<p class="qs-footer-extra">' . $zbp->Config('Jz52_qingshan')->footer . '</p>';
    }
    echo '<p class="qs-footer-powered" id="footer">Powered by <a href="https://www.zblogcn.com/" target="_blank">Z-BlogPHP</a> · Theme <a href="https://app.zbp.cool/" title="不见桃花不见秋" target="_blank">GebiLaoli</a></p>';
}

# 时光归档数据（带文件缓存）：
# 返回 array('total' => 文章总数, 'years' => 年份倒序 => 月份倒序 => array('title','url','date'))
# 缓存于 zb_users/cache/Jz52_qingshan_archives.php，有效期 1 小时；
# 发布/更新/删除文章时由 hook 清除。
function Jz52_qingshan_ArchiveData()
{
    global $zbp;
    $cacheFile = $zbp->path . 'zb_users/cache/Jz52_qingshan_archives.php';
    if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < 3600) {
        include $cacheFile;
        if (isset($jzArchData) && is_array($jzArchData)) {
            return $jzArchData;
        }
    }
    $list = GetList(array('count' => 10000, 'post_type' => 'article', 'post_status' => 0));
    $data = array('total' => count($list), 'years' => array());
    foreach ($list as $a) {
        $data['years'][$a->Time('Y')][$a->Time('n')][] = array(
            'title' => $a->Title,
            'url' => $a->Url,
            'date' => $a->Time('Y-m-d'),
        );
    }
    # 年份、月份各自倒序（避免引用循环残留变量）
    $years = array_keys($data['years']);
    rsort($years);
    $sorted = array();
    foreach ($years as $y) {
        $months = array_keys($data['years'][$y]);
        rsort($months);
        $sorted[$y] = array();
        foreach ($months as $m) {
            $sorted[$y][$m] = $data['years'][$y][$m];
        }
    }
    $data['years'] = $sorted;
    $cache = '<?php if (!defined(\'ZBP_PATH\')) {exit(\'Access denied\');} $jzArchData = ' . var_export($data, true) . ';';
    @file_put_contents($cacheFile, $cache);
    return $data;
}

function Jz52_qingshan_ArchiveCacheClear()
{
    global $zbp;
    $cacheFile = $zbp->path . 'zb_users/cache/Jz52_qingshan_archives.php';
    if (is_file($cacheFile)) {
        @unlink($cacheFile);
    }
}

function InstallPlugin_Jz52_qingshan()
{
    global $zbp;
    $zbp->BuildTemplate();
    $tpath = $zbp->path . 'zb_users/theme/Jz52_qingshan/';
    $logo = $tpath . 'style/images/logo.png';
    $vlogo = $tpath . 'var/logo.png';
    if (!is_file($logo) && is_file($vlogo)) {
        @mkdir(dirname($logo), 0755, true);
        @copy($vlogo, $logo);
    }
    $bg = $tpath . 'style/images/background.png';
    $vbg = $tpath . 'var/background.png';
    if (!is_file($bg) && is_file($vbg)) {
        @mkdir(dirname($bg), 0755, true);
        @copy($vbg, $bg);
    }
    if (!$zbp->Config('Jz52_qingshan')->HasKey('Version')) {
        $zbp->Config('Jz52_qingshan')->Version = '1.0.0';
        $zbp->Config('Jz52_qingshan')->beian = '';
        $zbp->Config('Jz52_qingshan')->footer = '';
        $zbp->Config('Jz52_qingshan')->listimg = '1';
        $zbp->Config('Jz52_qingshan')->logo_type = '0';
        $zbp->Config('Jz52_qingshan')->hero_title = '青山';
        $zbp->Config('Jz52_qingshan')->hero_poem = "醉里青山日月亏\n浮云老\n照影共执杯";
        $zbp->Config('Jz52_qingshan')->hero_summary = '';
        $zbp->Config('Jz52_qingshan')->background_image = '';
        $zbp->Config('Jz52_qingshan')->background_preset = '0';
        $zbp->Config('Jz52_qingshan')->primary_color = '#5b8fa3';
        $zbp->Config('Jz52_qingshan')->background_color = '#f2f4f5';
        $zbp->Config('Jz52_qingshan')->seo = '0';
        $zbp->Config('Jz52_qingshan')->nseo = '0';
        $zbp->Config('Jz52_qingshan')->seotitle = '';
        $zbp->Config('Jz52_qingshan')->seokeywords = '';
        $zbp->Config('Jz52_qingshan')->seodescription = '';
        $zbp->Config('Jz52_qingshan')->DelConfig = '0';
        $zbp->SaveConfig('Jz52_qingshan');
    }
}

function UninstallPlugin_Jz52_qingshan()
{
    global $zbp;
    if ($zbp->Config('Jz52_qingshan')->DelConfig) {
        $zbp->DelConfig('Jz52_qingshan');
    }
}
