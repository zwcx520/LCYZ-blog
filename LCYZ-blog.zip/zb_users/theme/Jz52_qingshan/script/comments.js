(function ($) {
  'use strict';

  // 评论框移回评论区底部原位（占位 #qsCmtFormOrigin 处），取消回复按钮放回评论区头部
  function returnCommentForm() {
    var $form = $('#comment');
    var $mark = $('#qsCmtFormOrigin');
    if ($form.length && $mark.length) {
      $mark.before($form);
    }
    var $cancel = $('#cancel-reply');
    if ($cancel.length) {
      $cancel.appendTo('.qs-comment-head');
    }
  }

  function initReply() {
    // 点「回复」：把评论框抓到目标楼层内容之后、楼中楼列表之前，取消回复按钮跟随表单
    $(document).on('click', '.qs-comment-reply', function (e) {
      e.preventDefault();
      var id = $(this).data('cmtid');
      var $form = $('#comment');
      var $item = $('#cmt' + id);
      if (!$form.length || !$item.length) { return; }
      // 记录评论框原始位置（评论区底部），仅首次点击时建立占位
      if (!$('#qsCmtFormOrigin').length) {
        $form.before('<i id="qsCmtFormOrigin" style="display:none"></i>');
      }
      var $main = $item.find('.qs-comment-main');
      var $kids = $item.find('.qs-comment-children');
      if ($main.length) {
        if ($kids.length) {
          $kids.first().before($form);
        } else {
          $main.append($form);
        }
      } else {
        $item.after($form);
      }
      // 取消回复按钮跟随表单：移到表单提交行（发表评论按钮左侧）并显示
      $('#cancel-reply').insertBefore($form.find('.qs-btn-primary')).show();
      // 系统契约：设置 inpRevID（zbp.comment.reply 同时处理 hash）
      if (window.zbp && zbp.comment && zbp.comment.reply) {
        try { zbp.comment.reply(id); } catch (err) { /* ignore */ }
      }
      // 每次点击都确保滚动到表单并聚焦（避免相同 hash 重复点击不滚动）
      $('html, body').stop(true).animate({ scrollTop: $form.offset().top - $(window).height() * 0.35 }, 350);
      var $ta = $('#txaArticle');
      if ($ta.length) { setTimeout(function () { $ta.focus(); }, 600); }
    });

    // 取消回复：系统 useDefaultEvents=true 时 #cancel-reply 点击由系统处理，
    // 其内置处理 return false 阻断事件冒泡，document 委托监听不到；
    // 因此监听系统契约事件 comment.reply.cancel（点击取消时由系统发出）执行归位，
    // document 委托仅作系统未发出事件时的兜底。
    $(document).on('click', '#cancel-reply', function (e) {
      e.preventDefault();
      returnCommentForm();
      $('#cancel-reply').hide();
      $('#inpRevID').val('0');
    });
    if (window.zbp && zbp.plugin && zbp.plugin.on) {
      zbp.plugin.on('comment.reply.cancel', 'qingshan', function () {
        returnCommentForm();
      });
    }

    // 提交成功：评论框回归评论区底部原位（系统 zbp.comment.post 成功事件）
    if (window.zbp && zbp.plugin && zbp.plugin.on) {
      zbp.plugin.on('comment.post.success', 'qingshan', function () {
        returnCommentForm();
        $('#cancel-reply').hide();
        $('#inpRevID').val('0');
      });
    }
  }

  $(function () {
    initReply();
  });
})(jQuery);
