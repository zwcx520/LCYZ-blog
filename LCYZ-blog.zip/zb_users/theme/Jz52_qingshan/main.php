<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action = 'root';
if (!$zbp->CheckRights($action)) {
    $zbp->ShowError(6);
    die();
}
if (!$zbp->CheckPlugin('Jz52_qingshan')) {
    $zbp->ShowError(48);
    die();
}

$L = &$zbp->lang['Jz52_qingshan'];

$blogtitle = $L['menu'];
$act = 'config';
if (isset($_GET['act']) && $_GET['act'] != '') {
    $act = $_GET['act'];
}
if (!in_array($act, array('config', 'home', 'style', 'seo', 'about'))) {
    $act = 'config';
}

# 中国传统色一键配色预设：主色（点睛）/ 背景色（宣纸）
$jzPresets = array(
    $L['p1'] => array('#5b8fa3', '#f2f4f5'),
    $L['p2'] => array('#425066', '#f3efe6'),
    $L['p3'] => array('#789262', '#f2f4ec'),
    $L['p4'] => array('#9d4e4a', '#f7f0ea'),
    $L['p5'] => array('#955539', '#f5efe4'),
    $L['p6'] => array('#9e6b8d', '#f7f2f5'),
);

# 首页预置水墨背景图（style/images/bgs/ 下文件名 => 语言包名称键）
$jzBgPresets = array(
    'bg-1.jpg' => $L['bg_1'],
    'bg-2.jpg' => $L['bg_2'],
    'bg-3.jpg' => $L['bg_3'],
    'bg-4.jpg' => $L['bg_4'],
);

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<style>
.jz-cfg .jz-tip { background: #eff6f8; border: 1px solid #cfe2ea; color: #3a6a7d; padding: 10px 14px; margin: 14px 0; line-height: 1.8; }
.jz-cfg .jz-tip a { color: #2f5b6e; text-decoration: underline; }
.jz-cfg table td { padding: 10px 8px; vertical-align: top; }
.jz-cfg table th { background: #f7f8fa; padding: 10px 8px; }
.jz-cfg .jz-desc { color: #888; font-size: 12px; line-height: 1.7; }
.jz-cfg input[type="text"], .jz-cfg textarea, .jz-cfg select { width: 95%; max-width: 560px; }
.jz-cfg input[type="radio"] { margin-right: 4px; }
.jz-cfg .jz-presets { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin: 0 0 16px; }
.jz-cfg .jz-presets-t { font-size: 13px; color: #78909c; }
.jz-cfg .jz-chip { display: inline-flex; align-items: center; gap: 6px; padding: 5px 12px; border: 1px solid #d8e2e6; border-radius: 999px; background: #fff; cursor: pointer; font-size: 13px; color: #334; line-height: 1.6; transition: all .15s; }
.jz-cfg .jz-chip:hover { border-color: #5b8fa3; color: #3a6a7d; box-shadow: 0 2px 8px rgba(91, 143, 163, .2); }
.jz-cfg .jz-chip i { position: relative; display: inline-block; width: 18px; height: 18px; border-radius: 50%; border: 1px solid rgba(0, 0, 0, .1); }
.jz-cfg .jz-chip i b { position: absolute; right: -3px; bottom: -3px; width: 10px; height: 10px; border-radius: 50%; border: 2px solid #fff; }
</style>
<div id="divMain">
    <div class="divHeader"><?php echo $blogtitle; ?></div>
    <div class="SubMenu"><?php Jz52_qingshan_SubMenu($act); ?><a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc"><span class="m-right"><?php echo $L['more_apps']; ?></span></a>
  <a href="https://gebilaoli.com" target="_blank"><span class="m-right"><?php echo $L['author_site']; ?></span></a></div>
    <div id="divMain2">
        <div class="jz-cfg">
            <?php if ($act == 'config') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_qingshan');
                $cfg->beian = trim((string) $_POST['beian']);
                $cfg->footer = trim((string) $_POST['footer']);
                $cfg->listimg = isset($_POST['listimg']) && $_POST['listimg'] == '1' ? '1' : '0';
                $cfg->logo_type = isset($_POST['logo_type']) && $_POST['logo_type'] == '1' ? '1' : '0';
                $cfg->DelConfig = isset($_POST['DelConfig']) && $_POST['DelConfig'] == '1' ? '1' : '0';
                $jzLogoFile = $zbp->path . 'zb_users/theme/Jz52_qingshan/style/images/logo.png';
                if (isset($_FILES['logo']) && $_FILES['logo']['error'] === 0 && is_uploaded_file($_FILES['logo']['tmp_name'])) {
                    $jzExt = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
                    if (in_array($jzExt, array('png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'))) {
                        @move_uploaded_file($_FILES['logo']['tmp_name'], $jzLogoFile);
                    }
                }
                $zbp->SaveConfig('Jz52_qingshan');
                $zbp->SetHint('good');
                Redirect('./main.php?act=config');
            }
            $cfg = $zbp->Config('Jz52_qingshan');
            ?>
            <div class="jz-tip"><?php echo str_replace('{version}', htmlspecialchars($zbp->themeinfo['version']), $L['tip_config']); ?></div>
            <form id="form1" name="form1" method="post" action="" enctype="multipart/form-data">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center"><?php echo $L['th_name']; ?></p></th><th width="50%"><p align="center"><?php echo $L['th_content']; ?></p></th><th width="28%"><p align="center"><?php echo $L['th_desc']; ?></p></th></tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_logo']; ?></p></td>
                        <td><p><?php ZbpForm::radio('logo_type', array($L['txt'], $L['img']), (int) $cfg->logo_type); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_logo_type']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_upload_logo']; ?></p></td>
                        <td><p><input type="file" name="logo" size="30" />&nbsp;&nbsp;<?php if (file_exists($zbp->path . 'zb_users/theme/Jz52_qingshan/style/images/logo.png')) { ?><img src="style/images/logo.png?time=<?php echo time(); ?>" alt="logo" style="max-height:30px;vertical-align:middle;border:1px solid #e4e9ea;" /><?php } else { ?><span class="jz-desc"><?php echo $L['no_logo']; ?></span><?php } ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_upload_logo']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_listimg']; ?></p></td>
                        <td><p><?php ZbpForm::radio('listimg', array($L['no'], $L['yes']), (int) $cfg->listimg); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_listimg']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_beian']; ?></p></td>
                        <td><p><?php ZbpForm::text('beian', htmlspecialchars($cfg->beian), '95%', $L['ph_beian']); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_beian']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_footer']; ?></p></td>
                        <td><p><?php ZbpForm::textarea('footer', htmlspecialchars($cfg->footer), '95%', '80px', $L['ph_footer']); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_footer']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_delcfg']; ?></p></td>
                        <td><p><?php ZbpForm::radio('DelConfig', array($L['no'], $L['yes']), (int) $cfg->DelConfig); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_delcfg']; ?></p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="<?php echo $L['btn_save']; ?>"/>
            </form>
            <?php } ?>

            <?php if ($act == 'home') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_qingshan');
                $cfg->hero_title = trim((string) $_POST['hero_title']);
                $cfg->hero_poem = trim((string) $_POST['hero_poem']);
                $cfg->hero_summary = trim((string) $_POST['hero_summary']);
                $cfg->background_image = trim((string) $_POST['background_image']);
                $jzBgPreset = isset($_POST['background_preset']) ? trim((string) $_POST['background_preset']) : '0';
                $cfg->background_preset = ($jzBgPreset === '0' || in_array($jzBgPreset, array_keys($jzBgPresets))) ? $jzBgPreset : '0';
                $jzBgFile = $zbp->path . 'zb_users/theme/Jz52_qingshan/style/images/background.png';
                if (isset($_FILES['background']) && $_FILES['background']['error'] === 0 && is_uploaded_file($_FILES['background']['tmp_name'])) {
                    $jzExt = strtolower(pathinfo($_FILES['background']['name'], PATHINFO_EXTENSION));
                    if (in_array($jzExt, array('png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'))) {
                        @move_uploaded_file($_FILES['background']['tmp_name'], $jzBgFile);
                    }
                }
                $zbp->SaveConfig('Jz52_qingshan');
                $zbp->SetHint('good');
                Redirect('./main.php?act=home');
            }
            $cfg = $zbp->Config('Jz52_qingshan');
            ?>
            <div class="jz-tip"><?php echo $L['tip_home']; ?></div>
            <form id="form2" name="form2" method="post" action="" enctype="multipart/form-data">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center"><?php echo $L['th_name']; ?></p></th><th width="50%"><p align="center"><?php echo $L['th_content']; ?></p></th><th width="28%"><p align="center"><?php echo $L['th_desc']; ?></p></th></tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_bg']; ?></p></td>
                        <td><p><?php ZbpForm::text('background_image', htmlspecialchars($cfg->background_image), '95%', $L['ph_bg']); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_bg']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_upload_bg']; ?></p></td>
                        <td><p><input type="file" name="background" size="30" />&nbsp;&nbsp;<img src="style/images/background.png?time=<?php echo time(); ?>" alt="background" style="max-height:40px;vertical-align:middle;border:1px solid #e4e9ea;" /></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_upload_bg']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_bg_preset']; ?></p></td>
                        <td><p><?php ZbpForm::radio('background_preset', array('0' => $L['bg_default']) + $jzBgPresets, (string) $cfg->background_preset); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_bg_preset']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_hero_title']; ?></p></td>
                        <td><p><?php ZbpForm::text('hero_title', htmlspecialchars($cfg->hero_title), '95%', $L['ph_hero_title']); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_hero_title']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_hero_poem']; ?></p></td>
                        <td><p><?php ZbpForm::textarea('hero_poem', htmlspecialchars($cfg->hero_poem), '95%', '80px', $L['ph_hero_poem']); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_hero_poem']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_hero_summary']; ?></p></td>
                        <td><p><?php ZbpForm::textarea('hero_summary', htmlspecialchars($cfg->hero_summary), '95%', '60px', $L['ph_hero_summary']); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_hero_summary']; ?></p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="<?php echo $L['btn_save']; ?>"/>
            </form>
            <?php } ?>

            <?php if ($act == 'style') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_qingshan');
                $cfg->primary_color = trim((string) $_POST['primary_color']);
                $cfg->background_color = trim((string) $_POST['background_color']);
                $zbp->SaveConfig('Jz52_qingshan');
                $zbp->SetHint('good');
                Redirect('./main.php?act=style');
            }
            $cfg = $zbp->Config('Jz52_qingshan');
            ?>
            <div class="jz-tip"><?php echo $L['tip_style']; ?></div>
            <div class="jz-presets">
                <span class="jz-presets-t"><?php echo $L['presets_label']; ?></span>
                <?php foreach ($jzPresets as $jzName => $jzCol) { ?>
                <button type="button" class="jz-chip" data-primary="<?php echo $jzCol[0]; ?>" data-bg="<?php echo $jzCol[1]; ?>" title="<?php echo sprintf($L['chip_apply'], $jzName); ?>">
                    <i style="background:<?php echo $jzCol[1]; ?>"><b style="background:<?php echo $jzCol[0]; ?>"></b></i><?php echo $jzName; ?>
                </button>
                <?php } ?>
            </div>
            <form id="form3" name="form3" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center"><?php echo $L['th_name']; ?></p></th><th width="50%"><p align="center"><?php echo $L['th_content']; ?></p></th><th width="28%"><p align="center"><?php echo $L['th_desc']; ?></p></th></tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_primary']; ?></p></td>
                        <td><p><?php ZbpForm::text('primary_color', htmlspecialchars($cfg->primary_color), '20%', $L['ph_primary']); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_primary']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_bgcolor']; ?></p></td>
                        <td><p><?php ZbpForm::text('background_color', htmlspecialchars($cfg->background_color), '20%', $L['ph_bgcolor']); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_bgcolor']; ?></p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="<?php echo $L['btn_save']; ?>"/>
            </form>
            <?php } ?>

            <?php if ($act == 'seo') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_qingshan');
                $cfg->seo = isset($_POST['seo']) && $_POST['seo'] == '1' ? '1' : '0';
                $cfg->nseo = isset($_POST['nseo']) && $_POST['nseo'] == '1' ? '1' : '0';
                $cfg->seotitle = trim((string) $_POST['seotitle']);
                $cfg->seokeywords = trim((string) $_POST['seokeywords']);
                $cfg->seodescription = trim((string) $_POST['seodescription']);
                $zbp->SaveConfig('Jz52_qingshan');
                $zbp->SetHint('good');
                Redirect('./main.php?act=seo');
            }
            $cfg = $zbp->Config('Jz52_qingshan');
            ?>
            <div class="jz-tip"><?php echo $L['tip_seo']; ?></div>
            <form id="form4" name="form4" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center"><?php echo $L['th_name']; ?></p></th><th width="50%"><p align="center"><?php echo $L['th_content']; ?></p></th><th width="28%"><p align="center"><?php echo $L['th_desc']; ?></p></th></tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_seo']; ?></p></td>
                        <td><p><?php ZbpForm::radio('seo', array($L['no'], $L['yes']), (int) $cfg->seo); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_seo']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_nseo']; ?></p></td>
                        <td><p><?php ZbpForm::radio('nseo', array($L['no'], $L['yes']), (int) $cfg->nseo); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_nseo']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_seotitle']; ?></p></td>
                        <td><p><?php ZbpForm::text('seotitle', htmlspecialchars($cfg->seotitle), '95%', $L['ph_seotitle']); ?><?php if ($zbp->subname) { ?> <span class="jz-desc">- <?php echo htmlspecialchars($zbp->subname); ?></span><?php } ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_seotitle']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_seokw']; ?></p></td>
                        <td><p><?php ZbpForm::text('seokeywords', htmlspecialchars($cfg->seokeywords), '95%', $L['ph_seokw']); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_seokw']; ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p><?php echo $L['f_seodesc']; ?></p></td>
                        <td><p><?php ZbpForm::textarea('seodescription', htmlspecialchars($cfg->seodescription), '95%', '80px', $L['ph_seodesc']); ?></p></td>
                        <td><p class="jz-desc"><?php echo $L['d_seodesc']; ?></p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="<?php echo $L['btn_save']; ?>"/>
            </form>
            <?php } ?>

            <?php if ($act == 'about') { ?>
            <div class="jz-tip">
                <h3>「极致·青山」天青水墨个人博客主题</h3>
                <p>一款天青色系传统水墨风格博客主题，以宣纸留白、墨色层次与天青点睛为设计主线：</p>
                <p>首页水墨大图 + 题字诗词，均可在后台配置<br />
                文章列表序号、印章徽标、封面图与阅读全文<br />
                文章目录、阅读进度、字数统计<br />
                全响应式布局，内置基础 SEO<br />
				<b>原作：<a href="https://github.com/CirillaQL/halo-theme-gui" target="_blank">归</a></b></p>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_qingshan");
// 一键配色：填入色值并直接保存
jQuery('.jz-chip').on('click', function () {
    var $t = jQuery(this);
    jQuery('#primary_color').val($t.data('primary'));
    jQuery('#background_color').val($t.data('bg'));
    var fd = new FormData(document.getElementById('form3'));
    fd.append('submit', '<?php echo $L['btn_save']; ?>');
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, false);
    xhr.send(fd);
    location.reload();
});
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
