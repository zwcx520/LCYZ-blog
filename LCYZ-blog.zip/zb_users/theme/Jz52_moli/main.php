<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action = 'root';
if (!$zbp->CheckRights($action)) {
    $zbp->ShowError(6);
    die();
}
if (!$zbp->CheckPlugin('Jz52_moli')) {
    $zbp->ShowError(48);
    die();
}

$blogtitle = '主题配置';
$act = 'config';
if (isset($_GET['act']) && $_GET['act'] != '') {
    $act = $_GET['act'];
}
if (!in_array($act, array('config', 'home', 'style', 'seo', 'about'))) {
    $act = 'config';
}

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<style>
.jz-cfg .jz-tip { background: #f0f4ff; border: 1px solid #d6e0ff; color: #3a5fc8; padding: 10px 14px; margin: 14px 0; line-height: 1.8; }
.jz-cfg .jz-tip a { color: #2f54b8; text-decoration: underline; }
.jz-cfg table td { padding: 10px 8px; vertical-align: top; }
.jz-cfg table th { background: #f7f8fa; padding: 10px 8px; }
.jz-cfg .jz-desc { color: #888; font-size: 12px; line-height: 1.7; }
.jz-cfg input[type="text"], .jz-cfg textarea, .jz-cfg select { width: 95%; max-width: 560px; }
.jz-cfg input[type="radio"] { margin-right: 4px; }
</style>
<div id="divMain">
    <div class="divHeader"><?php echo $blogtitle; ?></div>
    <div class="SubMenu"><?php Jz52_moli_SubMenu($act); ?><a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc"><span class="m-right">更多应用</span></a>
  <a href="https://gebilaoli.com" target="_blank"><span class="m-right">作者网站</span></a></div>
    <div id="divMain2">
        <div class="jz-cfg">
            <?php if ($act == 'config') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_moli');
                $cfg->logo_text = trim((string) $_POST['logo_text']);
                $cfg->logo_image = trim((string) $_POST['logo_image']);
                $cfg->brand_sub = trim((string) $_POST['brand_sub']);
                $cfg->avatar = trim((string) $_POST['avatar']);
                $cfg->email = trim((string) $_POST['email']);
                $cfg->github = trim((string) $_POST['github']);
                $cfg->tagline = trim((string) $_POST['tagline']);
                $cfg->beian = trim((string) $_POST['beian']);
                $cfg->footer = trim((string) $_POST['footer']);
                $cfg->darkmode = (string) intval($_POST['darkmode']);
                $cfg->DelConfig = isset($_POST['DelConfig']) && $_POST['DelConfig'] == '1' ? '1' : '0';
                $zbp->SaveConfig('Jz52_moli');
                $zbp->SetHint('good');
                Redirect('./main.php?act=config');
            }
            $cfg = $zbp->Config('Jz52_moli');
            ?>
            <form id="form1" name="form1" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr>
                        <td align="center"><p>Logo 标题文字</p></td>
                        <td><p><?php ZbpForm::text('logo_text', htmlspecialchars($cfg->logo_text), '95%', ''); ?></p></td>
                        <td><p class="jz-desc">导航 Logo 名称，留空使用系统站点名称</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>Logo 图片</p></td>
                        <td><p><?php ZbpForm::text('logo_image', htmlspecialchars($cfg->logo_image), '95%', 'https://…'); ?></p></td>
                        <td><p class="jz-desc">导航 Logo 左侧图标图片 URL，留空使用主题默认叶片图标</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>品牌副标题</p></td>
                        <td><p><?php ZbpForm::text('brand_sub', htmlspecialchars($cfg->brand_sub), '95%', 'SOFTWARE · AI'); ?></p></td>
                        <td><p class="jz-desc">导航 Logo 名称下方的小字，建议英文短语</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>站长头像</p></td>
                        <td><p><?php ZbpForm::text('avatar', htmlspecialchars($cfg->avatar), '95%', 'https://…'); ?></p></td>
                        <td><p class="jz-desc">用于「关于我」页与文章作者信息条，留空使用山峰图标徽章</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>联系邮箱</p></td>
                        <td><p><?php ZbpForm::text('email', htmlspecialchars($cfg->email), '95%', 'you@example.com'); ?></p></td>
                        <td><p class="jz-desc">显示导航「联系我」按钮与页脚邮箱胶囊，留空不显示</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>GitHub 主页</p></td>
                        <td><p><?php ZbpForm::text('github', htmlspecialchars($cfg->github), '95%', 'https://github.com/…'); ?></p></td>
                        <td><p class="jz-desc">显示页脚 GitHub 胶囊，留空不显示</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>页脚标语</p></td>
                        <td><p><?php ZbpForm::text('tagline', htmlspecialchars($cfg->tagline), '95%', '写代码，也写思考。'); ?></p></td>
                        <td><p class="jz-desc">页脚站名下方的一句话标语</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>备案号</p></td>
                        <td><p><?php ZbpForm::text('beian', htmlspecialchars($cfg->beian), '95%', '鲁ICP备00000000号'); ?></p></td>
                        <td><p class="jz-desc">填写后页脚显示备案链接</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>页脚自定义内容</p></td>
                        <td><p><?php ZbpForm::textarea('footer', htmlspecialchars($cfg->footer), '95%', '60px', '纯文本或简单 HTML'); ?></p></td>
                        <td><p class="jz-desc">显示在页脚版权之前</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>默认配色</p></td>
                        <td><p><?php ZbpForm::select('darkmode', array('0' => '跟随用户切换（默认深色）', '1' => '强制深色', '2' => '强制浅色'), $cfg->darkmode); ?></p></td>
                        <td><p class="jz-desc">本主题原生为深色玻璃拟态，浅色为可选模式；「跟随用户切换」时访客可在页头按钮自行切换（Cookie 记住选择，服务端渲染无闪烁）</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>清除主题配置</p></td>
                        <td><p><?php ZbpForm::radio('DelConfig', array('否', '是'), (int) $cfg->DelConfig); ?></p></td>
                        <td><p class="jz-desc">启用后切换主题将清空主题配置</p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'home') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_moli');
                $cfg->hero_enable = isset($_POST['hero_enable']) && $_POST['hero_enable'] == '1' ? '1' : '0';
                $cfg->hero_eyebrow = trim((string) $_POST['hero_eyebrow']);
                $cfg->hero_title = trim((string) $_POST['hero_title']);
                $cfg->hero_subtitle = trim((string) $_POST['hero_subtitle']);
                $cfg->hero_image = trim((string) $_POST['hero_image']);
                $cfg->hero_cta_text = trim((string) $_POST['hero_cta_text']);
                $cfg->hero_cta_anchor = trim((string) $_POST['hero_cta_anchor']);
                $zbp->SaveConfig('Jz52_moli');
                $zbp->SetHint('good');
                Redirect('./main.php?act=home');
            }
            $cfg = $zbp->Config('Jz52_moli');
            ?>
            <form id="form2" name="form2" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr>
                        <td align="center"><p>显示 Hero 区域</p></td>
                        <td><p><?php ZbpForm::radio('hero_enable', array('否', '是'), (int) $cfg->hero_enable); ?></p></td>
                        <td><p class="jz-desc">关闭后首页直接显示文章列表</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>眉题</p></td>
                        <td><p><?php ZbpForm::text('hero_eyebrow', htmlspecialchars($cfg->hero_eyebrow), '95%', 'SOFTWARE & AI ENGINEER'); ?></p></td>
                        <td><p class="jz-desc">Hero 区上方斜体小字</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>主标题</p></td>
                        <td><p><?php ZbpForm::text('hero_title', htmlspecialchars($cfg->hero_title), '95%', '在代码与智能之间，造一片绿野'); ?></p></td>
                        <td><p class="jz-desc">Hero 区衬线大标题</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>副标题</p></td>
                        <td><p><?php ZbpForm::textarea('hero_subtitle', htmlspecialchars($cfg->hero_subtitle), '95%', '60px', '一句话介绍'); ?></p></td>
                        <td><p class="jz-desc">Hero 区说明文字</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>横幅图</p></td>
                        <td><p><?php ZbpForm::text('hero_image', htmlspecialchars($cfg->hero_image), '95%', 'https://…'); ?></p></td>
                        <td><p class="jz-desc">Hero 底部宽幅意象图，建议宽幅深色图片，留空不显示</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>主按钮文案</p></td>
                        <td><p><?php ZbpForm::text('hero_cta_text', htmlspecialchars($cfg->hero_cta_text), '95%', '看看我的文章'); ?></p></td>
                        <td><p class="jz-desc">留空则不显示主按钮</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>主按钮目标</p></td>
                        <td><p><?php ZbpForm::text('hero_cta_anchor', htmlspecialchars($cfg->hero_cta_anchor), '95%', '#posts'); ?></p></td>
                        <td><p class="jz-desc">页内锚点（如 #posts）或完整链接</p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'style') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_moli');
                $cfg->accent_color = trim((string) $_POST['accent_color']);
                $cfg->weather = isset($_POST['weather']) && $_POST['weather'] == '1' ? '1' : '0';
                $cfg->webfont = isset($_POST['webfont']) && $_POST['webfont'] == '1' ? '1' : '0';
                $zbp->SaveConfig('Jz52_moli');
                $zbp->SetHint('good');
                Redirect('./main.php?act=style');
            }
            $cfg = $zbp->Config('Jz52_moli');
            ?>
            <div class="jz-tip">外观相关设置。强调色会派生全站描边、光晕与选中色。</div>
            <form id="form3" name="form3" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr>
                        <td align="center"><p>主题强调色</p></td>
                        <td><p><?php ZbpForm::text('accent_color', htmlspecialchars($cfg->accent_color), '95%', '#3b9b66'); ?></p></td>
                        <td><p class="jz-desc">十六进制颜色，留空使用默认 #3b9b66</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>天气背景特效</p></td>
                        <td><p><?php ZbpForm::radio('weather', array('否', '是'), (int) $cfg->weather); ?></p></td>
                        <td><p class="jz-desc">导航栏显示晴 / 雨 / 雪切换按钮，Canvas 粒子背景，用户选择保存在浏览器本地</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>在线衬线字体</p></td>
                        <td><p><?php ZbpForm::radio('webfont', array('否', '是'), (int) $cfg->webfont); ?></p></td>
                        <td><p class="jz-desc">加载 Google Fonts（Noto Serif SC 等）。国内访问缓慢时关闭，自动回退系统字体（默认关闭）</p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'seo') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_moli');
                $cfg->seo = isset($_POST['seo']) && $_POST['seo'] == '1' ? '1' : '0';
                $cfg->nseo = isset($_POST['nseo']) && $_POST['nseo'] == '1' ? '1' : '0';
                $cfg->seotitle = trim((string) $_POST['seotitle']);
                $cfg->seokeywords = trim((string) $_POST['seokeywords']);
                $cfg->seodescription = trim((string) $_POST['seodescription']);
                $zbp->SaveConfig('Jz52_moli');
                $zbp->SetHint('good');
                Redirect('./main.php?act=seo');
            }
            $cfg = $zbp->Config('Jz52_moli');
            ?>
            <div class="jz-tip">主题自带基础 SEO：可为首页设置标题/关键词/描述，为文章和分类设置独立关键词与描述。若已安装独立 SEO 插件，请关闭以下开关避免冲突。</div>
            <form id="form4" name="form4" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr>
                        <td align="center"><p>启用主题 SEO</p></td>
                        <td><p><?php ZbpForm::radio('seo', array('否', '是'), (int) $cfg->seo); ?></p></td>
                        <td><p class="jz-desc">使用主题自带的标题、关键词、描述输出</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>文章/分类自定义 SEO</p></td>
                        <td><p><?php ZbpForm::radio('nseo', array('否', '是'), (int) $cfg->nseo); ?></p></td>
                        <td><p class="jz-desc">在文章编辑页与分类编辑页增加关键词、描述字段</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>首页标题</p></td>
                        <td><p><?php ZbpForm::text('seotitle', htmlspecialchars($cfg->seotitle), '95%', '留空则使用网站名称'); ?><?php if ($zbp->subname) { ?> <span class="jz-desc">- <?php echo htmlspecialchars($zbp->subname); ?></span><?php } ?></p></td>
                        <td><p class="jz-desc">留空则使用网站名称</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>首页关键词</p></td>
                        <td><p><?php ZbpForm::text('seokeywords', htmlspecialchars($cfg->seokeywords), '95%', '多个关键词用英文逗号隔开'); ?></p></td>
                        <td><p class="jz-desc">多个关键词用英文逗号隔开</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>首页描述</p></td>
                        <td><p><?php ZbpForm::textarea('seodescription', htmlspecialchars($cfg->seodescription), '95%', '60px', '一段话描述网站内容'); ?></p></td>
                        <td><p class="jz-desc">一段话描述网站内容</p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'about') { ?>
            <div class="jz-tip">主题信息与维护说明。归档与标签总览页使用文件缓存，数据变化时自动失效重建，无需手动清理。</div>
            <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                <tr><th width="22%"><p align="center">项目</p></th><th><p align="center">内容</p></th></tr>
                <tr><td><p>主题版本</p></td><td><p>v<?php echo htmlspecialchars($zbp->themeinfo['version']); ?></p></td></tr>
                <tr><td><p>主题 ID / 名称</p></td><td><p>Jz52_moli · 极致·墨璃（玻璃拟态个人博客主题）</p></td></tr>
                <tr><td><p>作者</p></td><td><p>不见桃花不见秋 · 393988832@qq.com · <a href="https://gebilaoli.com/" target="_blank">https://gebilaoli.com/</a></p></td></tr>
                <tr><td><p>许可协议</p></td><td><p>GNU General Public License v3.0；视觉语言移植自 Halo 主题「Luye」</p></td></tr>
                <tr><td><p>文件缓存</p></td><td><p>zb_users/cache/Jz52_moli_archives.php、zb_users/cache/Jz52_moli_tags.php（随内容变化自动重建）</p></td></tr>
                <tr><td><p>深浅色与天气</p></td><td><p>访客选择保存在浏览器 Cookie / localStorage（键 jz52_moli_night / jz52_moli_weather）</p></td></tr>
				<tr><td><p>单页</p></td><td><p>内置archives (时光归档)、categories (分类总览)、page_about (关于我)、tags (标签总览)四个单页模板，在页面编辑中选择。特别提醒：时光归档页面别名需设置为archives以供页脚自动调用。</p></td></tr>
            </table>
            <?php } ?>
        </div>
    </div>
</div>



<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_moli");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
