/*
   极致·墨璃 Jz52_moli 主题交互脚本
*/
(function ($) {
  'use strict';
  if (typeof zbp === 'undefined') { return; }

  var $body = $(document.body);
  var $mask = $('#navMask');

  $('.nav-list li').each(function () {
    var $li = $(this);
    if (!$li.children('.sub-menu').length) { return; }
    var $dot = $('<em class="dot">').html(
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>'
    );
    $li.children('a.nav-link').after($dot);
    $dot.on('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var open = $li.toggleClass('on').hasClass('on');
      $li.children('.sub-menu').stop(true, true).slideToggle(open ? 260 : 200);
    });
  });

  (function () {
    var $navList = $('#navCenter .nav-list');
    if (!$navList.length) { return; }

    var $more = $('<li class="nav-item nav-more">').append(
      '<a class="nav-link" href="#">更多</a>'
    );
    $('<em class="dot">').html(
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>'
    ).appendTo($more);
    var $moreMenu = $('<ul class="sub-menu"></ul>').appendTo($more);
    $navList.append($more);
    $navList.removeClass('has-more');

    $more.children('em.dot').on('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var open = $more.toggleClass('on').hasClass('on');
      $moreMenu.stop(true, true).slideToggle(open ? 260 : 200);
    });
    $more.children('a.nav-link').on('click', function (e) { e.preventDefault(); });

    var GAP = 32; 

    function itemsTotal() {
      var items = $navList.children('li:not(.nav-more)');
      var w = 0, n = items.length;
      items.each(function () { w += $(this).outerWidth(true); });
      return { w: w, n: n };
    }

    function applyFold() {
      if ($(window).width() < 861) {
        $moreMenu.children('li').appendTo($navList);
        $more.removeClass('on');
        $navList.removeClass('has-more');
        return;
      }
      $moreMenu.children('li').appendTo($navList);
      var t = itemsTotal();
      var avail = $('#navCenter').width();
      $navList.addClass('has-more');
      var moreW = $more.outerWidth(true);
      var need = t.w + moreW + GAP * t.n; 
      if (need <= avail) { $navList.removeClass('has-more'); return; }
      while (t.n > 1) {
        $moreMenu.prepend($navList.children('li:not(.nav-more)').last());
        t = itemsTotal();
        need = t.w + moreW + GAP * t.n;
        if (need <= avail) { break; }
      }
      $navList.addClass('has-more');
    }

    var tmr;
    $(window).on('resize', function () {
      clearTimeout(tmr);
      tmr = setTimeout(applyFold, 150);
    });
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(function () { setTimeout(applyFold, 100); });
    }
    $(window).on('load', function () { setTimeout(applyFold, 200); });
    setTimeout(applyFold, 300);
  })();

  var $navToggle = $('#navToggle');
  var $navCenter = $('#navCenter');

  function closeDrawer() {
    $body.removeClass('nav-open');
    if ($mask.length) { $mask.removeClass('show'); }
    if ($navToggle.length) { $navToggle.attr('aria-expanded', 'false'); }
  }

  if ($navToggle.length && $navCenter.length) {
    $navToggle.on('click', function (e) {
      e.stopPropagation();
      var open = $body.toggleClass('nav-open').hasClass('nav-open');
      if ($mask.length) { $mask.toggleClass('show', open); }
      $(this).attr('aria-expanded', open ? 'true' : 'false');
    });
    $navCenter.on('click', 'a', function () {
      closeDrawer();
    });
  }
  if ($mask.length) {
    $mask.on('click', closeDrawer);
  }
  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') { closeDrawer(); }
  });

  var $searchToggle = $('#searchToggle');
  var $searchPanel = $('#searchPanel');
  if ($searchToggle.length && $searchPanel.length) {
    $searchToggle.on('click', function (e) {
      e.stopPropagation();
      var open = $searchPanel.toggleClass('open').hasClass('open');
      $(this).attr('aria-expanded', open ? 'true' : 'false');
      if (open) {
        setTimeout(function () {
          $searchPanel.find('input[type="search"]').trigger('focus');
        }, 220);
      }
    });
    $(document).on('click', function (e) {
      if ($searchPanel.hasClass('open') &&
          !$searchPanel[0].contains(e.target) &&
          !$searchToggle[0].contains(e.target)) {
        $searchPanel.removeClass('open');
        $searchToggle.attr('aria-expanded', 'false');
      }
    });
  }

  $('#themeToggle').on('click', function () {
    var light = $body.toggleClass('is-light').hasClass('is-light');
    try { zbp.cookie.set('jz52_dgreen_night', light ? '0' : '1'); } catch (e) {}
  });

  var $toTop = $('#toTop');
  if ($toTop.length) {
    $toTop.on('click', function (e) {
      e.preventDefault();
      $('html, body').animate({ scrollTop: 0 }, 400);
    });
    var toggleToTop = function () {
      $toTop.toggleClass('show', window.scrollY > window.innerHeight * 0.6);
    };
    $(window).on('scroll', toggleToTop);
    toggleToTop();
  }

  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { $(e.target).addClass('in'); io.unobserve(e.target); }
      });
    }, { threshold: 0.10 });
    $('.reveal').each(function () { io.observe(this); });
  } else {
    $('.reveal').addClass('in');
  }

  (function () {
    var path = window.location.pathname.replace(/\/+$/, '') || '/';
    $('.nav-list a').each(function () {
      var href = $(this).attr('href') || '';
      if (!href || href.charAt(0) === '#') { return; }
      var ap;
      try {
        ap = new URL(href, window.location.origin).pathname.replace(/\/+$/, '') || '/';
      } catch (e) { return; }
      if (ap === path) { $(this).addClass('active'); }
    });
  })();

  if (window.zbp && zbp.plugin) {
    zbp.plugin.unbind('comment.reply.start', 'system');
    zbp.plugin.on('comment.reply.start', 'Jz52_moli', function (i) {
      $('#inpRevID').val(i);
      var $frm = $('#divCommentPost'),
          $cancel = $('#cancel-reply'),
          $cancelHome = $cancel.closest('.comment-bar');
      if (!$('#temp-frm').length) {
        var $div = $('<div>', { id: 'temp-frm' }).css('display', 'none');
        $frm.before($div);
      }
      var $anchor = $('#AjaxComment' + i);
      if ($anchor.length) {
        $anchor.before($frm);
      } else {
        var $cmt = $('#cmt' + i),
            $child = $cmt.find('.comment-children').first();
        if ($child.length) { $child.before($frm); } else { $cmt.after($frm); }
      }
      $frm.prepend($cancel);
      $frm.addClass('reply-frm');
      $cancel.show();
      $cancel.off('click').on('click', function () {
        $('#inpRevID').val(0);
        var $temp = $('#temp-frm'),
            $frm2 = $('#divCommentPost');
        if (!$temp.length || !$frm2.length) { return; }
        $temp.before($frm2);
        $temp.remove();
        if ($cancelHome.length) { $cancelHome.append($cancel); }
        $(this).hide();
        $frm2.removeClass('reply-frm');
        return false;
      });
      try { $('#txaArticle').trigger('focus'); } catch (e) {}
      return false;
    });
    zbp.plugin.on('comment.get', 'Jz52_moli', function () {
      $('span.commentspage').html('Waiting...');
    });
    zbp.plugin.on('comment.got', 'Jz52_moli', function (formData, data) {
      $('#AjaxCommentBegin').nextUntil('#AjaxCommentEnd').remove();
      $('#AjaxCommentEnd').before(data);
      $('#cancel-reply').trigger('click');
    });
    zbp.plugin.on('comment.post.success', 'Jz52_moli', function () {
      $('#cancel-reply').trigger('click');
    });
  }

})(jQuery);
