<?php
if (!defined('ZBP_PATH')) {exit('Access denied');}

RegisterPlugin("Jz52_moli", "ActivePlugin_Jz52_moli");

function ActivePlugin_Jz52_moli()
{
    global $zbp;
    Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Jz52_moli_AddMenu');
    if ($zbp->Config('Jz52_moli')->seo && $zbp->Config('Jz52_moli')->nseo) {
        Add_Filter_Plugin('Filter_Plugin_Edit_Response5', 'Jz52_moli_Filter_Plugin_Edit_Response5');
        Add_Filter_Plugin('Filter_Plugin_Category_Edit_Response', 'Jz52_moli_Category_Edit_Response');
    }
}

function Jz52_moli_AddMenu(&$m)
{
    global $zbp;
    $m[] = MakeTopMenu("root", '主题配置', $zbp->host . "zb_users/theme/Jz52_moli/main.php?act=config", "", "topmenu_Jz52_moli", "icon-zblog");
}

function Jz52_moli_SubMenu($id)
{
    $arySubMenu = array(
        0 => array('基本设置', 'config', 'left', false),
        1 => array('首页设置', 'home', 'left', false),
        2 => array('外观设置', 'style', 'left', false),
        3 => array('SEO设置', 'seo', 'left', false),
        4 => array('关于', 'about', 'left', false),
    );
    foreach ($arySubMenu as $k => $v) {
        echo '<a href="?act=' . $v[1] . '" ' . ($v[3] == true ? 'target="_blank"' : '') . '><span class="m-' . $v[2] . ' ' . ($id == $v[1] ? 'm-now' : '') . '">' . $v[0] . '</span></a>';
    }
}

function Jz52_moli_Category_Edit_Response()
{
    global $zbp, $cate;
    echo '<p><span class="title">标题:（主题自带SEO）</span><br /><input style="width:95%" name="meta_flbt" value="' . htmlspecialchars($cate->Metas->flbt) . '"/></p>'
        . '<p><span class="title">关键词:（主题自带SEO）</span><br /><input style="width:95%" name="meta_flgjc" value="' . htmlspecialchars($cate->Metas->flgjc) . '"/></p>';
}

function Jz52_moli_Filter_Plugin_Edit_Response5()
{
    global $zbp, $article;
    echo '<table width="99%"><tr><td width="20%">关键词(主题自带SEO)</td><td width="80%"><input style="width:95%" name="meta_nrgjc" value="' . htmlspecialchars($article->Metas->nrgjc) . '"/></td></tr>'
        . '<tr><td>描述(主题自带SEO)</td><td><input style="width:95%" name="meta_nrms" value="' . htmlspecialchars($article->Metas->nrms) . '"/></td></tr></table>';
}

function Jz52_moli_TagList()
{
    global $zbp;
    $cacheFile = $zbp->cachedir . 'Jz52_moli_tags.php';
    $meta = $zbp->db->Query($zbp->db->sql->Select(
        $zbp->table['Tag'],
        array('COUNT(*) AS c', 'MAX(tag_ID) AS i', 'SUM(tag_Count) AS s', 'MAX(tag_UpdateTime) AS u')
    ));
    $key = $meta[0]['c'] . '|' . $meta[0]['i'] . '|' . $meta[0]['s'] . '|' . $meta[0]['u'];
    if (file_exists($cacheFile)) {
        $cached = include $cacheFile;
        if (isset($cached['key']) && $cached['key'] === $key) {
            return $cached['list'];
        }
    }
    if ((int) $meta[0]['c'] == 0) {
        @file_put_contents($cacheFile . '.tmp', '<?php return ' . var_export(array('key' => $key, 'list' => array()), true) . ';');
        @rename($cacheFile . '.tmp', $cacheFile);
        return array();
    }
    $list = $zbp->GetTagList();
    $rows = array();
    foreach ($list as $tag) {
        $rows[] = array(
            'Name'  => $tag->Name,
            'Url'   => $tag->Url,
            'Count' => (int) $tag->Count,
        );
    }
    @file_put_contents($cacheFile . '.tmp', '<?php return ' . var_export(array('key' => $key, 'list' => $rows), true) . ';');
    @rename($cacheFile . '.tmp', $cacheFile);
    return $rows;
}

function Jz52_moli_thumb($article)
{
    $images = $article->AllImages;
    return isset($images[0]) ? $images[0] : '';
}

function Jz52_moli_ArchiveList()
{
    global $zbp;
    $cacheFile = $zbp->cachedir . 'Jz52_moli_archives.php';
    $meta = $zbp->db->Query($zbp->db->sql->Select(
        $zbp->table['Post'],
        array('COUNT(*) AS c', 'MAX(log_PostTime) AS m'),
        array(array('=', 'log_Status', '0'), array('=', 'log_Type', '0'))
    ));
    $key = $meta[0]['c'] . '|' . $meta[0]['m'];
    if (file_exists($cacheFile)) {
        $cached = include $cacheFile;
        if (isset($cached['key']) && $cached['key'] === $key) {
            return $cached['list'];
        }
    }

    if ((int) $meta[0]['c'] == 0) {
        @file_put_contents($cacheFile . '.tmp', '<?php return ' . var_export(array('key' => $key, 'list' => array()), true) . ';');
        @rename($cacheFile . '.tmp', $cacheFile);
        return array();
    }

    $data = $zbp->db->Query($zbp->db->sql->Select(
        $zbp->table['Post'],
        array('log_ID', 'log_Title', 'log_Alias', 'log_PostTime', 'log_Intro', 'log_CateID', 'log_AuthorID'),
        array(array('=', 'log_Status', '0'), array('=', 'log_Type', '0'))
    ));
    $rows = array();
    foreach ($data as $d) {
        $p = new Post();
        $p->ID = (int) $d['log_ID'];
        $p->Title = $d['log_Title'];
        $p->Alias = $d['log_Alias'];
        $p->PostTime = (int) $d['log_PostTime'];
        $p->CateID = (int) $d['log_CateID'];
        $p->AuthorID = (int) $d['log_AuthorID'];
        $rows[] = array(
            'Title' => $d['log_Title'],
            'Url'   => $p->Url,
            'year'  => date('Y', $p->PostTime),
            'time'  => date('Y-m-d', $p->PostTime),
            'intro' => trim(SubStrUTF8(TransferHTML($d['log_Intro'], '[nohtml]'), 120)),
        );
    }
    @file_put_contents($cacheFile . '.tmp', '<?php return ' . var_export(array('key' => $key, 'list' => $rows), true) . ';');
    @rename($cacheFile . '.tmp', $cacheFile);
    return $rows;
}

function Jz52_moli_Footer()
{
    global $zbp;

    echo '<span>'.$zbp->option['ZC_BLOG_COPYRIGHT']. '</span>';
    if ($zbp->Config('Jz52_moli')->beian) {
        echo '<span class="dg-footer-beian"><a href="https://beian.miit.gov.cn/" rel="nofollow" target="_blank">' . $zbp->Config('Jz52_moli')->beian . '</a></span>';
    }
	if ($zbp->Config('Jz52_moli')->footer) {
        echo '<span class="dg-footer-custom">' . $zbp->Config('Jz52_moli')->footer . '</span>';
    }
    echo '<span>Powered by <a href="https://www.zblogcn.com/" target="_blank">Z-BlogPHP</a> · Theme <a href="https://app.zbp.cool/" target="_blank">极致·墨璃</a></span>';
}

function InstallPlugin_Jz52_moli()
{
    global $zbp;
    if (!$zbp->Config('Jz52_moli')->HasKey('Version')) {
        $zbp->Config('Jz52_moli')->Version = '1.0.0';
        $zbp->Config('Jz52_moli')->brand_sub = 'APP.ZBP.COOL';
        $zbp->Config('Jz52_moli')->logo_text = '';
        $zbp->Config('Jz52_moli')->logo_image = '';
        $zbp->Config('Jz52_moli')->avatar = '';
        $zbp->Config('Jz52_moli')->email = '';
        $zbp->Config('Jz52_moli')->github = '';
        $zbp->Config('Jz52_moli')->tagline = '人间有味是清欢。';
        $zbp->Config('Jz52_moli')->copyright = '';
        $zbp->Config('Jz52_moli')->beian = '';
        $zbp->Config('Jz52_moli')->footer = '';
        $zbp->Config('Jz52_moli')->darkmode = '0';
        $zbp->Config('Jz52_moli')->hero_enable = '1';
        $zbp->Config('Jz52_moli')->hero_eyebrow = 'POETRY & LIFE · 诗与生活';
        $zbp->Config('Jz52_moli')->hero_title = '人间草木，皆是文章';
        $zbp->Config('Jz52_moli')->hero_subtitle = '记录读书、旅行与生活里的微小诗意——春水煎茶，秋月听风，把平凡的日子过成温柔的诗。';
        $zbp->Config('Jz52_moli')->hero_image = '';
        $zbp->Config('Jz52_moli')->hero_cta_text = '读几篇随笔';
        $zbp->Config('Jz52_moli')->hero_cta_anchor = '#posts';
        $zbp->Config('Jz52_moli')->accent_color = '#3b9b66';
        $zbp->Config('Jz52_moli')->weather = '1';
        $zbp->Config('Jz52_moli')->webfont = '0';
        $zbp->Config('Jz52_moli')->seo = '0';
        $zbp->Config('Jz52_moli')->nseo = '0';
        $zbp->Config('Jz52_moli')->seotitle = '';
        $zbp->Config('Jz52_moli')->seokeywords = '';
        $zbp->Config('Jz52_moli')->seodescription = '';
        $zbp->Config('Jz52_moli')->DelConfig = '0';
        $zbp->SaveConfig('Jz52_moli');
    }
}

function UninstallPlugin_Jz52_moli()
{
    global $zbp;
    if ($zbp->Config('Jz52_moli')->DelConfig) {
        $zbp->DelConfig('Jz52_moli');
    }
    @unlink($zbp->cachedir . 'Jz52_moli_archives.php');
    @unlink($zbp->cachedir . 'Jz52_moli_tags.php');
}
