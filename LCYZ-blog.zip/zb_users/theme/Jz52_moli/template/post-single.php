{* Template Name:文章模板 *}
<main class="dg-main">
  <div class="dg-container">
    <header class="post-hero">
      <p class="eyebrow">{if $article.Category.Name}{$article.Category.Name}{else}文章{/if}</p>
      <h1 class="headline">{$article.Title}</h1>
      <div class="post-meta-bar">
        <span>{$article.Time('Y-m-d')}</span>
        <span class="sep">·</span>
        <span>{$article.Author.StaticName}</span>
        <span class="sep">·</span>
        <span>{$article.ViewNums} 次阅读</span>
        {if $article.CommNums}
        <span class="sep">·</span>
        <span>{$article.CommNums} 条评论</span>
        {/if}
      </div>
      {php}$jzDgCover = Jz52_moli_thumb($article);{/php}
      {if $jzDgCover}
      <img class="post-cover" src="{$jzDgCover}" alt="{$article.Title}">
      {/if}
    </header>
    <article class="post-panel">
      <div class="post-content">
        {$article.Content}
      </div>

      {if $article.Tags}
      <div class="post-tags-row">
        <span class="label">标签</span>
        {foreach $article.Tags as $jzDgTag}
        <a class="tag-pill" href="{$jzDgTag.Url}"># {$jzDgTag.Name}</a>
        {/foreach}
      </div>
      {/if}
      <div class="author-bar">
        {if $zbp->Config('Jz52_moli')->avatar}
        <img class="avatar" src="{$zbp->Config('Jz52_moli')->avatar}" alt="头像">
        {else}
        <span class="avatar-badge">
          <img src="{$host}zb_users/theme/{$theme}/style/images/mountain.svg" alt="">
        </span>
        {/if}
        <div class="info">
          <span class="nm">{$article.Author.StaticName}</span>
          {if $article.Author.Intro}<span class="bio">{$article.Author.Intro}</span>{/if}
        </div>
      </div>
      <nav class="post-nav" aria-label="上下篇">
        {if $article.Prev}
        <a class="post-nav-card" href="{$article.Prev.Url}">
          <span class="hint">← 上一篇</span>
          <span class="ttl">{$article.Prev.Title}</span>
        </a>
        {else}
        <span class="post-nav-card is-disabled"><span class="hint">← 上一篇</span><span class="ttl">没有了</span></span>
        {/if}
        {if $article.Next}
        <a class="post-nav-card next" href="{$article.Next.Url}">
          <span class="hint">下一篇 →</span>
          <span class="ttl">{$article.Next.Title}</span>
        </a>
        {else}
        <span class="post-nav-card next is-disabled"><span class="hint">下一篇 →</span><span class="ttl">没有了</span></span>
        {/if}
      </nav>
    </article>
    {if !$article.IsLock}
    <section class="comment-panel" id="comments">
      <h2 class="panel-title">评论</h2>
      {template:comments}
    </section>
    {/if}

  </div>
</main>
