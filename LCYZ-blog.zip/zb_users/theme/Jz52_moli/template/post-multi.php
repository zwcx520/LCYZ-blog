{* Template Name:列表文章项 *}
<article class="post-item reveal">
  <div class="post-item-head">
    <a href="{$article.Url}">
      <h3 class="post-title">{$article.Title}</h3>
    </a>
    <span class="post-date">{$article.Time('M j, Y')}</span>
  </div>
  {php}$jzDgExcerpt = trim(SubStrUTF8(TransferHTML($article->Intro, '[nohtml]'), 150));{/php}
  {if $jzDgExcerpt}<p class="post-excerpt">{$jzDgExcerpt}</p>{/if}
  <div class="post-meta">
    {if $article.Category.Name}<a class="cat-pill" href="{$article.Category.Url}">{$article.Category.Name}</a>{/if}
    {foreach $article.Tags as $jzDgTag}
    <a class="tag-pill" href="{$jzDgTag.Url}"># {$jzDgTag.Name}</a>
    {/foreach}
  </div>
</article>
