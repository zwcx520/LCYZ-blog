{* Template Name:时光归档 * Template Type:page *}
{template:header}
{php}
$jzDgArchList = Jz52_moli_ArchiveList();
$jzDgArch = array();
foreach ($jzDgArchList as $jzDgA) {
    $jzDgArch[$jzDgA['year']][] = $jzDgA;
}
krsort($jzDgArch);
{/php}
<main class="dg-main">
  <div class="dg-container">
    <header class="post-hero" style="padding-bottom:10px;">
      <p class="eyebrow">ARCHIVES · 归档</p>
      <h1 class="headline">{$article.Title}</h1>
      <p class="post-meta-bar"><span>共 {count($jzDgArchList)} 篇文章</span></p>
    </header>
    <div class="section" style="padding-top:20px;">
      {if !$jzDgArchList}
      <div class="empty-tip">暂无归档。</div>
      {/if}
      {foreach $jzDgArch as $jzDgYear => $jzDgArts}
      <h2 class="archive-year">{$jzDgYear}</h2>
      <div class="post-list">
        {foreach $jzDgArts as $jzDgA}
        <article class="post-item reveal">
          <div class="post-item-head">
            <a href="{$jzDgA['Url']}"><h3 class="post-title">{$jzDgA['Title']}</h3></a>
            <span class="post-date">{$jzDgA['time']}</span>
          </div>
          {if $jzDgA['intro']}<p class="post-excerpt">{$jzDgA['intro']}</p>{/if}
        </article>
        {/foreach}
      </div>
      {/foreach}
    </div>
  </div>
</main>
{template:footer}
