{* Template Name:单页模板 *}
<main class="dg-main">
  <div class="dg-container">
    <header class="post-hero">
      <p class="eyebrow">PAGE · 页面</p>
      <h1 class="headline">{$article.Title}</h1>
    </header>
    <article class="post-panel">
      <div class="post-content">
        {$article.Content}
      </div>
    </article>
    {if !$article.IsLock}
    <section class="comment-panel" id="comments">
      <h2 class="panel-title">评论</h2>
      {template:comments}
    </section>
    {/if}
  </div>
</main>
