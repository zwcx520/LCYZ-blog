{* Template Name:公用页脚模块 *}
<footer class="footer">
  <div class="watermark">{$name}</div>
  <div class="dg-container content-inner">
    <div class="top-line"></div>
    <div class="footer-head">
      <span class="name">{$name}</span>
      {if $zbp->Config('Jz52_moli')->tagline}<span class="tag">{$zbp->Config('Jz52_moli')->tagline}</span>{/if}
    </div>
    <div class="contact-row">
      {if $zbp->Config('Jz52_moli')->email}
      <a class="contact-pill" href="mailto:{$zbp->Config('Jz52_moli')->email}">{$zbp->Config('Jz52_moli')->email}</a>
      {/if}
      {if $zbp->Config('Jz52_moli')->github}
      <a class="contact-pill" href="{$zbp->Config('Jz52_moli')->github}" target="_blank" rel="noopener">GitHub</a>
      {/if}
      {php}$jzDgArch = GetPost(array('alias' => 'archives', 'only_page' => true));{/php}
      {if $jzDgArch}<a class="contact-pill" href="{$jzDgArch.Url}">文章归档</a>{/if}
      <a class="contact-pill" href="{$feedurl}" target="_blank" rel="noopener">RSS</a>
    </div>
    <div class="bottom-bar">
      {Jz52_moli_Footer()}
    </div>
  </div>
</footer>
<button type="button" class="to-top" id="toTop" aria-label="返回顶部" title="返回顶部">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5"/><path d="m5 12 7-7 7 7"/></svg>
</button>
<div class="nav-mask" id="navMask"></div>
<script src="{$host}zb_users/theme/{$theme}/script/main.js?v={$zbp->themeinfo['version']}"></script>
{if $zbp->Config('Jz52_moli')->weather == '1'}
<script src="{$host}zb_users/theme/{$theme}/script/weather.js?v={$zbp->themeinfo['version']}"></script>
{/if}
{$footer}
</body>
</html>
