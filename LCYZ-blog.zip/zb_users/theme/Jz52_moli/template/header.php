{* Template Name:公用头部模块 *}
<!DOCTYPE html>
<html lang="{$language}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#08120E">
{if $zbp->Config('Jz52_moli')->seo}{template:seo}{else}<title>{$name}{if $title != $name} - {$title}{/if}</title>{/if}
<meta name="generator" content="{$zblogphp}">
{if $zbp->Config('Jz52_moli')->webfont == '1'}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+SC:wght@300;400;500&amp;family=Noto+Sans+SC:wght@300;400;500&amp;family=Source+Serif+4:ital,wght@0,400;0,500;1,400;1,500&amp;display=swap" rel="stylesheet">
{/if}
<link rel="stylesheet" href="{$host}zb_users/theme/{$theme}/style/style.css?v={$zbp->themeinfo['version']}">
<style>{if $zbp->Config('Jz52_moli')->accent_color}:root{--green:{$zbp->Config('Jz52_moli')->accent_color};}{/if}</style>
<script src="{$host}zb_system/script/jquery-latest.min.js?v={$version}"></script>
<script src="{$host}zb_system/script/zblogphp.js?v={$version}"></script>
<script src="{$host}zb_system/script/c_html_js_add.php?v={$version}"></script>
{$header}
{if $type=='index' && isset($page) && $page=='1'}
<link rel="alternate" type="application/rss+xml" href="{$feedurl}" title="{$name}">
{/if}
</head>
<body class="dg-body is-{$type}{if $zbp->Config('Jz52_moli')->darkmode=='1'} is-night{elseif $zbp->Config('Jz52_moli')->darkmode=='2'} is-light{elseif GetVars('jz52_dgreen_night','COOKIE')=='0'} is-light{/if}">
<!-- 装饰雾光 -->
<div class="fog fog-1"></div>
<div class="fog fog-2"></div>
<div class="fog fog-3"></div>

<header class="nav" id="siteHeader">
  <div class="dg-container nav-inner">
    <a class="logo" href="{$host}" aria-label="首页">
      {if $zbp->Config('Jz52_moli')->logo_image}
      <img class="leaf" src="{$zbp->Config('Jz52_moli')->logo_image}" alt="">
      {else}
      <img class="leaf" src="{$host}zb_users/theme/{$theme}/style/images/leaf.svg" alt="">
      {/if}
      <span class="brand">
        {if $zbp->Config('Jz52_moli')->logo_text}
        {if $type=='index' && isset($page) && $page=='1'}<h1 class="name">{$zbp->Config('Jz52_moli')->logo_text}</h1>{else}<span class="name">{$zbp->Config('Jz52_moli')->logo_text}</span>{/if}
        {else}
        {if $type=='index' && isset($page) && $page=='1'}<h1 class="name">{$name}</h1>{else}<span class="name">{$name}</span>{/if}
        {/if}
        {if $zbp->Config('Jz52_moli')->brand_sub}<span class="sub">{$zbp->Config('Jz52_moli')->brand_sub}</span>{/if}
      </span>
    </a>
    <div class="nav-center" id="navCenter">
      <ul class="nav-list">
        {module:navbar}
      </ul>
    </div>
    <div class="nav-right">
      {if $zbp->Config('Jz52_moli')->weather == '1'}
      <div class="weather-switch" role="group" aria-label="背景天气切换">
        <button type="button" class="weather-btn" data-weather="sun" aria-pressed="false" aria-label="晴天" title="晴天">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
        </button>
        <button type="button" class="weather-btn" data-weather="rain" aria-pressed="false" aria-label="雨天" title="雨天">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="16" y1="13" x2="16" y2="21"/><line x1="8" y1="13" x2="8" y2="21"/><line x1="12" y1="15" x2="12" y2="23"/><path d="M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25"/></svg>
        </button>
        <button type="button" class="weather-btn" data-weather="snow" aria-pressed="false" aria-label="雪天" title="雪天">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12h20"/><path d="M12 2v20"/><path d="m20 16-4-4 4-4"/><path d="m4 8 4 4-4 4"/><path d="m16 4-4 4-4-4"/><path d="m8 20 4-4 4 4"/></svg>
        </button>
      </div>
      {/if}
      <button type="button" class="nav-btn search-toggle" id="searchToggle" aria-label="搜索" aria-expanded="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></svg>
      </button>
      <button type="button" class="nav-btn theme-toggle" id="themeToggle" aria-label="切换深浅色">
        <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"></path></svg>
        <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>
      </button>
      {if $zbp->Config('Jz52_moli')->email}
      <a class="nav-cta" href="mailto:{$zbp->Config('Jz52_moli')->email}">联系我</a>
      {/if}
      <button type="button" class="nav-toggle" id="navToggle" aria-label="打开菜单">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
  <div class="search-panel" id="searchPanel">
    <div class="dg-container">
      <form class="search-form" role="search" method="get" action="{$host}search.php">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></svg>
        <input type="search" name="q" placeholder="搜索文章…" autocomplete="off" maxlength="256">
        <button type="submit">搜索</button>
      </form>
    </div>
  </div>
</header>
