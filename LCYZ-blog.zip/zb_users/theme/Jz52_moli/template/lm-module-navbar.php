{* Template Name:导航模块 *}
<li class="nav-item">
  <a class="nav-link" href="{$item.href}" target="{$item.target}" title="{$item.title}">{$item.ico}{$item.text}</a>
  {if count($item.subs)}
  <ul class="sub-menu">{foreach $item.subs as $item}{template:lm-module-navbar}{/foreach}</ul>
  {/if}
</li>
