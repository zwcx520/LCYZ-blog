{* Template Name:列表置顶文章项 *}
<article class="post-featured reveal">
  <div class="card-top">
    <span class="idx">置顶</span>
    <img class="leaf" src="{$host}zb_users/theme/{$theme}/style/images/leaf-2.svg" alt="">
  </div>
  <a href="{$article.Url}">
    <h3 class="post-title">{$article.Title}</h3>
  </a>
  {php}$jzDgCover = Jz52_moli_thumb($article);{/php}
  {if $jzDgCover}
  <img class="cover" src="{$jzDgCover}" alt="{$article.Title}">
  {/if}
  {php}$jzDgExcerpt = trim(SubStrUTF8(TransferHTML($article->Intro, '[nohtml]'), 150));{/php}
  {if $jzDgExcerpt}<p class="post-excerpt">{$jzDgExcerpt}</p>{/if}
  <div class="post-meta">
    {if $article.Category.Name}<a class="cat-pill" href="{$article.Category.Url}">{$article.Category.Name}</a>{/if}
    {foreach $article.Tags as $jzDgTag}
    <a class="tag-pill" href="{$jzDgTag.Url}"># {$jzDgTag.Name}</a>
    {/foreach}
    <span class="post-date" style="margin-left:auto;">{$article.Time('M j, Y')}</span>
  </div>
</article>
