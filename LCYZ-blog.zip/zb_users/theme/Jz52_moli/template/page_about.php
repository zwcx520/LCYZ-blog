{* Template Name:关于我 * Template Type:page *}
{template:header}
<main class="dg-main">
  <div class="dg-container">
    <header class="about-hero">
      <p class="eyebrow">ABOUT · 关于我</p>
      <h1 class="title">{$article.Title}</h1>
      <div class="portrait">
        {if $zbp->Config('Jz52_moli')->avatar}
        <img class="photo" src="{$zbp->Config('Jz52_moli')->avatar}" alt="头像">
        {else}
        <img class="badge" src="{$host}zb_users/theme/{$theme}/style/images/mountain.svg" alt="">
        <span class="cap">{$name}{if $zbp->Config('Jz52_moli')->brand_sub} · {$zbp->Config('Jz52_moli')->brand_sub}{/if}</span>
        {/if}
      </div>
    </header>
    <article class="post-panel about-content">
      <div class="post-content">
        {$article.Content}
      </div>
    </article>
    {if !$article.IsLock}
    <section class="comment-panel" id="comments">
      <h2 class="panel-title">评论</h2>
      {template:comments}
    </section>
    {/if}
  </div>
</main>
{template:footer}
