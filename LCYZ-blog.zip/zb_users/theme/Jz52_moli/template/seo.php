{* Template Name: SEO * Template Type: none *}
{if $type=='article'}
<title>{$title}-{$name}</title>
{php}
$aryTags = array();
foreach ($article->Tags as $key) {
    $aryTags[] = $key->Name;
}
if (count($aryTags) > 0) {
    $keywords = implode(',', $aryTags);
} else {
    $keywords = $zbp->name;
}
$description = trim(SubStrUTF8(TransferHTML($article->Intro, '[nohtml]'), 135));
if ($description == '') {
    $description = trim(SubStrUTF8(TransferHTML($article->Content, '[nohtml]'), 135));
}
{/php}
<meta name="keywords" content="{if $article.Metas.nrgjc && $zbp->Config('Jz52_moli')->nseo}{$article.Metas.nrgjc}{else}{$keywords}{/if}">
<meta name="description" content="{if $article.Metas.nrms && $zbp->Config('Jz52_moli')->nseo}{$article.Metas.nrms}{else}{$description}{/if}">
<link rel="canonical" href="{$article.Url}"/>
{if $article.Prev}
<link rel="prev" title="{$article.Prev.Title}" href="{$article.Prev.Url}">
{/if}
{if $article.Next}
<link rel="next" title="{$article.Next.Title}" href="{$article.Next.Url}">
{/if}
{elseif $type=='page'}
<title>{$title}-{$name}</title>
<meta name="keywords" content="{if $article.Metas.nrgjc && $zbp->Config('Jz52_moli')->nseo}{$article.Metas.nrgjc}{else}{$title}{/if}">
{php}
$description = trim(SubStrUTF8(TransferHTML($article->Content, '[nohtml]'), 135));
{/php}
<meta name="description" content="{if $article.Metas.nrms && $zbp->Config('Jz52_moli')->nseo}{$article.Metas.nrms}{else}{$description}{/if}">
<link rel="canonical" href="{$article.Url}"/>
{elseif $type=='index'}
<title>{if $zbp->Config('Jz52_moli')->seotitle && isset($page) && $page=='1'}{$zbp->Config('Jz52_moli')->seotitle}{if $subname} - {$subname}{/if}{else}{$name}{if isset($page) && $page>'1'} - 第{$page}页{/if}{/if}</title>
{if $zbp->Config('Jz52_moli')->seokeywords}
<meta name="keywords" content="{$zbp->Config('Jz52_moli')->seokeywords}">
{/if}
{if $zbp->Config('Jz52_moli')->seodescription}
<meta name="description" content="{$zbp->Config('Jz52_moli')->seodescription}">
{/if}
{elseif $type=='tag'}
<title>{$tag.Name} - {$name}{if isset($page) && $page>'1'} - 第{$page}页{/if}</title>
<meta name="keywords" content="{$tag.Name}">
{if $tag.Intro}
<meta name="description" content="{$tag.Intro}">
{/if}
{elseif $type=='category'}
<title>{if $category.Metas.flbt && $zbp->Config('Jz52_moli')->nseo}{$category.Metas.flbt}{if isset($page) && $page>'1'} 第{$page}页{/if}{else}{$title}{/if} - {$name}</title>
<meta name="keywords" content="{if $category.Metas.flgjc && $zbp->Config('Jz52_moli')->nseo}{$category.Metas.flgjc}{else}{$title}{/if},{$name}">
<meta name="description" content="{if $category.Intro}{$category.Intro}{else}{$title}_{$name}{/if}">
{else}
<title>{$title} - {$name}</title>
<meta name="keywords" content="{$title},{$name}" />
<meta name="description" content="{$title}_{$name}{if isset($page) && $page>'1'}_当前是第{$page}页{/if}">
{/if}
