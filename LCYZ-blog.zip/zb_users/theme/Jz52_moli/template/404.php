{* Template Name:404模板 *}
{template:header}
<main class="dg-main">
  <div class="error-wrap">
    <span class="code">404</span>
    <h1 class="msg">页面走丢了</h1>
    <p class="hint">你要找的页面不存在，或者已被移走。回到首页，继续在此间寻一片诗意吧。</p>
    <div class="cta-row">
      <a class="cta-primary" href="{$host}">回到首页</a>
      {php}$jzDgArchE = GetPost(array('alias' => 'archives', 'only_page' => true));{/php}
      {if $jzDgArchE}<a class="secondary-link" href="{$jzDgArchE.Url}">浏览文章归档 ↓</a>{/if}
    </div>
  </div>
</main>
{template:footer}
