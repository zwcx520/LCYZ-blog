{* Template Name:评论模块 *}
{if isset($socialcomment) && $socialcomment}
{$socialcomment}
{else}
<div class="comment-bar">
  <h3 class="comment-title">评论<span class="comment-count">{$article.CommNums}</span></h3>
  <a rel="nofollow" id="cancel-reply" href="#divCommentPost" style="display:none;"><small>取消回复</small></a>
</div>
{template:commentpost}
<label id="AjaxCommentBegin"></label>
{if $article.CommNums>0}
<ul class="comment-list">
  {foreach $comments as $key => $comment}
  {template:comment}
  {/foreach}
</ul>
{/if}
<label id="AjaxCommentEnd"></label>
{if isset($commentspagebar) && $commentspagebar}
<div class="comment-page">{template:pagebar}</div>
{/if}
{/if}
