{* Template Name:标签总览 * Template Type:page *}
{template:header}
<main class="dg-main">
  <div class="dg-container">
    <header class="post-hero" style="padding-bottom:10px;">
      <p class="eyebrow">TAGS · 标签</p>
      <h1 class="headline">{$article.Title}</h1>
    </header>
    <div class="section" style="padding-top:20px;">
      {php}$jzDgTags = Jz52_moli_TagList();{/php}
      {if !$jzDgTags}
      <div class="empty-tip">还没有创建标签。</div>
      {else}
      <div class="card-grid">
        {foreach $jzDgTags as $jzDgT}
        <a class="glass-card reveal" href="{$jzDgT['Url']}">
          <div class="card-top">
            <span class="idx">#</span>
            <img class="leaf" src="{$host}zb_users/theme/{$theme}/style/images/leaf-3.svg" alt="">
          </div>
          <h3 class="card-title">{$jzDgT['Name']}</h3>
          <span class="card-tag">{$jzDgT['Count']} 篇文章</span>
        </a>
        {/foreach}
      </div>
      {/if}
    </div>
  </div>
</main>
{template:footer}
