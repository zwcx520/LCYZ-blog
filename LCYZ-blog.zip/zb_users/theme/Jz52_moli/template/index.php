{* Template Name:首页及列表模板（首页/分类/标签/搜索/作者/日期） *}
{template:header}
{if $type=='index' && (empty($page) || $page=='1') && $zbp->Config('Jz52_moli')->hero_enable == '1'}
<section class="hero">
  {if $zbp->Config('Jz52_moli')->hero_eyebrow}<p class="eyebrow">{$zbp->Config('Jz52_moli')->hero_eyebrow}</p>{/if}
  <h1 class="headline">{$zbp->Config('Jz52_moli')->hero_title}</h1>
  {if $zbp->Config('Jz52_moli')->hero_subtitle}<p class="sub">{$zbp->Config('Jz52_moli')->hero_subtitle}</p>{/if}
  <div class="cta-row">
    {if $zbp->Config('Jz52_moli')->hero_cta_text}
    <a class="cta-primary" href="{if $zbp->Config('Jz52_moli')->hero_cta_anchor}{$zbp->Config('Jz52_moli')->hero_cta_anchor}{else}#posts{/if}">{$zbp->Config('Jz52_moli')->hero_cta_text}</a>
    {/if}
    {php}$jzDgArchH = GetPost(array('alias' => 'archives', 'only_page' => true));{/php}
    {if $jzDgArchH}<a class="secondary-link" href="{$jzDgArchH.Url}">浏览全部文章 ↓</a>{/if}
  </div>
  <p class="scroll-hint">向下，且听风吟</p>
  {if $zbp->Config('Jz52_moli')->hero_image}
  <img class="hero-img" src="{$zbp->Config('Jz52_moli')->hero_image}" alt="横幅意象图">
  {/if}
</section>
{/if}

<main class="dg-main">
  <div class="dg-container">
    {if $type!='index' || (isset($page) && $page>'1')}
    {if $type=='author'}
    <header class="about-hero">
      <p class="eyebrow">AUTHOR · 作者</p>
      <h1 class="title">{$author.StaticName}</h1>
      <div class="portrait">
        <img class="photo" src="{$author.Avatar}" alt="头像">
      </div>
      {if $author.Intro}<p class="post-meta-bar"><span>{$author.Intro}</span></p>{/if}
    </header>
    {else}
    <header class="post-hero" style="padding-bottom:10px;">
      <p class="eyebrow">
        {if $type=='category'}CATEGORY · 分类
        {elseif $type=='tag'}TAG · 标签
        {elseif $type=='search'}SEARCH · 搜索
        {elseif $type=='date'}ARCHIVE · 归档
        {else}PAGE · 第{$page}页{/if}
      </p>
      <h1 class="headline">
        {if $type=='category'}{$category.Name}
        {elseif $type=='tag'}# {$tag.Name}
        {elseif $type=='search'}搜索：{$search}
        {elseif $type=='date'}{$title}
        {else}第{$page}页{/if}
      </h1>
      {if $type=='category' && $category.Intro}<p class="post-meta-bar"><span>{$category.Intro}</span></p>{/if}
      {if $type=='tag' && $tag.Intro}<p class="post-meta-bar"><span>{$tag.Intro}</span></p>{/if}
      {if $type=='search'}<p class="post-meta-bar"><span>共找到与“{$search}”相关的内容</span></p>{/if}
    </header>
    {/if}
    {/if}
    <section class="section" id="posts" style="{if $type=='index' && (empty($page) || $page=='1')}padding-top:20px;{/if}">
      {if $type=='index' && (empty($page) || $page=='1')}
      <div class="section-head reveal">
        <p class="eyebrow">ESSAYS · 随笔小记</p>
        <h2 class="title">落笔，皆是风景</h2>
      </div>
      {/if}
      {if !$articles}
      <div class="empty-tip">还没有发布文章，去后台写第一篇吧。</div>
      {else}
      <div class="post-list">
        {foreach $articles as $article}
        {if $article.IsTop}{template:post-istop}{else}{template:post-multi}{/if}
        {/foreach}
      </div>
      {/if}
      {template:pagebar}
    </section>
  </div>
</main>
{template:footer}
