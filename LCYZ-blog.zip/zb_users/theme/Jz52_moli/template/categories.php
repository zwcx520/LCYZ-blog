{* Template Name:分类总览 * Template Type:page *}
{template:header}
<main class="dg-main">
  <div class="dg-container">
    <header class="post-hero" style="padding-bottom:10px;">
      <p class="eyebrow">CATEGORIES · 分类</p>
      <h1 class="headline">{$article.Title}</h1>
    </header>
    <div class="section" style="padding-top:20px;">
      {php}$jzDgCates = $zbp->GetCategoryList();{/php}
      {php}$jzDgI = 0;{/php}
      {if !$jzDgCates}
      <div class="empty-tip">还没有创建分类。</div>
      {else}
      <div class="card-grid">
        {foreach $jzDgCates as $jzDgC}
        {php}$jzDgI++;{/php}
        <a class="glass-card reveal" href="{$jzDgC.Url}">
          <div class="card-top">
            <span class="idx">{php}echo str_pad($jzDgI, 2, '0', STR_PAD_LEFT);{/php}</span>
            <img class="leaf" src="{$host}zb_users/theme/{$theme}/style/images/leaf-2.svg" alt="">
          </div>
          <h3 class="card-title">{$jzDgC.Name}</h3>
          {if $jzDgC.Intro}<p class="card-desc">{$jzDgC.Intro}</p>{/if}
          <span class="card-tag">{$jzDgC.Count} 篇文章</span>
        </a>
        {/foreach}
      </div>
      {/if}
    </div>
  </div>
</main>
{template:footer}
