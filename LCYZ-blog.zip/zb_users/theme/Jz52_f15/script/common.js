/*
 * 极致·十五号 Jz52_f15 - 前台通用脚本
 * 作者：隔壁老李
 */
(function ($) {
    'use strict';

    $(function () {

        $(document).on('click', '.jz-nav > ul > li.has-sub > .down', function (e) {
            if ($(window).width() > 768) { return; }
            e.preventDefault();
            var $sub = $(this).next('.sub-menu');
            if ($sub.length) {
                $sub.stop(true, true).slideToggle(220, function () {
                    $(this).closest('li.has-sub').toggleClass('on', $(this).is(':visible'));
                });
            }
            return false;
        });

        (function () {
            var curUrl = location.href;
            var norm = function (u) { return u.split('#')[0].replace(/\/+$/, ''); };
            $('.jz-nav > ul > li > a').each(function () {
                var href = this.href;
                if (href && norm(href) === norm(curUrl)) {
                    $(this).parent().addClass('active');
                }
            });
        })();

        var $mainNav = $('#jzNav');
        $('#jzMenuToggle').on('click', function () {
            if ($(window).width() > 768) { return; } 
            $mainNav.addClass('is-open');
            $(this).attr('aria-expanded', 'true');
        });
        $('#jzNavClose').on('click', function () {
            $mainNav.removeClass('is-open');
            $(this).attr('aria-expanded', 'false');
        });
        $(document).on('click', function (e) {
            if ($(window).width() <= 768 && $mainNav.hasClass('is-open')
                && !$mainNav.is(e.target) && $mainNav.has(e.target).length === 0
                && !$('#jzMenuToggle').is(e.target) && $('#jzMenuToggle').has(e.target).length === 0) {
                $mainNav.removeClass('is-open');
            }
        });

        var $searchPanel = $('#jzSearch');
        var $searchToggle = $('#jzSearchToggle');
        $searchToggle.on('click', function () {
            $searchPanel.toggleClass('is-open');
            var open = $searchPanel.hasClass('is-open');
            $(this).attr('aria-expanded', open ? 'true' : 'false');
            if (open) { $searchPanel.find('input').trigger('focus'); }
        });
        $(document).on('click', function (e) {
            if ($searchPanel.hasClass('is-open')
                && !$searchPanel.is(e.target) && $searchPanel.has(e.target).length === 0
                && !$searchToggle.is(e.target) && $searchToggle.has(e.target).length === 0) {
                $searchPanel.removeClass('is-open');
                $searchToggle.attr('aria-expanded', 'false');
            }
        });

        var $body = $('body');
        $(document).on('click', '.jz-night-toggle', function () {
            var on = !$body.hasClass('night');
            $body.toggleClass('night', on);
            if (window.zbp && zbp.cookie) {
                zbp.cookie.set('jz15night', on ? '1' : '0', 365);
            }
        });

        var $backTop = $('#jzBackTop');
        var toggleBackTop = function () {
            var y = window.pageYOffset || document.documentElement.scrollTop || 0;
            $backTop.toggleClass('show', y > 300);
        };
        $(window).on('scroll', toggleBackTop);
        toggleBackTop();
        $backTop.on('click', function (e) {
            e.preventDefault();
            $('html, body').animate({ scrollTop: 0 }, 400);
        });

        if ($('#jzSlideSwiper').length && window.Swiper) {
            new Swiper('#jzSlideSwiper', {
                loop: true,
                speed: 600,
                autoplay: { delay: 4500, disableOnInteraction: false },
                pagination: { el: '.swiper-pagination', clickable: true }
            });
        }

        if (window.zbp && zbp.plugin) {
            var $frm = $('#divCommentPost'),
                $cancel = $('#cancel-reply');

            var jzRestoreForm = function () {
                if (!$frm.length) { return; }
                var orig = $frm.data('jz15-orig');
                if (orig && orig.parent) {
                    if (orig.next) {
                        $(orig.next).before($frm);
                    } else {
                        $(orig.parent).append($frm);
                    }
                }
                $frm.removeData('jz15-orig');
                $frm.removeClass('reply-frm');
                $('#inpRevID').val(0);
                $cancel.hide();
                if ($cancel.parent().hasClass('jz-comment-submit') === false) {
                    $('.jz-comment-submit').append($cancel);
                }
            };

            zbp.plugin.unbind('comment.reply.start', 'system');
            zbp.plugin.on('comment.reply.start', 'Jz52_f15', function (i) {
                if (!$frm.length) { return false; }

                if ($frm.hasClass('reply-frm')) {
                    jzRestoreForm();
                }

                if (!$frm.data('jz15-orig')) {
                    $frm.data('jz15-orig', {
                        parent: $frm.parent()[0] || null,
                        next: $frm[0].nextSibling || null
                    });
                }
                $('#inpRevID').val(i);

                var $anchor = $('#AjaxComment' + i);
                if ($anchor.length) {
                    $anchor.before($frm);
                }
                $frm.addClass('reply-frm');
                $cancel.show();
                $cancel.off('click').on('click', function () {
                    jzRestoreForm();
                    return false;
                });
                try { $('#txaArticle').trigger('focus'); } catch (e) {}
                return false;
            });
            zbp.plugin.on('comment.get', 'Jz52_f15', function () {
                $('.jz-comment-page').html('<span class="jz-comment-loading">加载中…</span>');
            });
            zbp.plugin.on('comment.got', 'Jz52_f15', function (formData, data) {
                $('#AjaxCommentBegin').nextUntil('#AjaxCommentEnd').remove();
                $('#AjaxCommentEnd').before(data);
                jzRestoreForm();
            });
            zbp.plugin.on('comment.post.success', 'Jz52_f15', function () {
                jzRestoreForm();
            });
        }

    });
})(jQuery);
