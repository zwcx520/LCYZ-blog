{* Template Name:404 页面 *}
{template:header}
{template:nav}
<main class="jz-main">
	<div class="jz-container">
		<div class="jz-404">
			<div class="jz-404-num">404</div>
			<h2 class="jz-404-title">页面走丢了…</h2>
			<p class="jz-404-text">您访问的页面不存在或已被移除，去别处逛逛吧。</p>
			<div class="jz-404-btns">
				<a href="{$host}" class="jz-404-btn"><i class="fa-solid fa-house"></i> 返回首页</a>
				<a href="javascript:history.back();" class="jz-404-btn"><i class="fa-solid fa-chevron-left"></i> 返回上一页</a>
			</div>
			<div class="jz-404-search">
				<form action="{$host}zb_system/cmd.php?act=search" method="post">
					<input type="hidden" name="csrfToken" value="{$zbp->GetCSRFToken()}">
					<input type="text" name="q" placeholder="搜点什么…">
					<button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
				</form>
			</div>
		</div>
	</div>
</main>
{template:footer}
