{* Template Name:公用头部模块 *}
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
{php}
$jzCfg = $zbp->Config('Jz52_f15');
{/php}
{template:seo}
{$header}
<link rel="stylesheet" href="{$host}zb_users/theme/Jz52_f15/style/style.css?v=2.0.1">
<link rel="stylesheet" href="{$host}zb_users/theme/Jz52_f15/style/css/all.min.css">
<style>
:root{
	--jz-color: {php} echo $jzCfg->color;{/php};
	--jz-header-h: 58px;
}
a{color:var(--jz-color);}
</style>
<script src="{$host}zb_system/script/jquery-2.2.4.min.js"></script>
<script src="{$host}zb_system/script/zblogphp.js?v={$version}"></script>
<script src="{$host}zb_system/script/c_html_js_add.php?{if isset($html_js_hash)}hash={$html_js_hash}&{/if}v={$version}"></script>
<script>window.jz15 = { host: '{$host}', path: '{$host}zb_users/theme/Jz52_f15/' };</script>
</head>
{php}
$jzNight = GetVars('jz15night', 'COOKIE');
$jzIsNight = '1';
if ($jzNight !== null && $jzNight !== '') {
    $jzIsNight = (string) $jzNight === '1' ? '1' : '0';
} else {
    $jzIsNight = (string) $jzCfg->night === '1' ? '1' : '0';
}
$jzBodyClass = 'header-fixed';
$jzBodyClass .= $jzIsNight === '1' ? ' night' : '';
$jzBodyClass .= ' ' . $type;
$jzColumn = (string) $jzCfg->list_column;
$jzBodyClass .= $jzColumn === '1' ? ' one' : ($jzColumn === '2' ? ' two' : ' three');
{/php}
<body class="{$jzBodyClass}">
