{* Template Name:单页分发模板 *}
{template:header}
{template:nav}
{if $type == 'page'}
{template:post-page}
{else}
{template:post-single}
{/if}
