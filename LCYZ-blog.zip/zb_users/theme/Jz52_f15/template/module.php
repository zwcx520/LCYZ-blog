{* Template Name:侧栏模块通用包装 *}
{if isset($module)}
{php}
$jz15Empty = trim((string) $module->Content) === '';
{/php}
<section class="jz-widget {$module.HtmlID}">
	{if !$module.IsHideTitle && $module.Name != ''}
	<h4 class="jz-widget-title"><span>{$module.Name}</span></h4>
	{/if}
	<div class="jz-widget-body">
	{if $jz15Empty}
	<p class="jz-widget-empty">暂无内容</p>
	{elseif $module.Type == 'ul'}
	<ul id="{$module.HtmlID}">{$module.Content}</ul>
	{elseif $module.Type == 'ol'}
	<ol id="{$module.HtmlID}">{$module.Content}</ol>
	{elseif $module.Type == 'dl'}
	<dl id="{$module.HtmlID}">{$module.Content}</dl>
	{else}
	<div id="{$module.HtmlID}">{$module.Content}</div>
	{/if}
	</div>
</section>
{/if}
