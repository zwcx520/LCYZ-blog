{* Template Name:最近发表模块 *}
{php}
$jzPrevContent = isset($module) ? (string) $module->Content : '';
if ($jzPrevContent === '') {
    $jzPrevContent = '<li class="jz15-side-post"><a href="' . $zbp->host . '" title="">暂无文章</a></li>';
    $jzPrevList = $zbp->GetArticleList(array('*'), array(array('=', 'log_Status', 0)), array('log_PostTime' => 'DESC'), array(10), null);
    if (!empty($jzPrevList)) {
        $jzPrevContent = '';
        foreach ($jzPrevList as $jzA) {
            $jzPrevContent .= '<li class="jz15-side-post"><a href="' . $jzA->Url . '" title="' . $jzA->Title . '">' . $jzA->Title . '</a></li>';
        }
    }
}
{/php}
{if isset($module)}
<section class="jz-widget divPrevious">
	{if !$module.IsHideTitle && $module.Name != ''}
	<h4 class="jz-widget-title"><span>{$module.Name}</span></h4>
	{/if}
	<div class="jz-widget-body">
	<ul id="divPrevious">
		{php}echo $jzPrevContent;{/php}
	</ul>
	</div>
</section>
{/if}
