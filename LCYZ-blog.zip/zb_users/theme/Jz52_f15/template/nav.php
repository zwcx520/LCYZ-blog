{* Template Name:顶部导航模块 *}
<header class="jz-header">
	<div class="jz-header-inner">
		<!-- Logo：白天/夜间双 LOGO -->
		<div class="jz-logo">
			{if $jzCfg->logo}<a href="{$host}"><img class="jz-logo-day" src="{$jzCfg->logo}" alt="{$name}"></a>{/if}
			{if $jzCfg->night_logo}<a href="{$host}"><img class="jz-logo-night" src="{$jzCfg->night_logo}" alt="{$name}"></a>{/if}
		</div>

		<!-- 主导航（LinksManage 导航） -->
		<nav class="jz-nav" id="jzNav">
			<button type="button" class="jz-nav-close" id="jzNavClose" aria-label="关闭菜单">×</button>
			<ul class="jz-nav-list">
				{module:navbar}
			</ul>
		</nav>
		<div class="jz-nav-mask"></div>

		<!-- 顶部工具：菜单（移动端）/ 搜索 / 夜间 / 登录管理 -->
		<div class="jz-header-actions">
			<button type="button" class="jz-menu-toggle" id="jzMenuToggle" aria-label="打开菜单"><i class="fa-solid fa-bars"></i></button>
			<button type="button" class="jz-search-toggle" id="jzSearchToggle" aria-label="搜索"><i class="fa-solid fa-magnifying-glass"></i></button>
			<a href="javascript:;" class="jz-night-toggle" id="jzNightToggle" title="切换深浅色"><i class="fa-regular fa-moon"></i></a>
			{if $user.ID != 0}
			<a class="jz-login" href="{$host}zb_system/admin/" rel="nofollow" title="管理后台"><i class="fa-solid fa-gear"></i></a>
			{else}
			<a class="jz-login" href="{$host}zb_system/login.php" rel="nofollow" title="登录"><i class="fa-regular fa-user"></i> 登录</a>
			{/if}
		</div>
	</div>

	<!-- 搜索面板 -->
	<div class="jz-search" id="jzSearch">
		<form name="search" method="post" action="{$host}zb_system/cmd.php?act=search">
			{php}echo '<input type="hidden" name="csrfToken" value="' . $zbp->GetCSRFToken() . '">';{/php}
			<input type="text" name="q" id="edtSearch" placeholder="输入关键词搜索">
			<button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
		</form>
	</div>
</header>
