{* Template Name:单条评论模板 *}
{php}
$jzFloor = (int) $comment->FloorID;
switch ($jzFloor) {
    case 1: $jzFloorTxt = '沙发'; break;
    case 2: $jzFloorTxt = '板凳'; break;
    case 3: $jzFloorTxt = '地板'; break;
    default: $jzFloorTxt = $jzFloor . '#'; break;
}
{/php}
<li class="jz-comment-item" id="cmt{$comment.ID}">
	<div class="jz-comment-avatar">
		<img src="{$comment.Author.Avatar}" alt="{$comment.Author.StaticName}" loading="lazy">
	</div>
	<div class="jz-comment-main">
		<div class="jz-comment-meta">
			<span class="jz-comment-name">{if $comment.Author.HomePage}<a href="{$comment.Author.HomePage}" rel="nofollow" target="_blank">{$comment.Author.StaticName}</a>{else}{$comment.Author.StaticName}{/if}</span>
			{if $comment.Level == '0'}<span class="jz-comment-floor">{$jzFloorTxt}</span>{/if}
			<span class="jz-comment-time">{$comment.Time()}</span>
			<a class="jz-comment-reply" href="#cancel-reply" onclick="zbp.comment.reply('{$comment.ID}')"><i class="fa-solid fa-reply"></i> 回复</a>
		</div>
		<div class="jz-comment-text">
			{if $comment.ParentID != 0}
			{php}$jzParent = $zbp->GetCommentByID($comment->ParentID);{/php}
			{if $jzParent}<a class="jz-comment-at" href="#cmt{$jzParent->ID}">@{if $jzParent->Author->StaticName}{$jzParent->Author->StaticName}{else}游客{/if}</a>{/if}
			{/if}
			{$comment.Content}
		</div>
		{* 回复锚点：位于主楼内容后、楼中楼前，回复表单随系统机制移动至此 *}
		<label id="AjaxComment{$comment.ID}"></label>
		{if count($comment.Comments)}
		<ul class="jz-comment-children">
			{foreach $comment.Comments as $comment}
			{template:comment}
			{/foreach}
		</ul>
		{/if}
	</div>
</li>
