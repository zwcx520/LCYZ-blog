{* Template Name:左侧导航（三栏模式） *}
<div class="jz-left-nav-box">
	<div class="jz-left-nav-title"><i class="fa-solid fa-bars"></i> 栏目导航</div>
	<ul class="jz-left-nav-list">
		<li><a href="{$host}"><i class="fa-solid fa-house"></i> 网站首页</a></li>
		{php}
		$jzLeftNav = trim((string) $jzCfg->left_navigation);
		$jzNavLines = array();
		if ($jzLeftNav !== '') {
		    foreach (explode("\n", $jzLeftNav) as $jzLine) {
		        $jzLine = trim($jzLine);
		        if ($jzLine === '') { continue; }
		        $jzParts = explode('|', $jzLine);
		        if (isset($jzParts[1]) && $jzParts[1] !== '') {
		            $jzNavLines[] = array(
		                'name' => trim($jzParts[0]),
		                'url' => str_replace('{#ZC_BLOG_HOST#}', $zbp->host, trim($jzParts[1])),
		            );
		        }
		    }
		}
		{/php}
		{foreach $jzNavLines as $jzLine}
		<li><a href="{$jzLine['url']}"><i class="fa-solid fa-angle-right"></i> {$jzLine['name']}</a></li>
		{/foreach}
	</ul>
	{if $jzCfg->author_show == '1'}
	<div class="jz-left-nav-author">
		{php}
		$jzAuthName = (string) $jzCfg->author_name;
		$jzAuthAvatar = (string) $jzCfg->author_avatar;
		$jzAuthIntro = (string) $jzCfg->author_intro;
		if ($jzAuthName === '') { $jzAuthName = $zbp->name; }
		if ($jzAuthAvatar === '') { $jzAuthAvatar = $host . 'zb_users/theme/Jz52_f15/style/images/avatar.svg'; }
		if ($jzAuthIntro === '') { $jzAuthIntro = '专注优质内容分享'; }
		echo '<img class="jz-left-nav-avatar" src="' . $jzAuthAvatar . '" alt="' . $jzAuthName . '">'
		    . '<b>' . $jzAuthName . '</b>'
		    . '<p>' . $jzAuthIntro . '</p>';
		{/php}
	</div>
	{/if}
</div>
