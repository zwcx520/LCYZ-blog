{* Template Name:首页幻灯片模块 *}
{php}
$jzSlideOn = (int) $jzCfg->s_slide === 1;
$jzSlides = Jz52_f15_Slider();
{/php}
{if $jzSlideOn && count($jzSlides) > 0}
<div class="jz-slide-wrap">
	<!-- 轮播图 -->
	<div class="jz-slide">
		<div class="swiper-container" id="jzSlideSwiper">
			<div class="swiper-wrapper">
			{foreach $jzSlides as $jzS}
				<div class="swiper-slide">
				{if $jzS['url'] != ''}
					<a href="{$jzS['url']}">
						<img src="{$jzS['img']}" alt="{$jzS['title']}">
						{if $jzS['title'] != ''}<div class="jz-slide-caption"><b>{$jzS['title']}</b></div>{/if}
					</a>
				{else}
					<img src="{$jzS['img']}" alt="{$jzS['title']}">
					{if $jzS['title'] != ''}<div class="jz-slide-caption"><b>{$jzS['title']}</b></div>{/if}
				{/if}
				</div>
			{/foreach}
			</div>
			<div class="swiper-pagination"></div>
		</div>
	</div>
</div>
{/if}
