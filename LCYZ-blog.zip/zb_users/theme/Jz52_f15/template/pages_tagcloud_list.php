{* Template Name:标签云页模板 *}
{template:header}
{template:nav}
{php}$jzColumn = (string) $jzCfg->list_column;{/php}
<main class="jz-main">
	<div class="jz-container">
		{if $jzColumn == '3'}
		<aside class="jz-left-nav">{template:left-nav}</aside>
		{/if}
		<div class="jz-content">
			{template:breadcrumb}
			<div class="jz-tagcloud">
				<h1 class="jz-tagcloud-title"><i class="fa-solid fa-tags"></i> 标签云</h1>
				<div class="jz-tagcloud-body">
					{foreach $tagCloudList as $jzT}
					<a class="jz-tagcloud-item" href="{$jzT->Url}" title="{$jzT->Name}（{$jzT->Count} 篇文章）">{$jzT->Name}<i>{$jzT->Count}</i></a>
					{/foreach}
				</div>
			</div>
			{template:pagebar}
		</div>
		{if $jzColumn != '1'}
		<aside class="jz-sidebar">{template:sidebar2}</aside>
		{/if}
	</div>
</main>
{template:footer}
