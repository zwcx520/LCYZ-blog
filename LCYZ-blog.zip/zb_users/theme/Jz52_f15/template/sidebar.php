{* Template Name:侧栏模板（sidebar2~9 由系统按此模板自动扩展） *}
{foreach $sidebar as $module}
{if $module->HtmlID == 'divComments'}
{template:module-comments}
{elseif $module->HtmlID == 'divPrevious'}
{template:module-previous}
{else}
{template:module}
{/if}
{/foreach}
