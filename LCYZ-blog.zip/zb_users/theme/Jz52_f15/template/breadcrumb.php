{* Template Name:面包屑模块 *}
{php}$jzSearchWord = htmlspecialchars((string) GetVars('q'));{/php}
{if $type != 'index'}
<div class="jz-crumb">
	<i class="fa-solid fa-house"></i>
	<a href="{$host}">首页</a>
	{if $type == 'category'}
		<i class="fa-solid fa-angle-right"></i>
		{if $category->Parent != null}<a href="{$category->Parent->Url}">{$category->Parent->Name}</a><i class="fa-solid fa-angle-right"></i>{/if}
		<span>{$category->Name}</span>
	{elseif $type == 'article'}
		<i class="fa-solid fa-angle-right"></i>
		{if $article->Category != null}<a href="{$article->Category->Url}">{$article->Category->Name}</a><i class="fa-solid fa-angle-right"></i>{/if}
		<span>{$article->Title}</span>
	{elseif $type == 'page'}
		<i class="fa-solid fa-angle-right"></i><span>{$article->Title}</span>
	{elseif $type == 'tag'}
		<i class="fa-solid fa-angle-right"></i><span>标签：{$tag->Name}</span>
	{elseif $type == 'author'}
		<i class="fa-solid fa-angle-right"></i><span>{$author->StaticName} 的文章</span>
	{elseif $type == 'date'}
		<i class="fa-solid fa-angle-right"></i><span>日期归档</span>
	{elseif $type == 'search'}
		<i class="fa-solid fa-angle-right"></i><span>搜索：{$jzSearchWord}</span>
	{elseif $type == 'Tags'}
		<i class="fa-solid fa-angle-right"></i><span>标签云</span>
	{elseif $type == 'TopArticles'}
		<i class="fa-solid fa-angle-right"></i><span>热门文章</span>
	{elseif $type == 'TopComments'}
		<i class="fa-solid fa-angle-right"></i><span>热评文章</span>
	{else}
		<i class="fa-solid fa-angle-right"></i><span>{$title}</span>
	{/if}
</div>
{/if}
