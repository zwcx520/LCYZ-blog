{* Template Name:分页模块 *}
{if $pagebar != null && $pagebar->PageAll > 1}
<div class="jz-pagebar">
	{if $pagebar->PageNow > 1}<a class="jz-page-btn" href="{$pagebar->prevbutton}"><i class="fa-solid fa-angle-left"></i> 上一页</a>{/if}
	{foreach $pagebar->buttons as $jzK => $jzV}
		{if $pagebar->PageNow == $jzK}
		<span class="jz-page-num on">{$jzK}</span>
		{else}
		<a class="jz-page-num" href="{$jzV}">{$jzK}</a>
		{/if}
	{/foreach}
	{if $pagebar->PageNow < $pagebar->PageAll}<a class="jz-page-btn" href="{$pagebar->nextbutton}">下一页 <i class="fa-solid fa-angle-right"></i></a>{/if}
</div>
{/if}
