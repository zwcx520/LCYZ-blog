{* Template Name:评论提交模块 *}
<div class="jz-comment-post" id="divCommentPost">
	<form id="frmSumbit" target="_self" method="post" action="{$article.CommentPostUrl}" class="jz-comment-form">
		<input type="hidden" name="inpId" id="inpId" value="{$article.ID}">
		<input type="hidden" name="inpRevID" id="inpRevID" value="0">
		{if $user.ID > 0}
		<input type="hidden" name="inpName" id="inpName" value="{$user.Name}">
		<input type="hidden" name="inpEmail" id="inpEmail" value="{$user.Email}">
		<input type="hidden" name="inpHomePage" id="inpHomePage" value="{$user.HomePage}">
		{else}
		{if $option['ZC_COMMENT_VERIFY_ENABLE']}
		<div class="jz-comment-fields">
			<div class="jz-comment-field">
				<label for="inpName">昵称 <i>*</i></label>
				<input type="text" name="inpName" id="inpName" class="text" value="" size="28" tabindex="1" maxlength="20">
			</div>
			<div class="jz-comment-field">
				<label for="inpEmail">邮箱</label>
				<input type="text" name="inpEmail" id="inpEmail" class="text" value="" size="28" tabindex="2" maxlength="50">
			</div>
			<div class="jz-comment-field">
				<label for="inpHomePage">网址</label>
				<input type="text" name="inpHomePage" id="inpHomePage" class="text" value="" size="28" tabindex="3" maxlength="100">
			</div>
			<div class="jz-comment-field">
				<label for="inpVerify">验证码 <i>*</i></label>
				<input type="text" name="inpVerify" id="inpVerify" class="text" value="" size="28" tabindex="4" maxlength="6">
				<img class="jz-comment-captcha" src="{$article.ValidCodeUrl}" alt="验证码" title="点击刷新" onclick="this.src='{$article.ValidCodeUrl}&amp;tm='+Math.random();">
			</div>
		</div>
		{else}
		<div class="jz-comment-fields">
			<div class="jz-comment-field">
				<label for="inpName">昵称 <i>*</i></label>
				<input type="text" name="inpName" id="inpName" class="text" value="" size="28" tabindex="1" maxlength="20">
			</div>
			<div class="jz-comment-field">
				<label for="inpEmail">邮箱</label>
				<input type="text" name="inpEmail" id="inpEmail" class="text" value="" size="28" tabindex="2" maxlength="50">
			</div>
			<div class="jz-comment-field">
				<label for="inpHomePage">网址</label>
				<input type="text" name="inpHomePage" id="inpHomePage" class="text" value="" size="28" tabindex="3" maxlength="100">
			</div>
		</div>
		{/if}
		{/if}
		<div class="jz-comment-textarea">
			<textarea name="txaArticle" id="txaArticle" class="text" cols="50" rows="4" tabindex="5" placeholder="说点什么吧…"></textarea>
		</div>
		<div class="jz-comment-submit">
			<button type="submit" name="sumbit" tabindex="6" value="提交评论" onclick="return zbp.comment.post()" class="jz-btn">提交评论</button>
		</div>
	</form>
</div>
