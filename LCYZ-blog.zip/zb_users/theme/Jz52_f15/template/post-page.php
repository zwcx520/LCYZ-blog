{* Template Name:独立页面模板 *}
{php}$jzColumn = (string) $jzCfg->list_column;{/php}
<main class="jz-main">
	<div class="jz-container">
		{if $jzColumn == '3'}
		<aside class="jz-left-nav">{template:left-nav}</aside>
		{/if}
		<div class="jz-content">
			{template:breadcrumb}
			<article class="jz-article">
				<h1 class="jz-article-title">{$article->Title}</h1>
				<div class="jz-article-content">
					{$article->Content}
				</div>
			</article>
			{template:comments}
		</div>
		{if $jzColumn != '1'}
		<aside class="jz-sidebar">{template:sidebar3}</aside>
		{/if}
	</div>
</main>
{template:footer}
