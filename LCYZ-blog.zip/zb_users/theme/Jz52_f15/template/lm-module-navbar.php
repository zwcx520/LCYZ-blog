{* Template Name:导航菜单模块（LinksManage） *}
{if count($item.subs)}<li class="has-sub">{else}<li>{/if}
<a href="{$item.href}" target="{$item.target}" title="{$item.title}">{$item.ico}{$item.text}</a>
{if count($item.subs)}<em class="down"></em>{/if}
{if count($item.subs)}
<ul class="sub-menu">{foreach $item.subs as $item}{template:lm-module-navbar}{/foreach}</ul>
{/if}
</li>
