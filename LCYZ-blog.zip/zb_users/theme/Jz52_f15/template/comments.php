{* Template Name:评论模块 *}
{if isset($socialcomment) && $socialcomment}
{$socialcomment}
{else}
<div class="jz-comment-card">
	<div class="jz-comment-head">
		<h3 class="jz-comment-title">评论 <span>（{$article.CommNums}）</span></h3>
		<a rel="nofollow" id="cancel-reply" href="#divCommentPost" style="display:none;"><small>取消回复</small></a>
	</div>
	<label id="AjaxCommentBegin"></label>
	{if $article.CommNums > 0}
	<ul class="jz-comment-list">
		{foreach $comments as $key => $comment}
		{template:comment}
		{/foreach}
	</ul>
	{/if}
	<label id="AjaxCommentEnd"></label>
	{if $commentspagebar}
	<div class="jz-comment-page">{template:pagebar}</div>
	{/if}
	{template:commentpost}
</div>
{/if}
