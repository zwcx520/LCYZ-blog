{* Template Name:列表文章模板 *}
{php}
$jzShowImg = (int) $jzCfg->listimg === 1;
$jzShowExcerpt = (int) $jzCfg->zhaiyao === 1;
{/php}
<article class="jz-post{if !$jzShowImg} jz-post-noimg{/if}">
	{if $jzShowImg}
	<a class="jz-post-thumb" href="{$article->Url}" title="{$article->Title}">
		{php} echo Jz52_f15_GetImg(Jz52_f15_Thumb($article, 130, 90), $article->Title, 'jz-post-img');{/php}
	</a>
	{/if}
	<div class="jz-post-main">
		<h3 class="jz-post-title"><a href="{$article->Url}" title="{$article->Title}">{$article->Title}</a></h3>
		<div class="jz-post-meta">
			<span class="jz-post-cate"><a href="{$article->Category->Url}">{$article->Category->Name}</a></span>
			<span class="jz-post-date"><i class="fa-regular fa-clock"></i> {php} echo Jz52_f15_DisplayTime($article);{/php}</span>
			<span class="jz-post-views"><i class="fa-regular fa-eye"></i> {php} echo $article->ViewNums;{/php}</span>
			<span class="jz-post-comments"><i class="fa-regular fa-comment"></i> {php} echo $article->CommNums;{/php}</span>
		</div>
		{if $jzShowExcerpt}
		<p class="jz-post-excerpt">{php} echo Jz52_f15_Intro($article, 80);{/php}</p>
		{/if}
	</div>
</article>
