{* Template Name:文章页模板 *}
{php}
$jzAuthor = $article->Author;
$jzTags = $article->Tags;
$jzCate = $article->Category;
$jzPrev = $article->Prev;
$jzNext = $article->Next;
$jzColumn = (string) $jzCfg->list_column;
{/php}
<main class="jz-main">
	<div class="jz-container">
		{if $jzColumn == '3'}
		<aside class="jz-left-nav">{template:left-nav}</aside>
		{/if}

		<div class="jz-content">
			{template:breadcrumb}

			<!-- 文章主体 -->
			<article class="jz-article">
				<header class="jz-article-hd">
					{if $jzCate instanceof Category}<a class="jz-article-cate" href="{$jzCate->Url}">{$jzCate->Name}</a>{/if}
					<h1 class="jz-article-title">{$article->Title}</h1>
					<div class="jz-article-meta">
						<span class="jz-article-author"><i class="fa-regular fa-user"></i> <a href="{$jzAuthor->Url}">{$jzAuthor->StaticName}</a></span>
						<span class="jz-article-date"><i class="fa-regular fa-clock"></i> {php} echo Jz52_f15_DisplayTime($article);{/php}</span>
						<span class="jz-article-views"><i class="fa-regular fa-eye"></i> {php} echo $article->ViewNums;{/php} 阅读</span>
						<span class="jz-article-comments"><i class="fa-regular fa-comment"></i> {php} echo $article->CommNums;{/php} 评论</span>
					</div>
				</header>

				<!-- 正文 -->
				<div class="jz-article-content" id="jzArticleContent">
					{$article->Content}
				</div>

				<!-- 文章标签 -->
				{if count($jzTags) > 0}
				<div class="jz-article-tags">
					<i class="fa-solid fa-tags"></i>
					{foreach $jzTags as $jzT}
					<a href="{$jzT->Url}">{$jzT->Name}</a>
					{/foreach}
				</div>
				{/if}
			</article>

			<!-- 上一篇 / 下一篇 -->
			<div class="jz-prevnext">
				{if $jzPrev instanceof Post}
				<a class="jz-prevnext-item" href="{$jzPrev->Url}">
					<span class="jz-prevnext-tag">上一篇</span>
					<b class="jz-prevnext-title">{$jzPrev->Title}</b>
				</a>
				{else}
				<span class="jz-prevnext-item jz-prevnext-empty"><span class="jz-prevnext-tag">上一篇</span><b class="jz-prevnext-title">没有了</b></span>
				{/if}
				{if $jzNext instanceof Post}
				<a class="jz-prevnext-item jz-prevnext-next" href="{$jzNext->Url}">
					<span class="jz-prevnext-tag">下一篇</span>
					<b class="jz-prevnext-title">{$jzNext->Title}</b>
				</a>
				{else}
				<span class="jz-prevnext-item jz-prevnext-next jz-prevnext-empty"><span class="jz-prevnext-tag">下一篇</span><b class="jz-prevnext-title">没有了</b></span>
				{/if}
			</div>

			<!-- 作者卡（配置式，参照 Jz52_f10） -->
			{if $jzCfg->author_show == '1'}
			<div class="jz-author-card">
				{php}
				$jzAuthName = (string) $jzCfg->author_name;
				$jzAuthAvatar = (string) $jzCfg->author_avatar;
				$jzAuthIntro = (string) $jzCfg->author_intro;
				if ($jzAuthName === '') { $jzAuthName = $jzAuthor->StaticName; }
				if ($jzAuthAvatar === '') { $jzAuthAvatar = $jzAuthor->Avatar; }
				if ($jzAuthIntro === '') { $jzAuthIntro = '这个人很懒，什么都没有留下~'; }
				{/php}
				<img class="jz-author-avatar" src="{php} echo $jzAuthAvatar;{/php}" alt="{$jzAuthName}">
				<div class="jz-author-info">
					<h3>{$jzAuthName}</h3>
					<p>{php} echo $jzAuthIntro;{/php}</p>
				</div>
			</div>
			{/if}

			<!-- 评论 -->
			{template:comments}
		</div>

		{if $jzColumn != '1'}
		<aside class="jz-sidebar">{template:sidebar3}</aside>
		{/if}
	</div>
</main>
{template:footer}
