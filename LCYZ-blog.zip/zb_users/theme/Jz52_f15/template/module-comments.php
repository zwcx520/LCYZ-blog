{* Template Name:最新评论模块 *}
{if isset($module)}
{php}
$jzCmts = $zbp->GetCommentList(
    '',
    array(array('=', 'comm_IsChecking', 0)),
    array('comm_ID' => 'DESC'),
    array(8),
    null
);
{/php}
<section class="jz-widget divComments">
	{if !$module.IsHideTitle && $module.Name != ''}
	<h4 class="jz-widget-title"><span>{$module.Name}</span></h4>
	{/if}
	<div class="jz-widget-body">
	<ul id="divComments">
		{if count($jzCmts) == 0}
		<li class="jz-widget-empty">暂无评论</li>
		{/if}
		{foreach $jzCmts as $jzC}
		<li class="jz-widget-comment">
			{if $jzC->Author->Avatar}<img class="jz-widget-comment-avatar" src="{$jzC->Author->Avatar}" alt="{$jzC->Author->StaticName}">{/if}
			<div class="jz-widget-comment-main">
				<b class="jz-widget-comment-name">{if $jzC->Author->HomePage}<a href="{$jzC->Author->HomePage}" rel="nofollow" target="_blank">{$jzC->Author->StaticName}</a>{else}{$jzC->Author->StaticName}{/if}</b>
				<a class="jz-widget-comment-text" href="{$jzC->Post->Url}#cmt{$jzC->ID}" target="_blank" title="查看原文">{php} echo SubStrUTF8(TransferHTML($jzC->Content, '[nohtml]'), 36);{/php}…</a>
				<span class="jz-widget-comment-time">{$jzC->Time()}</span>
			</div>
		</li>
		{/foreach}
	</ul>
	</div>
</section>
{/if}
