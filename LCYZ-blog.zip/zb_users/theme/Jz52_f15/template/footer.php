{* Template Name:公用底部模块 *}
<footer class="jz-footer">
	<div class="jz-container">
		<div class="jz-footer-copy">
			<p>{$copyright}</p>
			{if $jzCfg->beian != ''}<p class="jz-footer-beian"><a href="https://beian.miit.gov.cn/" rel="nofollow" target="_blank">{$jzCfg->beian}</a></p>{/if}
			{if $jzCfg->footer != ''}<p class="jz-footer-extra">{$jzCfg->footer}</p>{/if}
			
			Powered by <a href="https://www.zblogcn.com/" target="_blank" rel="noopener">Z-BlogPHP</a>
			Theme by <a href="https://app.zbp.cool/" title="不见桃花不见秋" target="_blank">GebiLaoli</a>
		</div>
	</div>
</footer>

<!-- 返回顶部 -->
<a href="javascript:;" class="jz-back-top" id="jzBackTop" title="返回顶部"><i class="fa-solid fa-chevron-up"></i></a>

<!-- 底部脚本 -->
<script src="{$host}zb_users/theme/Jz52_f15/script/swiper.min.js"></script>
<script src="{$host}zb_users/theme/Jz52_f15/script/common.js?v=2.0.1"></script>
{$footer}
</body>
</html>
