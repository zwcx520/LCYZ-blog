{* Template Name:列表页（首页/分类/标签/搜索/热门/热评通用） *}
{template:header}
{template:nav}
{php}$jzColumn = (string) $jzCfg->list_column;{/php}
<main class="jz-main">
	<div class="jz-container">
		{if $jzColumn == '3'}
		<!-- 左侧导航（仅三栏模式） -->
		<aside class="jz-left-nav">
			{template:left-nav}
		</aside>
		{/if}

		<!-- 内容区 -->
		<div class="jz-content">
			{template:breadcrumb}

			<!-- 首页幻灯片 + 右侧推荐 -->
			{if $type == 'index'}
			{template:index-slide}
			{/if}

			<!-- 文章列表 -->
			<div class="jz-post-list" id="jzPostList">
			{foreach $articles as $article}
			{if $article->IsTop}
			{template:post-istop}
			{else}
			{template:post-multi}
			{/if}
			{/foreach}
			</div>

			{template:pagebar}
		</div>

		<!-- 右侧栏（单栏模式不输出） -->
		{if $jzColumn != '1'}
		<aside class="jz-sidebar">
			{if $type == 'index'}
			{template:sidebar}
			{else}
			{template:sidebar2}
			{/if}
		</aside>
		{/if}
	</div>
</main>
{template:footer}
