<?php

if (!defined('ZBP_PATH')) {
    exit('Access Denied');
}

define('JZ52_F15_INCLUDED', 1);

require_once __DIR__ . '/function/common.php';
require_once __DIR__ . '/function/route.php';

RegisterPlugin('Jz52_f15', 'ActivePlugin_Jz52_f15');

function ActivePlugin_Jz52_f15()
{

    Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Jz52_f15_AddMenu');

    Add_Filter_Plugin('Filter_Plugin_Template_Handforward', 'Jz52_f15_TemplateFilter');

    global $zbp;
    if ($zbp->Config('Jz52_f15')->seo && $zbp->Config('Jz52_f15')->nseo) {
        Add_Filter_Plugin('Filter_Plugin_Edit_Response5', 'Jz52_f15_Article_Edit_Response');
        Add_Filter_Plugin('Filter_Plugin_Category_Edit_Response', 'Jz52_f15_Category_Edit_Response');
    }
    Jz52_f15_RegRoute();
}

function Jz52_f15_AddMenu(&$m)
{
    global $zbp;
    $m[] = MakeTopMenu("root", '主题配置', $zbp->host . "zb_users/theme/Jz52_f15/main.php?act=config", "", "topmenu_Jz52_f15", "icon-zblog");
}

function Jz52_f15_SubMenu($act)
{
    $arySubMenu = array(
        0 => array('基本设置', 'config', 'left', false),
        1 => array('SEO设置', 'seo', 'left', false),
        2 => array('关于主题', 'about', 'left', false),
    );
    foreach ($arySubMenu as $v) {
        echo '<a href="?act=' . $v[1] . '" ' . ($v[3] == true ? 'target="_blank"' : '') . '><span class="m-' . $v[2] . ' ' . ($act == $v[1] ? 'm-now' : '') . '">' . $v[0] . '</span></a>';
    }
}

function Jz52_f15_TemplateFilter(&$template)
{
    $name = $template['name'];
    if (in_array($name, array(
        'breadcrumb', 'index-slide', 'nav', 'left-nav', 'pages_tagcloud_list',
    ))) {
        return false;
    }
    return true;
}

function Jz52_f15_Article_Edit_Response()
{
    global $zbp;
    $id = (int) GetVars('id');
    if ($id > 0) {
        $post = $zbp->GetPostByID($id);
        $listimg = (string) $post->Metas->listimg;
        $nrgjc = (string) $post->Metas->nrgjc;
        $nrms = (string) $post->Metas->nrms;
    } else {
        $listimg = '';
        $nrgjc = '';
        $nrms = '';
    }
    $host = $zbp->host;
    echo '<div class="editor_note" style="margin-top:8px;"><p><label>文章封面图</label><br><input name="meta_listimg" id="meta_listimg" class="edit" style="width:75%;" value="' . htmlspecialchars($listimg) . '" placeholder="图片地址，留空自动取正文首图/随机图"><input type="button" class="button" value="浏览文件" onclick="window.open(\'' . $host . 'zb_system/admin/upload.php?inpId=meta_listimg\',\'upload\',\'width=600,height=400\')"></p></div>';
    echo '<table width="99%"><tr><td width="20%">关键词(主题自带SEO)</td><td width="80%"><input style="width:95%" name="meta_nrgjc" value="' . htmlspecialchars($nrgjc) . '"/></td></tr>'
        . '<tr><td>描述(主题自带SEO)</td><td><input style="width:95%" name="meta_nrms" value="' . htmlspecialchars($nrms) . '"/></td></tr></table>';
}

function Jz52_f15_Category_Edit_Response()
{
    global $zbp;
    $id = (int) GetVars('id');
    $cate = $zbp->categorys[$id];
    $flbt = (string) $cate->Metas->flbt;
    $flgjc = (string) $cate->Metas->flgjc;
    echo '<p><span class="title">标题:（主题自带SEO）</span><br /><input style="width:95%" name="meta_flbt" value="' . htmlspecialchars($flbt) . '"/></p>'
        . '<p><span class="title">关键词:（主题自带SEO）</span><br /><input style="width:95%" name="meta_flgjc" value="' . htmlspecialchars($flgjc) . '"/></p>';
}

function InstallPlugin_Jz52_f15()
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_f15');
    if (!$cfg->HasKey('Version')) {
        $host = $zbp->host;
        $tUrl = 'zb_users/theme/Jz52_f15/';
        $defaults = array(
            'Version' => '2.0.0',
            'logo' => $host . $tUrl . 'style/images/logo.png',
            'night_logo' => $host . $tUrl . 'style/images/nightlogo.png',
            'color' => '#0084ff',
            'night' => '0',
            'listimg' => '1',
            'thumbnail' => 'b',
            'zhaiyao' => '1',
            'beian' => '',
            'footer' => '',
            'author_show' => '1',
            'author_name' => '',
            'author_avatar' => '',
            'author_intro' => '',
            'seo' => '1',
            'nseo' => '0',
            'seotitle' => '',
            'seokeywords' => '',
            'seodescription' => '',
            's_slide' => '1',
            'slide_img1' => '',
            'slide_img2' => '',
            'slide_img3' => '',
            'list_column' => '3',
            'left_navigation' => "热门文章|{#ZC_BLOG_HOST#}pages/toparticles.html\n热评文章|{#ZC_BLOG_HOST#}pages/topcomments.html\n标签云|{#ZC_BLOG_HOST#}pages/tagcloud.html",
            'Page_Tags_List' => '{%host%}pages/tagcloud_{%page%}.html',
            'Page_TopArticles_List' => '{%host%}pages/toparticles_{%page%}.html',
            'Page_TopComments_List' => '{%host%}pages/topcomments_{%page%}.html',
            'DelConfig' => '0',
        );
        foreach ($defaults as $key => $val) {
            $cfg->$key = $val;
        }
        $zbp->SaveConfig('Jz52_f15');
    }
}

function UninstallPlugin_Jz52_f15()
{
    global $zbp;
    if ($zbp->Config('Jz52_f15')->DelConfig) {
        $zbp->DelConfig('Jz52_f15');
    }
}
