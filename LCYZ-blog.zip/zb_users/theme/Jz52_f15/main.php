<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action = 'root';
if (!$zbp->CheckRights($action)) {
    $zbp->ShowError(6);
    die();
}
if (!$zbp->CheckPlugin('Jz52_f15')) {
    $zbp->ShowError(48);
    die();
}

$blogtitle = '主题配置';
$act = 'config';
if (isset($_GET['act']) && $_GET['act'] != '') {
    $act = $_GET['act'];
}
if (!in_array($act, array('config', 'seo', 'about'))) {
    $act = 'config';
}

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<style>
.jz-cfg .jz-tip { background: #f0f4ff; border: 1px solid #d6e0ff; color: #3a5fc8; padding: 10px 14px; margin: 14px 0; line-height: 1.8; }
.jz-cfg .jz-tip a { color: #2f54b8; text-decoration: underline; }
.jz-cfg table td { padding: 10px 8px; vertical-align: top; }
.jz-cfg table th { background: #f7f8fa; padding: 10px 8px; }
.jz-cfg .jz-desc { color: #888; font-size: 12px; line-height: 1.7; }
.jz-cfg input[type="text"], .jz-cfg textarea, .jz-cfg select { width: 95%; max-width: 560px; height:26px}
.jz-cfg input[type="radio"] { margin-right: 4px; }
</style>
<div id="divMain">
    <div class="divHeader"><?php echo $blogtitle; ?></div>
    <div class="SubMenu"><?php Jz52_f15_SubMenu($act); ?><a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc"><span class="m-right">更多应用</span></a><a href="https://gebilaoli.com" target="_blank"><span class="m-right">作者网站</span></a></div>
    <div id="divMain2">
        <div class="jz-cfg">
            <?php if ($act == 'config') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_f15');
                $cfg->logo = trim((string) $_POST['logo']);
                $cfg->night_logo = trim((string) $_POST['night_logo']);
                $cfg->color = trim((string) $_POST['color']);
                $cfg->night = (string) intval($_POST['night']);
                $cfg->listimg = isset($_POST['listimg']) && $_POST['listimg'] == '1' ? '1' : '0';
                $cfg->thumbnail = (string) $_POST['thumbnail'];
                $cfg->zhaiyao = isset($_POST['zhaiyao']) && $_POST['zhaiyao'] == '1' ? '1' : '0';
                $cfg->beian = trim((string) $_POST['beian']);
                $cfg->footer = trim((string) $_POST['footer']);
                $cfg->author_show = isset($_POST['author_show']) && $_POST['author_show'] == '1' ? '1' : '0';
                $cfg->author_name = trim((string) $_POST['author_name']);
                $cfg->author_avatar = trim((string) $_POST['author_avatar']);
                $cfg->author_intro = trim((string) $_POST['author_intro']);
                $cfg->s_slide = isset($_POST['s_slide']) && $_POST['s_slide'] == '1' ? '1' : '0';
                $cfg->slide_img1 = trim((string) $_POST['slide_img1']);
                $cfg->slide_img2 = trim((string) $_POST['slide_img2']);
                $cfg->slide_img3 = trim((string) $_POST['slide_img3']);
                $cfg->list_column = (string) $_POST['list_column'];
                $cfg->left_navigation = trim((string) $_POST['left_navigation']);
                $cfg->DelConfig = isset($_POST['DelConfig']) && $_POST['DelConfig'] == '1' ? '1' : '0';
                $zbp->SaveConfig('Jz52_f15');
                $zbp->SetHint('good');
                Redirect('./main.php?act=config');
            }
            $cfg = $zbp->Config('Jz52_f15');
            ?>
            <form id="form1" name="form1" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr>
                        <td align="center"><p>网站 LOGO</p></td>
                        <td><p><?php ZbpForm::text('logo', htmlspecialchars($cfg->logo), '95%', 'https://…'); ?></p></td>
                        <td><p class="jz-desc">图片 URL，留空则不显示</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>夜间 LOGO</p></td>
                        <td><p><?php ZbpForm::text('night_logo', htmlspecialchars($cfg->night_logo), '95%', 'https://…'); ?></p></td>
                        <td><p class="jz-desc">夜间模式下的 LOGO，图片 URL</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>主题强调色</p></td>
                        <td><p><?php ZbpForm::text('color', htmlspecialchars($cfg->color), '95%', '#0084ff'); ?></p></td>
                        <td><p class="jz-desc">链接与按钮强调色，如：#0084ff</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>默认配色</p></td>
                        <td><p><?php ZbpForm::radio('night', array('浅色', '深色'), (int) $cfg->night); ?></p></td>
                        <td><p class="jz-desc">站点默认深浅色，访客可在页头按钮切换（Cookie 记住选择）</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>列表显示缩略图</p></td>
                        <td><p><?php ZbpForm::radio('listimg', array('否', '是'), (int) $cfg->listimg); ?></p></td>
                        <td><p class="jz-desc">启用后文章列表显示缩略图</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>缩略图模式</p></td>
                        <td><p><?php ZbpForm::select('thumbnail', array('a' => '不裁剪（原图）', 'b' => '裁剪（生成缩略图）'), $cfg->thumbnail); ?></p></td>
                        <td><p class="jz-desc">裁剪模式性能更好、排版更统一</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>列表显示摘要</p></td>
                        <td><p><?php ZbpForm::radio('zhaiyao', array('否', '是'), (int) $cfg->zhaiyao); ?></p></td>
                        <td><p class="jz-desc">文章列表显示正文摘要</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>首页幻灯片</p></td>
                        <td><p><?php ZbpForm::radio('s_slide', array('否', '是'), (int) $cfg->s_slide); ?></p></td>
                        <td><p class="jz-desc">首页顶部轮播图开关</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>幻灯片图片 1</p></td>
                        <td><p><?php ZbpForm::text('slide_img1', htmlspecialchars($cfg->slide_img1), '95%', 'https://…，留空使用内置 Banner'); ?></p></td>
                        <td rowspan="3"><p class="jz-desc">轮播图 URL（建议宽度 1200+，高度比例 16:9 左右）。三张全部留空则使用主题内置 Banner 图</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>幻灯片图片 2</p></td>
                        <td><p><?php ZbpForm::text('slide_img2', htmlspecialchars($cfg->slide_img2), '95%', 'https://…，留空使用内置 Banner'); ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>幻灯片图片 3</p></td>
                        <td><p><?php ZbpForm::text('slide_img3', htmlspecialchars($cfg->slide_img3), '95%', 'https://…，留空使用内置 Banner'); ?></p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>整体布局</p></td>
                        <td><p><?php ZbpForm::select('list_column', array('1' => '单栏', '2' => '两栏（内容+侧栏）', '3' => '三栏（左导航+内容+侧栏）'), $cfg->list_column); ?></p></td>
                        <td><p class="jz-desc">三栏为自媒体资讯布局，两栏适合传统博客</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>左侧导航栏目</p></td>
                        <td><p><?php ZbpForm::textarea('left_navigation', htmlspecialchars($cfg->left_navigation), '95%', '120px', '每行：名称|链接，{#ZC_BLOG_HOST#} 代表站点地址'); ?></p></td>
                        <td><p class="jz-desc">三栏模式下左侧导航的自定义栏目，每行一条：名称|链接</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>显示作者卡片</p></td>
                        <td><p><?php ZbpForm::radio('author_show', array('否', '是'), (int) $cfg->author_show); ?></p></td>
                        <td><p class="jz-desc">文章底部显示作者介绍卡片</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>作者昵称</p></td>
                        <td><p><?php ZbpForm::text('author_name', htmlspecialchars($cfg->author_name), '95%', '留空则使用文章作者名'); ?></p></td>
                        <td><p class="jz-desc">作者卡片显示的名称，留空则使用文章作者名</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>作者头像</p></td>
                        <td><p><?php ZbpForm::text('author_avatar', htmlspecialchars($cfg->author_avatar), '95%', 'https://…'); ?></p></td>
                        <td><p class="jz-desc">作者卡片头像 URL，留空则使用默认头像</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>作者简介</p></td>
                        <td><p><?php ZbpForm::textarea('author_intro', htmlspecialchars($cfg->author_intro), '95%', '80px', '一句话介绍，显示在作者卡片中'); ?></p></td>
                        <td><p class="jz-desc">一句话介绍，显示在作者卡片中</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>备案号</p></td>
                        <td><p><?php ZbpForm::text('beian', htmlspecialchars($cfg->beian), '95%', '鲁ICP备00000000号'); ?></p></td>
                        <td><p class="jz-desc">填写后页脚显示备案链接</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>页脚自定义内容</p></td>
                        <td><p><?php ZbpForm::textarea('footer', htmlspecialchars($cfg->footer), '95%', '80px', '纯文本或简单 HTML，显示在页脚'); ?></p></td>
                        <td><p class="jz-desc">纯文本或简单 HTML，显示在页脚</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>清除主题配置</p></td>
                        <td><p><?php ZbpForm::radio('DelConfig', array('否', '是'), (int) $cfg->DelConfig); ?></p></td>
                        <td><p class="jz-desc">启用后切换主题将清空主题配置</p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'seo') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_f15');
                $cfg->seo = isset($_POST['seo']) && $_POST['seo'] == '1' ? '1' : '0';
                $cfg->nseo = isset($_POST['nseo']) && $_POST['nseo'] == '1' ? '1' : '0';
                $cfg->seotitle = trim((string) $_POST['seotitle']);
                $cfg->seokeywords = trim((string) $_POST['seokeywords']);
                $cfg->seodescription = trim((string) $_POST['seodescription']);
                $zbp->SaveConfig('Jz52_f15');
                $zbp->SetHint('good');
                Redirect('./main.php?act=seo');
            }
            $cfg = $zbp->Config('Jz52_f15');
            ?>
            <div class="jz-tip">主题自带基础 SEO：可为首页设置标题/关键词/描述，为文章和分类设置独立关键词与描述。若已安装独立 SEO 插件，请关闭以下开关避免冲突。</div>
            <form id="form2" name="form2" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr>
                        <td align="center"><p>启用主题 SEO</p></td>
                        <td><p><?php ZbpForm::radio('seo', array('否', '是'), (int) $cfg->seo); ?></p></td>
                        <td><p class="jz-desc">使用主题自带的标题、关键词、描述输出</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>文章/分类自定义 SEO</p></td>
                        <td><p><?php ZbpForm::radio('nseo', array('否', '是'), (int) $cfg->nseo); ?></p></td>
                        <td><p class="jz-desc">在文章编辑页与分类编辑页增加关键词、描述字段</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>首页标题</p></td>
                        <td><p><?php ZbpForm::text('seotitle', htmlspecialchars($cfg->seotitle), '95%', '留空则使用网站名称'); ?><?php if ($zbp->subname) { ?> <span class="jz-desc">- <?php echo htmlspecialchars($zbp->subname); ?></span><?php } ?></p></td>
                        <td><p class="jz-desc">留空则使用网站名称</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>首页关键词</p></td>
                        <td><p><?php ZbpForm::text('seokeywords', htmlspecialchars($cfg->seokeywords), '95%', '多个关键词用英文逗号隔开'); ?></p></td>
                        <td><p class="jz-desc">多个关键词用英文逗号隔开</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>首页描述</p></td>
                        <td><p><?php ZbpForm::textarea('seodescription', htmlspecialchars($cfg->seodescription), '95%', '80px', '一段话描述网站内容'); ?></p></td>
                        <td><p class="jz-desc">一段话描述网站内容</p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'about') { ?>
            <div class="jz-tip">
                <h3>「极致·十五号」自媒体资讯主题</h3>
                <p>一款三栏资讯布局的 Z-BlogPHP 主题，功能精简实用：</p>
                <p>· 三栏/两栏/单栏布局切换，自媒体左导航<br />
                · 首页幻灯片轮播（自定义图片）<br />
                · 标签云/热门/热评独立伪静态页<br />
                · 深浅色双主题，Cookie 记住选择<br />
                · 内置基础 SEO，文章/分类独立关键词<br />
                · 系统侧栏模块统一样式，评论回复抓取表单<br />
                · 全响应式，移动端抽屉导航</p>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_f15");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
