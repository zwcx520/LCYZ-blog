<?php
# Jz52_f15 伪静态路由处理
# 三条自定义路由：标签云 / 热门文章 / 热评文章
# 路由规则存于 Config（Page_Tags_List / Page_TopArticles_List / Page_TopComments_List）

if (!defined('ZBP_PATH')) {
    exit('Access Denied');
}

# ===== 注册三条路由 =====
function Jz52_f15_RegRoute()
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_f15');

    # 标签云
    $zbp->RegRoute(array(
        'posttype' => null,
        'type' => 'rewrite',
        'name' => 'jz15_tags_list',
        'call' => 'Jz52_f15_GetTagCloud_List',
        'urlrule' => $cfg->Page_Tags_List,
        'args' => array('page' => '[0-9]*'),
    ));

    # 热门文章
    $zbp->RegRoute(array(
        'posttype' => null,
        'type' => 'rewrite',
        'name' => 'jz15_toparticles_list',
        'call' => 'Jz52_f15_GetTopArticles_List',
        'urlrule' => $cfg->Page_TopArticles_List,
        'args' => array('page' => '[0-9]*'),
    ));

    # 热评文章
    $zbp->RegRoute(array(
        'posttype' => null,
        'type' => 'rewrite',
        'name' => 'jz15_topcomments_list',
        'call' => 'Jz52_f15_GetTopComments_List',
        'urlrule' => $cfg->Page_TopComments_List,
        'args' => array('page' => '[0-9]*'),
    ));
}

# ===== 标签云 =====
function Jz52_f15_GetTagCloud_List($args)
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_f15');
    $type = 'Tags';
    $currentPage = isset($args['page']) ? (int) $args['page'] : 1;

    $pagebar = new Pagebar($cfg->Page_Tags_List, false);
    $perPage = 50;
    $pagebar->PageCount = $perPage;
    $pagebar->PageNow = $currentPage;
    $pagebar->PageBarCount = $zbp->pagebarcount;

    $where = '';
    $order = array('tag_ID' => 'DESC');
    $array = $zbp->GetTagList(
        '',
        $where,
        $order,
        array(($pagebar->PageNow - 1) * $pagebar->PageCount, $pagebar->PageCount),
        array('pagebar' => $pagebar)
    );

    $zbp->template->SetTags('pagebar', $pagebar);
    $zbp->template->SetTags('tagCloudList', $array);
    $zbp->template->SetTags('type', $type);
    $zbp->template->Display('pages_tagcloud_list');
}

# ===== 热门文章 =====
function Jz52_f15_GetTopArticles_List($args)
{
    global $zbp;
    $type = 'TopArticles';
    $currentPage = isset($args['page']) ? (int) $args['page'] : 1;

    $pagebar = new Pagebar($zbp->Config('Jz52_f15')->Page_TopArticles_List, false);
    $pagebar->PageCount = $zbp->option['ZC_DISPLAY_COUNT'];
    $pagebar->PageNow = $currentPage;
    $pagebar->PageBarCount = $zbp->pagebarcount;

    $where = array(array('=', 'log_Type', '0'), array('=', 'log_Status', '0'));
    $order = array('log_ViewNums' => 'DESC');
    $array = $zbp->GetPostList(
        '',
        $where,
        $order,
        array(($pagebar->PageNow - 1) * $pagebar->PageCount, $pagebar->PageCount),
        array('pagebar' => $pagebar)
    );

    $zbp->template->SetTags('pagebar', $pagebar);
    $zbp->template->SetTags('articles', $array);
    $zbp->template->SetTags('type', $type);
    $zbp->template->Display('index');
}

# ===== 热评文章 =====
function Jz52_f15_GetTopComments_List($args)
{
    global $zbp;
    $type = 'TopComments';
    $currentPage = isset($args['page']) ? (int) $args['page'] : 1;

    $pagebar = new Pagebar($zbp->Config('Jz52_f15')->Page_TopComments_List, false);
    $pagebar->PageCount = $zbp->option['ZC_DISPLAY_COUNT'];
    $pagebar->PageNow = $currentPage;
    $pagebar->PageBarCount = $zbp->pagebarcount;

    $where = array(array('=', 'log_Type', '0'), array('=', 'log_Status', '0'));
    $order = array('log_CommNums' => 'DESC');
    $array = $zbp->GetPostList(
        '',
        $where,
        $order,
        array(($pagebar->PageNow - 1) * $pagebar->PageCount, $pagebar->PageCount),
        array('pagebar' => $pagebar)
    );

    $zbp->template->SetTags('pagebar', $pagebar);
    $zbp->template->SetTags('articles', $array);
    $zbp->template->SetTags('type', $type);
    $zbp->template->Display('index');
}
