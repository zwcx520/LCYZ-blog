<?php
# Jz52_f15 公共函数（f10 精简版）：图片、时间、链接、侧栏数据

if (!defined('ZBP_PATH')) {
    exit('Access Denied');
}

function Jz52_f15_Url($file = '')
{
    global $zbp;
    return $zbp->host . 'zb_users/theme/Jz52_f15/' . ltrim($file, '/');
}

function Jz52_f15_GetImg($url, $alt = '', $class = '')
{
    return '<img src="' . $url . '" alt="' . $alt . '" class="' . $class . '">';
}

function Jz52_f15_Thumb($article, $w = 0, $h = 0)
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_f15');
    $img = '';
    if ((string) $cfg->thumbnail == 'a') {
        $img = trim((string) $article->Metas->listimg);
        if ($img === '') {
            $allImages = $article->AllImages;
            if (is_array($allImages) && count($allImages) > 0) {
                $img = (string) $allImages[0];
            }
        }
        if ($img === '') {
            $img = Jz52_f15_Ran_Img();
        }
    } else {
        $listimg = trim((string) $article->Metas->listimg);
        if ($listimg !== '') {
            $t = Thumb::Thumbs(array($listimg), $w, $h, 1, true);
            if (isset($t[0]) && $t[0] !== '') {
                $img = $t[0];
            }
        }
        if ($img === '') {
            $t = $article->Thumbs($w, $h, 1);
            if (isset($t[0]) && $t[0] !== '') {
                $img = $t[0];
            }
        }
        if ($img === '') {
            $t = Thumb::Thumbs(array(Jz52_f15_Ran_Img()), $w, $h, 1, true);
            if (isset($t[0]) && $t[0] !== '') {
                $img = $t[0];
            }
        }
    }
    return $img;
}

function Jz52_f15_Ran_Img()
{
    return Jz52_f15_Url('style/images/rand/' . mt_rand(1, 5) . '.jpg');
}

function Jz52_f15_Intro($article, $len = 100)
{
    $text = trim(preg_replace('/\s(?=\s)/', '', trim(SubStrUTF8(TransferHTML($article->Content, '[nohtml]'), $len))));
    return $text . '...';
}

function Jz52_f15_DisplayTime($post)
{
    return date('Y-m-d', (int) $post->PostTime);
}

function Jz52_f15_Slider()
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_f15');
    $slides = array();
    $base = Jz52_f15_Url('style/images/');
    for ($i = 1; $i <= 3; $i++) {
        $key = 'slide_img' . $i;
        $img = trim((string) $cfg->$key);
        if ($img === '') {
            $img = $base . 'banner-' . $i . '.jpg';
        }
        $slides[] = array(
            'img' => $img,
            'title' => '',
            'url' => '',
        );
    }
    return $slides;
}
