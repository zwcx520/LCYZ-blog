<?php
if (!defined('ZBP_PATH')) {exit('Access denied');}

RegisterPlugin("Jz52_Fuwari", "ActivePlugin_Jz52_Fuwari");

function ActivePlugin_Jz52_Fuwari()
{
    global $zbp;
    # 自定义模块：创建/刷新/删除
    Add_Filter_Plugin('Filter_Plugin_Misc_Begin', 'Jz52_Fuwari_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostModule_Succeed', 'Jz52_Fuwari_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostComment_Succeed', 'Jz52_Fuwari_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostComment_Del', 'Jz52_Fuwari_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostArticle_Succeed', 'Jz52_Fuwari_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_PostArticle_Del', 'Jz52_Fuwari_Event_CreateModule');
    Add_Filter_Plugin('Filter_Plugin_Zbp_Load', 'Jz52_Fuwari_Module_Load');
    # 文章/分类/标签编辑页：封面与 SEO 自定义字段
    Add_Filter_Plugin('Filter_Plugin_Edit_Response5', 'Jz52_Fuwari_Edit_Response5');
    Add_Filter_Plugin('Filter_Plugin_Category_Edit_Response', 'Jz52_Fuwari_Category_Edit_Response');
    Add_Filter_Plugin('Filter_Plugin_Tag_Edit_Response', 'Jz52_Fuwari_Tag_Edit_Response');
    # 归档/标签页缓存：文章/页面/标签增删改时自动失效
    Add_Filter_Plugin('Filter_Plugin_PostArticle_Succeed', 'Jz52_Fuwari_cache_clear');
    Add_Filter_Plugin('Filter_Plugin_PostArticle_Del', 'Jz52_Fuwari_cache_clear');
    Add_Filter_Plugin('Filter_Plugin_PostPage_Succeed', 'Jz52_Fuwari_cache_clear');
    Add_Filter_Plugin('Filter_Plugin_PostPage_Del', 'Jz52_Fuwari_cache_clear');
    Add_Filter_Plugin('Filter_Plugin_PostTag_Succeed', 'Jz52_Fuwari_cache_clear');
    Add_Filter_Plugin('Filter_Plugin_PostTag_Del', 'Jz52_Fuwari_cache_clear');
    # 后台顶部菜单
    Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Jz52_Fuwari_AddMenu');
}

# 阅读数友好显示
function Jz52_Fuwari_num($num)
{
    if ($num >= 10000) {
        return round($num / 10000, 1) . 'w';
    }
    if ($num >= 1000) {
        return round($num / 1000, 1) . 'k';
    }
    return $num;
}

# 列表摘要：纯文本，空时截取正文
function Jz52_Fuwari_excerpt($article, $len = 120)
{
    $intro = '';
    if ($article->Intro != '') {
        $intro = trim(TransferHTML($article->Intro, '[nohtml]'));
        $intro = preg_replace('/\s+/u', ' ', $intro);
    }
    if ($intro == '') {
        $intro = trim(TransferHTML($article->Content, '[nohtml]'));
        $intro = preg_replace('/\s+/u', ' ', $intro);
        $intro = SubStrUTF8_Start($intro, 0, $len);
    }
    return $intro;
}

# 文章封面图：自定义封面优先，其次系统
function Jz52_Fuwari_IMG($article, $w = 480, $h = 320)
{
    if ($article->Metas->Jzzdimg) {
        return $article->Metas->Jzzdimg;
    }
    if ($article->ImageCount > 0) {
        $Thumb = $article->Thumbs($w, $h, 1, false);
        if (isset($Thumb[0]) && $Thumb[0]) {
            return $Thumb[0];
        }
        return $article->AllImages[0];
    }
    return Jz52_Fuwari_ranIMG($article->ID);
}

#随机缩略图（目录列表静态缓存，避免每次调用扫描磁盘）
function Jz52_Fuwari_ranIMG($id = 0)
{
    global $zbp, $blogpath;
	static $files = null;
    if ($files === null) {
		$dir = $blogpath.'zb_users/theme/Jz52_Fuwari/assets/images/random/';
        $files = array();
        if (is_dir($dir)) {
            foreach (scandir($dir) as $file) {
                if (pathinfo($file, PATHINFO_EXTENSION) == 'jpg') {
                    $files[] = $file;
                }
            }
        }
    }
    if (count($files) > 0) {
        return $zbp->host . 'zb_users/theme/Jz52_Fuwari/assets/images/random/' . $files[$id % count($files)];
    }
    return $zbp->host . 'zb_users/theme/Jz52_Fuwari/assets/images/noimg.svg';
}

# 社交图标映射
function Jz52_Fuwari_social()
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_Fuwari');
    $map = array(
        'github' => 'ri-github-fill', 'qq' => 'ri-qq-fill', 'wechat' => 'ri-wechat-fill',
        'weibo' => 'ri-weibo-line', 'bilibili' => 'ri-bilibili-fill', 'twitter' => 'ri-twitter-x-line',
        'telegram' => 'ri-telegram-fill', 'youtube' => 'ri-youtube-fill', 'instagram' => 'ri-instagram-line',
        'facebook' => 'ri-facebook-circle-fill', 'google' => 'ri-google-fill', 'steam' => 'ri-steam-fill',
        'discord' => 'ri-discord-fill', 'spotify' => 'ri-spotify-fill', 'netease' => 'ri-netease-cloud-music-line',
        'xiami' => 'ri-cloud-line', 'tencent' => 'ri-qq-fill', 'kugou' => 'ri-music-2-line',
        'baidu' => 'ri-baidu-line', 'apple' => 'ri-apple-fill', 'android' => 'ri-android-fill',
        'zhihu' => 'ri-zhihu-line', 'douban' => 'ri-douban-line', 'mail' => 'ri-mail-line',
        'link' => 'ri-link', 'rss' => 'ri-rss-fill', 'global' => 'ri-global-line',
    );
    $lines = preg_split('/[\r\n]+/', (string) $cfg->profile_social, -1, PREG_SPLIT_NO_EMPTY);
    foreach ($lines as $line) {
        $p = explode('|', $line);
        $platform = trim(isset($p[0]) ? $p[0] : '');
        $name = trim(isset($p[1]) ? $p[1] : '');
        $url = trim(isset($p[2]) ? $p[2] : '');
        if (!$platform || !$url) {
            continue;
        }
        $cls = isset($map[$platform]) ? $map[$platform] : 'ri-sparkling-2-fill';
        echo '<a class="btn-regular size-10 rounded-lg active:scale-90" href="' . htmlspecialchars($url) . '" title="' . htmlspecialchars($name ? $name : $platform) . '" target="_blank" rel="noopener"><i class="' . $cls . ' text-[1.25rem]" aria-hidden="true"></i></a>';
    }
}

# 个人资料卡
function Jz52_Fuwari_profile_html()
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_Fuwari');
    $avatar = $cfg->profile_avatar ? $cfg->profile_avatar : $zbp->host . 'zb_users/theme/Jz52_Fuwari/assets/images/demo-avatar.png';
    $name = $cfg->profile_name ? $cfg->profile_name : $zbp->name;
    $bio = $cfg->profile_bio ? $cfg->profile_bio : $zbp->subname;
    $url = $cfg->profile_url ? $cfg->profile_url : $zbp->host;
    $str = '';
    $str .= '<div class="card-base p-3">';
    $str .= '<a aria-label="Profile" href="' . htmlspecialchars($url) . '" class="group relative mx-auto mb-3 mt-1 block max-w-[12rem] overflow-hidden rounded-xl active:scale-95 lg:mx-0 lg:mt-0 lg:max-w-none">';
    $str .= '<div class="pointer-events-none absolute z-50 flex h-full w-full items-center justify-center transition group-hover:bg-black/30 group-active:bg-black/50">'
        . '<i class="ri-profile-line scale-90 text-5xl text-white opacity-0 transition group-hover:scale-100 group-hover:opacity-100" aria-hidden="true"></i></div>';
    $str .= '<div class="mx-auto aspect-square h-full lg:mt-0 lg:w-full overflow-hidden relative">';
    $str .= '<div class="pointer-events-none absolute inset-0 bg-black/10 transition dark:bg-black/10"></div>';
    $str .= '<img src="' . htmlspecialchars($avatar) . '" alt="' . htmlspecialchars($name) . '" class="h-full w-full object-cover" loading="lazy"/>';
    $str .= '</div></a>';
    $str .= '<div class="px-2">';
    $str .= '<div class="mb-1 text-center text-xl font-bold text-black/90 transition dark:text-neutral-50">' . htmlspecialchars($name) . '</div>';
    $str .= '<div class="mx-auto mb-2 h-1 w-5 rounded-full bg-(--primary) transition"></div>';
    $str .= '<div class="mb-2.5 text-center text-neutral-400 transition">' . htmlspecialchars($bio) . '</div>';
    $str .= '<div class="mb-1 flex flex-wrap justify-center gap-2">';
    ob_start();
    Jz52_Fuwari_social();
    $social = ob_get_clean();
    if ($social) {
        $str .= $social;
    }
    $str .= '</div></div></div>';
    return $str;
}

# 侧栏自定义模块（音乐）
function Jz52_Fuwari_Event_CreateModule()
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_Fuwari');
    $module_list = array();
    # 音乐部件：启用则创建/更新，关闭则删除
    if ($cfg->music_enable === '' || $cfg->music_enable == '1') {
        $module_list[] = array('jz52_fuwari_music', 'widget-music', 'div', '音乐', '0');
    } else {
        $delmods = $zbp->GetModuleList(array('*'), array(array('IN', 'mod_FileName', array('jz52_fuwari_music'))));
        foreach ($delmods as $delmod) {
            $delmod->Del();
        }
    }

    if (!$module_list) {
        return;
    }
    $module_filenames = array();
    foreach ($module_list as $item) {
        array_push($module_filenames, $item[0]);
    }
    $modules = $zbp->GetModuleList(array('*'), array(array('IN', 'mod_FileName', $module_filenames)));
    $has_modules = array();
    foreach ($modules as $item) {
        $item->Content = Jz52_Fuwari_Event_SideContent($item);
        $item->Save();
        array_push($has_modules, $item->FileName);
    }
    foreach ($module_filenames as $k => $item) {
        if (!in_array($item, $has_modules)) {
            $module = $module_list[$k];
            $t = new Module();
            $t->Name = $module[3];
            $t->IsHideTitle = $module[4];
            $t->FileName = $module[0];
            $t->Source = "theme_Jz52_Fuwari";
            $t->SidebarID = 0;
            $t->Content = Jz52_Fuwari_Event_SideContent($t);
            $t->HtmlID = $module[1];
            $t->Type = $module[2];
            $t->Save();
        }
    }
    $zbp->SaveOption();
}

function Jz52_Fuwari_Event_DelModule()
{
    global $zbp;
    $modules = array('jz52_fuwari_music');
    $modules = $zbp->GetModuleList(array('*'), array(array('IN', 'mod_FileName', $modules)));
    foreach ($modules as $item) {
        $item->Del();
    }
}

function Jz52_Fuwari_Event_SideContent(&$module)
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_Fuwari');
    $str = '';
    switch ($module->FileName) {
        case 'jz52_fuwari_music':
            if ($cfg->music_enable === '' || $cfg->music_enable == '1') {
                $server = $cfg->music_server ? $cfg->music_server : 'netease';
                $type = $cfg->music_type ? $cfg->music_type : 'playlist';
                $id = $cfg->music_id ? $cfg->music_id : '';
                $playMode = $cfg->music_play_mode ? $cfg->music_play_mode : 'list';
                $volume = $cfg->music_volume !== '' ? $cfg->music_volume : '0.7';
                $api = $cfg->music_api !== '' ? $cfg->music_api : 'https://api.injahow.cn/meting/';
                $str .= '<div class="fw-music firefly-music-player relative w-full" data-server="' . htmlspecialchars($server) . '" data-type="' . htmlspecialchars($type) . '" data-id="' . htmlspecialchars($id) . '" data-play-mode="' . htmlspecialchars($playMode) . '" data-volume="' . htmlspecialchars($volume) . '" data-api="' . htmlspecialchars($api) . '">'
                    . '<div class="mb-2 flex items-center gap-2 px-1">'
                    . '<div class="relative h-14 w-14 shrink-0">'
                    . '<div class="fw-music-cover-wrap relative z-10 flex h-full w-full items-center justify-center overflow-hidden rounded-full border-2 border-white bg-(--primary)/10 shadow-lg dark:border-neutral-700">'
                    . '<i class="fw-music-cover-ph ri-music-2-fill absolute text-2xl text-(--primary) opacity-40" aria-hidden="true"></i>'
                    . '<img class="fw-music-cover relative z-10 h-full w-full object-cover animate-spin-slow" src="" alt="cover" style="animation-play-state:paused;display:none;"/>'
                    . '</div>'
                    . '</div>'
                    . '<div class="flex min-w-0 flex-1 flex-col overflow-hidden">'
                    . '<div class="flex items-center justify-between gap-2 overflow-hidden">'
                    . '<div class="relative min-w-0 flex-1 overflow-hidden"><h3 class="fw-music-title truncate text-base font-bold leading-tight text-neutral-800 dark:text-neutral-100">未播放</h3></div>'
                    . '<button type="button" class="fw-music-lrc-toggle shrink-0 p-0.5 pr-2 text-neutral-400 transition-all duration-300 hover:text-(--primary) active:scale-95" title="歌词"><i class="ri-timeline-view text-xl"></i></button>'
                    . '</div>'
                    . '<div class="min-w-0 overflow-hidden"><p class="fw-music-artist truncate text-xs font-medium text-neutral-500 dark:text-neutral-400">&nbsp;</p></div>'
                    . '<div class="flex h-5 items-center gap-3 text-neutral-400">'
                    . '<div class="flex h-full shrink-0 items-center gap-1 font-mono text-[10px]"><span class="fw-music-current">0:00</span><span class="opacity-50">/</span><span class="fw-music-total">0:00</span></div>'
                    . '<div class="ml-auto flex h-full items-center gap-1">'
                    . '<button type="button" class="fw-music-mute flex items-center rounded-md p-0.5 transition-colors hover:text-(--primary)" title="音量"><i class="ri-volume-up-line text-lg"></i></button>'
                    . '<div class="fw-music-vol relative ml-1 h-1 w-16 cursor-pointer rounded-full bg-neutral-200 dark:bg-neutral-600" role="slider" aria-label="音量"><div class="fw-music-vol-bar absolute left-0 top-0 h-full rounded-full bg-(--primary)" style="width:' . (floatval($volume) * 100) . '%"></div></div>'
                    . '</div>'
                    . '</div>'
                    . '</div>'
                    . '</div>'
                    . '<div class="px-1">'
                    . '<div class="fw-music-progress group relative mb-2 mt-2 h-1 w-full cursor-pointer touch-none rounded-full bg-neutral-100 dark:bg-neutral-700/50" role="slider" aria-label="播放进度">'
                    . '<div class="fw-music-progress-bar absolute left-0 top-0 h-full rounded-full bg-(--primary)" style="width:0%"></div>'
                    . '<div class="fw-music-progress-thumb absolute top-1/2 -ml-1.5 -mt-1.5 h-3 w-3 scale-0 rounded-full bg-(--primary) shadow-sm ring-2 ring-white transition-transform duration-200 group-hover:scale-100 dark:ring-neutral-800" style="left:0%"></div>'
                    . '</div>'
                    . '</div>'
                    . '<div class="flex select-none items-center justify-between px-1">'
                    . '<button type="button" class="fw-music-mode p-2 transition-colors hover:text-(--primary) active:scale-95" title="播放模式"><i class="ri-shuffle-line text-xl"></i></button>'
                    . '<button type="button" class="fw-music-btn p-2 text-neutral-600 transition-colors hover:text-(--primary) active:scale-95 dark:text-neutral-300" data-act="prev" title="上一首"><i class="ri-skip-back-fill text-3xl"></i></button>'
                    . '<button type="button" class="fw-music-toggle flex h-12 w-12 items-center justify-center rounded-full bg-(--btn-regular-bg) text-(--primary) transition-all duration-300 hover:bg-(--btn-regular-bg-hover) active:bg-(--btn-regular-bg-active)" data-act="toggle" title="播放/暂停"><i class="ri-play-fill ml-0.5 text-3xl"></i></button>'
                    . '<button type="button" class="fw-music-btn p-2 text-neutral-600 transition-colors hover:text-(--primary) active:scale-95 dark:text-neutral-300" data-act="next" title="下一首"><i class="ri-skip-forward-fill text-3xl"></i></button>'
                    . '<button type="button" class="fw-music-drawer-toggle p-2 text-neutral-400 transition-all duration-300 hover:text-(--primary) active:scale-95" title="播放列表"><i class="ri-play-list-line text-xl"></i></button>'
                    . '</div>'
                    . '<div class="fw-music-lrc-drawer grid grid-rows-[0fr] opacity-0 transition-all duration-300"><div class="min-h-0 overflow-hidden"><div class="fw-music-lrc custom-scrollbar relative flex h-48 flex-col items-center gap-2 overflow-y-auto scroll-smooth p-4 py-6 text-center"></div></div></div>'
                    . '<div class="fw-music-drawer grid grid-rows-[0fr] opacity-0 transition-all duration-300"><div class="min-h-0 overflow-hidden"><div class="fw-music-playlist custom-scrollbar flex max-h-48 flex-col gap-1 overflow-y-auto p-1"></div></div></div>'
                    . '<div class="fw-music-loading absolute inset-0 z-20 flex flex-col items-center justify-center rounded-xl bg-white/60 backdrop-blur-[2px] transition-opacity duration-300 opacity-0 pointer-events-none dark:bg-[#1e1e1e]/60"><i class="ri-refresh-line animate-spin text-3xl text-(--primary)"></i></div>'
                    . '<audio class="fw-music-audio" crossorigin="anonymous" preload="metadata" style="display:none;"></audio>'
                    . '</div>';
            }
            break;
    }
    return $str;
}

function Jz52_Fuwari_Module_Load()
{
    global $zbp;
    $module_names = array('jz52_fuwari_music');
    foreach ($module_names as $name) {
        if (isset($zbp->modulesbyfilename[$name])) {
            $zbp->modulesbyfilename[$name]->Content = Jz52_Fuwari_Event_SideContent($zbp->modulesbyfilename[$name]);
        }
    }
}

# 文章编辑页
function Jz52_Fuwari_Edit_Response5()
{
    global $zbp, $article;
    $cfg = $zbp->Config('Jz52_Fuwari');
    if ($article->Type == "0" || ($article->Type == "1" && ($cfg->nseo === '' || $cfg->nseo == '1') && ($cfg->seo === '' || $cfg->seo == '1'))) {
        echo '<table width="99%">';
    }
    if ($article->Type == "0") {
        $jzzdimg = $article->Metas->Jzzdimg;
        echo '<tr><td width="15%">文章封面</td><td>';
        echo '<div class="cfg-preview" id="jzzdimg-prev"><img src="' . htmlspecialchars($jzzdimg) . '" alt="" onerror="this.style.display=\'none\'" style="max-height:54px;max-width:220px;border:1px solid #e5eaf2;padding:2px;background:#fff;"></div>';
        echo '<div class="cfg-upload uploadimg" data-id="jzzdimg-prev" style="display:flex;">';
        echo '<input type="text" class="uplod_img" style="width:60%;height:31px" name="meta_Jzzdimg" value="' . htmlspecialchars($jzzdimg) . '" placeholder="图片地址或点击浏览"/>';
        echo '<strong  style="display: inline-block;height:30px;padding:0 12px;color:#3a6ea5;border:1px solid #3a6ea5;cursor:pointer;" >浏览文件</strong></div></td></tr>';
        echo '<script type="text/javascript" src="' . $zbp->host . 'zb_users/theme/Jz52_Fuwari/admin/js/lib.upload.js"></script>';
    }
    if (($cfg->nseo === '' || $cfg->nseo == '1') && ($cfg->seo === '' || $cfg->seo == '1')) {
        echo '<tr><td width="15%">SEO标题</td><td width="75%"><input style="width:95%;height:31px" name="meta_nrtit" value="' . $article->Metas->nrtit . '"/></td></tr><tr><td>SEO关键词</td><td><input style="width:95%;height:31px" name="meta_nrgjc" value="' . $article->Metas->nrgjc . '"/></td></tr><tr><td>SEO描述</td><td><input style="width:95%;height:31px" name="meta_nrms" value="' . $article->Metas->nrms . '"/></td></tr>';
    }
    if ($article->Type == "0" || ($article->Type == "1" && ($cfg->nseo === '' || $cfg->nseo == '1') && ($cfg->seo === '' || $cfg->seo == '1'))) {
        echo '</table>';
    }
}

# 分类编辑页
function Jz52_Fuwari_Category_Edit_Response()
{
    global $zbp, $cate;
    $cfg = $zbp->Config('Jz52_Fuwari');
    if (($cfg->nseo === '' || $cfg->nseo == '1') && ($cfg->seo === '' || $cfg->seo == '1')) {
        echo '<p>
        <span class="title">标题:(主题自带seo功能)</span>
        <br>
        <input name="meta_flbt" value="' . $cate->Metas->flbt . '" class="edit">
        </p>
        <p>
        <span class="title">关键词:(主题自带seo功能)</span>
        <br>
        <input name="meta_flgjc" value="' . $cate->Metas->flgjc . '" class="edit">
        </p>
        <p>
        <span class="title">摘要:(主题自带seo功能)</span>
        <br>
        <textarea cols="3" rows="6" name="meta_fenld" style="width:600px;">' . $cate->Metas->fenld . '</textarea>
        </p>';
    }
}

# 标签编辑页
function Jz52_Fuwari_Tag_Edit_Response()
{
    global $zbp, $tag;
    $cfg = $zbp->Config('Jz52_Fuwari');
    if (($cfg->nseo === '' || $cfg->nseo == '1') && ($cfg->seo === '' || $cfg->seo == '1')) {
        echo '<p><span class="title">标题:(主题自带seo功能)</span><br /><input style="width:95%" name="meta_tagt" value="' . $tag->Metas->tagt . '"/></p><p><span class="title">关键词:(主题自带seo功能)</span><br /><input style="width:95%" name="meta_tagk" value="' . $tag->Metas->tagk . '"/></p><p><span class="title">摘要:(主题自带seo功能)</span><br /><textarea cols="3" rows="6" name="meta_tagd" style="width:600px;">' . $tag->Metas->tagd . '</textarea></p>';
    }
}

# 归档页缓存
function Jz52_Fuwari_cache_dir()
{
    global $zbp;
    $dir = $zbp->cachedir . 'compiled/' . $zbp->theme . '/jzcache/';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return $dir;
}

# 读取缓存：未命中、模板已更新或过期（1 小时）返回 false；$tpl 传模板文件名时校验其 mtime
function Jz52_Fuwari_cache_get($key, $tpl = '')
{
    global $zbp;
    $file = Jz52_Fuwari_cache_dir() . $key . '.html';
    if (!is_file($file)) {
        return false;
    }
    if ($tpl != '') {
        $tplFile = $zbp->path . 'zb_users/theme/' . $zbp->theme . '/template/' . $tpl;
        if (is_file($tplFile) && filemtime($tplFile) > filemtime($file)) {
            @unlink($file);
            return false;
        }
    }
    if (time() - filemtime($file) > 3600) {
        @unlink($file);
        return false;
    }
    return file_get_contents($file);
}

# 写入缓存
function Jz52_Fuwari_cache_set($key, $html)
{
    $file = Jz52_Fuwari_cache_dir() . $key . '.html';
    return @file_put_contents($file, $html);
}

# 清空归档缓存
function Jz52_Fuwari_cache_clear()
{
    $dir = Jz52_Fuwari_cache_dir();
    $files = glob($dir . '*.html');
    if (is_array($files)) {
        foreach ($files as $file) {
            @unlink($file);
        }
    }
}

# 后台子菜单
function Jz52_Fuwari_SubMenu($cur)
{
    $items = array(
        1 => array('config.php', '基本设置'),
        2 => array('banner.php', '横幅设置'),
        3 => array('sidebar.php', '侧栏部件'),
        4 => array('article.php', '文章设置'),
        5 => array('icp.php', '备案信息'),
        6 => array('link.php', '友链设置'),
        7 => array('code.php', '自定义代码'),
        8 => array('seo.php', 'SEO 设置'),
    );
    foreach ($items as $v) {
        echo '<a href="' . $v[0] . '"><span class="m-left ' . ($cur == $v[0] ? 'm-now' : '') . '">' . $v[1] . '</span></a>';
    }
}

# 后台顶部菜单
function Jz52_Fuwari_AddMenu(&$m) {
	global $zbp;
	$m[] = MakeTopMenu("root", '主题配置', $zbp->host . "zb_users/theme/Jz52_Fuwari/admin/config.php", "", "topmenu_Jz52_Fuwari", "icon-x-diamond-fill");
}


# 上传目录
function Jz52_Fuwari_newcachedir()
{
    global $zbp;
    $dir = $zbp->usersdir . 'upload/Jz52_Fuwari';
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }
}

# 初始数据
function Jz52_Fuwari_DefaultConfig()
{
    global $zbp;
    $cfg = $zbp->Config('Jz52_Fuwari');
    $defaults = array(
        'Version' => '1.0.0',
        # 基础
        'themeColor_hue' => '250',
        'themeColor_fixed' => '0',
        'banner_enable' => '1',
        'banner_src' => '',
        'banner_position' => 'center',
        'banner_credit_enable' => '0',
        'banner_credit_text' => '© 2022 Fuwari',
        'banner_credit_url' => '',
        # 样式
        'color_scheme' => 'auto',
        'enable_change_color_scheme' => '1',
        # 侧栏
        'music_server' => 'netease',
        'music_type' => 'playlist',
        'music_id' => '',
        'music_play_mode' => 'list',
        'music_volume' => '0.7',
        'music_api' => '',
        'music_enable' => '1',
        'html_widget' => '',
        # 个人
        'profile_enable' => '1',
        'profile_avatar' => '',
        'profile_name' => '',
        'profile_bio' => '',
        'profile_url' => '',
        'profile_social' => '',
        # 文章
        'license_enable' => '0',
        'license_name' => 'CC BY-NC-SA 4.0',
        'license_url' => 'https://creativecommons.org/licenses/by-nc-sa/4.0/',
        'content_size' => 'prose-base',
        'content_theme' => 'prose-gray',
        'enable_toc' => '1',
        'toc_depth' => '2',
        # 备案
        'icp_text' => '',
        'icp_link' => 'https://beian.miit.gov.cn/',
        'gongan_text' => '',
        'gongan_link' => 'https://beian.mps.gov.cn/#/query/webSearch',
        # 友链申请（提交到留言板评论）
        'link_apply_enable' => '1',
        'links_list' => '',
        'links_default_avatar' => '',
        'links_apply_desc' => '请先在贵站添加本站友链，提交后会作为留言发送，站长会手动审核。',
        'links_target' => '',
        'links_apply_site_link_page' => '',
        'links_apply_site_rss_url' => '',
        'links_my_name' => '',
        'links_my_url' => '',
        'links_my_desc' => '',
        'links_my_avatar' => '',
        # SEO
        'seo' => '1',
        'seotitle' => '',
        'seokeywords' => '',
        'seodescription' => '',
        'nseo' => '1',
        'seofgf' => ' - ',
        'og' => '1',
        'google' => '1',
        'generator' => '0',
        'ogimg' => '',
        'googlelogo' => '',
        # 自定义
        'custom_css' => '',
        'custom_js_head' => '',
        'custom_js_footer' => '',
        'DelConfig' => '0',
        # 网站 Logo（图片/ico/文字三开关）
        'logo_img_enable' => '0',
        'logo_img' => '',
        'logo_ico_enable' => '1',
        'logo_ico' => '',
        'logo_text_enable' => '1',
        'logo_text' => '',
    );
    $needSave = false;
    foreach ($defaults as $k => $v) {
        if (!$cfg->HasKey($k)) {
            $cfg->$k = $v;
            $needSave = true;
        }
    }
    if ($needSave) {
        $zbp->SaveConfig('Jz52_Fuwari');
    }
}

function InstallPlugin_Jz52_Fuwari()
{
    global $zbp;
    Jz52_Fuwari_DefaultConfig();
    Jz52_Fuwari_newcachedir();
    Jz52_Fuwari_Event_CreateModule();
}

function UninstallPlugin_Jz52_Fuwari()
{
    global $zbp;
    Jz52_Fuwari_Event_DelModule();
    if ($zbp->Config('Jz52_Fuwari')->DelConfig) {
        $zbp->DelConfig('Jz52_Fuwari');
    }
}
