{* Template Name:页面正文 *}
<article class="relative mb-4 flex w-full overflow-hidden rounded-(--radius-large)">
  <div id="post-container" class="card-base relative z-10 w-full px-6 pb-4 pt-6 md:px-9">
    <div class="onload-animation relative">
      <h1 class="mb-3 block w-full text-3xl font-bold text-black/90 transition before:absolute before:-left-4.5 before:top-3 before:h-5 before:rounded-md before:bg-(--primary) dark:text-white/90 md:text-[2.25rem]/[2.75rem] md:before:w-1">{$article.Title}</h1>
    </div>
    <div id="content" class="custom-md markdown-content onload-animation prose prose-base mb-6 max-w-none! dark:prose-invert! {$fwContentSize} {$fwContentTheme}">
      {$article.Content}
    </div>
  </div>
</article>

{if !$article.IsLock}
<div class="card-base relative z-10 w-full px-6 pb-4 pt-6 md:px-9" id="comment">
  <h2 class="mb-2 text-base font-medium text-gray-900 dark:text-slate-50">评论</h2>
  {template:comments}
</div>
{/if}
