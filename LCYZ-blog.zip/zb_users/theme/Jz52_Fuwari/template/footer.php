{* Template Name:页脚（返回顶部+TOC+脚本） *}
<div class="back-to-top-wrapper hidden lg:block" data-astro-cid-774ni4gk>
  <div id="back-to-top-btn" class="back-to-top-btn hide flex items-center rounded-2xl overflow-hidden transition" data-astro-cid-774ni4gk>
    <button type="button" aria-label="回到顶部" class="btn-card h-[3.75rem] w-[3.75rem]" data-astro-cid-774ni4gk>
      <i class="ri-arrow-up-s-line mx-auto text-[1.75rem]" aria-hidden="true"></i>
    </button>
  </div>
</div>
<div id="toc-container">
  <div class="absolute z-0 hidden w-full xl:block">
    <div class="relative mx-auto max-w-(--page-width)">
      {if $fwTocEnable}
      <div id="toc-wrapper" class="pointer-events-auto absolute -right-(--toc-width) top-0 hidden w-(--toc-width) items-center transition lg:block">
        <div id="toc-inner-wrapper" data-toc-scroll class="hide-scrollbar fixed top-14 h-[calc(100vh-20rem)] w-(--toc-width) overflow-x-hidden overflow-y-scroll">
          <div id="toc" class="transition h-full w-full">
            <div class="h-8 w-full"></div>
            <div id="fw-toc" class="group relative block" data-max-depth="{$fwTocDepth}">
              <div id="active-indicator" style="opacity:0" class="-z-10 absolute left-0 right-0 rounded-xl border-2 border-dashed border-(--toc-btn-hover) bg-(--toc-btn-hover) transition-all group-hover:border-(--toc-btn-active) group-hover:bg-transparent"></div>
            </div>
            <div class="h-8 w-full"></div>
          </div>
        </div>
      </div>
      {else}<div id="toc"></div>{/if}
    </div>
  </div>
</div>
{if $fwcfg->custom_js_footer}
{$fwcfg->custom_js_footer}
{/if}
<script src="{$host}zb_users/theme/{$theme}/script/fuwari.js?v={$themeinfo['version']}"></script>
{$footer}
