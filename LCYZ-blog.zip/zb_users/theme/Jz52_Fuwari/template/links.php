{* Template Name:友链页（独立页面模板） *}
{template:c_head}
{php}
/* 友链列表：读后台「友链设置」的 links_list 配置（每行：名称|网址|简介|头像） */
$fwLinks = array();
foreach (array_filter(array_map('trim', explode("\n", $fwcfg->links_list))) as $fwLine) {
    $fwParts = array_map('trim', explode('|', $fwLine));
    if (count($fwParts) < 2) {
        continue;
    }
    $fwLinks[] = array(
        'name' => $fwParts[0],
        'url' => $fwParts[1],
        'desc' => isset($fwParts[2]) ? $fwParts[2] : '',
        'avatar' => isset($fwParts[3]) ? $fwParts[3] : '',
    );
}
/* 友链申请提交目标：links_target 配置的页面评论，留空为本页 */
$fwLinkTarget = $article;
if ($fwcfg->links_target) {
    $fwLinkTargetPost = $zbp->GetPostByID((int) $fwcfg->links_target);
    if ($fwLinkTargetPost->ID) { $fwLinkTarget = $fwLinkTargetPost; }
}
{/php}
<!DOCTYPE html>
<html lang="{$language}" class="{$fwHtmlClass}">
<head>
{template:header}
</head>
<body class="min-h-screen transition {$fwBodyClass}{if $fwBannerEnable} enable-banner{/if}" style="{if $fwBannerEnable}--bannerOffset: {$fwBannerOffset};{/if}">
{template:c_top}
<div id="main-panel-wrapper" class="pointer-events-none absolute z-30 w-full" style="top:{if $fwBannerEnable}calc(35vh - 3.5rem){else}5.5rem{/if}">
  <div class="pointer-events-auto relative mx-auto max-w-(--page-width)">
    <div id="main-grid" class="left-0 right-0 mx-auto grid w-full grid-cols-[17.5rem_auto] grid-rows-[auto_1fr_auto] gap-4 px-0 transition duration-700 md:px-4 lg:grid-rows-[auto]">
      {template:sidebar}
      <main id="swup-container" class="transition-swup-fade col-span-2 overflow-hidden lg:col-span-1">
        <div id="content-wrapper" class="onload-animation">
          <section class="card-base onload-animation mb-4 px-6 py-6 md:px-9">
            <div class="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div class="flex flex-col gap-2">
                <h1 class="text-3xl font-bold text-90">友情链接</h1>
                <div class="text-sm text-50"><i class="ri-link mr-1" aria-hidden="true"></i><span>Friends links</span></div>
              </div>
              {if $fwcfg->link_apply_enable == '1'}
              <a href="#link-application" data-link-application-trigger aria-controls="link-application-details" aria-expanded="false" class="btn-regular inline-flex h-10 w-full shrink-0 items-center gap-2 rounded-xl px-4 font-bold outline-none active:scale-95 focus-visible:ring-2 focus-visible:ring-(--primary)/40 sm:w-auto"><i class="ri-add-line text-xl" aria-hidden="true"></i><span>申请</span></a>
              {/if}
            </div>
            {if count($fwLinks)>0}
            <div class="space-y-8">
              <section class="onload-animation">
                <div class="mb-4 flex items-center justify-between gap-4">
                  <h2 class="text-xl font-bold text-90">友链</h2>
                  <span class="rounded-lg bg-(--btn-regular-bg) px-2.5 py-1 text-xs font-bold text-(--btn-content)">{count($fwLinks)}</span>
                </div>
                <ul class="fw-links-grid grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                  {foreach $fwLinks as $fwLink}
                  <li class="link-item">
                    <a href="{$fwLink['url']}" target="_blank" title="{$fwLink['desc']}">
                      {if $fwLink['avatar']}
                      <span class="fw-link-logo"><img src="{$fwLink['avatar']}" alt="{$fwLink['name']}" loading="lazy"/></span>
                      {elseif $fwcfg->links_default_avatar}
                      <span class="fw-link-logo"><img src="{$fwcfg->links_default_avatar}" alt="{$fwLink['name']}" loading="lazy"/></span>
                      {/if}
                      <span class="fw-link-text">
                        <span class="fw-link-name">{$fwLink['name']}</span>
                        {if $fwLink['desc']}<span class="fw-link-desc">{$fwLink['desc']}</span>{/if}
                      </span>
                    </a>
                  </li>
                  {/foreach}
                </ul>
              </section>
            </div>
            {else}
            <div class="py-12 text-center text-50">还没有友链</div>
            {/if}
          </section>

          {if $fwcfg->link_apply_enable == '1' && !$fwLinkTarget->IsLock}
          <div id="link-application" class="card-base onload-animation mb-4 block scroll-mt-24">
            <details id="link-application-details" data-application-details class="group">
              <summary class="flex cursor-pointer list-none items-center gap-4 px-6 py-5 outline-none transition hover:bg-(--btn-card-bg-hover) focus-visible:bg-(--btn-card-bg-hover) focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-(--primary)/35 md:px-9">
                <span class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-(--btn-regular-bg) text-(--primary) transition group-hover:scale-105"><i class="ri-add-line text-2xl" aria-hidden="true"></i></span>
                <span class="min-w-0 flex-1">
                  <span class="block text-lg font-bold text-90">申请友情链接</span>
                  <span class="mt-1 block text-sm leading-6 text-50">{if $fwcfg->links_apply_desc}{$fwcfg->links_apply_desc}{else}请先在贵站添加本站友链，提交后会作为留言发送，站长会手动审核。{/if}</span>
                </span>
                <i class="ri-arrow-down-s-line shrink-0 text-2xl text-30 transition-transform duration-300 group-open:rotate-180 group-hover:text-(--primary)" aria-hidden="true"></i>
              </summary>
              <div class="border-t border-dashed border-black/10 px-6 pb-7 pt-6 dark:border-white/15 md:px-9">
                <div class="mb-6 grid gap-x-6 gap-y-3 rounded-xl border border-dashed border-black/10 bg-black/[0.02] p-4 text-sm text-50 dark:border-white/15 dark:bg-white/[0.025] sm:grid-cols-2">
                  <div><span class="font-bold text-75">本站名称</span><span class="ml-2">{if $fwcfg->links_my_name}{$fwcfg->links_my_name}{else}{$name}{/if}</span></div>
                  <div><span class="font-bold text-75">本站网址</span><span class="ml-2">{if $fwcfg->links_my_url}{$fwcfg->links_my_url}{else}{$host}{/if}</span></div>
                  <div><span class="font-bold text-75">本站简介</span><span class="ml-2">{if $fwcfg->links_my_desc}{$fwcfg->links_my_desc}{else}{$subname}{/if}</span></div>
                  <div><span class="font-bold text-75">本站头像</span><span class="ml-2">{if $fwcfg->links_my_avatar}{$fwcfg->links_my_avatar}{else}默认头像{/if}</span></div>
                  <div><span class="font-bold text-75">友链页面</span><span class="ml-2">{if $fwcfg->links_apply_site_link_page}{$fwcfg->links_apply_site_link_page}{else}{$host}links{/if}</span></div>
                  <div><span class="font-bold text-75">RSS 订阅</span><span class="ml-2">{if $fwcfg->links_apply_site_rss_url}{$fwcfg->links_apply_site_rss_url}{else}{$host}feed.php{/if}</span></div>
                </div>
                <form data-application-form class="space-y-6" action="{$fwLinkTarget->CommentPostUrl}" method="post" autocomplete="off">
                  <input type="hidden" name="LogID" value="{$fwLinkTarget->ID}">
                  <input type="hidden" name="replyid" value="0">
                  <input type="hidden" name="format" value="json">
                  <div class="grid gap-x-5 gap-y-4 md:grid-cols-2">
                    <label>
                      <span class="mb-2 block text-sm font-bold text-75">网站名称<span aria-hidden="true" class="ml-0.5 text-(--primary)">*</span></span>
                      <input class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25" name="siteName" type="text" autocomplete="organization" required maxlength="80" placeholder="你的网站名称"/>
                    </label>
                    <label>
                      <span class="mb-2 block text-sm font-bold text-75">网站地址<span aria-hidden="true" class="ml-0.5 text-(--primary)">*</span></span>
                      <input class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25" name="url" type="url" autocomplete="url" spellcheck="false" required maxlength="300" placeholder="https://example.com"/>
                    </label>
                    <label>
                      <span class="mb-2 block text-sm font-bold text-75">网站头像</span>
                      <input class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25" name="logo" type="url" autocomplete="off" spellcheck="false" maxlength="300" placeholder="https://example.com/logo.png"/>
                    </label>
                    <label>
                      <span class="mb-2 block text-sm font-bold text-75">联系邮箱<span aria-hidden="true" class="ml-0.5 text-(--primary)">*</span></span>
                      <input class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25" name="email" type="email" autocomplete="email" spellcheck="false" required maxlength="160" placeholder="hello@example.com"/>
                    </label>
                    <label>
                      <span class="mb-2 block text-sm font-bold text-75">友链页面</span>
                      <input class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25" name="backlinkUrl" type="url" autocomplete="off" spellcheck="false" maxlength="300" placeholder="https://example.com/links"/>
                    </label>
                    <label>
                      <span class="mb-2 block text-sm font-bold text-75">RSS 订阅地址</span>
                      <input class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25" name="rssUrl" type="url" autocomplete="off" spellcheck="false" maxlength="300" placeholder="https://example.com/rss.xml"/>
                    </label>
                    <label class="md:col-span-2">
                      <span class="mb-2 block text-sm font-bold text-75">网站描述<span aria-hidden="true" class="ml-0.5 text-(--primary)">*</span></span>
                      <textarea class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25 min-h-28 resize-y leading-6" name="description" autocomplete="off" required maxlength="240" placeholder="简单介绍一下你的网站"></textarea>
                    </label>
                  </div>
                  {if $option['ZC_COMMENT_VERIFY_ENABLE'] && !$zbp.CheckRights('NoValidCode')}
                  <div class="rounded-xl border border-dashed border-black/10 bg-black/[0.02] p-3.5 dark:border-white/15 dark:bg-white/[0.025]">
                    <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div class="shrink-0">
                        <div class="text-sm font-bold text-75">验证码<span aria-hidden="true" class="ml-0.5 text-(--primary)">*</span></div>
                        <p class="mt-0.5 text-xs text-30">请输入图片中的字符，点击图片可刷新。</p>
                      </div>
                      <div class="flex flex-col gap-2 sm:flex-row sm:items-center">
                        <button data-captcha-refresh type="button" class="relative flex h-12 w-full shrink-0 cursor-pointer items-center justify-center overflow-hidden rounded-lg bg-white px-2 outline-none ring-1 ring-black/5 transition hover:ring-(--primary)/35 focus-visible:ring-2 focus-visible:ring-(--primary) sm:w-40" aria-label="刷新验证码" title="刷新验证码">
                          <img data-application-captcha class="h-full w-full object-contain" alt="验证码" width="160" height="48" src="{$fwLinkTarget->ValidCodeUrl}"/>
                        </button>
                        <div class="flex items-center gap-2">
                          <input class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25 h-12 min-w-0 flex-1 text-center font-mono text-base tracking-[0.3em] sm:w-40" name="verify" required autocomplete="off" spellcheck="false" placeholder="验证码"/>
                          <button data-captcha-refresh type="button" class="btn-plain scale-animation h-10 w-10 shrink-0 rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-(--primary)/40" aria-label="刷新验证码"><i class="ri-refresh-line text-xl" aria-hidden="true"></i></button>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/if}
                  <div data-application-result class="application-result break-words" role="status" aria-live="polite" hidden></div>
                  <div class="flex flex-col gap-4 border-t border-dashed border-black/10 pt-5 dark:border-white/15 sm:flex-row sm:items-center sm:justify-between">
                    <p class="flex items-center gap-2 text-sm leading-6 text-50"><i class="ri-information-line text-base" aria-hidden="true"></i>提交后会作为留言发送，站长手动审核后展示。</p>
                    <button data-application-submit type="submit" class="btn-regular inline-flex h-11 w-full shrink-0 gap-2 rounded-xl px-5 font-bold outline-none active:scale-95 focus-visible:ring-2 focus-visible:ring-(--primary)/40 disabled:cursor-wait disabled:opacity-60 sm:w-auto"><i class="ri-send-plane-fill text-lg" aria-hidden="true"></i><span data-submit-label>提交到留言板</span></button>
                  </div>
                </form>
              </div>
            </details>
          </div>
          {elseif $fwcfg->link_apply_enable == '1'}
          <div class="card-base onload-animation mb-4 px-6 py-6 text-center text-sm text-50"><i class="ri-close-circle-line mr-1" aria-hidden="true"></i>本页评论已关闭，暂不支持提交友链申请。</div>
          {/if}

          <div id="comment" class="card-base relative z-10 w-full px-6 pb-4 pt-6 md:px-9">
            <h2 class="mb-2 text-base font-medium text-gray-900 dark:text-slate-50">评论</h2>
            {template:comments}
          </div>
        </div>
      </main>
      {template:c_footer}
    </div>
  </div>
</div>
{template:footer}
</body>
</html>
