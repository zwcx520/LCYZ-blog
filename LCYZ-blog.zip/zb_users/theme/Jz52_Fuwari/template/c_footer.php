{* Template Name:页脚区块（网格内，版权+备案） *}
<div class="footer onload-animation col-span-2 block">
  <div class="mx-8 my-10 border-t border-dashed border-black/10 transition dark:border-white/15 md:mx-32"></div>
  <footer class="mb-12 flex flex-col items-center justify-center rounded-2xl px-6 text-center text-sm text-50 transition">
    <div>
      {$copyright}
    </div>
    <div class="mt-2" id="footer">
    {if $fwcfg->icp_text}<a class="link font-medium text-(--primary)" href="{$fwcfg->icp_link}" target="_blank" rel="noopener">{$fwcfg->icp_text}</a>
    {/if}
    {if $fwcfg->gongan_text}<a class="link font-medium text-(--primary)" href="{$fwcfg->gongan_link}" target="_blank" rel="noopener">{$fwcfg->gongan_text}</a>
    {/if}
      Powered by <a class="link font-medium text-(--primary)" href="https://www.zblogcn.com/" target="_blank" rel="noopener">Z-BlogPHP</a>
      Theme by <a class="link font-medium text-(--primary)" href="https://app.zbp.cool/" title="不见桃花不见秋" target="_blank">GebiLaoli</a>
    </div>
  </footer>
</div>
