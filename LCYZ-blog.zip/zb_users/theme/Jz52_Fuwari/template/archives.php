{* Template Name:归档页（独立页面模板，时间线） *}
{template:c_head}
{php}
$fwArts = $zbp->GetArticleList('*', array(array('=', 'log_Status', 0)), array('log_PostTime' => 'DESC'), array(1000), null, false);
$fwArch = array();
foreach ($fwArts as $fwA) {
    $fwY = date('Y', $fwA->PostTime);
    $fwM = date('Y-m', $fwA->PostTime);
    if (!isset($fwArch[$fwY])) { $fwArch[$fwY] = array('months' => array()); }
    if (!isset($fwArch[$fwY]['months'][$fwM])) { $fwArch[$fwY]['months'][$fwM] = array(); }
    $fwArch[$fwY]['months'][$fwM][] = $fwA;
}
{/php}
<!DOCTYPE html>
<html lang="{$language}" class="{$fwHtmlClass}">
<head>
{template:header}
</head>
<body class="min-h-screen transition {$fwBodyClass}{if $fwBannerEnable} enable-banner{/if}" style="{if $fwBannerEnable}--bannerOffset: {$fwBannerOffset};{/if}">
{template:c_top}
<div id="main-panel-wrapper" class="pointer-events-none absolute z-30 w-full" style="top:{if $fwBannerEnable}calc(35vh - 3.5rem){else}5.5rem{/if}">
  <div class="pointer-events-auto relative mx-auto max-w-(--page-width)">
    <div id="main-grid" class="left-0 right-0 mx-auto grid w-full grid-cols-[17.5rem_auto] grid-rows-[auto_1fr_auto] gap-4 px-0 transition duration-700 md:px-4 lg:grid-rows-[auto]">
      {template:sidebar}
      <main id="swup-container" class="transition-swup-fade col-span-2 overflow-hidden lg:col-span-1">
        <div id="content-wrapper" class="onload-animation">
          {php}
          // 归档页缓存：命中直接输出，未命中渲染后写入缓存（文章增删改或模板更新时自动失效）
          $fwCacheHtml = Jz52_Fuwari_cache_get('archives', 'archives.php');
          if ($fwCacheHtml === false) { ob_start(); }
          {/php}
          {if $fwCacheHtml === false}
          <div class="card-base onload-animation mb-4 px-8 py-6">
            {if count($fwArts)==0}
            <div class="py-10 text-center text-lg font-bold text-neutral-700 transition dark:text-neutral-300">暂无文章</div>
            {else}
            {foreach $fwArch as $fwY => $fwYData}
            <div>
              {php}$fwYCount = 0; foreach ($fwYData['months'] as $fwMs) { $fwYCount += count($fwMs); }{/php}
              <div class="flex h-15 w-full flex-row items-center">
                <div class="w-[15%] text-right text-2xl font-bold text-75 transition md:w-[10%]">{$fwY}</div>
                <div class="w-[15%] md:w-[10%]"><div class="z-50 mx-auto h-3 w-3 rounded-full bg-none outline-3 -outline-offset-2 outline-(--primary)"></div></div>
                <div class="w-[70%] text-left text-50 transition md:w-[80%]">{$fwYCount} 篇文章</div>
              </div>
              {foreach $fwYData['months'] as $fwM => $fwPosts}
              {foreach $fwPosts as $fwP}
              <a href="{$fwP.Url}" aria-label="{$fwP.Title}" class="group btn-plain block! h-10 w-full rounded-lg hover:text-[initial]">
                <div class="flex h-full flex-row items-center justify-start">
                  <div class="w-[15%] text-right text-sm text-50 transition md:w-[10%]">{$fwP.Time('m-d')}</div>
                  <div class="dash-line relative flex h-full w-[15%] items-center md:w-[10%]">
                    <div class="z-50 mx-auto h-1 w-1 rounded bg-[oklch(0.5_0.05_var(--hue))] outline-4 outline-(--card-bg) transition-all group-hover:h-5 group-hover:bg-(--primary) group-hover:outline-(--btn-plain-bg-hover) group-active:outline-(--btn-plain-bg-active)"></div>
                  </div>
                  <div class="w-[70%] overflow-hidden overflow-ellipsis whitespace-nowrap pr-8 text-left font-bold text-75 transition-all group-hover:translate-x-1 group-hover:text-(--primary) md:w-[65%] md:max-w-[65%]">{$fwP.Title}</div>
                  <div class="hidden overflow-hidden overflow-ellipsis whitespace-nowrap text-left text-sm text-30 transition md:block md:w-[15%]">
                    {foreach $fwP.Tags as $fwT} #{$fwT.Name} {/foreach}
                  </div>
                </div>
              </a>
              {/foreach}
              {/foreach}
            </div>
            {/foreach}
            {/if}
          </div>
          {/if}
          {php}
          if ($fwCacheHtml === false) {
              $fwCacheHtml = ob_get_clean();
              Jz52_Fuwari_cache_set('archives', $fwCacheHtml);
          }
          echo $fwCacheHtml;
          {/php}
        </div>
      </main>
      {template:c_footer}
    </div>
  </div>
</div>
{template:footer}
</body>
</html>
