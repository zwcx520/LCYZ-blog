{* Template Name:侧栏 *}
<aside id="sidebar" class="onload-animation col-span-2 row-start-2 row-end-3 mb-4 lg:col-span-1 lg:row-start-1 lg:row-end-2 lg:max-w-70 w-full">
  {if $fwcfg->profile_enable == '1'}
  <div class="mb-4">
    {php}echo Jz52_Fuwari_profile_html();{/php}
  </div>
  {/if}
  <div id="sidebar-sticky" class="flex w-full flex-col gap-4 transition-all duration-700">
    {foreach $sidebar as $module}
    {template:module}
    {/foreach}
  </div>
</aside>
