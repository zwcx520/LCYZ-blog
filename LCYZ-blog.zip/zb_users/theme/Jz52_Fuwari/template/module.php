{* Template Name:单个模块（通用部件卡） *}
<dl class="fw-widget card-base pb-4 onload-animation" id="{$module.HtmlID}">
{if (!$module.IsHideTitle)&&($module.Name)}
<dt class="fw-widget-title relative mb-2 ml-8 mt-4 text-lg font-bold text-neutral-900 transition before:absolute before:left-[-16px] before:top-[5.5px] before:h-4 before:w-1 before:rounded-md before:bg-(--primary) dark:text-neutral-100">{$module.Name}</dt>
{else}
<dt class="hidden"></dt>
{/if}
<dd class="fw-widget-body px-4">
{if $module.Type=='div'}
<div>{$module.Content}</div>
{/if}
{if $module.Type=='ul'}
<ul class="fw-widget-list">{if $module.Content}{$module.Content}{/if}</ul>
{/if}
</dd>
</dl>
