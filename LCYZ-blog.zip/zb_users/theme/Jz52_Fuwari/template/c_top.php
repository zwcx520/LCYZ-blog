{* Template Name:页顶（导航条+Banner+面板） *}
{if $fwBannerEnable}
<div id="banner-wrapper" class="absolute z-10 w-full overflow-hidden transition duration-700" style="top: -30vh">
  <div id="banner" class="h-full object-cover opacity-0 scale-105 transition duration-700 overflow-hidden relative">
    <div class="pointer-events-none absolute inset-0 bg-black/10 transition dark:bg-black/10"></div>
    <img src="{$fwBannerSrc}" alt="{$name}" class="h-full w-full object-cover" style="object-position: {$fwBannerPos}">
  </div>
</div>
{/if}
<div id="top-row" class="pointer-events-none relative z-50 mx-auto max-w-(--page-width) px-0 transition-all duration-700 md:px-4">
  <div id="navbar-wrapper" class="pointer-events-auto sticky top-0 transition-all">
    <div id="navbar" class="z-50 onload-animation">
      <div class="absolute left-0 right-0 -top-8 h-8 bg-(--card-bg) transition"></div>
      <div class="card-base !overflow-visible mx-auto flex h-[4.5rem] max-w-(--page-width) items-center justify-between !rounded-t-none px-4">
        <a href="{$host}" class="btn-plain scale-animation h-[3.25rem] rounded-lg px-5 font-bold active:scale-95" aria-label="首页">
          <div class="flex flex-row items-center text-md text-(--primary)">
            {if $fwcfg->logo_img_enable == '1' && $fwcfg->logo_img}
            <img src="{$fwcfg->logo_img}" alt="{$name}" class="mr-2 h-7 w-auto object-contain logo"/>
            {/if}
            {if $fwcfg->logo_ico_enable == '1'}
            {if $fwcfg->logo_ico}
            <img src="{$fwcfg->logo_ico}" alt="" class="mb-1 mr-2 h-[1.4rem] w-[1.4rem] object-contain"/>
            {else}
            <span class="ri-home-line mb-1 mr-2 text-[1.75rem]"></span>
            {/if}
            {/if}
            {if $fwcfg->logo_text_enable == '1'}
            <span>{if $fwcfg->logo_text}{$fwcfg->logo_text}{else}{$name}{/if}</span>
            {/if}
          </div>
        </a>
        <nav class="hidden md:flex" aria-label="导航菜单">
          <ul class="fw-nav-desktop flex items-center gap-1">
            {module:navbar}
          </ul>
        </nav>
        <div class="flex items-center">
          <button type="button" class="btn-plain scale-animation h-11 w-11 rounded-lg active:scale-90" id="search-switch" aria-label="搜索" aria-expanded="false"><i class="ri-search-line text-[1.25rem]" aria-hidden="true"></i></button>
          {if !$fwHueFixed}
          <button type="button" class="btn-plain scale-animation h-11 w-11 rounded-lg active:scale-90" id="display-settings-switch" aria-label="显示设置" aria-expanded="false"><i class="ri-palette-line text-[1.25rem]" aria-hidden="true"></i></button>
          {/if}
          {if $fwCanChange}
          <div class="relative z-50" role="menu" tabindex="-1" id="scheme-switch-wrap">
            <button type="button" role="menuitem" class="relative btn-plain scale-animation rounded-lg h-11 w-11 active:scale-90" id="scheme-switch" aria-label="亮暗模式">
              <span class="fw-scheme-ico fw-ico-light"><i class="ri-sun-line text-[1.25rem] leading-none" aria-hidden="true"></i></span>
              <span class="fw-scheme-ico fw-ico-dark"><i class="ri-moon-line text-[1.25rem] leading-none" aria-hidden="true"></i></span>
              <span class="fw-scheme-ico fw-ico-auto"><i class="ri-computer-line text-[1.25rem] leading-none" aria-hidden="true"></i></span>
            </button>
            <div id="light-dark-panel" class="hidden lg:block absolute transition float-panel-closed top-11 -right-2 pt-5">
              <div class="card-base float-panel p-2">
                <button type="button" data-scheme="light" class="fw-scheme-option flex transition whitespace-nowrap items-center justify-start w-full btn-plain scale-animation rounded-lg h-9 px-3 font-medium active:scale-95 mb-0.5"><i class="ri-sun-line text-[1.25rem] mr-3" aria-hidden="true"></i>亮色</button>
                <button type="button" data-scheme="dark" class="fw-scheme-option flex transition whitespace-nowrap items-center justify-start w-full btn-plain scale-animation rounded-lg h-9 px-3 font-medium active:scale-95 mb-0.5"><i class="ri-moon-line text-[1.25rem] mr-3" aria-hidden="true"></i>暗色</button>
                <button type="button" data-scheme="auto" class="fw-scheme-option flex transition whitespace-nowrap items-center justify-start w-full btn-plain scale-animation rounded-lg h-9 px-3 font-medium active:scale-95"><i class="ri-computer-line text-[1.25rem] mr-3" aria-hidden="true"></i>系统</button>
              </div>
            </div>
          </div>
          {/if}
          <button type="button" class="btn-plain scale-animation h-11 w-11 rounded-lg active:scale-90 md:!hidden" id="nav-menu-switch" aria-label="菜单" name="导航菜单" aria-expanded="false"><i class="ri-menu-line text-[1.25rem]" aria-hidden="true"></i></button>
        </div>
        <div id="nav-menu-panel" class="float-panel float-panel-closed fixed right-4 px-2 py-2 transition-all">
          <nav aria-label="导航菜单">
            <ul class="fw-nav-mobile flex w-full flex-col">
              {module:navbar}
            </ul>
          </nav>
        </div>
        <div id="display-setting" class="float-panel float-panel-closed absolute transition-all w-80 right-4 px-4 py-4">
          <div class="flex flex-row gap-2 mb-3 items-center justify-between">
            <div class="flex gap-2 font-bold text-lg text-neutral-900 transition relative ml-3 before:w-1 before:h-4 before:rounded-md before:bg-(--primary) before:absolute before:-left-3 before:top-[0.33rem] dark:text-neutral-100">
              主题色
            </div>
            <div class="flex gap-1">
              <button type="button" id="hue-reset" class="btn-regular w-7 h-7 rounded-md active:scale-90 will-change-transform" title="重置为默认值"><i class="ri-refresh-line text-[0.875rem]" aria-hidden="true"></i></button>
              <div id="hueValue" class="transition bg-(--btn-regular-bg) w-10 h-7 rounded-md flex justify-center font-bold text-sm items-center text-(--btn-content)">{$fwHue}</div>
            </div>
          </div>
          <div class="w-full h-6 px-1 bg-[oklch(0.80_0.10_0)] dark:bg-[oklch(0.70_0.10_0)] rounded select-none">
            <input aria-label="主题色" type="range" min="0" max="360" id="colorSlider" step="5" data-default="{$fwDefaultHue}" style="width: 100%" value="{$fwHue}"/>
          </div>
        </div>
        <div id="search-panel" class="float-panel float-panel-closed absolute transition-all right-4 w-96 max-w-[calc(100vw-2rem)] px-4 py-4">
          <form class="fw-search-form flex w-full items-center gap-2" role="search" method="get" action="{$host}search.php">
            <input type="search" name="q" class="fw-search-input h-11 w-full rounded-lg bg-(--btn-regular-bg) px-4 text-sm outline-none transition focus:ring-2 focus:ring-(--primary)/15" placeholder="搜索文章…" autocomplete="off" maxlength="256"/>
            <button type="submit" class="btn-primary h-11 w-11 shrink-0 rounded-lg" aria-label="搜索"><i class="ri-search-line text-[1.25rem]" aria-hidden="true"></i></button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
