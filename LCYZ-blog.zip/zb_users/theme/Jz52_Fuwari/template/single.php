{* Template Name:单篇自动模板 *}
{template:c_head}
<!DOCTYPE html>
<html lang="{$language}" class="{$fwHtmlClass}">
<head>
{template:header}
</head>
<body class="min-h-screen transition {$fwBodyClass}{if $fwBannerEnable} enable-banner{/if}" style="{if $fwBannerEnable}--bannerOffset: {$fwBannerOffset};{/if}">
{template:c_top}
<div id="main-panel-wrapper" class="pointer-events-none absolute z-30 w-full" style="top:{if $fwBannerEnable}calc(35vh - 3.5rem){else}5.5rem{/if}">
  <div class="pointer-events-auto relative mx-auto max-w-(--page-width)">
    <div id="main-grid" class="left-0 right-0 mx-auto grid w-full grid-cols-[17.5rem_auto] grid-rows-[auto_1fr_auto] gap-4 px-0 transition duration-700 md:px-4 lg:grid-rows-[auto]">
      {template:sidebar2}
      <main id="swup-container" class="transition-swup-fade col-span-2 overflow-hidden lg:col-span-1">
        <div id="content-wrapper" class="onload-animation">
          {if $article.Type==ZC_POST_TYPE_ARTICLE}
          {template:post-single}
          {else}
          {template:post-page}
          {/if}
        </div>
      </main>
      {template:c_footer}
    </div>
  </div>
</div>
{template:footer}
</body>
</html>
