{* Template Name:头部计算（片段模板，供入口模板首行引入） *}
{php}
global $zbp;
$fwcfg = $zbp->Config('Jz52_Fuwari');
# 夜间模式：访客 cookie 优先，其次主题默认配色
$fwThemeCookie = GetVars('fuwari_theme', 'COOKIE');
$fwDefaultMode = $fwcfg->color_scheme ? $fwcfg->color_scheme : 'auto';
$fwMode = ($fwThemeCookie !== null && $fwThemeCookie !== '') ? $fwThemeCookie : $fwDefaultMode;
$fwHtmlClass = ($fwMode === 'dark') ? 'dark' : '';
$fwBodyClass = ($fwMode === 'dark') ? 'is-night' : '';
$fwCanChange = ($fwcfg->enable_change_color_scheme === '' || $fwcfg->enable_change_color_scheme == '1');
# 主题色：访客 cookie 优先，固定色调则忽略访客值
$fwHueCookie = GetVars('fuwari_hue', 'COOKIE');
$fwDefaultHue = ($fwcfg->themeColor_hue !== '' && is_numeric($fwcfg->themeColor_hue)) ? (int)$fwcfg->themeColor_hue : 250;
$fwHueFixed = ($fwcfg->themeColor_fixed == '1');
if ($fwHueFixed) {
    $fwHue = $fwDefaultHue;
} else {
    $fwHue = ($fwHueCookie !== null && is_numeric($fwHueCookie)) ? (int)$fwHueCookie : $fwDefaultHue;
}
$fwHue = max(0, min(360, $fwHue));
# Banner
$fwBannerEnable = ($fwcfg->banner_enable == '1');
$fwBannerSrc = $fwcfg->banner_src ? $fwcfg->banner_src : $zbp->host . 'zb_users/theme/Jz52_Fuwari/assets/images/demo-banner.png';
$fwBannerPos = $fwcfg->banner_position ? $fwcfg->banner_position : 'center';
$fwBannerOffset = ($fwcfg->banner_position == 'top') ? '30vh' : (($fwcfg->banner_position == 'bottom') ? '0' : '15vh');
$fwBannerCreditEnable = ($fwcfg->banner_credit_enable == '1');
$fwBannerCreditText = $fwcfg->banner_credit_text;
$fwBannerCreditUrl = $fwcfg->banner_credit_url;
# 首页首屏
$fwHome = false;
if (isset($type) && $type == 'index') {
    if (!isset($page) || $page === '' || $page == '1') {
        $fwHome = true;
    }
}
# 文章页开关
$fwTocEnable = ($fwcfg->enable_toc === '' || $fwcfg->enable_toc == '1');
$fwTocDepth = ($fwcfg->toc_depth !== '' && (int)$fwcfg->toc_depth > 0) ? (int)$fwcfg->toc_depth : 2;
$fwLicenseEnable = ($fwcfg->license_enable == '1');
$fwLicenseName = $fwcfg->license_name ? $fwcfg->license_name : 'CC BY-NC-SA 4.0';
$fwLicenseUrl = $fwcfg->license_url ? $fwcfg->license_url : 'https://creativecommons.org/licenses/by-nc-sa/4.0/';
$fwContentSize = $fwcfg->content_size ? $fwcfg->content_size : 'prose-base';
$fwContentTheme = $fwcfg->content_theme ? $fwcfg->content_theme : 'prose-gray';
# 头像（Favicon 与资料卡共用）
$fwAvatar = $fwcfg->profile_avatar ? $fwcfg->profile_avatar : $zbp->host . 'zb_users/theme/Jz52_Fuwari/assets/images/demo-avatar.png';
{/php}
