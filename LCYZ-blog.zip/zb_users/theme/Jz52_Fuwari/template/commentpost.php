{* Template Name:评论发布框 *}
<div class="post" id="divCommentPost">
  <p class="posttop flex items-center gap-2">
    <a name="comment" class="font-bold text-neutral-900 transition dark:text-neutral-100">{if $user.ID>0}{$user.StaticName}{/if}发表评论</a>
    <a rel="nofollow" id="cancel-reply" href="#divCommentPost" style="display:none;" class="text-sm text-(--primary)">取消回复</a>
  </p>
  <form id="frmSumbit" class="fw-comment-form space-y-4" target="_self" method="post" action="{$article.CommentPostUrl}">
    <input type="hidden" name="inpId" id="inpId" value="{$article.ID}" />
    <input type="hidden" name="inpRevID" id="inpRevID" value="0" />
    {if $user.ID>0}
    <input type="hidden" name="inpName" id="inpName" value="{$user.Name}" />
    <input type="hidden" name="inpEmail" id="inpEmail" value="{$user.Email}" />
    <input type="hidden" name="inpHomePage" id="inpHomePage" value="{$user.HomePage}" />
    {else}
    <div class="grid gap-x-5 gap-y-4 md:grid-cols-3">
      <label class="block">
        <span class="mb-2 block text-sm font-bold text-75">名称<span aria-hidden="true" class="ml-0.5 text-(--primary)">*</span></span>
        <input class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25" type="text" name="inpName" id="inpName" value="{$user.Name}" size="28" tabindex="1"/>
      </label>
      <label class="block">
        <span class="mb-2 block text-sm font-bold text-75">邮箱</span>
        <input class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25" type="text" name="inpEmail" id="inpEmail" value="{$user.Email}" size="28" tabindex="2"/>
      </label>
      <label class="block">
        <span class="mb-2 block text-sm font-bold text-75">网址</span>
        <input class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25" type="text" name="inpHomePage" id="inpHomePage" value="{$user.HomePage}" size="28" tabindex="3"/>
      </label>
    </div>
    {template:commentpost-verify}
    {/if}
    <label class="block">
      <span class="mb-2 block text-sm font-bold text-75">正文<span aria-hidden="true" class="ml-0.5 text-(--primary)">*</span></span>
      <textarea class="fw-form-input w-full rounded-xl border border-black/10 bg-black/[0.025] px-3.5 py-3 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25 min-h-28 resize-y leading-6" name="txaArticle" id="txaArticle" cols="50" rows="4" tabindex="5"></textarea>
    </label>
    <button type="submit" tabindex="6" onclick="return zbp.comment.post()" class="btn-primary inline-flex h-11 items-center justify-center gap-2 rounded-lg px-6 font-bold active:scale-95"><i class="ri-send-plane-fill text-lg" aria-hidden="true"></i>提交</button>
  </form>
  <p class="postbottom mt-4 text-sm text-neutral-400">欢迎参与讨论，请在这里发表您的看法、交流您的观点。</p>
</div>
