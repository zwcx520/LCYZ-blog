{php}
if (!defined('ZBP_PATH')) {
    exit('Access denied');
}
{/php}
{* Template Name:极致·说说 模板 *}
{template:c_head}
<!DOCTYPE html>
<html lang="{$language}" class="{$fwHtmlClass}">
<head>
{template:header}
<link rel="stylesheet" type="text/css" href="{$jz52_pluginurl}css/front.css?v={$jz52_assets_ver}" />
</head>
<body class="min-h-screen transition {$fwBodyClass}{if $fwHome} lg:is-home{/if}{if $fwBannerEnable} enable-banner{/if}" style="{if $fwBannerEnable}--bannerOffset: {$fwBannerOffset};{/if}">
{template:c_top}
<div id="main-panel-wrapper" class="pointer-events-none absolute z-30 w-full" style="top:{if $fwBannerEnable}calc(35vh - 3.5rem){else}5.5rem{/if}">
  <div class="pointer-events-auto relative mx-auto max-w-(--page-width)">
    <div id="main-grid" class="left-0 right-0 mx-auto grid w-full grid-cols-[17.5rem_auto] grid-rows-[auto_1fr_auto] gap-4 px-0 transition duration-700 md:px-4 lg:grid-rows-[auto]">
      {template:sidebar}
      <main id="swup-container" class="transition-swup-fade col-span-2 overflow-hidden lg:col-span-1">
        <div id="content-wrapper" class="onload-animation">

{if $jz52_type == 'list'}
{* ============ 说说列表页 ============ *}
<section class="card-base onload-animation mb-4 overflow-hidden px-5 py-5 md:px-7 md:py-6">
  <div class="mb-5 flex flex-col items-start gap-3 md:flex-row md:items-end md:justify-between">
    <div>
      <h1 class="text-3xl font-bold text-90">{php}echo htmlspecialchars($jz52_pageTitle, ENT_QUOTES, 'UTF-8');{/php}</h1>
      <div class="mt-1 text-sm text-50"><span>{Jz52_shuoshuo_Count(Jz52_shuoshuo_VisibleWhere())} 条动态</span></div>
    </div>
    <a href="{$jz52_rssurl}" class="btn-regular h-11 w-fit rounded-lg px-4 text-sm font-bold active:scale-95"><i class="ri-rss-fill mr-1.5 text-base" aria-hidden="true"></i><span>RSS</span></a>
  </div>

  {if count($jz52_tags) > 0}
  <div class="mb-5 flex flex-wrap gap-2">
    <a href="{$jz52_allurl}" class="btn-card h-9 rounded-lg px-3 text-sm font-bold text-75{if $jz52_tag == ''} bg-(--primary) text-white dark:text-black/70{/if}">全部</a>
    {foreach $jz52_tags as $jz52_tname => $jz52_tcount}
    <a href="{php}echo htmlspecialchars(Jz52_shuoshuo_ListUrl(1, $jz52_tname), ENT_QUOTES, 'UTF-8');{/php}" class="btn-card h-9 rounded-lg px-3 text-sm font-bold text-75{if $jz52_tag == $jz52_tname} bg-(--primary) text-white dark:text-black/70{/if}">{php}echo htmlspecialchars($jz52_tname, ENT_QUOTES, 'UTF-8');{/php}<span class="ml-1 text-30">{$jz52_tcount}</span></a>
    {/foreach}
  </div>
  {/if}

  {if count($jz52_moments) == 0}
  <div class="py-12 text-center text-50">暂无说说</div>
  {else}
  <div class="moment-list divide-y divide-dashed divide-black/10 transition dark:divide-white/15">
    {foreach $jz52_moments as $i => $jz52_moment}
    <article class="relative py-5 onload-animation transition" style="animation-delay: calc(var(--content-delay) + {$i} * 50ms)">
      <div class="flex items-start gap-4">
        <div class="relative shrink-0">
          {if $jz52_cfg.show_author == 1 && $jz52_moment.Avatar != ''}
          <img src="{php}echo htmlspecialchars($jz52_moment->Avatar, ENT_QUOTES, 'UTF-8');{/php}" alt="" class="h-13 w-13 rounded-full object-cover ring-2 ring-(--btn-card-bg-hover)" loading="lazy" />
          <span class="absolute -bottom-0.5 -right-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-(--primary) text-white ring-2 ring-(--card-bg)"><i class="ri-check-line text-base" aria-hidden="true"></i></span>
          {else}
          <span class="flex h-13 w-13 shrink-0 items-center justify-center rounded-full bg-(--btn-regular-bg) text-(--primary) ring-2 ring-(--btn-card-bg-hover)"><i class="ri-account-circle-line text-3xl" aria-hidden="true"></i></span>
          {/if}
        </div>
        <div class="min-w-0 flex-1">
          <div class="flex min-w-0 items-start justify-between gap-3">
            <div class="min-w-0">
              {if $jz52_cfg.show_author == 1}
              <div class="truncate text-base font-bold text-(--primary)">{php}echo htmlspecialchars($jz52_moment->AuthorName, ENT_QUOTES, 'UTF-8');{/php}</div>
              {/if}
              <time class="mt-0.5 block text-sm text-50" datetime="{$jz52_moment.TimeText}">{php}echo htmlspecialchars($jz52_moment->TimeText, ENT_QUOTES, 'UTF-8');{/php}</time>
            </div>
            <div class="flex shrink-0 items-center gap-1">
              {if $jz52_isroot}
                {if $jz52_moment.IsPrivate}<span class="jz52-moment-badge">私密</span>{/if}
                {if $jz52_moment.IsPending}<span class="jz52-moment-badge">待审核</span>{/if}
              {/if}
              <a href="{$jz52_moment.Url}" class="btn-plain h-11 w-11 rounded-lg text-50 active:scale-95" aria-label="查看说说"><i class="ri-more-line text-2xl" aria-hidden="true"></i></a>
            </div>
          </div>
          <div class="custom-md markdown-content prose prose-base mt-4 max-w-none! text-75 dark:prose-invert!">{$jz52_moment.Html}</div>
          {if $jz52_moment.MediaHtml != ''}
          <div class="moment-media mt-4 grid max-w-full gap-2.5">{$jz52_moment.MediaHtml}</div>
          {/if}
          {if count($jz52_moment.TagList) > 0}
          <div class="mt-2 flex flex-wrap gap-x-2 gap-y-1 text-base">
            {foreach $jz52_moment.TagList as $jz52_t}
            <a href="{php}echo htmlspecialchars(Jz52_shuoshuo_ListUrl(1, $jz52_t), ENT_QUOTES, 'UTF-8');{/php}" class="link font-medium text-(--primary)">#{php}echo htmlspecialchars($jz52_t, ENT_QUOTES, 'UTF-8');{/php}</a>
            {/foreach}
          </div>
          {/if}
          <div class="mt-4 flex flex-wrap items-center gap-5 text-sm text-50">
            {if $jz52_cfg.like_enable == 1}
            <button type="button" class="jz52-shuoshuo-like flex h-10 items-center gap-1.5 transition{if $jz52_moment.IsLiked} is-liked{/if}" data-id="{$jz52_moment.ID}" aria-label="点赞"><i class="ri-thumb-up-line text-xl" aria-hidden="true"></i><span class="jz52-shuoshuo-like-num">{$jz52_moment.LikeNums}</span></button>
            {/if}
            <a href="{$jz52_moment.Url}" class="link flex h-10 items-center gap-1.5 text-50"><i class="ri-external-link-line text-xl" aria-hidden="true"></i><span>详情</span></a>
            <a href="{$jz52_moment.Url}#comments" class="flex h-10 items-center gap-1.5"><i class="ri-chat-3-line text-xl" aria-hidden="true"></i><span>{$jz52_moment.CommentNums}</span></a>
          </div>
        </div>
      </div>
    </article>
    {/foreach}
  </div>
  {/if}

  {if $jz52_pager != ''}
  <nav class="mt-6 flex flex-row justify-center gap-3" aria-label="分页">{$jz52_pager}</nav>
  {/if}
</section>

{else}
{* ============ 说说详情页 ============ *}
<section class="card-base onload-animation mb-4 overflow-hidden px-5 py-5 md:px-7 md:py-6">
  <article class="relative">
    <div class="flex items-start gap-4">
      <div class="relative shrink-0">
        {if $jz52_cfg.show_author == 1 && $jz52_moment.Avatar != ''}
        <img src="{php}echo htmlspecialchars($jz52_moment->Avatar, ENT_QUOTES, 'UTF-8');{/php}" alt="" class="h-13 w-13 rounded-full object-cover ring-2 ring-(--btn-card-bg-hover)" />
        <span class="absolute -bottom-0.5 -right-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-(--primary) text-white ring-2 ring-(--card-bg)"><i class="ri-check-line text-base" aria-hidden="true"></i></span>
        {else}
        <span class="flex h-13 w-13 shrink-0 items-center justify-center rounded-full bg-(--btn-regular-bg) text-(--primary) ring-2 ring-(--btn-card-bg-hover)"><i class="ri-account-circle-line text-3xl" aria-hidden="true"></i></span>
        {/if}
      </div>
      <div class="min-w-0 flex-1">
        <div class="flex min-w-0 items-start justify-between gap-3">
          <div class="min-w-0">
            {if $jz52_cfg.show_author == 1}
            <div class="truncate text-base font-bold text-(--primary)">{php}echo htmlspecialchars($jz52_moment->AuthorName, ENT_QUOTES, 'UTF-8');{/php}</div>
            {/if}
            <time class="mt-0.5 block text-sm text-50" datetime="{$jz52_moment.TimeText}">{php}echo htmlspecialchars($jz52_moment->TimeText, ENT_QUOTES, 'UTF-8');{/php}</time>
          </div>
          <div class="flex shrink-0 items-center gap-1">
            {if $jz52_isroot}
              {if $jz52_moment.IsPrivate}<span class="jz52-moment-badge">私密</span>{/if}
              {if $jz52_moment.IsPending}<span class="jz52-moment-badge">待审核</span>{/if}
            {/if}
            <a href="{$jz52_listurl}" class="btn-plain h-11 w-11 rounded-lg text-50 active:scale-95" aria-label="返回说说列表"><i class="ri-arrow-left-line text-2xl" aria-hidden="true"></i></a>
          </div>
        </div>
        <div class="custom-md markdown-content prose prose-base mt-4 max-w-none! text-75 dark:prose-invert!">{$jz52_moment.Html}</div>
        {if $jz52_moment.MediaHtml != ''}
        <div class="moment-media mt-4 grid max-w-full gap-2.5">{$jz52_moment.MediaHtml}</div>
        {/if}
        {if count($jz52_moment.TagList) > 0}
        <div class="mt-2 flex flex-wrap gap-x-2 gap-y-1 text-base">
          {foreach $jz52_moment.TagList as $jz52_t}
          <a href="{php}echo htmlspecialchars(Jz52_shuoshuo_ListUrl(1, $jz52_t), ENT_QUOTES, 'UTF-8');{/php}" class="link font-medium text-(--primary)">#{php}echo htmlspecialchars($jz52_t, ENT_QUOTES, 'UTF-8');{/php}</a>
          {/foreach}
        </div>
        {/if}
        <div class="mt-4 flex flex-wrap items-center gap-5 text-sm text-50">
          {if $jz52_cfg.like_enable == 1}
          <button type="button" class="jz52-shuoshuo-like flex h-10 items-center gap-1.5 transition{if $jz52_moment.IsLiked} is-liked{/if}" data-id="{$jz52_moment.ID}" aria-label="点赞"><i class="ri-thumb-up-line text-xl" aria-hidden="true"></i><span class="jz52-shuoshuo-like-num">{$jz52_moment.LikeNums}</span></button>
          {/if}
          <span class="flex h-10 items-center gap-1.5"><i class="ri-eye-line text-xl" aria-hidden="true"></i><span>{$jz52_moment.ViewNums}</span></span>
          <a href="#comments" class="flex h-10 items-center gap-1.5"><i class="ri-chat-3-line text-xl" aria-hidden="true"></i><span>{$jz52_moment.CommentNums}</span></a>
        </div>
      </div>
    </div>

    {if $jz52_show_comments}{template:lm-shuoshuo-comments}{/if}
  </article>
</section>
{/if}

        </div>
      </main>
      {template:c_footer}
    </div>
  </div>
</div>
{* 说说页脚本：HLS + ArtPlayer + 插件交互（点赞/留言/灯箱/音频） *}
<script type="text/javascript" src="{$jz52_pluginurl}js/hls.min.js?v={$jz52_assets_ver}"></script>
<script type="text/javascript" src="{$jz52_pluginurl}js/artplayer.min.js?v={$jz52_assets_ver}"></script>
<script type="text/javascript">var Jz52ShuoshuoCfg = {likeUrl: "{$jz52_likeurl}", commentUrl: "{$jz52_commenturl}"};</script>
<script type="text/javascript" src="{$jz52_pluginurl}js/front.js?v={$jz52_assets_ver}"></script>
{template:footer}
</body>
</html>
