{* Template Name:首页/列表自动模板 *}
{template:c_head}
<!DOCTYPE html>
<html lang="{$language}" class="{$fwHtmlClass}">
<head>
{template:header}
</head>
<body class="min-h-screen transition {$fwBodyClass}{if $fwHome} lg:is-home{/if}{if $fwBannerEnable} enable-banner{/if}" style="{if $fwBannerEnable}--bannerOffset: {$fwBannerOffset};{/if}">
{template:c_top}
<div id="main-panel-wrapper" class="pointer-events-none absolute z-30 w-full" style="top:{if $fwBannerEnable}calc(35vh - 3.5rem){else}5.5rem{/if}">
  <div class="pointer-events-auto relative mx-auto max-w-(--page-width)">
    <div id="main-grid" class="left-0 right-0 mx-auto grid w-full grid-cols-[17.5rem_auto] grid-rows-[auto_1fr_auto] gap-4 px-0 transition duration-700 md:px-4 lg:grid-rows-[auto]">
      {if $fwBannerEnable && $fwBannerCreditEnable}
      <a id="banner-credit" class="group onload-animation absolute -top-13 right-4 flex h-9 items-center justify-center rounded-full bg-black/60 px-3 transition-all hover:bg-black/70 active:bg-black/80" href="{$fwBannerCreditUrl}" target="_blank" rel="noopener" aria-label="Visit image source">
        <i class="ri-copyright-line mr-1 text-[1.25rem] text-white/75" aria-hidden="true"></i>
        <span class="text-xs text-white/75">{if $fwBannerCreditText}{$fwBannerCreditText}{else}Credit{/if}</span>
        <i class="ri-external-link-line absolute right-4 text-[0.75rem] text-[oklch(0.75_0.14_var(--hue))] opacity-0 transition group-hover:opacity-100" aria-hidden="true"></i>
      </a>
      {/if}
      {template:sidebar}
      <main id="swup-container" class="transition-swup-fade col-span-2 overflow-hidden lg:col-span-1">
        <div id="content-wrapper" class="onload-animation">
          {if count($articles)==0}
          <div class="card-base relative z-10 w-full px-6 py-10 text-center">
            <div class="text-lg font-bold text-neutral-700 transition dark:text-neutral-300">暂无文章</div>
            <div class="mt-2 text-sm text-neutral-400">这里还没有内容，去看看其他页面吧</div>
          </div>
          {else}
          <div class="mb-4 flex flex-col rounded-(--radius-large) bg-(--card-bg) py-1 transition md:gap-4 md:bg-transparent md:py-0">
            {foreach $articles as $i => $article}
            <div class="onload-animation" style="animation-delay: calc(var(--content-delay) + {$i} * 50ms)">
              {if $article.TopType}{template:post-istop}{else}{template:post-multi}{/if}
              <div class="mx-6 border-t-[1px] border-dashed border-black/10 transition last:border-t-0 dark:border-white/15 md:hidden"></div>
            </div>
            {/foreach}
          </div>
          {if $pagebar}
          <nav class="mb-4 onload-animation flex flex-row justify-center gap-3" aria-label="分页">
            {template:pagebar}
          </nav>
          {/if}
          {/if}
        </div>
      </main>
      {template:c_footer}
    </div>
  </div>
</div>
{template:footer}
</body>
</html>
