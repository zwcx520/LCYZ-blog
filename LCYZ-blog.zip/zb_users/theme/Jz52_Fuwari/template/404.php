{* Template Name:404 页 *}
{template:c_head}
{php} $title = '404'; {/php}
<!DOCTYPE html>
<html lang="{$language}" class="{$fwHtmlClass}">
<head>
{template:header}
</head>
<body class="min-h-screen transition {$fwBodyClass}{if $fwBannerEnable} enable-banner{/if}" style="{if $fwBannerEnable}--bannerOffset: {$fwBannerOffset};{/if}">
{template:c_top}
<div id="main-panel-wrapper" class="pointer-events-none absolute z-30 w-full" style="top:{if $fwBannerEnable}calc(35vh - 3.5rem){else}5.5rem{/if}">
  <div class="pointer-events-auto relative mx-auto max-w-(--page-width)">
    <div id="main-grid" class="left-0 right-0 mx-auto grid w-full grid-cols-[17.5rem_auto] grid-rows-[auto_1fr_auto] gap-4 px-0 transition duration-700 md:px-4 lg:grid-rows-[auto]">
      {template:sidebar}
      <main id="swup-container" class="transition-swup-fade col-span-2 overflow-hidden lg:col-span-1">
        <div id="content-wrapper" class="onload-animation">
          <div class="card-base relative z-10 w-full px-6 py-16 text-center">
            <div class="text-7xl font-black text-(--primary)">404</div>
            <div class="mt-4 text-lg font-bold text-neutral-900 transition dark:text-neutral-100">页面不存在</div>
            <div class="mt-2 text-sm text-neutral-400">你访问的页面可能已删除或地址有误</div>
            <a href="{$host}" class="btn-primary mt-8 inline-flex h-11 items-center justify-center rounded-lg px-6 font-bold"><i class="ri-home-4-line mr-2" aria-hidden="true"></i>返回首页</a>
          </div>
        </div>
      </main>
      {template:c_footer}
    </div>
  </div>
</div>
{template:footer}
</body>
</html>
