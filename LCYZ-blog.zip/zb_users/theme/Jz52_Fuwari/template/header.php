{* Template Name:公用页头 *}
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="renderer" content="webkit">
{template:seo}
{if $fwMode == 'auto'}
{pre}<script>(function(){var h=document.documentElement;try{if(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches){h.classList.add('dark');h.style.colorScheme='dark';}}catch(e){}})();</script>{/pre}
{/if}
<link rel="stylesheet" rev="stylesheet" href="{$host}zb_users/theme/{$theme}/style/remixicon/remixicon.css?v={$themeinfo['version']}" type="text/css" media="all" />
<link rel="stylesheet" rev="stylesheet" href="{$host}zb_users/theme/{$theme}/style/fuwari.css?v={$themeinfo['version']}" type="text/css" media="all" />
<link rel="stylesheet" rev="stylesheet" href="{$host}zb_users/theme/{$theme}/style/custom.css?v={$themeinfo['version']}" type="text/css" media="all" />
<style>
:root{--hue: {$fwHue};--jz-header-h: 3.5rem;}
{if $fwcfg->custom_css}
{$fwcfg->custom_css}
{/if}
</style>
<script src="{$host}zb_system/script/jquery-latest.min.js?v={$version}"></script>
<script src="{$host}zb_system/script/zblogphp.js?v={$version}"></script>
<script src="{$host}zb_system/script/c_html_js_add.php?v={$version}"></script>
{$header}
{if $fwcfg->custom_js_head}
{$fwcfg->custom_js_head}
{/if}
