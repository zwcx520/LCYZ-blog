{* Template Name:文章卡片（列表普通项） *}
{php}$fwCover = Jz52_Fuwari_IMG($article);{/php}
<article class="card-base relative flex w-full flex-col-reverse overflow-hidden rounded-(--radius-large) md:flex-col{if $fwCover} has-cover{else} no-cover{/if}">
  <div class="relative w-full pb-6 pl-6 pr-6 pt-6 md:pb-6 md:pl-9 md:pr-2 md:pt-7 md:w-[calc(100%_-_var(--post-card-cover-width)_-_12px)]">
    <a href="{$article.Url}" class="group mb-3 block w-full text-3xl font-bold text-90 transition before:absolute before:left-[18px] before:top-[35px] before:hidden before:h-5 before:w-1 before:rounded-md before:bg-(--primary) hover:text-(--primary) active:text-(--title-active) dark:hover:text-(--primary) dark:active:text-(--title-active) md:before:block">
      <span>{$article.Title}</span>
      <i class="ri-arrow-right-s-line absolute inline translate-y-0.5 text-[2rem] text-(--primary) md:hidden" aria-hidden="true"></i>
      <i class="ri-arrow-right-s-line absolute hidden -translate-x-1 translate-y-0.5 text-[2rem] text-(--primary) opacity-0 transition group-hover:translate-x-0 group-hover:opacity-100 md:inline" aria-hidden="true"></i>
    </a>
    <div class="mb-4 flex flex-wrap items-center gap-4 gap-x-4 gap-y-2 text-neutral-500 dark:text-neutral-400">
      <div class="flex items-center">
        <div class="meta-icon"><i class="ri-calendar-line text-xl" aria-hidden="true"></i></div>
        <span class="text-sm font-medium text-50">{$article.Time('Y-m-d')}</span>
      </div>
      {if $article.Category.ID>0}
      <div class="flex items-center">
        <div class="meta-icon"><i class="ri-book-2-line text-xl" aria-hidden="true"></i></div>
        <div class="flex flex-row flex-nowrap items-center">
          <a href="{$article.Category.Url}" class="link-lg whitespace-nowrap text-sm font-medium text-50 transition hover:text-(--primary) dark:hover:text-(--primary)">{$article.Category.Name}</a>
        </div>
      </div>
      {/if}
      {if count($article.Tags)>0}
      <div class="items-center hidden md:flex">
        <div class="meta-icon"><i class="ri-price-tag-3-line text-xl" aria-hidden="true"></i></div>
        <div class="flex flex-row flex-nowrap items-center">
          {foreach $article.Tags as $ti => $tag}
          <span class="mx-1.5 text-sm text-(--meta-divider) transition">/</span>
          <a href="{$tag.Url}" class="link-lg whitespace-nowrap text-sm font-medium text-50 transition hover:text-(--primary) dark:hover:text-(--primary)">{$tag.Name}</a>
          {/foreach}
        </div>
      </div>
      {/if}
    </div>
    <div class="mb-3.5 pr-4 text-75 transition line-clamp-2 md:line-clamp-1">{Jz52_Fuwari_excerpt($article, 140)}</div>
    <div class="flex items-center gap-4 text-sm text-black/30 transition dark:text-white/30">
      <div class="inline-flex items-center">
        <i class="ri-eye-line mr-1 text-base leading-none" aria-hidden="true"></i>
        <span class="leading-none">{$article.ViewNums}</span>
      </div>
      <div class="leading-none">|</div>
      <div class="inline-flex items-center">
        <i class="ri-chat-3-line mr-1 text-base leading-none" aria-hidden="true"></i>
        <span class="leading-none">{$article.CommNums}</span>
      </div>
    </div>
  </div>
  {if $fwCover}
  <a href="{$article.Url}" aria-label="{$article.Title}" class="group relative mx-4 -mb-2 mt-4 max-h-[20vh] overflow-hidden rounded-xl active:scale-95 md:absolute md:bottom-3 md:right-3 md:top-3 md:mx-0 md:mb-0 md:mt-0 md:max-h-none md:w-(--post-card-cover-width)">
    <div class="pointer-events-none absolute z-10 h-full w-full transition group-hover:bg-black/30 group-active:bg-black/50"></div>
    <div class="pointer-events-none absolute z-20 flex h-full w-full items-center justify-center">
      <i class="ri-arrow-right-s-line scale-50 text-5xl text-white opacity-0 transition group-hover:scale-100 group-hover:opacity-100" aria-hidden="true"></i>
    </div>
    <img src="{$fwCover}" alt="{$article.Title}" class="h-full w-full object-cover" loading="lazy">
  </a>
  {else}
  <a href="{$article.Url}" aria-label="{$article.Title}" class="btn-regular absolute bottom-3 right-3 top-3 !hidden w-[3.25rem] rounded-xl bg-(--enter-btn-bg) hover:bg-(--enter-btn-bg-hover) active:scale-95 active:bg-(--enter-btn-bg-active) md:!flex">
    <i class="ri-arrow-right-s-line mx-auto text-4xl text-(--primary) transition" aria-hidden="true"></i>
  </a>
  {/if}
</article>
