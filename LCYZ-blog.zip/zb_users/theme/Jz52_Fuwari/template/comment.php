{* Template Name:单条评论（楼中楼递归） *}
<li class="fw-comment" id="cmt{$comment.ID}">
  <div class="fw-comment-head">
    <img class="fw-comment-avatar" src="{$comment.Author.Avatar}" alt="{$comment.Author.StaticName}" loading="lazy"/>
    <div class="min-w-0 flex-1">
      <span class="fw-comment-name"><a href="{$comment.Author.HomePage}" rel="nofollow" target="_blank">{$comment.Author.StaticName}</a></span>
      <span class="fw-comment-time">{$comment.Time()}</span>
    </div>
  </div>
  <div class="fw-comment-body">{$comment.Content}</div>
  <div class="fw-comment-actions">
    <label id="AjaxComment{$comment.ID}"></label>
    <a href="#comment" rel="nofollow" onclick="zbp.comment.reply('{$comment.ID}')">回复</a>
  </div>
  <ul class="fw-comment-children">
  {foreach $comment.Comments as $comment}
  {template:comment}
  {/foreach}
  </ul>
</li>
