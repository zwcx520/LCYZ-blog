{* Template Name:搜索页 *}
{template:c_head}
<!DOCTYPE html>
<html lang="{$language}" class="{$fwHtmlClass}">
<head>
{template:header}
</head>
<body class="min-h-screen transition {$fwBodyClass}{if $fwBannerEnable} enable-banner{/if}" style="{if $fwBannerEnable}--bannerOffset: {$fwBannerOffset};{/if}">
{template:c_top}
<div id="main-panel-wrapper" class="pointer-events-none absolute z-30 w-full" style="top:{if $fwBannerEnable}calc(35vh - 3.5rem){else}5.5rem{/if}">
  <div class="pointer-events-auto relative mx-auto max-w-(--page-width)">
    <div id="main-grid" class="left-0 right-0 mx-auto grid w-full grid-cols-[17.5rem_auto] grid-rows-[auto_1fr_auto] gap-4 px-0 transition duration-700 md:px-4 lg:grid-rows-[auto]">
      {template:sidebar}
      <main id="swup-container" class="transition-swup-fade col-span-2 overflow-hidden lg:col-span-1">
        <div id="content-wrapper" class="onload-animation">
          <div class="card-base relative z-10 w-full px-6 py-6 md:px-9">
            <h1 class="text-xl font-bold text-neutral-900 transition dark:text-neutral-100">搜索结果「{$search}」</h1>
            <p class="mt-1 text-sm text-neutral-400">共找到：{if isset($pagebar) && $pagebar}{$pagebar.Count}{else}{count($articles)}{/if} 条记录</p>
          </div>
          {if count($articles)==0}
          <div class="card-base relative z-10 mt-4 w-full px-6 py-10 text-center">
            <div class="text-lg font-bold text-neutral-700 transition dark:text-neutral-300">暂无文章</div>
            <div class="mt-2 text-sm text-neutral-400">这里还没有内容，去看看其他页面吧</div>
          </div>
          {else}
          <div class="mb-4 mt-4 flex flex-col rounded-(--radius-large) bg-(--card-bg) py-1 transition md:gap-4 md:bg-transparent md:py-0">
            {foreach $articles as $i => $article}
            <div class="onload-animation" style="animation-delay: calc(var(--content-delay) + {$i} * 50ms)">
              {template:post-multi}
              <div class="mx-6 border-t-[1px] border-dashed border-black/10 transition last:border-t-0 dark:border-white/15 md:hidden"></div>
            </div>
            {/foreach}
          </div>
          {if $pagebar}
          <nav class="mb-4 onload-animation flex flex-row justify-center gap-3" aria-label="分页">
            {template:pagebar}
          </nav>
          {/if}
          {/if}
        </div>
      </main>
      {template:c_footer}
    </div>
  </div>
</div>
{template:footer}
</body>
</html>
