{* Template Name:所有评论模板 *}
{if $socialcomment}
{$socialcomment}
{else}
<label id="AjaxCommentBegin"></label>
{if count($comments)>0}
<ul class="fw-comment-list">
{foreach $comments as $key => $comment}
{template:comment}
{/foreach}
</ul>
{else}
<div class="fw-comment-empty py-8 text-center text-sm text-neutral-400">还没有评论，快来抢沙发吧</div>
{/if}
{if $pagebar}
<div class="pagebar commentpagebar mb-4 flex flex-row justify-center gap-3">
{template:pagebar}
</div>
{/if}
<label id="AjaxCommentEnd"></label>
{template:commentpost}
{/if}
