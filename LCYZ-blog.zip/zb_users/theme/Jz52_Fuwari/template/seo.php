<?php echo'404';die();?>{* Template Name: SEO * Template Type: none *}
{php}
global $zbp;
$fwcfg = $zbp->Config('Jz52_Fuwari');
$fwSeoGF = $fwcfg->seofgf !== '' ? $fwcfg->seofgf : ' - ';
$fwSeoOpen = ($fwcfg->seo === '' || $fwcfg->seo == '1');
$fwNseo = ($fwcfg->nseo === '' || $fwcfg->nseo == '1');
{/php}
{if $type=='article'}
{php}
$fwArtTags = array();
foreach ($article->Tags as $fwT) {
    $fwArtTags[] = $fwT->Name;
}
if (count($fwArtTags) > 0) {
    $fwKeywords = implode(',', $fwArtTags);
} else {
    $fwKeywords = $zbp->name;
}
$fwDesc = trim(SubStrUTF8(TransferHTML($article->Intro, '[nohtml]'), 110)) . '...';
if ($fwNseo && $article->Metas->nrms) {
    $fwDesc = $article->Metas->nrms;
}
if ($fwNseo && $article->Metas->nrtit) {
    $fwTitle = $article->Metas->nrtit;
} else {
    $fwTitle = $title;
}
{/php}
<title>{$fwTitle}{$fwSeoGF}{$name}</title>
<meta name="keywords" content="{if $fwNseo && $article->Metas->nrgjc}{$article->Metas->nrgjc}{else}{$fwKeywords}{/if}">
<meta name="description" content="{$fwDesc}">
<meta name="applicable-device" content="pc,mobile">
{if !$fwcfg->generator}
<meta name="generator" content="{$zblogphp} Themes: Jz52_Fuwari">
{/if}
{if $fwcfg->og}
<meta property="og:type" content="article">
<meta property="og:title" content="{$fwTitle}">
<meta property="og:site_name" content="{$name}">
<meta property="og:description" content="{$fwDesc}">
<meta property="og:url" content="{$article.Url}">
<meta property="og:image" content="{if $article.ImageCount}{$article.AllImages[0]}{else}{$fwcfg->ogimg}{/if}">
{/if}
{if $article.Prev}
<link rel="prev" title="{$article.Prev.Title}" href="{$article.Prev.Url}">
{/if}
{if $article.Next}
<link rel="next" title="{$article.Next.Title}" href="{$article.Next.Url}">
{/if}
<link rel="canonical" href="{$article.Url}">
{if $fwcfg->google}
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    "headline": "{$fwTitle}",
    "image": [{if $article.ImageCount > 2}"{$article.AllImages[0]}","{$article.AllImages[1]}","{$article.AllImages[2]}"{elseif $article.ImageCount}"{$article.AllImages[0]}"{else}""{/if}],
    "datePublished": "{$article.Time('Y-m-d')}T{$article.Time('H:i:s')}+08:00",
    "dateModified": "{$article.Time('Y-m-d','UpdateTime')}T{$article.Time('H:i:s','UpdateTime')}+08:00",
    "author": [{
        "@type": "Person",
        "name": "{$article.Author.StaticName}",
        "url": "{$article.Author.Url}"
    }]
}
</script>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "{$name}",
        "item": "{$host}"
    },{
        "@type": "ListItem",
        "position": 2,
        "name": "{$article.Category.Name}",
        "item": "{$article.Category.Url}"
    },{
        "@type": "ListItem",
        "position": 3,
        "name": "{$fwTitle}"
    }]
}
</script>
{/if}
{elseif $type=='page'}
{php}
$fwDesc = trim(SubStrUTF8(TransferHTML($article->Content, '[nohtml]'), 110)) . '...';
if ($fwNseo && $article->Metas->nrms) {
    $fwDesc = $article->Metas->nrms;
}
if ($fwNseo && $article->Metas->nrtit) {
    $fwTitle = $article->Metas->nrtit;
} else {
    $fwTitle = $title;
}
{/php}
<title>{$fwTitle}{$fwSeoGF}{$name}</title>
<meta name="keywords" content="{if $fwNseo && $article->Metas->nrgjc}{$article->Metas->nrgjc}{else}{$title}{/if}">
<meta name="description" content="{$fwDesc}">
<meta name="applicable-device" content="pc,mobile">
{if !$fwcfg->generator}
<meta name="generator" content="{$zblogphp} Themes: Jz52_Fuwari">
{/if}
{if $fwcfg->og}
<meta property="og:type" content="article">
<meta property="og:title" content="{$fwTitle}">
<meta property="og:site_name" content="{$name}">
<meta property="og:description" content="{$fwDesc}">
<meta property="og:url" content="{$article.Url}">
<meta property="og:image" content="{if $article.ImageCount}{$article.AllImages[0]}{else}{$fwcfg->ogimg}{/if}">
{/if}
<link rel="canonical" href="{$article.Url}">
{elseif $type=='index'}
{php}
if ($fwcfg->seotitle && $page == '1') {
    $fwTitle = $fwcfg->seotitle;
    if ($subname) {
        $fwTitle .= $fwSeoGF . $subname;
    }
} else {
    $fwTitle = $name;
    if ($page > '1') {
        $fwTitle .= $fwSeoGF . '第' . $pagebar->PageNow . '页';
    }
}
$fwKeywords = $fwcfg->seokeywords ? $fwcfg->seokeywords : $name;
$fwDesc = $fwcfg->seodescription ? $fwcfg->seodescription : $subname;
{/php}
<title>{$fwTitle}</title>
<meta name="keywords" content="{$fwKeywords}">
<meta name="description" content="{$fwDesc}">
<meta name="applicable-device" content="pc,mobile">
{if !$fwcfg->generator}
<meta name="generator" content="{$zblogphp} Themes: Jz52_Fuwari">
{/if}
{if $fwcfg->og}
<meta property="og:type" content="website">
<meta property="og:title" content="{$fwTitle}">
<meta property="og:site_name" content="{$name}">
<meta property="og:description" content="{$fwDesc}">
<meta property="og:url" content="{$host}">
<meta property="og:image" content="{$fwcfg->ogimg}">
{/if}
{if $fwcfg->google && $page == '1'}
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "Organization",
    "url": "{$host}",
    "logo": "{$fwcfg->googlelogo}"
}
</script>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "{$name}",
        "item": "{$host}"
    }]
}
</script>
{/if}
{elseif $type=='tag'}
{php}
if ($fwNseo && $tag->Metas->tagt) {
    $fwTitle = $tag->Metas->tagt;
} else {
    $fwTitle = $tag->Name;
}
if ($page > '1') {
    $fwTitle .= ' 第' . $pagebar->PageNow . '页';
}
if ($fwNseo && $tag->Metas->tagd) {
    $fwDesc = $tag->Metas->tagd . '_' . $title . '_' . $name;
} elseif ($tag->Intro) {
    $fwDesc = $tag->Intro . '_' . $title . '_' . $name;
} else {
    $fwDesc = $title . '_' . $name;
}
{/php}
<title>{$fwTitle}{$fwSeoGF}{$name}</title>
<meta name="keywords" content="{if $fwNseo && $tag->Metas->tagk}{$tag->Metas->tagk}{else}{$tag->Name}{/if}">
<meta name="description" content="{$fwDesc}">
<meta name="applicable-device" content="pc,mobile">
{if !$fwcfg->generator}
<meta name="generator" content="{$zblogphp} Themes: Jz52_Fuwari">
{/if}
{if $fwcfg->og}
<meta property="og:type" content="website">
<meta property="og:title" content="{$fwTitle}">
<meta property="og:site_name" content="{$name}">
<meta property="og:description" content="{$fwDesc}">
<meta property="og:url" content="{$tag.Url}">
<meta property="og:image" content="{$fwcfg->ogimg}">
{/if}
{if $fwcfg->google}
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "{$name}",
        "item": "{$host}"
    },{
        "@type": "ListItem",
        "position": 2,
        "name": "{$tag.Name}",
        "item": "{$tag.Url}"
    }]
}
</script>
{/if}
{elseif $type=='category'}
{php}
if ($fwNseo && $category->Metas->flbt) {
    $fwTitle = $category->Metas->flbt;
    if ($page > '1') {
        $fwTitle .= ' 第' . $pagebar->PageNow . '页';
    }
} else {
    $fwTitle = $title;
}
if ($fwNseo && $category->Metas->fenld) {
    $fwDesc = $category->Metas->fenld . '_' . $title . '_' . $name;
} elseif ($category->Intro) {
    $fwDesc = $category->Intro . '_' . $title . '_' . $name;
} else {
    $fwDesc = $title . '_' . $name;
}
{/php}
<title>{$fwTitle}{$fwSeoGF}{$name}</title>
<meta name="keywords" content="{if $fwNseo && $category->Metas->flgjc}{$category->Metas->flgjc}{else}{$title}{/if},{$name}">
<meta name="description" content="{$fwDesc}">
<meta name="applicable-device" content="pc,mobile">
{if !$fwcfg->generator}
<meta name="generator" content="{$zblogphp} Themes: Jz52_Fuwari">
{/if}
{if $fwcfg->og}
<meta property="og:type" content="website">
<meta property="og:title" content="{$fwTitle}">
<meta property="og:site_name" content="{$name}">
<meta property="og:description" content="{$fwDesc}">
<meta property="og:url" content="{$category.Url}">
<meta property="og:image" content="{$fwcfg->ogimg}">
{/if}
{if $fwcfg->google}
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [{
        "@type": "ListItem",
        "position": 1,
        "name": "{$name}",
        "item": "{$host}"
    },{
        "@type": "ListItem",
        "position": 2,
        "name": "{$category.Name}",
        "item": "{$category.Url}"
    }]
}
</script>
{/if}
{else}
{php}
if ($fwSeoOpen) {
    $fwTitle = $title . $fwSeoGF . $name;
} else {
    $fwTitle = $title . '_' . $name;
}
$fwKeywords = $title . ',' . $name;
$fwDesc = $title . '_' . $name;
if ($page > '1') {
    $fwDesc .= '_第' . $pagebar->PageNow . '页';
}
{/php}
<title>{$fwTitle}</title>
<meta name="keywords" content="{$fwKeywords}">
<meta name="description" content="{$fwDesc}">
<meta name="applicable-device" content="pc,mobile">
{if !$fwcfg->generator}
<meta name="generator" content="{$zblogphp} Themes: Jz52_Fuwari">
{/if}
{/if}
