{* Template Name:分类模块（系统 ModuleBuilder 数据源 $catalogs，Fuwari 行式） *}
<div class="fw-widget-cat" data-more="更多">
  <div class="collapse-wrapper">
    <ul class="fw-widget-list">
      {php}$i = $maxLi; $j = 0;{/php}
      {foreach $catalogs as $catalog}
      <li class="fw-cat-li" data-level="{$catalog.Level}">
        <a class="fw-cat-link" title="{$catalog.Name}" href="{$catalog.Url}">
          <span class="fw-cat-name">{$catalog.Name}</span>
          <span class="fw-cat-count">{if $catalog.Count}{$catalog.Count}{else}0{/if}</span>
        </a>
      </li>
      {$j = $j + 1}
      {if $i != 0 && $j >= $i}
      {php}break;{/php}
      {/if}
      {/foreach}
    </ul>
  </div>
</div>
