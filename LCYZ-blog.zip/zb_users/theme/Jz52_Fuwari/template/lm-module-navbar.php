{* Template Name:导航菜单（LinksManage 递归） *}
<li class="fw-nav-item{if count($item.subs)} fw-has-sub{/if}">
  <a class="fw-nav-link" href="{$item.href}" target="{$item.target}" title="{$item.title}">{$item.ico}{$item.text}</a>
  {if count($item.subs)}
  <ul class="fw-sub-menu">
    {foreach $item.subs as $item}
    {template:lm-module-navbar}
    {/foreach}
  </ul>
  {/if}
</li>
