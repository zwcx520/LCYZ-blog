{* Template Name:分页条（Fuwari 翻页） *}
{if $pagebar}
{php}
$fwPb = $pagebar;
$fwBtns = $fwPb->buttons;
$fwNow = (int) $fwPb->PageNow;
$fwTotal = 0;
foreach ($fwBtns as $k => $v) { $fwTotal = max($fwTotal, (int) $k); }
$fwFull = $fwPb->isFullLink;
$fwKeys = array_keys($fwBtns);
$fwFirst = isset($fwKeys[0]) ? (int) $fwKeys[0] : 1;
$fwLast = isset($fwKeys[count($fwKeys) - 1]) ? (int) $fwKeys[count($fwKeys) - 1] : $fwNow;
$fwPrev = ($fwNow - 1 > 0 && isset($fwBtns[$fwNow - 1])) ? $fwBtns[$fwNow - 1] : (($fwNow - 1 > 0) ? '' : '');
$fwNext = isset($fwBtns[$fwNow + 1]) ? $fwBtns[$fwNow + 1] : '';
{/php}
<a href="{if $fwPrev}{$fwPrev}{else}javascript:void(0);{/if}" class="btn-card h-11 w-11 overflow-hidden rounded-lg text-(--primary){if !$fwPrev} disabled{/if}" aria-label="上一页"><i class="ri-arrow-left-s-line text-[1.75rem]" aria-hidden="true"></i></a>
<div class="flex flex-row items-center rounded-lg bg-(--card-bg) font-bold text-neutral-700 dark:text-neutral-300">
{foreach $fwBtns as $k => $v}
  {if ($fwFull==false)&&($fwNow==$k)}
  <span class="flex h-11 w-11 items-center justify-center rounded-lg bg-(--primary) font-bold text-white dark:text-black/70">{$k}</span>
  {else}
  <a href="{$v}" title="{$k}" class="btn-card h-11 w-11 overflow-hidden rounded-lg active:scale-[0.85]">{$k}</a>
  {/if}
{/foreach}
</div>
<a href="{if $fwNext}{$fwNext}{else}javascript:void(0);{/if}" class="btn-card h-11 w-11 overflow-hidden rounded-lg text-(--primary){if !$fwNext} disabled{/if}" aria-label="下一页"><i class="ri-arrow-right-s-line text-[1.75rem]" aria-hidden="true"></i></a>
{/if}
