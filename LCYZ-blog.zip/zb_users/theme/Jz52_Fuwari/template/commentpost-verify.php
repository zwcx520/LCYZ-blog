{* Template Name:评论验证码 *}
{if $option['ZC_COMMENT_VERIFY_ENABLE'] && !$zbp.CheckRights('NoValidCode')}
<div class="fw-comment-verify flex items-center gap-4 rounded-xl border border-dashed border-black/10 bg-black/[0.02] p-3.5 dark:border-white/15 dark:bg-white/[0.025]">
  <img class="fw-verify-img h-12 w-40 cursor-pointer rounded-lg object-contain" style="width:{$option['ZC_VERIFYCODE_WIDTH']}px;height:{$option['ZC_VERIFYCODE_HEIGHT']}px;" src="{$article.ValidCodeUrl}" alt="验证码" title="点击刷新验证码" onclick="javascript:this.src='{$article.ValidCodeUrl}&amp;tm='+Math.random();"/>
  <label class="flex min-w-0 flex-1 items-center gap-2">
    <input class="fw-form-input h-12 min-w-0 flex-1 rounded-xl border border-black/10 bg-black/[0.025] px-3.5 text-sm text-90 outline-none transition placeholder:text-black/25 hover:border-(--primary)/35 focus:border-(--primary) focus:ring-2 focus:ring-(--primary)/15 dark:border-white/10 dark:bg-white/[0.035] dark:placeholder:text-white/25" type="text" name="inpVerify" id="inpVerify" value="" size="28" tabindex="4"/>
    <span class="shrink-0 text-sm text-75">验证码(*)</span>
  </label>
</div>
{/if}
