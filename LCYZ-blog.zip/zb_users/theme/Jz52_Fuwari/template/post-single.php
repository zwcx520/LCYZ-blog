{* Template Name:文章正文 *}
<article class="relative mb-4 flex w-full overflow-hidden rounded-(--radius-large)">
  <div id="post-container" class="card-base relative z-10 w-full px-6 pb-4 pt-6 md:px-9">
    <div class="onload-animation mb-3 flex flex-row gap-5 text-black/30 transition dark:text-white/30">
      <div class="flex flex-row items-center">
        <div class="mr-2 flex h-6 w-6 items-center justify-center rounded-md bg-black/5 text-black/50 transition dark:bg-white/10 dark:text-white/50"><i class="ri-eye-line" aria-hidden="true"></i></div>
        <span class="text-sm">{$article.ViewNums}</span>
      </div>
      <div class="flex flex-row items-center">
        <div class="mr-2 flex h-6 w-6 items-center justify-center rounded-md bg-black/5 text-black/50 transition dark:bg-white/10 dark:text-white/50"><i class="ri-chat-3-line" aria-hidden="true"></i></div>
        <span class="text-sm">{$article.CommNums}</span>
      </div>
    </div>
    <div class="onload-animation relative">
      <h1 class="mb-3 block w-full text-3xl font-bold text-black/90 transition before:absolute before:-left-4.5 before:top-3 before:h-5 before:rounded-md before:bg-(--primary) dark:text-white/90 md:text-[2.25rem]/[2.75rem] md:before:w-1">{$article.Title}</h1>
    </div>
    <div class="onload-animation">
      <div class="mb-5 flex flex-wrap items-center gap-4 gap-x-4 gap-y-2 text-neutral-500 dark:text-neutral-400">
        <div class="flex items-center">
          <div class="meta-icon"><i class="ri-calendar-line text-xl" aria-hidden="true"></i></div>
          <span class="text-sm font-medium text-50">{$article.Time('Y-m-d')}</span>
        </div>
        {if $article.Category.ID>0}
        <div class="flex items-center">
          <div class="meta-icon"><i class="ri-book-2-line text-xl" aria-hidden="true"></i></div>
          <div class="flex flex-row flex-nowrap items-center">
            <a href="{$article.Category.Url}" class="link-lg whitespace-nowrap text-sm font-medium text-50 transition hover:text-(--primary) dark:hover:text-(--primary)">{$article.Category.Name}</a>
          </div>
        </div>
        {/if}
        {if count($article.Tags)>0}
        <div class="items-center flex">
          <div class="meta-icon"><i class="ri-price-tag-3-line text-xl" aria-hidden="true"></i></div>
          <div class="flex flex-row flex-nowrap items-center">
            {foreach $article.Tags as $ti => $tag}
            <span class="mx-1.5 text-sm text-(--meta-divider) transition">/</span>
            <a href="{$tag.Url}" class="link-lg whitespace-nowrap text-sm font-medium text-50 transition hover:text-(--primary) dark:hover:text-(--primary)">{$tag.Name}</a>
            {/foreach}
          </div>
        </div>
        {/if}
      </div>
    </div>
    <div id="content" class="custom-md markdown-content onload-animation prose prose-base mb-6 max-w-none! dark:prose-invert! {$fwContentSize} {$fwContentTheme}">
      {$article.Content}
    </div>
    {if $fwLicenseEnable}
    <div class="license-container onload-animation relative mb-6 overflow-hidden rounded-xl bg-(--license-block-bg) px-6 py-5 transition">
      <div class="font-bold text-black/75 transition dark:text-white/75">{$article.Title}</div>
      <a data-current-post-url href="{$article.Url}" class="link break-all text-(--primary)">{$article.Url}</a>
      <div class="mt-2 flex flex-wrap gap-6">
        <div>
          <div class="text-sm text-black/30 transition dark:text-white/30">作者</div>
          <div class="line-clamp-2 text-black/75 transition dark:text-white/75">{$article.Author.StaticName}</div>
        </div>
        <div>
          <div class="text-sm text-black/30 transition dark:text-white/30">发布于</div>
          <div class="line-clamp-2 text-black/75 transition dark:text-white/75">{$article.Time('Y-m-d')}</div>
        </div>
        <div>
          <div class="text-sm text-black/30 transition dark:text-white/30">许可协议</div>
          <a href="{$fwLicenseUrl}" target="_blank" rel="noopener" class="link line-clamp-2 text-(--primary)">{$fwLicenseName}</a>
        </div>
      </div>
      <i class="ri-double-quotes-r pointer-events-none absolute right-6 top-1/2 -translate-y-1/2 text-[15rem] text-black/5 transition dark:text-white/5" aria-hidden="true"></i>
    </div>
    {/if}
  </div>
</article>

<nav class="mb-4 flex w-full flex-col justify-between gap-4 overflow-hidden md:flex-row" aria-label="文章导航">
  {if $article.Prev}
  <a href="{$article.Prev.Url}" title="{$article.Prev.Title}" class="w-full overflow-hidden font-bold active:scale-95">
    <div class="btn-card flex h-15 w-full max-w-full justify-start! gap-4 rounded-2xl px-4">
      <i class="ri-arrow-left-s-line text-2xl! font-black text-(--primary)" aria-hidden="true"></i>
      <span class="max-w-[calc(100%-3rem)] overflow-hidden overflow-ellipsis whitespace-nowrap text-black/75 transition dark:text-white/75">{$article.Prev.Title}</span>
    </div>
  </a>
  {else}
  <div class="btn-card h-15 w-full rounded-2xl px-4 text-30"><span>没有更早的文章</span></div>
  {/if}
  {if $article.Next}
  <a href="{$article.Next.Url}" title="{$article.Next.Title}" class="w-full overflow-hidden font-bold active:scale-95">
    <div class="btn-card flex h-15 w-full max-w-full justify-end! gap-4 rounded-2xl px-4">
      <span class="max-w-[calc(100%-3rem)] overflow-hidden overflow-ellipsis whitespace-nowrap text-black/75 transition dark:text-white/75">{$article.Next.Title}</span>
      <i class="ri-arrow-right-s-line text-2xl! font-black text-(--primary)" aria-hidden="true"></i>
    </div>
  </a>
  {else}
  <div class="btn-card h-15 w-full rounded-2xl px-4 text-30"><span>没有更新的文章</span></div>
  {/if}
</nav>

{if !$article.IsLock}
<div class="card-base relative z-10 w-full px-6 pb-4 pt-6 md:px-9" id="comment">
  <h2 class="mb-2 text-base font-medium text-gray-900 dark:text-slate-50">评论</h2>
  {template:comments}
</div>
{/if}
