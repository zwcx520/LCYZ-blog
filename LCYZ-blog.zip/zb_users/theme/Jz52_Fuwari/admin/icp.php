<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_Fuwari/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_Fuwari_SubMenu('icp.php'); ?><a target="_blank" href="https://gebilaoli.com/"><span class="m-right">不见桃花不见秋</span></a>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span class="m-right">更多应用</span></a>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken') {
                continue;
            }
            $zbp->Config('Jz52_Fuwari')->$k = $v;
        }
        $zbp->SaveConfig('Jz52_Fuwari');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    $cfg = $zbp->Config('Jz52_Fuwari');
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">备案信息</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>ICP 备案号</p></td>
          <td><?php ZbpForm::text('icp_text', $cfg->icp_text, '280px', '如 鲁ICP备00000000号'); ?></td>
          <td><p class="jz-desc">页脚显示的 ICP 备案号，留空不显示</p></td>
        </tr>
        <tr>
          <td align="center"><p>ICP 链接</p></td>
          <td><?php ZbpForm::text('icp_link', $cfg->icp_link, '280px', '备案查询地址'); ?></td>
          <td><p class="jz-desc">点击备案号跳转的地址</p></td>
        </tr>
        <tr>
          <td align="center"><p>公安备案号</p></td>
          <td><?php ZbpForm::text('gongan_text', $cfg->gongan_text, '280px', '如 鲁公网安备37000000000000号'); ?></td>
          <td><p class="jz-desc">页脚显示的公安备案号，留空不显示</p></td>
        </tr>
        <tr>
          <td align="center"><p>公安链接</p></td>
          <td><?php ZbpForm::text('gongan_link', $cfg->gongan_link, '280px', '公安备案查询地址'); ?></td>
          <td><p class="jz-desc">点击公安备案号跳转的地址</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_Fuwari");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
