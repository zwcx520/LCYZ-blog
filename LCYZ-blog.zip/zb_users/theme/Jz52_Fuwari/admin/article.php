<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_Fuwari/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_Fuwari_SubMenu('article.php'); ?><a target="_blank" href="https://gebilaoli.com/"><span class="m-right">不见桃花不见秋</span></a>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span class="m-right">更多应用</span></a>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken') {
                continue;
            }
            $zbp->Config('Jz52_Fuwari')->$k = $v;
        }
        $zbp->SaveConfig('Jz52_Fuwari');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    $cfg = $zbp->Config('Jz52_Fuwari');
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">许可协议</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>显示许可协议</p></td>
          <td><?php ZbpForm::radio('license_enable', array('0' => '否', '1' => '是'), $cfg->license_enable); ?></td>
          <td><p class="jz-desc">文章底部显示版权许可协议</p></td>
        </tr>
        <tr>
          <td align="center"><p>协议名称</p></td>
          <td><?php ZbpForm::text('license_name', $cfg->license_name, '280px', '协议名称'); ?></td>
          <td><p class="jz-desc">如 CC BY-NC-SA 4.0</p></td>
        </tr>
        <tr>
          <td align="center"><p>协议链接</p></td>
          <td><?php ZbpForm::text('license_url', $cfg->license_url, '280px', '协议说明地址'); ?></td>
          <td><p class="jz-desc">协议说明页面地址</p></td>
        </tr>
      </table>
      <div class="jztit">文章排版</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>正文字号</p></td>
          <td><?php ZbpForm::radio('content_size', array('prose-sm' => '小', 'prose-base' => '标准', 'prose-lg' => '大'), $cfg->content_size); ?></td>
          <td><p class="jz-desc">文章正文字号大小</p></td>
        </tr>
        <tr>
          <td align="center"><p>目录导航</p></td>
          <td><?php ZbpForm::radio('enable_toc', array('1' => '是', '0' => '否'), $cfg->enable_toc); ?></td>
          <td><p class="jz-desc">文章页右侧显示目录导航</p></td>
        </tr>
        <tr>
          <td align="center"><p>目录层级</p></td>
          <td><?php ZbpForm::radio('toc_depth', array('2' => '2 级', '3' => '3 级', '4' => '4 级'), $cfg->toc_depth); ?></td>
          <td><p class="jz-desc">目录提取的最大标题层级</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_Fuwari");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
