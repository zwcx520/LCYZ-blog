<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_Fuwari/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_Fuwari_SubMenu('sidebar.php'); ?><a target="_blank" href="https://gebilaoli.com/"><span class="m-right">不见桃花不见秋</span></a>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span class="m-right">更多应用</span></a>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken') {
                continue;
            }
            $zbp->Config('Jz52_Fuwari')->$k = $v;
        }
        $zbp->SaveConfig('Jz52_Fuwari');
        Jz52_Fuwari_Event_CreateModule();
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    $cfg = $zbp->Config('Jz52_Fuwari');
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">个人资料卡</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>显示资料卡</p></td>
          <td><?php ZbpForm::radio('profile_enable', array('1' => '是', '0' => '否'), $cfg->profile_enable); ?></td>
          <td><p class="jz-desc">侧栏顶部显示博主个人资料卡</p></td>
        </tr>
        <tr>
          <td align="center"><p>头像</p></td>
          <td>
            <div class="cfg-preview" id="profile-avatar-prev"><img src="<?php echo $cfg->profile_avatar; ?>" alt="" onerror="this.style.display='none'" style="max-height:54px;max-width:220px;"></div>
            <div class="cfg-upload uploadimg" data-id="profile-avatar-prev">
              <?php ZbpForm::text('profile_avatar', $cfg->profile_avatar, '280px', '图片地址或点击浏览'); ?><strong>浏览文件</strong>
            </div>
          </td>
          <td><p class="jz-desc">头像图片，建议方形；留空使用主题默认头像</p></td>
        </tr>
        <tr>
          <td align="center"><p>昵称</p></td>
          <td><?php ZbpForm::text('profile_name', $cfg->profile_name, '280px', '你的昵称'); ?></td>
          <td><p class="jz-desc">留空显示网站名称</p></td>
        </tr>
        <tr>
          <td align="center"><p>简介</p></td>
          <td><?php ZbpForm::text('profile_bio', $cfg->profile_bio, '280px', '一句话介绍'); ?></td>
          <td><p class="jz-desc">留空显示网站副标题</p></td>
        </tr>
        <tr>
          <td align="center"><p>主页链接</p></td>
          <td><?php ZbpForm::text('profile_url', $cfg->profile_url, '280px', '个人主页地址'); ?></td>
          <td><p class="jz-desc">点击头像跳转的地址，留空为网站首页</p></td>
        </tr>
        <tr>
          <td align="center"><p>社交图标</p></td>
          <td><?php ZbpForm::textarea('profile_social', $cfg->profile_social, '380px', '120px', '每行：平台|名称|链接'); ?></td>
          <td><p class="jz-desc">每行一个，格式：平台|名称|链接，如 github|GitHub|https://github.com/xxx；支持 github/qq/wechat/weibo/bilibili/twitter/telegram/youtube/instagram/rss 等平台</p></td>
        </tr>
      </table>
      <div class="jztit">音乐部件</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>启用音乐</p></td>
          <td><?php ZbpForm::radio('music_enable', array('1' => '是', '0' => '否'), $cfg->music_enable); ?></td>
          <td><p class="jz-desc">侧栏显示音乐播放器部件</p></td>
        </tr>
        <tr>
          <td align="center"><p>音乐服务器</p></td>
          <td><?php ZbpForm::radio('music_server', array('netease' => '网易云', 'tencent' => 'QQ音乐', 'xiami' => '虾米', 'kugou' => '酷狗', 'baidu' => '百度'), $cfg->music_server); ?></td>
          <td><p class="jz-desc">音乐来源平台</p></td>
        </tr>
        <tr>
          <td align="center"><p>资源类型</p></td>
          <td><?php ZbpForm::radio('music_type', array('playlist' => '歌单', 'song' => '单曲', 'album' => '专辑', 'artist' => '歌手', 'radio' => '电台'), $cfg->music_type); ?></td>
          <td><p class="jz-desc">按对应平台的分享链接类型选择</p></td>
        </tr>
        <tr>
          <td align="center"><p>歌单/歌曲 ID</p></td>
          <td><?php ZbpForm::text('music_id', $cfg->music_id, '280px', '资源 ID'); ?></td>
          <td><p class="jz-desc">对应平台资源的 ID（歌单号/歌曲 ID 等）</p></td>
        </tr>
        <tr>
          <td align="center"><p>播放模式</p></td>
          <td><?php ZbpForm::radio('music_play_mode', array('list' => '列表循环', 'random' => '随机播放', 'single' => '单曲循环'), $cfg->music_play_mode); ?></td>
          <td><p class="jz-desc">默认播放模式</p></td>
        </tr>
        <tr>
          <td align="center"><p>默认音量</p></td>
          <td><?php ZbpForm::text('music_volume', $cfg->music_volume, '280px', '0-1'); ?></td>
          <td><p class="jz-desc">0-1 之间的小数，如 0.7</p></td>
        </tr>
        <tr>
          <td align="center"><p>自定义接口</p></td>
          <td><?php ZbpForm::text('music_api', $cfg->music_api, '280px', '音乐接口地址'); ?></td>
          <td><p class="jz-desc">自定义音乐解析接口，留空使用默认接口</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_Fuwari");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
