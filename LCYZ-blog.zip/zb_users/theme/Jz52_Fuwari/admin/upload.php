<?php
require '../../../../zb_system/function/c_system_base.php';
require '../../../../zb_system/function/c_system_admin.php';
$zbp->Load();
header('Content-Type: application/json; charset=utf-8');
if (!$zbp->CheckRights('root')) {
    die('{"state":"error","msg":"无权限"}');
}
if ($_POST) {
    if (!$zbp->VerifyCSRFToken(isset($_POST['csrfToken']) ? $_POST['csrfToken'] : '')) {
        die('{"state":"error","msg":"CSRF 校验失败，请刷新页面重试"}');
    }
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== 0) {
        die('{"state":"error","msg":"上传失败，请重试"}');
    }
    $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
    $allowExt = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico');
    if (!in_array($ext, $allowExt)) {
        die('{"state":"error","msg":"只允许上传图片文件（jpg/png/gif/webp/bmp/svg/ico）"}');
    }
    $_POST['auto_rename'] = 'on';
    $upload = PostUpload();
    if ($upload) {
        echo json_encode(array('state' => 'success', 'url' => $upload->Url, 'msg' => ''));
        exit;
    }
    echo json_encode(array('state' => 'error', 'msg' => '上传失败，请检查图片大小'));
    exit;
}
echo json_encode(array('state' => 'error', 'msg' => '非法请求'));
