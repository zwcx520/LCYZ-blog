<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_Fuwari/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_Fuwari_SubMenu('seo.php'); ?><a target="_blank" href="https://gebilaoli.com/"><span class="m-right">不见桃花不见秋</span></a>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span class="m-right">更多应用</span></a>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken') {
                continue;
            }
            $zbp->Config('Jz52_Fuwari')->$k = $v;
        }
        $zbp->SaveConfig('Jz52_Fuwari');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    $cfg = $zbp->Config('Jz52_Fuwari');
    function fw_seo_check($v) { return $v == '1' ? ' checked="checked"' : ''; }
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">SEO 设置</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>启用主题 SEO</p></td>
          <td><input type="checkbox" name="seo" value="1"<?php echo fw_seo_check($cfg->seo); ?>/></td>
          <td><p class="jz-desc">主题自带 SEO 输出，安装了 SEO 插件请关闭</p></td>
        </tr>
        <tr>
          <td align="center"><p>首页标题</p></td>
          <td><?php ZbpForm::text('seotitle', $cfg->seotitle, '280px', '自定义首页标题'); ?></td>
          <td><p class="jz-desc">自定义首页标题，留空使用站点名</p></td>
        </tr>
        <tr>
          <td align="center"><p>首页关键词</p></td>
          <td><?php ZbpForm::text('seokeywords', $cfg->seokeywords, '280px', '多个关键词用逗号隔开'); ?></td>
          <td><p class="jz-desc">多个关键词用英文逗号隔开</p></td>
        </tr>
        <tr>
          <td align="center"><p>首页描述</p></td>
          <td><?php ZbpForm::textarea('seodescription', $cfg->seodescription, '380px', '60px', '网站描述'); ?></td>
          <td><p class="jz-desc">网站描述</p></td>
        </tr>
        <tr>
          <td align="center"><p>文章自定义 SEO</p></td>
          <td><input type="checkbox" name="nseo" value="1"<?php echo fw_seo_check($cfg->nseo); ?>/></td>
          <td><p class="jz-desc">开启后文章/分类/标签编辑页可自定义标题、关键词、描述</p></td>
        </tr>
        <tr>
          <td align="center"><p>标题分隔符</p></td>
          <td><?php ZbpForm::text('seofgf', $cfg->seofgf, '280px', '标题分隔符'); ?></td>
          <td><p class="jz-desc">标题拼接分隔符，默认 -</p></td>
        </tr>
      </table>
      <div class="jztit">社交分享</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>Open Graph</p></td>
          <td><input type="checkbox" name="og" value="1"<?php echo fw_seo_check($cfg->og); ?>/></td>
          <td><p class="jz-desc">输出 og: 社交分享标签</p></td>
        </tr>
        <tr>
          <td align="center"><p>OG 默认图</p></td>
          <td>
            <div class="cfg-preview" id="ogimg-prev"><img src="<?php echo $cfg->ogimg; ?>" alt="" onerror="this.style.display='none'"></div>
            <div class="cfg-upload uploadimg" data-id="ogimg-prev">
              <?php ZbpForm::text('ogimg', $cfg->ogimg, '280px', '图片地址或点击浏览'); ?><strong>浏览文件</strong>
            </div>
          </td>
          <td><p class="jz-desc">文章无图时分享默认图</p></td>
        </tr>
      </table>
      <div class="jztit">搜索引擎</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>Schema.org</p></td>
          <td><input type="checkbox" name="google" value="1"<?php echo fw_seo_check($cfg->google); ?>/></td>
          <td><p class="jz-desc">输出结构化数据（NewsArticle/BreadcrumbList/Organization）</p></td>
        </tr>
        <tr>
          <td align="center"><p>站点 Logo</p></td>
          <td>
            <div class="cfg-preview" id="googlelogo-prev"><img src="<?php echo $cfg->googlelogo; ?>" alt="" onerror="this.style.display='none'"></div>
            <div class="cfg-upload uploadimg" data-id="googlelogo-prev">
              <?php ZbpForm::text('googlelogo', $cfg->googlelogo, '280px', '图片地址或点击浏览'); ?><strong>浏览文件</strong>
            </div>
          </td>
          <td><p class="jz-desc">Organization 结构化数据 Logo</p></td>
        </tr>
        <tr>
          <td align="center"><p>隐藏 generator</p></td>
          <td><input type="checkbox" name="generator" value="1"<?php echo fw_seo_check($cfg->generator); ?>/></td>
          <td><p class="jz-desc">勾选后不输出 meta generator</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_Fuwari");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
