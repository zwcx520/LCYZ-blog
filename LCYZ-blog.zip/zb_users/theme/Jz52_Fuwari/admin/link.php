<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_Fuwari/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_Fuwari_SubMenu('link.php'); ?><a target="_blank" href="https://gebilaoli.com/"><span class="m-right">不见桃花不见秋</span></a>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span class="m-right">更多应用</span></a>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken') {
                continue;
            }
            $zbp->Config('Jz52_Fuwari')->$k = $v;
        }
        $zbp->SaveConfig('Jz52_Fuwari');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    $cfg = $zbp->Config('Jz52_Fuwari');
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">友链列表</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>友链列表</p></td>
          <td><p><?php ZbpForm::textarea('links_list', htmlspecialchars($cfg->links_list), '300px', '160px', '名称|网址|简介|头像'); ?></p></td>
          <td><p class="jz-desc">每行一条，格式：名称|网址|简介|头像地址（后两项可留空）。友链申请提交到「友链」页面的评论区，站长手动审核后把对方站点填入此处展示</p></td>
        </tr>
        <tr>
          <td align="center"><p>默认头像</p></td>
          <td>
            <div class="cfg-preview" id="links-avatar-prev"><img src="<?php echo htmlspecialchars($cfg->links_default_avatar); ?>" alt="" onerror="this.style.display='none'" style="height:36px;border-radius:50%;"></div>
            <div class="cfg-upload uploadimg" data-id="links-avatar-prev">
              <?php ZbpForm::text('links_default_avatar', htmlspecialchars($cfg->links_default_avatar), '280px', '图片地址或点击浏览'); ?><strong>浏览文件</strong>
            </div>
          </td>
          <td><p class="jz-desc">友链未填写头像时使用的默认头像，留空显示链接图标</p></td>
        </tr>
      </table>
      <div class="jztit">申请设置</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>启用友链申请</p></td>
          <td><p><?php ZbpForm::radio('link_apply_enable', array('1' => '开启', '0' => '关闭'), (int) $cfg->link_apply_enable); ?></p></td>
          <td><p class="jz-desc">友链页显示本站资料与自助申请表单，提交内容作为留言发送</p></td>
        </tr>
        <tr>
          <td align="center"><p>申请说明</p></td>
          <td><p><?php ZbpForm::textarea('links_apply_desc', htmlspecialchars($cfg->links_apply_desc), '300px', '80px', '申请条件说明'); ?></p></td>
          <td><p class="jz-desc">友链申请区上方的说明文字，留空使用默认文案</p></td>
        </tr>
        <tr>
          <td align="center"><p>申请目标页面 ID</p></td>
          <td><p><?php ZbpForm::text('links_target', htmlspecialchars($cfg->links_target), '120px', '留空为本页'); ?></p></td>
          <td><p class="jz-desc">友链申请提交到哪个页面的评论（填写页面 ID），留空提交到本页</p></td>
        </tr>
      </table>
      <div class="jztit">本站友链信息</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>本站名称</p></td>
          <td><p><?php ZbpForm::text('links_my_name', htmlspecialchars($cfg->links_my_name), '300px', '留空使用站点名称'); ?></p></td>
          <td><p class="jz-desc">申请表单中展示的本站信息，供对方站长复制</p></td>
        </tr>
        <tr>
          <td align="center"><p>本站网址</p></td>
          <td><p><?php ZbpForm::text('links_my_url', htmlspecialchars($cfg->links_my_url), '300px', '留空使用站点地址'); ?></p></td>
          <td><p class="jz-desc">申请表单中展示的本站网址</p></td>
        </tr>
        <tr>
          <td align="center"><p>本站简介</p></td>
          <td><p><?php ZbpForm::text('links_my_desc', htmlspecialchars($cfg->links_my_desc), '300px', '留空使用站点描述'); ?></p></td>
          <td><p class="jz-desc">申请表单中展示的本站简介</p></td>
        </tr>
        <tr>
          <td align="center"><p>本站头像</p></td>
          <td>
            <div class="cfg-preview" id="links-my-prev"><img src="<?php echo htmlspecialchars($cfg->links_my_avatar); ?>" alt="" onerror="this.style.display='none'" style="height:36px;border-radius:50%;"></div>
            <div class="cfg-upload uploadimg" data-id="links-my-prev">
              <?php ZbpForm::text('links_my_avatar', htmlspecialchars($cfg->links_my_avatar), '280px', '图片地址或点击浏览'); ?><strong>浏览文件</strong>
            </div>
          </td>
          <td><p class="jz-desc">申请表单中展示的本站头像</p></td>
        </tr>
        <tr>
          <td align="center"><p>本站友链页面</p></td>
          <td><p><?php ZbpForm::text('links_apply_site_link_page', htmlspecialchars($cfg->links_apply_site_link_page), '300px', '留空使用站点地址+/links'); ?></p></td>
          <td><p class="jz-desc">申请表单中展示的本站友链页面地址</p></td>
        </tr>
        <tr>
          <td align="center"><p>本站 RSS 订阅</p></td>
          <td><p><?php ZbpForm::text('links_apply_site_rss_url', htmlspecialchars($cfg->links_apply_site_rss_url), '300px', '留空使用站点地址+/feed.php'); ?></p></td>
          <td><p class="jz-desc">申请表单中展示的本站 RSS 地址</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_Fuwari");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
