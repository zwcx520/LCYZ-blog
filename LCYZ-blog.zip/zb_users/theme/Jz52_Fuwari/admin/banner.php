<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_Fuwari/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_Fuwari_SubMenu('banner.php'); ?><a target="_blank" href="https://gebilaoli.com/"><span class="m-right">不见桃花不见秋</span></a>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span class="m-right">更多应用</span></a>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken') {
                continue;
            }
            $zbp->Config('Jz52_Fuwari')->$k = $v;
        }
        $zbp->SaveConfig('Jz52_Fuwari');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    $cfg = $zbp->Config('Jz52_Fuwari');
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">横幅设置</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>启用横幅</p></td>
          <td><?php ZbpForm::radio('banner_enable', array('1' => '是', '0' => '否'), $cfg->banner_enable); ?></td>
          <td><p class="jz-desc">开启后在页头显示横幅大图</p></td>
        </tr>
        <tr>
          <td align="center"><p>横幅图片</p></td>
          <td>
            <div class="cfg-preview" id="banner-src-prev"><img src="<?php echo $cfg->banner_src; ?>" alt="" onerror="this.style.display='none'" style="max-height:54px;max-width:220px;"></div>
            <div class="cfg-upload uploadimg" data-id="banner-src-prev">
              <?php ZbpForm::text('banner_src', $cfg->banner_src, '280px', '图片地址或点击浏览'); ?><strong>浏览文件</strong>
            </div>
          </td>
          <td><p class="jz-desc">横幅背景图，建议使用宽图；留空则使用渐变背景</p></td>
        </tr>
        <tr>
          <td align="center"><p>图片位置</p></td>
          <td><?php ZbpForm::radio('banner_position', array('center' => '居中', 'left' => '靠左', 'right' => '靠右'), $cfg->banner_position); ?></td>
          <td><p class="jz-desc">横幅背景图的水平对齐位置</p></td>
        </tr>
        <tr>
          <td align="center"><p>显示图片来源</p></td>
          <td><?php ZbpForm::radio('banner_credit_enable', array('0' => '否', '1' => '是'), $cfg->banner_credit_enable); ?></td>
          <td><p class="jz-desc">横幅右上角显示图片来源版权信息</p></td>
        </tr>
        <tr>
          <td align="center"><p>版权文字</p></td>
          <td><?php ZbpForm::text('banner_credit_text', $cfg->banner_credit_text, '280px', '图片来源文字'); ?></td>
          <td><p class="jz-desc">如：© 2022 Fuwari</p></td>
        </tr>
        <tr>
          <td align="center"><p>版权链接</p></td>
          <td><?php ZbpForm::text('banner_credit_url', $cfg->banner_credit_url, '280px', '图片来源地址'); ?></td>
          <td><p class="jz-desc">点击版权文字跳转的地址，留空不跳转</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_Fuwari");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
