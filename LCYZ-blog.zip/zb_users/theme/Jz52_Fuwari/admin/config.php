<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_Fuwari/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_Fuwari_SubMenu('config.php'); ?><a target="_blank" href="https://gebilaoli.com/"><span class="m-right">不见桃花不见秋</span></a>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span class="m-right">更多应用</span></a>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken') {
                continue;
            }
            $zbp->Config('Jz52_Fuwari')->$k = $v;
        }
        $zbp->SaveConfig('Jz52_Fuwari');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    $cfg = $zbp->Config('Jz52_Fuwari');
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">网站 Logo</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>Logo 图片</p></td>
          <td><p><?php ZbpForm::radio('logo_img_enable', array('1' => '开启', '0' => '关闭'), (int) $cfg->logo_img_enable); ?></p></td>
          <td><p class="jz-desc">开启后导航栏显示上传的 Logo 图片</p></td>
        </tr>
        <tr>
          <td align="center"><p>图片地址</p></td>
          <td>
            <div class="cfg-preview" id="logo-img-prev"><img src="<?php echo htmlspecialchars($cfg->logo_img); ?>" alt="" onerror="this.style.display='none'" style="height:36px;border-radius:6px;"></div>
            <div class="cfg-upload uploadimg" data-id="logo-img-prev">
              <?php ZbpForm::text('logo_img', htmlspecialchars($cfg->logo_img), '280px', '图片地址或点击浏览'); ?><strong>浏览文件</strong>
            </div>
          </td>
          <td><p class="jz-desc">导航栏 Logo 图片地址，可上传或直接填 URL</p></td>
        </tr>
        <tr>
          <td align="center"><p>Logo 图标（ico）</p></td>
          <td><p><?php ZbpForm::radio('logo_ico_enable', array('1' => '开启', '0' => '关闭'), (int) $cfg->logo_ico_enable); ?></p></td>
          <td><p class="jz-desc">开启后 Logo 前显示站点图标（不填则用默认图标）</p></td>
        </tr>
        <tr>
          <td align="center"><p>图标地址</p></td>
          <td>
            <div class="cfg-preview" id="logo-ico-prev"><img src="<?php echo htmlspecialchars($cfg->logo_ico); ?>" alt="" onerror="this.style.display='none'" style="height:36px;border-radius:6px;"></div>
            <?php ZbpForm::text('logo_ico', htmlspecialchars($cfg->logo_ico), '280px', 'ico 图标地址（http://… 或 /favicon.ico）'); ?>
          </td>
          <td><p class="jz-desc">ico 图标地址（可用 favicon 或任意小图），留空显示默认图标</p></td>
        </tr>
        <tr>
          <td align="center"><p>Logo 文字</p></td>
          <td><p><?php ZbpForm::radio('logo_text_enable', array('1' => '开启', '0' => '关闭'), (int) $cfg->logo_text_enable); ?></p></td>
          <td><p class="jz-desc">开启后 Logo 位置显示站点名称文字</p></td>
        </tr>
        <tr>
          <td align="center"><p>文字内容</p></td>
          <td><p><?php ZbpForm::text('logo_text', htmlspecialchars($cfg->logo_text), '280px', '留空使用站点名称'); ?></p></td>
          <td><p class="jz-desc">Logo 文字内容，留空显示站点名称（{$name}）</p></td>
        </tr>
      </table>
      <div class="jztit">主题色</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>主题色 Hue</p></td>
          <td><?php ZbpForm::text('themeColor_hue', $cfg->themeColor_hue, '280px', '0-360'); ?></td>
          <td><p class="jz-desc">主题色相值（0-360），控制整个站点的主色调</p></td>
        </tr>
        <tr>
          <td align="center"><p>固定主题色</p></td>
          <td><?php ZbpForm::radio('themeColor_fixed', array('0' => '否', '1' => '是'), $cfg->themeColor_fixed); ?></td>
          <td><p class="jz-desc">开启后前台不再显示主题色选择器，禁止访客修改</p></td>
        </tr>
      </table>
      <div class="jztit">外观模式</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>默认配色方案</p></td>
          <td><?php ZbpForm::radio('color_scheme', array('auto' => '跟随系统', 'light' => '亮色', 'dark' => '暗色'), $cfg->color_scheme); ?></td>
          <td><p class="jz-desc">默认的亮暗模式，auto 为跟随系统</p></td>
        </tr>
        <tr>
          <td align="center"><p>允许切换配色</p></td>
          <td><?php ZbpForm::radio('enable_change_color_scheme', array('1' => '是', '0' => '否'), $cfg->enable_change_color_scheme); ?></td>
          <td><p class="jz-desc">关闭后前台不显示亮暗模式切换按钮</p></td>
        </tr>
      </table>
      <div class="jztit">卸载设置</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>卸载清除配置</p></td>
          <td><?php ZbpForm::radio('DelConfig', array('0' => '否', '1' => '是'), $cfg->DelConfig); ?></td>
          <td><p class="jz-desc">卸载主题时是否同时删除主题配置数据</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_Fuwari");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
