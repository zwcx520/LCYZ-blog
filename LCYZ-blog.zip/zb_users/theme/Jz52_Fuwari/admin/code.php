<?php
require '../../../../zb_system/function/c_system_base.php';
require $blogpath . 'zb_users/theme/Jz52_Fuwari/admin/Admin_header.php';
?>
<div class="SubMenu jzSubMenu">
  <?php Jz52_Fuwari_SubMenu('code.php'); ?><a target="_blank" href="https://gebilaoli.com/"><span class="m-right">不见桃花不见秋</span></a>
  <a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc" ><span class="m-right">更多应用</span></a>
</div>
<div id="divMain2">
<?php
    if ($_POST) {
        CheckIsRefererValid();
        foreach ($_POST as $k => $v) {
            if ($k == 'csrfToken') {
                continue;
            }
            $zbp->Config('Jz52_Fuwari')->$k = $v;
        }
        $zbp->SaveConfig('Jz52_Fuwari');
        $zbp->SetHint('good');
        redirect(GetVars('HTTP_REFERER', 'SERVER'));
    }
    $cfg = $zbp->Config('Jz52_Fuwari');
    ?>
    <form class="jzadmin" method="post" action="">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
      <div class="jztit">自定义样式</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>自定义 CSS</p></td>
          <td><?php ZbpForm::textarea('custom_css', $cfg->custom_css, '380px', '160px', '自定义样式代码'); ?></td>
          <td><p class="jz-desc">追加到主题样式表之后，覆盖默认样式</p></td>
        </tr>
      </table>
      <div class="jztit">自定义脚本</div>
      <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
        <tr>
          <td width="20%" align="center"><p>头部 JS</p></td>
          <td><?php ZbpForm::textarea('custom_js_head', $cfg->custom_js_head, '380px', '120px', '头部脚本代码'); ?></td>
          <td><p class="jz-desc">输出在 &lt;/head&gt; 之前，可放统计代码</p></td>
        </tr>
        <tr>
          <td align="center"><p>页脚 JS</p></td>
          <td><?php ZbpForm::textarea('custom_js_footer', $cfg->custom_js_footer, '380px', '120px', '页脚脚本代码'); ?></td>
          <td><p class="jz-desc">输出在 &lt;/body&gt; 之前</p></td>
        </tr>
      </table>
      <div class="jzsubmit">
        <input type="submit" class="button" value="提交" />
      </div>
    </form>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_Fuwari");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
