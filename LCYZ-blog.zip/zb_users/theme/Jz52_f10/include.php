<?php
# 注册主题插件
RegisterPlugin("Jz52_f10", "ActivePlugin_Jz52_f10");

function ActivePlugin_Jz52_f10()
{
    global $zbp;
    Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Jz52_f10_AddMenu');
    if ($zbp->Config('Jz52_f10')->seo && $zbp->Config('Jz52_f10')->nseo) {
        Add_Filter_Plugin('Filter_Plugin_Edit_Response5', 'Jz52_f10_Filter_Plugin_Edit_Response5');
        Add_Filter_Plugin('Filter_Plugin_Category_Edit_Response', 'Jz52_f10_Category_Edit_Response');
    }
}

function Jz52_f10_AddMenu(&$m)
{
    global $zbp;
    $m[] = MakeTopMenu("root", '主题配置', $zbp->host . "zb_users/theme/Jz52_f10/main.php?act=config", "", "topmenu_Jz52_f10", "icon-zblog");
}

function Jz52_f10_SubMenu($id)
{
    $arySubMenu = array(
        0 => array('基本设置', 'config', 'left', false),
        1 => array('SEO设置', 'seo', 'left', false),
        2 => array('关于主题', 'about', 'left', false),
    );
    foreach ($arySubMenu as $k => $v) {
        echo '<a href="?act=' . $v[1] . '" ' . ($v[3] == true ? 'target="_blank"' : '') . '><span class="m-' . $v[2] . ' ' . ($id == $v[1] ? 'm-now' : '') . '">' . $v[0] . '</span></a>';
    }
}

function Jz52_f10_Category_Edit_Response()
{
    global $zbp, $cate;
    echo '<p><span class="title">标题:（主题自带SEO）</span><br /><input style="width:95%" name="meta_flbt" value="' . htmlspecialchars($cate->Metas->flbt) . '"/></p>'
        . '<p><span class="title">关键词:（主题自带SEO）</span><br /><input style="width:95%" name="meta_flgjc" value="' . htmlspecialchars($cate->Metas->flgjc) . '"/></p>';
}

function Jz52_f10_Filter_Plugin_Edit_Response5()
{
    global $zbp, $article;
    echo '<table width="99%"><tr><td width="20%">关键词(主题自带SEO)</td><td width="80%"><input style="width:95%" name="meta_nrgjc" value="' . htmlspecialchars($article->Metas->nrgjc) . '"/></td></tr>'
        . '<tr><td>描述(主题自带SEO)</td><td><input style="width:95%" name="meta_nrms" value="' . htmlspecialchars($article->Metas->nrms) . '"/></td></tr></table>';
}

function Jz52_f10_Footer()
{
    global $zbp;
    echo '<p class="footer-copy">' . $zbp->option['ZC_BLOG_COPYRIGHT'];
    if ($zbp->Config('Jz52_f10')->beian) {
        echo ' · <a href="https://beian.miit.gov.cn/" rel="nofollow" target="_blank">' . $zbp->Config('Jz52_f10')->beian . '</a>';
    }
    echo '</p>';
    if ($zbp->Config('Jz52_f10')->footer) {
        echo '<p class="footer-extra">' . $zbp->Config('Jz52_f10')->footer . '</p>';
    }
    echo '<p class="footer-powered" id="footer">Powered by <a href="https://www.zblogcn.com/" target="_blank">Z-BlogPHP</a> · Theme <a href="https://app.zbp.cool/" title="隔壁老李" target="_blank">GebiLaoli</a>';
}

function InstallPlugin_Jz52_f10()
{
    global $zbp;
	if(!$zbp->HasConfig('Jz52_f10')){
        $zbp->Config('Jz52_f10')->Version = '2.0.0';
        $zbp->Config('Jz52_f10')->beian = '';
        $zbp->Config('Jz52_f10')->footer = '';
        $zbp->Config('Jz52_f10')->listimg = '1';
        $zbp->Config('Jz52_f10')->zhaiyao = '1';
        $zbp->Config('Jz52_f10')->darkmode = '0';
        $zbp->Config('Jz52_f10')->author_show = '1';
        $zbp->Config('Jz52_f10')->author_name = '';
        $zbp->Config('Jz52_f10')->author_avatar = '';
        $zbp->Config('Jz52_f10')->author_intro = '';
        $zbp->Config('Jz52_f10')->seo = '0';
        $zbp->Config('Jz52_f10')->nseo = '0';
        $zbp->Config('Jz52_f10')->seotitle = '';
        $zbp->Config('Jz52_f10')->seokeywords = '';
        $zbp->Config('Jz52_f10')->seodescription = '';
        $zbp->SaveConfig('Jz52_f10');
    }
}

function UninstallPlugin_Jz52_f10()
{
    global $zbp;
	if($zbp->Config('Jz52_f10')->DelConfig){
    $zbp->DelConfig('Jz52_f10');
	}
}
