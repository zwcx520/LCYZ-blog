<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';

$zbp->Load();
$action = 'root';
if (!$zbp->CheckRights($action)) {
    $zbp->ShowError(6);
    die();
}
if (!$zbp->CheckPlugin('Jz52_f10')) {
    $zbp->ShowError(48);
    die();
}

$blogtitle = '主题配置';
$act = 'config';
if (isset($_GET['act']) && $_GET['act'] != '') {
    $act = $_GET['act'];
}
if (!in_array($act, array('config', 'seo', 'about'))) {
    $act = 'config';
}

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<style>
.jz-cfg .jz-tip { background: #f0f4ff; border: 1px solid #d6e0ff; color: #3a5fc8; padding: 10px 14px; margin: 14px 0; line-height: 1.8; }
.jz-cfg .jz-tip a { color: #2f54b8; text-decoration: underline; }
.jz-cfg table td { padding: 10px 8px; vertical-align: top; }
.jz-cfg table th { background: #f7f8fa; padding: 10px 8px; }
.jz-cfg .jz-desc { color: #888; font-size: 12px; line-height: 1.7; }
.jz-cfg input[type="text"], .jz-cfg textarea, .jz-cfg select { width: 95%; max-width: 560px; }
.jz-cfg input[type="radio"] { margin-right: 4px; }
</style>
<div id="divMain">
    <div class="divHeader"><?php echo $blogtitle; ?></div>
    <div class="SubMenu"><?php Jz52_f10_SubMenu($act); ?><a href="<?php echo $bloghost;?>zb_users/plugin/AppCentre/main.php?auth=1ba3bdce-cfd4-44d9-bbda-c1316b47adbc"><span class="m-right">更多应用</span></a>
  <a href="https://gebilaoli.com" target="_blank"><span class="m-right">作者网站</span></a></div>
    <div id="divMain2">
        <div class="jz-cfg">
            <?php if ($act == 'config') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_f10');
                $cfg->beian = trim((string) $_POST['beian']);
                $cfg->footer = trim((string) $_POST['footer']);
                $cfg->listimg = isset($_POST['listimg']) && $_POST['listimg'] == '1' ? '1' : '0';
                $cfg->zhaiyao = isset($_POST['zhaiyao']) && $_POST['zhaiyao'] == '1' ? '1' : '0';
                $cfg->DelConfig = isset($_POST['DelConfig']) && $_POST['DelConfig'] == '1' ? '1' : '0';
                $cfg->darkmode = (string) intval($_POST['darkmode']);
                $cfg->author_show = isset($_POST['author_show']) && $_POST['author_show'] == '1' ? '1' : '0';
                $cfg->author_name = trim((string) $_POST['author_name']);
                $cfg->author_avatar = trim((string) $_POST['author_avatar']);
                $cfg->author_intro = trim((string) $_POST['author_intro']);
                $zbp->SaveConfig('Jz52_f10');
                $zbp->SetHint('good');
                Redirect('./main.php?act=config');
            }
            $cfg = $zbp->Config('Jz52_f10');
            ?>
            <div class="jz-tip">当前主题版本 v<?php echo htmlspecialchars($zbp->themeinfo['version']); ?>。本主题系 <a href="https://gebilaoli.com" target="_blank">隔壁老李</a> 为个人博客量身设计：简洁排版、深浅色切换、阅读进度、响应式布局。</div>
            <form id="form1" name="form1" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr>
                        <td align="center"><p>列表显示缩略图</p></td>
                        <td><p><?php ZbpForm::radio('listimg', array('否', '是'), (int) $cfg->listimg); ?></p></td>
                        <td><p class="jz-desc">启用后文章列表显示文章第一张图，无图则不显示</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>文章页显示摘要</p></td>
                        <td><p><?php ZbpForm::radio('zhaiyao', array('否', '是'), (int) $cfg->zhaiyao); ?></p></td>
                        <td><p class="jz-desc">文章正文前显示摘要引言框</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>默认配色</p></td>
                        <td><p><?php ZbpForm::select('darkmode', array('0' => '跟随系统', '1' => '浅色', '2' => '深色'), $cfg->darkmode); ?></p></td>
                        <td><p class="jz-desc">站点默认深浅色，访客可在页头按钮自行切换（浏览器记住选择）</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>显示作者卡片</p></td>
                        <td><p><?php ZbpForm::radio('author_show', array('否', '是'), (int) $cfg->author_show); ?></p></td>
                        <td><p class="jz-desc">文章底部显示作者介绍卡片</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>作者昵称</p></td>
                        <td><p><?php ZbpForm::text('author_name', htmlspecialchars($cfg->author_name), '95%', '留空则使用文章作者名'); ?></p></td>
                        <td><p class="jz-desc">留空则使用文章作者名</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>作者头像</p></td>
                        <td><p><?php ZbpForm::text('author_avatar', htmlspecialchars($cfg->author_avatar), '95%', 'https://…'); ?></p></td>
                        <td><p class="jz-desc">图片 URL，留空则使用默认头像</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>作者简介</p></td>
                        <td><p><?php ZbpForm::textarea('author_intro', htmlspecialchars($cfg->author_intro), '95%', '80px', '一句话介绍，显示在作者卡片中'); ?></p></td>
                        <td><p class="jz-desc">一句话介绍，显示在作者卡片中</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>备案号</p></td>
                        <td><p><?php ZbpForm::text('beian', htmlspecialchars($cfg->beian), '95%', '鲁ICP备00000000号'); ?></p></td>
                        <td><p class="jz-desc">填写后页脚显示备案链接，如：鲁ICP备00000000号</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>页脚自定义内容</p></td>
                        <td><p><?php ZbpForm::textarea('footer', htmlspecialchars($cfg->footer), '95%', '80px', '纯文本或简单 HTML，显示在页脚中部'); ?></p></td>
                        <td><p class="jz-desc">纯文本或简单 HTML，显示在页脚中部</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>清除主题配置</p></td>
                        <td><p><?php ZbpForm::radio('DelConfig', array('否', '是'), (int) $cfg->DelConfig); ?></p></td>
                        <td><p class="jz-desc">启用后切换主题将清空主题配置</p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'seo') { ?>
            <?php
            if (isset($_POST['submit']) && isset($_POST['csrfToken']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])) {
                $cfg = $zbp->Config('Jz52_f10');
                $cfg->seo = isset($_POST['seo']) && $_POST['seo'] == '1' ? '1' : '0';
                $cfg->nseo = isset($_POST['nseo']) && $_POST['nseo'] == '1' ? '1' : '0';
                $cfg->seotitle = trim((string) $_POST['seotitle']);
                $cfg->seokeywords = trim((string) $_POST['seokeywords']);
                $cfg->seodescription = trim((string) $_POST['seodescription']);
                $zbp->SaveConfig('Jz52_f10');
                $zbp->SetHint('good');
                Redirect('./main.php?act=seo');
            }
            $cfg = $zbp->Config('Jz52_f10');
            ?>
            <div class="jz-tip">主题自带基础 SEO：可为首页设置标题/关键词/描述，为文章和分类设置独立关键词与描述。若已安装独立 SEO 插件，请关闭以下开关避免冲突。</div>
            <form id="form2" name="form2" method="post" action="">
                <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken(); ?>">
                <table width="100%" cellspacing="0" cellpadding="0" class="tableBorder">
                    <tr><th width="22%"><p align="center">选项名称</p></th><th width="50%"><p align="center">选项内容</p></th><th width="28%"><p align="center">选项说明</p></th></tr>
                    <tr>
                        <td align="center"><p>启用主题 SEO</p></td>
                        <td><p><?php ZbpForm::radio('seo', array('否', '是'), (int) $cfg->seo); ?></p></td>
                        <td><p class="jz-desc">使用主题自带的标题、关键词、描述输出</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>文章/分类自定义 SEO</p></td>
                        <td><p><?php ZbpForm::radio('nseo', array('否', '是'), (int) $cfg->nseo); ?></p></td>
                        <td><p class="jz-desc">在文章编辑页与分类编辑页增加关键词、描述字段</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>首页标题</p></td>
                        <td><p><?php ZbpForm::text('seotitle', htmlspecialchars($cfg->seotitle), '95%', '留空则使用网站名称'); ?><?php if ($zbp->subname) { ?> <span class="jz-desc">- <?php echo htmlspecialchars($zbp->subname); ?></span><?php } ?></p></td>
                        <td><p class="jz-desc">留空则使用网站名称</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>首页关键词</p></td>
                        <td><p><?php ZbpForm::text('seokeywords', htmlspecialchars($cfg->seokeywords), '95%', '多个关键词用英文逗号隔开'); ?></p></td>
                        <td><p class="jz-desc">多个关键词用英文逗号隔开</p></td>
                    </tr>
                    <tr>
                        <td align="center"><p>首页描述</p></td>
                        <td><p><?php ZbpForm::textarea('seodescription', htmlspecialchars($cfg->seodescription), '95%', '80px', '一段话描述网站内容'); ?></p></td>
                        <td><p class="jz-desc">一段话描述网站内容</p></td>
                    </tr>
                </table>
                <br />
                <input name="submit" type="submit" class="button jz-btn" value="保存设置"/>
            </form>
            <?php } ?>

            <?php if ($act == 'about') { ?>
            <div class="jz-tip">
                <h3>「极致·简」个人博客主题</h3>
                <p>一款轻量个人博客主题，风格简约而不简单：</p>
                <p>· 排版优先，专注阅读体验<br />
                · 深浅色双主题，支持跟随系统<br />
                · 阅读进度条、返回顶部、侧栏吸顶<br />
                · 全响应式，移动端抽屉导航<br />
                · 内置基础 SEO 与结构化数据</p>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_f10");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
