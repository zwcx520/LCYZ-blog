{* Template Name:文章模板 *}
<main class="container layout">
  <div class="main-col">
    <article class="post-card">
      <nav class="breadcrumb" aria-label="面包屑">
        <a href="{$host}">首页</a><span class="sep">/</span>
        <a href="{$article.Category.Url}">{$article.Category.Name}</a><span class="sep">/</span>
        <span>正文</span>
      </nav>
      <header class="post-header">
        <h1 class="post-title-lg">{$article.Title}</h1>
        <div class="post-meta-row">
          <span class="meta-author">
            <img class="meta-avatar" src="{$article.Author.Avatar}" alt="{$article.Author.StaticName}" loading="lazy">
            {$article.Author.StaticName}
          </span>
          <span class="meta-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline></svg>
            {$article.Time('Y-m-d H:i')}
          </span>
          <span class="meta-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
            {$article.ViewNums} 阅读
          </span>
          <span class="meta-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-3.8-.9L3 21l1.9-5.7a8.5 8.5 0 1 1 16.1-3.8z"></path></svg>
            {$article.CommNums} 评论
          </span>
        </div>
      </header>
      {if $zbp->Config('Jz52_f10')->zhaiyao}
      {php}$abstract = trim(SubStrUTF8(TransferHTML($article->Intro, '[nohtml]'), 150));{/php}
      {if $abstract}
      <div class="post-abstract"><strong>摘要</strong>{$abstract}</div>
      {/if}
      {/if}
      <div class="post-content">
        {$article.Content}
      </div>
      {if count($article.Tags)}
      <div class="post-tags">
        {foreach $article.Tags as $tag}
        <a class="tag-chip" href="{$tag.Url}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>
          {$tag.Name}
        </a>
        {/foreach}
      </div>
      {/if}
    </article>

    <nav class="post-nav" aria-label="上下篇">
      {if $article.Prev}
      <a class="post-nav-item" href="{$article.Prev.Url}">
        <span class="post-nav-label">上一篇</span>
        <span class="post-nav-title">{$article.Prev.Title}</span>
      </a>
      {else}
      <span class="post-nav-item is-disabled"><span class="post-nav-label">上一篇</span><span class="post-nav-title">没有了</span></span>
      {/if}
      {if $article.Next}
      <a class="post-nav-item is-next" href="{$article.Next.Url}">
        <span class="post-nav-label">下一篇</span>
        <span class="post-nav-title">{$article.Next.Title}</span>
      </a>
      {else}
      <span class="post-nav-item is-next is-disabled"><span class="post-nav-label">下一篇</span><span class="post-nav-title">没有了</span></span>
      {/if}
    </nav>

    <div class="related-card">
      <h3 class="card-title">相关文章</h3>
  {if count($article.RelatedList) > 0}
{$relatedList=GetList($zbp->Config('Jz52_corpseven')->xgnewsnum,null,null,null,null,null,array('is_related'=>$article->ID));}
  {else}
{$relatedList=GetList(array('count'=>$zbp->Config('Jz52_corpseven')->xgnewsnum,'cate'=>$article->Category->ID,'where_custom' => array(array('<>', 'log_ID', $article->ID))));}
  {/if}
      <ul class="related-list">
        {foreach $relatedList as $related}
        <li><a href="{$related.Url}" title="{$related.Title}">{$related.Title}</a><time datetime="{$related.Time('Y-m-d')}">{$related.Time('Y-m-d')}</time></li>
        {/foreach}
      </ul>
    </div>

    {if $zbp->Config('Jz52_f10')->author_show}
    <aside class="author-card">
      {php}
      $jzAuthorName = $zbp->Config('Jz52_f10')->author_name ? $zbp->Config('Jz52_f10')->author_name : $article->Author->StaticName;
      $jzAuthorAvatar = $zbp->Config('Jz52_f10')->author_avatar ? $zbp->Config('Jz52_f10')->author_avatar : $article->Author->Avatar;
      $jzAuthorIntro = $zbp->Config('Jz52_f10')->author_intro;
      {/php}
      <img class="author-avatar" src="{$jzAuthorAvatar}" alt="{$jzAuthorName}" loading="lazy">
      <div class="author-body">
        <div class="author-name">{$jzAuthorName}</div>
        {if $jzAuthorIntro}<p class="author-intro">{$jzAuthorIntro}</p>{/if}
      </div>
    </aside>
    {/if}

    {if !$article.IsLock}
    <div class="comment-card" id="comments">
      {template:comments}
    </div>
    {/if}
  </div>
  <aside class="side-col">
    {template:sidebar3}
  </aside>
</main>
