{* Template Name:404模板 *}
{template:header}
<main class="container page-404-wrap">
  <div class="page-404">
    <div class="nf-code">404</div>
    <p class="nf-text">抱歉，你访问的页面不存在或已被移除。</p>
    <div class="nf-actions">
      <a class="btn btn-primary" href="{$host}">返回首页</a>
      <button type="button" class="btn btn-ghost" id="nfBack">返回上页</button>
    </div>
  </div>
</main>
{template:footer}
