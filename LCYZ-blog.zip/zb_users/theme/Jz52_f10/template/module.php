{* Template Name:单个模块 *}
<div class="widget" id="{$module.HtmlID}">
  {if (!$module.IsHideTitle)&&($module.Name)}
  <h3 class="widget-title">{$module.Name}</h3>
  {/if}
  {if $module.Type=='div'}
  <div class="widget-body">{$module.Content}</div>
  {/if}
  {if $module.Type=='ul'}
  <ul class="widget-body widget-list">{$module.Content}</ul>
  {/if}
</div>
