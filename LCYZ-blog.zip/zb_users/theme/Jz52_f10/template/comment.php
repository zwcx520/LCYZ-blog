{* Template Name:单条评论模板 *}
<li class="comment-item" id="cmt{$comment.ID}">
  <div class="comment-avatar">
    <img src="{$comment.Author.Avatar}" alt="{$comment.Author.StaticName}" loading="lazy">
  </div>
  <div class="comment-main">
    <div class="comment-head">
      <span class="comment-name">
        {if $comment.Author.HomePage}<a href="{$comment.Author.HomePage}" rel="nofollow" target="_blank">{$comment.Author.StaticName}</a>{else}{$comment.Author.StaticName}{/if}
      </span>
      <span class="comment-time">{$comment.Time()}</span>
      <a class="comment-reply" href="#cancel-reply" onclick="zbp.comment.reply('{$comment.ID}')">回复</a>
    </div>
    <div class="comment-text">{$comment.Content}</div>
    {if count($comment.Comments)}
    <ul class="comment-children">
      {foreach $comment.Comments as $comment}
      {template:comment}
      {/foreach}
    </ul>
    {/if}
  </div>
</li>
<label id="AjaxComment{$comment.ID}"></label>
