{* Template Name:列表模板（首页/分类/标签/作者/日期/搜索） *}
{template:header}
<main class="container layout">
  <div class="main-col">
    <div class="page-head">
      {if $type=='category'}
      <nav class="breadcrumb" aria-label="面包屑"><a href="{$host}">首页</a><span class="sep">/</span><span>{$category.Name}</span>{if $page>'1'}<span class="sep">/</span><span>第{$page}页</span>{/if}</nav>
      <h1 class="page-title">{$category.Name}</h1>
      {if $category.Intro}<p class="page-desc">{$category.Intro}</p>{/if}
      {elseif $type=='tag'}
      <nav class="breadcrumb" aria-label="面包屑"><a href="{$host}">首页</a><span class="sep">/</span><span>标签</span>{if $page>'1'}<span class="sep">/</span><span>第{$page}页</span>{/if}</nav>
      <h1 class="page-title">{$tag.Name}</h1>
      {if $tag.Intro}<p class="page-desc">{$tag.Intro}</p>{/if}
      {elseif $type=='author'}
      <nav class="breadcrumb" aria-label="面包屑"><a href="{$host}">首页</a><span class="sep">/</span><span>作者</span></nav>
      <h1 class="page-title">{$author.StaticName}</h1>
      {elseif $type=='date'}
      <nav class="breadcrumb" aria-label="面包屑"><a href="{$host}">首页</a><span class="sep">/</span><span>归档</span></nav>
      <h1 class="page-title">{$title}</h1>
      {elseif $type=='search'}
      <nav class="breadcrumb" aria-label="面包屑"><a href="{$host}">首页</a><span class="sep">/</span><span>搜索</span></nav>
      <h1 class="page-title">搜索：{$search}</h1>
      <p class="page-desc">共找到与“{$search}”相关的内容</p>
      {elseif $page>'1'}
      <nav class="breadcrumb" aria-label="面包屑"><a href="{$host}">首页</a><span class="sep">/</span><span>第{$page}页</span></nav>
      <h1 class="page-title">第{$page}页</h1>
      {/if}
    </div>
    <div class="post-list">
      {foreach $articles as $article}
      {if $article.TopType}
      {template:post-istop}
      {else}
      {template:post-multi}
      {/if}
      {/foreach}
    </div>
    {if !$articles}
    <div class="post-empty">
      <p>这里还没有内容。</p>
    </div>
    {/if}
    {template:pagebar}
  </div>
  <aside class="side-col">
    {template:sidebar2}
  </aside>
</main>
{template:footer}
