{* Template Name:分页模板 *}
{if $pagebar}
<nav class="pagination" aria-label="分页">
  {foreach $pagebar.buttons as $k=>$v}
  {if $pagebar.PageNow==$k}
  <span class="page page-current" aria-current="page">{$k}</span>
  {elseif $k=='‹‹' and $pagebar.PageNow!=$pagebar.PageFirst}
  <a class="page" href="{$v}">首页</a>
  {elseif $k=='‹‹' and $pagebar.PageNow==$pagebar.PageFirst}
  <span class="page page-disabled">首页</span>
  {elseif $k=='››' and $pagebar.PageNow==$pagebar.PageLast}
  <span class="page page-disabled">尾页</span>
  {elseif $k=='››' and $pagebar.PageNow!=$pagebar.PageLast}
  <a class="page" href="{$v}">尾页</a>
  {elseif $k=='‹'}
  <a class="page page-prev" href="{$v}">‹ 上一页</a>
  {elseif $k=='›'}
  <a class="page page-next" href="{$v}">下一页 ›</a>
  {else}
  <a class="page" href="{$v}">{$k}</a>
  {/if}
  {/foreach}
</nav>
{/if}
