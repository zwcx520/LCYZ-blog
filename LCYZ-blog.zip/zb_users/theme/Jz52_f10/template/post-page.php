{* Template Name:单页模板 *}
<main class="container layout layout-single">
  <div class="main-col">
    <article class="post-card">
      <nav class="breadcrumb" aria-label="面包屑">
        <a href="{$host}">首页</a><span class="sep">/</span><span>{$article.Title}</span>
      </nav>
      <header class="post-header">
        <h1 class="post-title-lg">{$article.Title}</h1>
        <div class="post-meta-row">
          <span class="meta-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline></svg>
            {$article.Time('Y-m-d')}
          </span>
          <span class="meta-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
            {$article.ViewNums} 阅读
          </span>
        </div>
      </header>
      <div class="post-content">
        {$article.Content}
      </div>
    </article>
    {if !$article.IsLock}
    <div class="comment-card" id="comments">
      {template:comments}
    </div>
    {/if}
  </div>
</main>
