{* Template Name:列表文章项 *}
<article class="post-item">
  {if $zbp->Config('Jz52_f10')->listimg && $article.ImageCount}
  <a class="post-thumb" href="{$article.Url}" tabindex="-1" aria-hidden="true">
    <img src="{$article.Thumbs(280,175,1)[0]}" alt="{$article.Title}" loading="lazy">
  </a>
  {/if}
  <div class="post-body">
    <div class="post-meta">
      <span class="post-meta-item post-cat">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
        <a href="{$article.Category.Url}">{$article.Category.Name}</a>
      </span>
      <span class="post-meta-item">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline></svg>
        <time datetime="{$article.Time('Y-m-d')}">{$article.Time('Y-m-d')}</time>
      </span>
    </div>
    <h2 class="post-title"><a href="{$article.Url}">{$article.Title}</a></h2>
    {php}$excerpt = trim(SubStrUTF8(TransferHTML($article->Intro, '[nohtml]'), 120));{/php}
    {if $excerpt}<p class="post-excerpt">{$excerpt}</p>{/if}
    <div class="post-foot">
      <span class="post-meta-item">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
        {$article.ViewNums}
      </span>
      <span class="post-meta-item">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.38 8.38 0 0 1-8.5 8.5 8.5 8.5 0 0 1-3.8-.9L3 21l1.9-5.7a8.5 8.5 0 1 1 16.1-3.8z"></path></svg>
        {$article.CommNums}
      </span>
      <a class="post-more" href="{$article.Url}">阅读全文</a>
    </div>
  </div>
</article>
