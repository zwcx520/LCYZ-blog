{* Template Name:公用页脚模块 *}
<footer class="site-footer">
  <div class="container">
    {Jz52_f10_Footer()}
  </div>
</footer>
<a href="#" class="back-to-top" id="backToTop" aria-label="返回顶部">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
</a>
<div class="nav-mask" id="navMask"></div>
<script>
var jzdef = '{$zbp->Config('Jz52_f10')->darkmode}';
</script>
<script src="{$host}zb_users/theme/{$theme}/script/custom.js"></script>
{$footer}
</body>
</html>
