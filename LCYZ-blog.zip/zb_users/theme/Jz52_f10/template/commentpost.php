{* Template Name:评论提交模块 *}
<div class="comment-form-wrap" id="divCommentPost">
  <form id="frmSumbit" target="_self" method="post" action="{$article.CommentPostUrl}" class="comment-form">
    <input type="hidden" name="inpId" id="inpId" value="{$article.ID}">
    <input type="hidden" name="inpRevID" id="inpRevID" value="0">
    {if $user.ID>0}
    <input type="hidden" name="inpName" id="inpName" value="{$user.Name}">
    <input type="hidden" name="inpEmail" id="inpEmail" value="{$user.Email}">
    <input type="hidden" name="inpHomePage" id="inpHomePage" value="{$user.HomePage}">
    {else}
    {if $option['ZC_COMMENT_VERIFY_ENABLE']}
    <div class="comment-fields">
      <div class="comment-field">
        <label for="inpName">昵称<i>*</i></label>
        <input type="text" name="inpName" id="inpName" class="text" value="访客" size="28" tabindex="1" maxlength="20">
      </div>
      <div class="comment-field">
        <label for="inpEmail">邮箱</label>
        <input type="text" name="inpEmail" id="inpEmail" class="text" value="" size="28" tabindex="2" maxlength="50">
      </div>
      <div class="comment-field">
        <label for="inpHomePage">网站</label>
        <input type="text" name="inpHomePage" id="inpHomePage" class="text" value="" size="28" tabindex="3" maxlength="100">
      </div>
      <div class="comment-field">
        <label for="inpVerify">验证码<i>*</i></label>
        <input type="text" name="inpVerify" id="inpVerify" class="text" value="" size="28" tabindex="4" maxlength="6">
        <img class="comment-captcha" src="{$article.ValidCodeUrl}" alt="验证码" title="点击刷新" onclick="this.src='{$article.ValidCodeUrl}&amp;tm='+Math.random();">
      </div>
    </div>
    {else}
    <div class="comment-fields">
      <div class="comment-field">
        <label for="inpName">昵称<i>*</i></label>
        <input type="text" name="inpName" id="inpName" class="text" value="访客" size="28" tabindex="1" maxlength="20">
      </div>
      <div class="comment-field">
        <label for="inpEmail">邮箱</label>
        <input type="text" name="inpEmail" id="inpEmail" class="text" value="" size="28" tabindex="2" maxlength="50">
      </div>
      <div class="comment-field">
        <label for="inpHomePage">网站</label>
        <input type="text" name="inpHomePage" id="inpHomePage" class="text" value="" size="28" tabindex="3" maxlength="100">
      </div>
    </div>
    {/if}
    {/if}
    <div class="comment-field comment-field-textarea">
      <label for="txaArticle">评论内容<i>*</i></label>
      <textarea name="txaArticle" id="txaArticle" class="text" cols="50" rows="4" tabindex="5" placeholder="友善交流，理性表达…"></textarea>
    </div>
    <div class="comment-submit">
      <button type="submit" name="sumbit" tabindex="6" value="提交" onclick="return zbp.comment.post()" class="btn btn-primary">发表评论</button>
    </div>
  </form>
</div>
