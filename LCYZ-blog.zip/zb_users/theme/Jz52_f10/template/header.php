{* Template Name:公用头部模块 *}
<!DOCTYPE html>
<html lang="{$language}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
{if $zbp->Config('Jz52_f10')->seo}{template:seo}{else}<title>{$name}-{$title}</title>{/if}
<meta name="generator" content="{$zblogphp}">
<link rel="stylesheet" href="{$host}zb_users/theme/{$theme}/style/style.css">
<script src="{$host}zb_system/script/jquery-latest.min.js"></script>
<script src="{$host}zb_system/script/zblogphp.js"></script>
<script src="{$host}zb_system/script/c_html_js_add.php"></script>
{$header}
{if $type=='index' && isset($page) && $page=='1'}
<link rel="alternate" type="application/rss+xml" href="{$feedurl}" title="{$name}">
{/if}
</head>
<body>
<div class="reading-progress" id="readingProgress" aria-hidden="true"></div>
<header class="site-header" id="siteHeader">
  <div class="container header-inner">
    <div class="logo"><a href="{$host}" title="{$name}">{if $type=='index'&&$page=='1'}<h1>{$name}</h1>{else}{$name}{/if}</a></div>
    <nav class="main-nav" id="mainNav" aria-label="主导航">
      <button type="button" class="drawer-close" id="drawerClose" aria-label="关闭菜单">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><line x1="6" y1="6" x2="18" y2="18"></line><line x1="18" y1="6" x2="6" y2="18"></line></svg>
      </button>
      <ul class="nav-list" id="navList">
        {module:navbar}
      </ul>
    </nav>
    <div class="header-actions">
      <button type="button" class="header-btn search-toggle" id="searchToggle" aria-label="搜索" aria-expanded="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></svg>
      </button>
      <button type="button" class="header-btn theme-toggle" id="themeToggle" aria-label="切换深浅色">
        <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"></path></svg>
        <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>
      </button>
      <button type="button" class="header-btn menu-toggle" id="menuToggle" aria-label="打开菜单" aria-expanded="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
      </button>
    </div>
  </div>
  <div class="search-panel" id="searchPanel">
    <div class="container">
      <form action="{$host}search.php" method="get" role="search" class="search-form">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></svg>
        <input type="search" name="q" placeholder="搜索文章…" autocomplete="off" maxlength="256">
        <button type="submit">搜索</button>
      </form>
    </div>
  </div>
</header>
