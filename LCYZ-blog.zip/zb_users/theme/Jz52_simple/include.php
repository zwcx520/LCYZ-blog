<?php
#注册插件
RegisterPlugin("Jz52_simple","ActivePlugin_Jz52_simple");

function ActivePlugin_Jz52_simple() {
	global $zbp;
	Add_Filter_Plugin('Filter_Plugin_Admin_TopMenu', 'Jz52_simple_AddMenu');
	Add_Filter_Plugin('Filter_Plugin_ViewList_Template', 'Jz52_simple_Footerc');
	Add_Filter_Plugin('Filter_Plugin_ViewPost_Template', 'Jz52_simple_Footerc');
}
function Jz52_simple_AddMenu(&$m) {
	global $zbp;
	$m[] = MakeTopMenu("root", '主题配置', $zbp->host . "zb_users/theme/Jz52_simple/main.php?act=config", "", "topmenu_Jz52_simple");
}
function Jz52_simple_SubMenu($id){
	$arySubMenu = array(
		0 => array('基本设置', 'config', 'left', false),
		1 => array('SEO设置', 'other', 'left', false),
	);
	foreach($arySubMenu as $k => $v){
		echo '<a href="?act='.$v[1].'" '.($v[3]==true?'target="_blank"':'').'><span class="m-'.$v[2].' '.($id==$v[1]?'m-now':'').'">'.$v[0].'</span></a>';
	}
}
function Jz52_simple_Footer(){
	global $zbp;
	echo '<ul class="menu">'.$zbp->Config('Jz52_simple')->navz.'</ul>';
	echo '<div style="display: flex;justify-content: space-between;"><div class="left">';
	echo '<span>'.$zbp->option['ZC_BLOG_COPYRIGHT'].'</span>';
	if($zbp->Config('Jz52_simple')->beian){
	echo '<span> <a href="https://beian.miit.gov.cn" target="_blank">'.$zbp->Config('Jz52_simple')->beian.'</a></span>';
	}
	echo '</div>';
	echo $zbp->Config('Jz52_simple')->footer;
}
function Jz52_simple_Footerc(){
	global $zbp;
	if(strpos($zbp->Config('Jz52_simple')->footer,'yeelz.com') == false){ 
	$zbp->footer .='<script type="text/javascript">alert("\u4fdd\u7559\u7248\u6743\u662f\u4e00\u79cd\u7f8e\u5fb7");</script>'; }	
}
function InstallPlugin_Jz52_simple() {
	global $zbp;
	if(!$zbp->Config('Jz52_simple')->HasKey('Version')){
		$zbp->Config('Jz52_simple')->Version = '1.1.5';
		$zbp->Config('Jz52_simple')->navz = '<li><a href="#">关于博主</a></li>
<li><a href="#">友情链接</a></li>
<li><a href="#">标签列表</a></li>
<li><a href="#">网站地图</a></li>';
		$zbp->Config('Jz52_simple')->beian = '';
		$zbp->Config('Jz52_simple')->DelCon = '1';
		$zbp->Config('Jz52_simple')->seo = '0';	
        $zbp->Config('Jz52_simple')->seotitle = '网站标题';
        $zbp->Config('Jz52_simple')->seokeywords = '网站关键字,用英文的逗号隔开';
        $zbp->Config('Jz52_simple')->seodescription = '用一段话描述你的网站';
		$zbp->Config('Jz52_simple')->footer = '<div class="right" id="copyr"> <span>Powered: <a href="http://www.zblogcn.com/" target="_blank">Z-BlogPHP</a></span> <span>Theme: <a href="https://yeelz.com" target="_blank">YEELZ</a></span> </div> </div> <span id="go-to-top"></span><script src="'.$zbp->host.'zb_users/theme/Jz52_simple/script/custom.js"></script>';
		$zbp->SaveConfig('Jz52_simple');
	}
}
function UninstallPlugin_Jz52_simple() {
}