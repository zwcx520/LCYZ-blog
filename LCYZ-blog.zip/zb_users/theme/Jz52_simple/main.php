<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';
$zbp->Load();
$action='root';
if (!$zbp->CheckRights($action)) {$zbp->ShowError(6);die();}
if (!$zbp->CheckPlugin('Jz52_simple')) {$zbp->ShowError(48);die();}
$blogtitle='主题配置';
$act = "";
if ($_GET['act']){
$act = $_GET['act'] == "" ? 'config' : $_GET['act'];
}
require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
<style>
.lianxi { padding: 10px; }
.lianxi p { line-height: 36px; }
.lianxi a { padding: 0 10px; }
.wiki { padding: 10px; background-color: #f4f4f4; }
.wiki p { line-height: 36px; }
input { margin: 5px 0; }
strong { background-color: #3a6ea5; padding: 5px 10px; color: #ffffff; }
p { margin: 5px 0; }
td { padding: 10px; }
</style>
<div id="divMain">
	<div class="divHeader"><?php echo $blogtitle;?></div>
	<div class="SubMenu">
	<?php Jz52_simple_SubMenu($act);?>
     <a href="https://www.jz52.com" target="_blank"><span class="m-right">技术支持</span></a>
    </div>
<div id="divMain2">
<?php 
if ($act == 'config') { 
if(isset($_POST['beian']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])){	
	//基本配置
	$zbp->Config('Jz52_simple')->beian = $_POST['beian'];
	$zbp->Config('Jz52_simple')->navz = $_POST['navz'];
	$zbp->SaveConfig('Jz52_simple');
	$zbp->ShowHint('good');	
}
?>
<table name="form1" width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
	<br/>
	<tr>
    <td>	
		<p>1、极致·极简单栏博客主题一款是由 <a href="https://www.jz52.com" target="_blank">极致时空</a> 开发制作的Z-BLOG主题。</p>
		<p>2、免费主题不提供在线咨询服务，有问题可到 <a href="https://yeelz.com/post/472.html" target="_blank">主题发布页</a> 或者到应用中心留言</p>
		<p>3、欢迎加入交流群：236895886（验证：zblog）</p>
	</td>
	
	</tr>	
</table>
<form id="form1" name="form1" method="post">	
    <table width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
	<input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken();?>">
		<tr>
			<th width="15%"><p align="center">选项名称</p></th>
			<th width="50%"><p align="center">选项内容</p></th>
			<th width="25%"><p align="center">选项说明</p></th>
		</tr>
		
		<tr>
        <td width="20%"  align="center"><p>页脚自定义菜单</p></td>
        <td>
          <p><textarea name="navz" type="text" id="navz" style="width:98%;"><?php echo $zbp->Config('Jz52_simple')->navz;?></textarea></p>
		</td>
		<td><p align="left">页脚自定义导航菜单代码</p></td>
      </tr>
	  <tr>
        <td width="20%"  align="center"><p>备案号</p></td>
        <td>
          <p><input type="text" name="beian" id="beian" style="width:98%;" value="<?php echo $zbp->Config('Jz52_simple')->beian;?>"/></p>
		</td>
		<td><p align="left">备案号</p></td>
      </tr>
	</table>
	<br />
	<input name="submit" type="Submit" class="button" style="width:15%;" value="保存"/>
</form>
<?php } 
if($act == 'other'){
if(isset($_POST['seodescription']) && $zbp->VerifyCSRFToken($_POST['csrfToken'])){	
	//seo
	$zbp->Config('Jz52_simple')->seo = $_POST['seo'];
	$zbp->Config('Jz52_simple')->seotitle = $_POST['seotitle'];
	$zbp->Config('Jz52_simple')->seokeywords = $_POST['seokeywords'];
	$zbp->Config('Jz52_simple')->seodescription = $_POST['seodescription'];
	$zbp->SaveConfig('Jz52_simple');
	$zbp->ShowHint('good');	
}	
?>
<form id="form2" name="form2" method="post">	
    <table width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
	<input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCSRFToken();?>">
		<tr>
			<th width="15%"><p align="center">选项名称</p></th>
			<th width="50%"><p align="center">选项内容</p></th>
			<th width="25%"><p align="center">选项说明</p></th>
		</tr>
		<tr>
			<td><label for="seo"><p align="center">主题SEO设置</p></label></td>
			<td><p align="left"><input type="text" id="seo" name="seo" class="checkbox" value="<?php echo $zbp->Config('Jz52_simple')->seo;?>"/></p></td>
			<td><p align="left">选择是否使用主题自带SEO设置，默认开启</p></td>
		</tr>
		<tr>
			<td><label for="seotitle"><p align="center">站点标题</p></label></td>
			<td><p align="left"><input type="text" name="seotitle" id="seotitle" style="width:98%;" value="<?php echo $zbp->Config('Jz52_simple')->seotitle;?>"/></p></td>
			<td><p align="left">自定义网站首页标题</p></td>
		</tr>
		<tr>
			<td><label for="seokeywords"><p align="center">关键词</p></label></td>
			<td><p align="left"><input type="text" name="seokeywords" id="seokeywords" style="width:98%;" value="<?php echo $zbp->Config('Jz52_simple')->seokeywords;?>"/></p></td>
			<td><p align="left">自定义网站关键词，多个关键词用英文逗号隔开</p></td>
		</tr>
		<tr>
			 <td><label for="seodescription"><p align="center">网站描述</p></label></td>
			<td><p align="left"><textarea name="seodescription" type="text" id="seodescription" style="width:98%;"><?php echo $zbp->Config('Jz52_simple')->seodescription;?></textarea></p></td>
			<td><p align="left">自定义网站描述</p></td>
		</tr>
	</table>
	<br />
	<input name="submit" type="Submit" class="button" style="width:15%;" value="保存"/>
</form>
<?php } 
if($act == 'bankuai'){
if(isset($_POST['side_hot_view_day'])){
	//侧栏
	$zbp->Config('Jz52_simple')->side_icons = $_POST['side_icons'];
	$zbp->Config('Jz52_simple')->side_tui_list = $_POST['side_tui_list'];
	$zbp->Config('Jz52_simple')->side_hot_cmt_day = $_POST['side_hot_cmt_day'];
	$zbp->Config('Jz52_simple')->side_hot_view_day = $_POST['side_hot_view_day'];
	$zbp->SaveConfig('Jz52_simple');
	$zbp->ShowHint('good');	
}
?>
<form id="form3" name="form3" method="post">	
        <table width="100%" style="padding:0;margin:0;" cellspacing="0" cellpadding="0" class="tableBorder">
		<tr>
			<th width="15%"><p align="center">选项名称</p></th>
			<th width="50%"><p align="center">选项内容</p></th>
			<th width="25%"><p align="center">选项说明</p></th>
		</tr>
		<tr>
			<td><label for="side_tui_list"><p align="center">推荐主题</p></label></td>
			<td><p align="left"><input type="text" name="side_tui_list" id="side_tui_list" style="width:98%;" value="<?php echo $zbp->Config('Jz52_simple')->side_tui_list;?>"/></p></td>
			<td><p align="left">填入文章的ID，并用英文逗号分隔即可</p></td>
		</tr>
		<tr>
			<td><label for="side_hot_view_day"><p align="center">热门文章时间</p></label></td>
			<td><p align="left"><input type="text" name="side_hot_view_day" id="side_hot_view_day" style="width:98%;" value="<?php echo $zbp->Config('Jz52_simple')->side_hot_view_day;?>"/></p></td>
			<td><p align="left">按照天数计算，请输入时间天数范围的正整数</p></td>
		</tr>
		<tr>
			<td><label for="side_hot_cmt_day"><p align="center">热评文章时间</p></label></td>
			<td><p align="left"><input type="text" name="side_hot_cmt_day" id="side_hot_cmt_day" style="width:98%;" value="<?php echo $zbp->Config('Jz52_simple')->side_hot_cmt_day;?>"/></p></td>
			<td><p align="left">按照天数计算，请输入时间天数范围的正整数</p></td>
		</tr>
		<tr>
			 <td><label for="side_icons"><p align="center">社交图标</p></label></td>
			<td><p align="left"><textarea name="side_icons" type="text" id="side_icons" style="width:98%;"><?php echo $zbp->Config('Jz52_simple')->side_icons;?></textarea></p></td>
			<td><p align="left">页面顶部社交图标代码</p></td>
		</tr>
	</table>
	<br />
	<input name="submit" type="Submit" class="button" style="width:15%;" value="保存"/>
</form>
<?php
    }	
?>
</div>
</div>
<script type="text/javascript">
ActiveTopMenu("topmenu_Jz52_simple");
</script> 
<?php
if ($zbp->CheckPlugin('UEditor')) {	
	echo '<script type="text/javascript" src="'.$zbp->host.'zb_users/plugin/UEditor/ueditor.config.php"></script>';
	echo '<script type="text/javascript" src="'.$zbp->host.'zb_users/plugin/UEditor/ueditor.all.min.js"></script>';
	echo '<script type="text/javascript" src="'.$zbp->host.'zb_users/theme/Jz52_simple/function/js/lib.upload.js"></script>';
	}
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
?>